# Datos de demostración en producción (para la entrega)

Deja el sistema con datos coherentes para mostrar cada módulo funcionando:
catálogo, stock, proveedor, ventas, caja, **predicción de demanda** y
**recomendaciones de reposición**.

Todo es **reversible** con `--limpiar`.

---

## 1. Requisito único en `~/pos-backend/.env`

Para que la predicción se pueda demostrar mientras el negocio todavía no
tiene 12+ semanas de ventas reales, agrega esta línea (una sola vez):

```sh
echo 'DJANGO_PREDICCION_SINTETICO=True' >> ~/pos-backend/.env
touch ~/pos-backend/tmp/restart.txt      # recarga la app
```

Con eso, los 10 productos del catálogo demo usan la serie sintética del
paquete `ml/` y sus predicciones aparecen marcadas como **SINTÉTICO**.
Cuando haya histórico real, el sistema pasa solo a **REAL** — no hay que
tocar nada.

## 2. Cargar los datos de demo

```sh
sh ~/pos-backend/deploy/datos_demo.sh
```

Hace, en orden:

1. `cargar_demo` — usuarios `admin_demo` / `bodega_demo` / `vende_demo`
   (clave `demo12345`), 5 categorías, 5 marcas, 10 productos con stock y
   parámetros, 1 proveedor, y **entrena el modelo**.
2. `predecir_demanda --horizonte 4` — genera la tabla de predicciones.
3. `calcular_reposicion` — recomendaciones de compra según esas predicciones.

Es **idempotente**: se puede correr varias veces.

## 3. Verificar en el navegador

Entra como `admin_demo` / `demo12345`:

| Pantalla | Qué mirar |
|---|---|
| **Predicción** | "Modelo activo" con métricas · tabla con 10 predicciones (SINTÉTICO) · botón "Calcular ahora" con SKU `BEB-001` |
| **Reposición** | "Generar recomendaciones" · tabla con stock / demanda / punto de pedido / cantidad a comprar |
| **Dashboard** | KPIs, alertas, ofertas |
| **Punto de venta / Caja** | abrir caja, vender, ver el arqueo y el cierre |

## 4. Revertir (después de la demo)

```sh
sh ~/pos-backend/deploy/datos_demo.sh --limpiar
```

Borra los productos demo que no tengan ventas/compras asociadas, desactiva
los usuarios `@demo.cl` y quita el proveedor demo si quedó sin órdenes.
Lo que tenga historial (ventas de prueba) no se borra: anúlalo primero si
lo quieres eliminar.

Si además quieres dejar la predicción sin datos sintéticos, quita la línea
`DJANGO_PREDICCION_SINTETICO=True` de `~/pos-backend/.env` y
`touch ~/pos-backend/tmp/restart.txt`.
