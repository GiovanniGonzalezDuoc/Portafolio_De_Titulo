# Etapa 2 — Modelo entidad-relación (POS Picking)

**Base:** `docs/00-analisis-requisitos.md`, `docs/01-arquitectura.md`, `docs/DECISIONES.md`.
**Fecha:** 2026-09-07
**Compatibilidad:** MariaDB 10.6+ (InnoDB, `utf8mb4`) · Django ORM 5.x · migraciones Django.

---

## 0. Convenciones

- **PK**: toda tabla tiene `id` `BIGINT AUTO_INCREMENT` (implícito de Django, `BigAutoField`). No se repite en cada ficha.
- **Timestamps**: las entidades que lo indican heredan de `TimeStampedModel` → `creado_en DATETIME` (default: ahora, `auto_now_add`) y `actualizado_en DATETIME` (`auto_now`).
- **Montos**: enteros CLP → `INTEGER` (o `BIGINT` en acumulados). Sin decimales (peso chileno).
- **Cantidades de inventario**: `DECIMAL(12,3)` para admitir fracciones (kg, litros); productos "por unidad" usan enteros lógicos.
- **Textos**: `VARCHAR(n)` con `n` explícito; descripciones largas `TEXT`.
- **Fechas/hora**: `DATETIME` en zona `America/Santiago` (`USE_TZ=True`, se guarda en UTC).
- **Borrado**: entidades maestras usan **inactivación** (`activo BOOLEAN`), no borrado físico, para preservar historial. Entidades transaccionales no se borran (se anulan).
- **FK on_delete**: `PROTECT` para referencias históricas (no perder trazabilidad); `CASCADE` solo para líneas hijas de su cabecera; `SET NULL` para responsables opcionales.
- **CHECK**: MariaDB 10.2+ soporta `CHECK`; se usan para no-negatividad y rangos. Django los emite vía `Meta.constraints = [CheckConstraint(...)]`.
- **Índices**: además de los de FK (automáticos), se declaran los de búsqueda/filtro frecuentes.
- **JSON**: MariaDB mapea `JSON` a `LONGTEXT` con validación; se usa solo para payloads de auditoría/DTE/ML, nunca para datos consultados por filtros.
- Nombres de tabla: `app_modelo` (default de Django). Nombres de campo y modelo **en español**.

---

## 1. Diagrama de relaciones (textual, alto nivel)

```
Usuario ──* MovimientoInventario, Venta, Caja, OrdenCompra, RecepcionCompra, SesionConteo, RegistroAuditoria
Rol 1──* Usuario           Rol *──* Permiso  (RolPermiso)

Categoria 1──* Producto     Marca 1──* Producto
Producto 1──* Stock (por Ubicacion)      Producto 1──1 ParametroInventario (por Ubicacion)
Producto 1──* MovimientoInventario
Producto *──* Proveedor  (ProductoProveedor: costo, código proveedor)

Ubicacion 1──* Stock, MovimientoInventario

Proveedor 1──* OrdenCompra
OrdenCompra 1──* LineaOrdenCompra ──* (Producto)
OrdenCompra 1──* RecepcionCompra 1──* LineaRecepcion ──* (LineaOrdenCompra, Producto)
RecepcionCompra 1──* MovimientoInventario   (tipo=COMPRA)

Caja 1──* MovimientoCaja        Caja 1──* Venta (ventas efectivo asociadas)
Venta 1──* LineaVenta ──* (Producto)
Venta 1──* PagoVenta
Venta 1──* MovimientoInventario  (tipo=VENTA)
Venta 1──1 DocumentoTributario 1──* EventoDTE      DocumentoTributario 1──1 RespuestaProveedorDTE
Venta 1──* DevolucionVenta 1──* LineaDevolucion    DevolucionVenta 1──* MovimientoInventario (tipo=DEVOLUCION)
LineaVenta 0──1 AutorizacionDescuento

SesionConteo 1──* LineaConteo ──* (Producto)
SesionConteo 1──* AjusteDiscrepancia 1──1 MovimientoInventario (tipo=AJUSTE)

Producto 1──* PrediccionDemanda ──* ModeloPrediccion
Producto 1──* RecomendacionReposicion ──0..1 Proveedor
Producto 1──* Alerta        Usuario 0──* Alerta

ParametroSistema  (singleton)     ParametroReposicion (singleton)     ReglaAlerta (catálogo de reglas)
RegistroAuditoria (append-only, referencia genérica por app+modelo+id)
```

---

## 2. Seguridad y usuarios

### 2.1 `Rol` (app `usuarios`)
| Campo | Tipo | PK | FK | Null | Default | Unique | Notas |
|---|---|---|---|---|---|---|---|
| nombre | VARCHAR(50) | | | No | | **Sí** | `administrador`, `bodeguero`, `vendedor`, `mayorista` |
| descripcion | VARCHAR(200) | | | Sí | '' | | |
| activo | BOOLEAN | | | No | true | | |
| creado_en / actualizado_en | DATETIME | | | No | auto | | TimeStampedModel |

Índices: `nombre` (unique). Cardinalidad: `Rol 1 — * Usuario`.

### 2.2 `Permiso` (app `usuarios`)
| Campo | Tipo | Null | Default | Unique | Notas |
|---|---|---|---|---|---|
| codigo | VARCHAR(60) | No | | **Sí** | `modulo.accion` (ej. `ventas.crear`) |
| descripcion | VARCHAR(200) | Sí | '' | | |
| modulo | VARCHAR(30) | No | | | para agrupar en UI |

Se cargan por **data migration** (lista fija). Cardinalidad: `Permiso * — * Rol`.

### 2.3 `RolPermiso` (tabla intermedia, app `usuarios`)
| Campo | Tipo | FK | Null | Notas |
|---|---|---|---|---|
| rol | BIGINT | → `Rol` (CASCADE) | No | |
| permiso | BIGINT | → `Permiso` (CASCADE) | No | |

Unique: (`rol`, `permiso`). Índice compuesto en ese par.

### 2.4 `Usuario` (app `usuarios`, `AUTH_USER_MODEL`)
Extiende `AbstractBaseUser` + `PermissionsMixin` (se usa `is_active`, `is_staff` para el admin de Django; la autorización de negocio va por `rol`).

| Campo | Tipo | Null | Default | Unique | Notas |
|---|---|---|---|---|---|
| username | VARCHAR(150) | No | | **Sí** | login |
| email | VARCHAR(254) | Sí | '' | Sí (si no vacío) | |
| nombres | VARCHAR(100) | No | | | |
| apellidos | VARCHAR(100) | No | | | |
| rut | VARCHAR(12) | Sí | null | Sí (si no null) | formato `12345678-9`, validado |
| rol | BIGINT | No | | | FK → `Rol` (**PROTECT**) |
| activo (`is_active`) | BOOLEAN | No | true | | inactivo ⇒ no login |
| is_staff | BOOLEAN | No | false | | acceso al admin Django |
| password | VARCHAR(128) | No | | | hash PBKDF2/Argon2 |
| ultimo_login (`last_login`) | DATETIME | Sí | null | | |
| creado_en / actualizado_en | DATETIME | No | auto | | |

Índices: `username` (u), `rut` (u parcial), `rol`. 
Cardinalidad: `Usuario * — 1 Rol`.

### 2.5 `IntentoLogin` (app `usuarios`)
| Campo | Tipo | Null | Default | Notas |
|---|---|---|---|---|
| username | VARCHAR(150) | No | | puede no existir como usuario |
| ip | VARCHAR(45) | No | | IPv4/IPv6 |
| exito | BOOLEAN | No | false | |
| fecha | DATETIME | No | ahora | |

Índices: (`username`, `fecha`), (`ip`, `fecha`). Uso: bloqueo tras N fallos en ventana de tiempo. Retención: purga por cron (> 30 días).

---

## 3. Catálogo

### 3.1 `Categoria` (app `catalogo`)
| Campo | Tipo | Null | Default | Unique | Notas |
|---|---|---|---|---|---|
| nombre | VARCHAR(80) | No | | **Sí** | |
| descripcion | VARCHAR(200) | Sí | '' | | |
| activo | BOOLEAN | No | true | | |
| creado_en / actualizado_en | DATETIME | No | auto | | |

### 3.2 `Marca` (app `catalogo`)
Igual estructura que `Categoria` (`nombre` unique, `activo`, timestamps).

### 3.3 `Producto` (app `catalogo`)
| Campo | Tipo | Null | Default | Unique | Notas |
|---|---|---|---|---|---|
| sku | VARCHAR(40) | No | | **Sí** | código interno |
| codigo_barras | VARCHAR(64) | Sí | null | **Sí** (si no null) | EAN/UPC u otro; puede faltar al crear |
| nombre | VARCHAR(150) | No | | | |
| descripcion | TEXT | Sí | '' | | |
| categoria | BIGINT | No | | | FK → `Categoria` (**PROTECT**) |
| marca | BIGINT | Sí | null | | FK → `Marca` (**PROTECT**) |
| unidad_medida | VARCHAR(10) | No | 'UN' | | choices: UN, KG, LT, MT, CJ |
| precio_venta | INTEGER | No | 0 | | CLP, IVA **incluido**; CHECK ≥ 0 |
| precio_mayorista | INTEGER | Sí | null | | CLP, IVA incluido; CHECK ≥ 0 (D5) |
| costo_referencial | INTEGER | No | 0 | | último costo conocido; CHECK ≥ 0 |
| afecto_iva | BOOLEAN | No | true | | si false ⇒ exento |
| activo | BOOLEAN | No | true | | inactivo ⇒ no vende/compra |
| creado_en / actualizado_en | DATETIME | No | auto | | |

Índices: `sku` (u), `codigo_barras` (u parcial), `nombre` (búsqueda), (`categoria`,`activo`), (`marca`,`activo`).
Constraints: `CHECK (precio_venta >= 0)`, `CHECK (costo_referencial >= 0)`, `CHECK (precio_mayorista IS NULL OR precio_mayorista >= 0)`.
Cardinalidad: `Producto * — 1 Categoria`, `* — 0..1 Marca`.

### 3.4 `ProductoProveedor` (app `catalogo` o `proveedores`)
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| producto | BIGINT | → `Producto` (CASCADE) | No | | |
| proveedor | BIGINT | → `Proveedor` (CASCADE) | No | | |
| codigo_proveedor | VARCHAR(40) | | Sí | '' | SKU del proveedor |
| costo | INTEGER | | No | 0 | CLP; CHECK ≥ 0 |
| es_preferente | BOOLEAN | | No | false | proveedor por defecto para reposición |

Unique: (`producto`, `proveedor`). Índice: (`producto`, `es_preferente`).
Cardinalidad: `Producto * — * Proveedor`.

---

## 4. Inventario

### 4.1 `Ubicacion` (app `inventario`)
| Campo | Tipo | Null | Default | Unique | Notas |
|---|---|---|---|---|---|
| nombre | VARCHAR(60) | No | | **Sí** | 'Sala', 'Bodega' |
| tipo | VARCHAR(15) | No | 'BODEGA' | | choices: SALA, BODEGA |
| activo | BOOLEAN | No | true | | |

Se crea 1 por defecto (D9). Modelo preparado para N.

### 4.2 `Stock` (app `inventario`) — cantidad actual por producto/ubicación
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| producto | BIGINT | → `Producto` (PROTECT) | No | | |
| ubicacion | BIGINT | → `Ubicacion` (PROTECT) | No | | |
| cantidad | DECIMAL(12,3) | | No | 0 | CHECK ≥ 0 (salvo ajuste; ver servicio) |
| actualizado_en | DATETIME | | No | auto | |

Unique: (`producto`, `ubicacion`). Índice: (`ubicacion`, `cantidad`) para "stock bajo".
**Concurrencia:** las salidas hacen `SELECT ... FOR UPDATE` sobre la fila de `Stock` dentro de `transaction.atomic`.
Constraint: `CHECK (cantidad >= 0)` (los ajustes negativos autorizados se validan en servicio antes de persistir; nunca dejan la fila < 0).

### 4.3 `ParametroInventario` (app `inventario`)
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| producto | BIGINT | → `Producto` (CASCADE) | No | | |
| ubicacion | BIGINT | → `Ubicacion` (CASCADE) | No | | |
| stock_minimo | DECIMAL(12,3) | | No | 0 | dispara alerta stock bajo; CHECK ≥ 0 |
| punto_reposicion | DECIMAL(12,3) | | No | 0 | referencia; CHECK ≥ 0 |
| stock_seguridad | DECIMAL(12,3) | | No | 0 | usado/override por `reposicion`; CHECK ≥ 0 |
| multiplo_compra | DECIMAL(12,3) | | No | 1 | redondeo de cantidad sugerida; CHECK > 0 |

Unique: (`producto`, `ubicacion`).

### 4.4 `MovimientoInventario` (app `inventario`) — **libro mayor de stock, append-only**
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| producto | BIGINT | → `Producto` (PROTECT) | No | | |
| ubicacion | BIGINT | → `Ubicacion` (PROTECT) | No | | |
| tipo | VARCHAR(15) | | No | | choices: VENTA, COMPRA, DEVOLUCION, AJUSTE_POS, AJUSTE_NEG, CONTEO, TRASPASO |
| cantidad | DECIMAL(12,3) | | No | | **con signo**: negativa = salida, positiva = entrada; CHECK <> 0 |
| stock_antes | DECIMAL(12,3) | | No | | snapshot |
| stock_despues | DECIMAL(12,3) | | No | | snapshot |
| motivo | VARCHAR(200) | | Sí | '' | |
| doc_tipo | VARCHAR(20) | | Sí | null | 'venta','recepcion','ajuste_discrepancia','devolucion' |
| doc_id | BIGINT | | Sí | null | id del documento origen (no FK: polimórfico) |
| usuario | BIGINT | → `Usuario` (PROTECT) | No | | responsable |
| creado_en | DATETIME | | No | ahora | (sin `actualizado_en`: inmutable) |

Índices: (`producto`, `creado_en`), (`tipo`, `creado_en`), (`usuario`, `creado_en`), (`doc_tipo`, `doc_id`).
Cardinalidad: `Producto 1 — * MovimientoInventario`. **Nunca se edita ni borra.**

---

## 5. Inventario físico y discrepancias (app `inventario_fisico`)

### 5.1 `SesionConteo`
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| codigo | VARCHAR(20) | | No | | correlativo `CNT-000001`; Unique |
| descripcion | VARCHAR(200) | | Sí | '' | |
| ubicacion | BIGINT | → `Ubicacion` (PROTECT) | No | | |
| alcance | VARCHAR(15) | | No | 'TOTAL' | choices: TOTAL, PARCIAL |
| categoria | BIGINT | → `Categoria` (SET NULL) | Sí | null | si PARCIAL por categoría |
| estado | VARCHAR(15) | | No | 'ABIERTA' | choices: ABIERTA, EN_REVISION, CERRADA, ANULADA |
| creada_por | BIGINT | → `Usuario` (PROTECT) | No | | |
| autorizada_por | BIGINT | → `Usuario` (SET NULL) | Sí | null | quien aprueba la regularización |
| creado_en / actualizado_en | DATETIME | | No | auto | |
| cerrada_en | DATETIME | | Sí | null | |

### 5.2 `LineaConteo`
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| sesion | BIGINT | → `SesionConteo` (CASCADE) | No | | |
| producto | BIGINT | → `Producto` (PROTECT) | No | | |
| cantidad_sistema | DECIMAL(12,3) | | No | | snapshot al momento del conteo |
| cantidad_contada | DECIMAL(12,3) | | Sí | null | null = aún no contado |
| diferencia | DECIMAL(12,3) | | No | 0 | `contada - sistema` (calculada al guardar) |
| contada_por | BIGINT | → `Usuario` (SET NULL) | Sí | null | |
| contada_en | DATETIME | | Sí | null | |

Unique: (`sesion`, `producto`). Índice: (`sesion`, `diferencia`).

### 5.3 `AjusteDiscrepancia`
| Campo | Tipo | FK | Null | Notas |
|---|---|---|---|---|
| sesion | BIGINT | → `SesionConteo` (PROTECT) | No | |
| linea | BIGINT | → `LineaConteo` (PROTECT) | No | |
| movimiento | BIGINT | → `MovimientoInventario` (PROTECT) | No | el ajuste generado (tipo CONTEO) |
| autorizado_por | BIGINT | → `Usuario` (PROTECT) | No | |
| creado_en | DATETIME | | No | |

Cardinalidad: `SesionConteo 1 — * LineaConteo`; cada línea con diferencia ≠ 0 genera 1 `AjusteDiscrepancia` al regularizar → 1 `MovimientoInventario`.

---

## 6. Proveedores y compras

### 6.1 `Proveedor` (app `proveedores`)
| Campo | Tipo | Null | Default | Unique | Notas |
|---|---|---|---|---|---|
| razon_social | VARCHAR(150) | No | | | |
| rut | VARCHAR(12) | No | | **Sí** | validado |
| giro | VARCHAR(120) | Sí | '' | | |
| contacto_nombre | VARCHAR(100) | Sí | '' | | |
| contacto_email | VARCHAR(254) | Sí | '' | | |
| contacto_telefono | VARCHAR(20) | Sí | '' | | |
| direccion | VARCHAR(200) | Sí | '' | | |
| lead_time_dias | SMALLINT | No | 7 | | días hábiles; CHECK ≥ 0 |
| activo | BOOLEAN | No | true | | |
| creado_en / actualizado_en | DATETIME | No | auto | | |

Índices: `rut` (u), `razon_social` (búsqueda).
> `reposicion` convierte `lead_time_dias` a semanas (`L = dias/7`).

### 6.2 `OrdenCompra` (app `compras`)
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| codigo | VARCHAR(20) | | No | | `OC-000001`; Unique |
| proveedor | BIGINT | → `Proveedor` (PROTECT) | No | | |
| estado | VARCHAR(15) | | No | 'BORRADOR' | choices: BORRADOR, EMITIDA, RECIBIDA_PARCIAL, RECIBIDA, CERRADA, ANULADA |
| fecha_emision | DATETIME | | Sí | null | al pasar a EMITIDA |
| observacion | VARCHAR(300) | | Sí | '' | |
| total_estimado | INTEGER | | No | 0 | suma de líneas; CLP |
| creada_por | BIGINT | → `Usuario` (PROTECT) | No | | |
| creado_en / actualizado_en | DATETIME | | No | auto | | |

Índices: `codigo` (u), (`proveedor`, `estado`), (`estado`, `fecha_emision`).
**Stock en tránsito** (`T` de reposición) = Σ (cantidad pedida − recibida) de líneas de OC en estado EMITIDA / RECIBIDA_PARCIAL.

### 6.3 `LineaOrdenCompra` (app `compras`)
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| orden | BIGINT | → `OrdenCompra` (CASCADE) | No | | |
| producto | BIGINT | → `Producto` (PROTECT) | No | | |
| cantidad | DECIMAL(12,3) | | No | | CHECK > 0 |
| cantidad_recibida | DECIMAL(12,3) | | No | 0 | acumulada por recepciones; CHECK ≥ 0 |
| costo_unitario | INTEGER | | No | | CLP; CHECK ≥ 0 |

Unique: (`orden`, `producto`). Constraint: `CHECK (cantidad_recibida <= cantidad)`.

### 6.4 `RecepcionCompra` (app `compras`)
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| codigo | VARCHAR(20) | | No | | `REC-000001`; Unique |
| orden | BIGINT | → `OrdenCompra` (PROTECT) | No | | |
| ubicacion | BIGINT | → `Ubicacion` (PROTECT) | No | | dónde ingresa el stock |
| documento_proveedor | VARCHAR(40) | | Sí | '' | N° factura/guía |
| recibida_por | BIGINT | → `Usuario` (PROTECT) | No | | |
| creado_en | DATETIME | | No | ahora | inmutable |

### 6.5 `LineaRecepcion` (app `compras`)
| Campo | Tipo | FK | Null | Notas |
|---|---|---|---|---|
| recepcion | BIGINT | → `RecepcionCompra` (CASCADE) | No | |
| linea_orden | BIGINT | → `LineaOrdenCompra` (PROTECT) | No | |
| cantidad | DECIMAL(12,3) | | No | CHECK > 0 |
| movimiento | BIGINT | → `MovimientoInventario` (PROTECT) | Sí | el generado (tipo COMPRA) |

**Regla (RF-E5/E6):** crear OC no toca stock. La recepción, en `transaction.atomic`: valida `cantidad ≤ pendiente`, crea `MovimientoInventario` (+), incrementa `Stock`, suma `cantidad_recibida` en la línea de OC, recalcula estado de la OC, registra auditoría, actualiza `costo_referencial` del producto.

---

## 7. Ventas / POS (app `ventas`)

### 7.1 `Venta`
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| folio | VARCHAR(20) | | No | | correlativo interno `V-000001`; Unique |
| caja | BIGINT | → `Caja` (PROTECT) | No | | caja abierta del vendedor |
| vendedor | BIGINT | → `Usuario` (PROTECT) | No | | |
| estado | VARCHAR(12) | | No | 'PAGADA' | choices: PAGADA, ANULADA |
| neto | INTEGER | | No | 0 | CLP; CHECK ≥ 0 |
| iva | INTEGER | | No | 0 | CLP; CHECK ≥ 0 |
| exento | INTEGER | | No | 0 | CLP; CHECK ≥ 0 |
| descuento_total | INTEGER | | No | 0 | CLP; CHECK ≥ 0 |
| total | INTEGER | | No | 0 | CLP; CHECK ≥ 0 (= neto+iva+exento) |
| redondeo | SMALLINT | | No | 0 | ajuste efectivo (Chile), puede ser negativo |
| anulada_por | BIGINT | → `Usuario` (SET NULL) | Sí | null | |
| anulada_en | DATETIME | | Sí | null | |
| motivo_anulacion | VARCHAR(200) | | Sí | '' | |
| creado_en | DATETIME | | No | ahora | |

Índices: `folio` (u), (`caja`), (`vendedor`, `creado_en`), (`estado`, `creado_en`), (`creado_en`) para dashboard.
**Confirmación** = transacción: bloquea `Stock` de cada producto, valida, crea líneas y pagos, descuenta stock + `MovimientoInventario` (tipo VENTA, cantidad negativa), asocia pagos efectivo a `MovimientoCaja`, dispara `boleta.emitir` (tolerante a fallo), audita, genera alertas.

### 7.2 `LineaVenta`
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| venta | BIGINT | → `Venta` (CASCADE) | No | | |
| producto | BIGINT | → `Producto` (PROTECT) | No | | |
| descripcion | VARCHAR(150) | | No | | snapshot del nombre |
| cantidad | DECIMAL(12,3) | | No | | CHECK > 0 |
| precio_unitario | INTEGER | | No | | snapshot (venta o mayorista); CHECK ≥ 0 |
| descuento_monto | INTEGER | | No | 0 | CLP por línea; CHECK ≥ 0 |
| afecto_iva | BOOLEAN | | No | true | snapshot |
| total_linea | INTEGER | | No | | `cantidad*precio - descuento`; CHECK ≥ 0 |

Índices: (`venta`), (`producto`, `venta`) para "más vendidos".

### 7.3 `PagoVenta`
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| venta | BIGINT | → `Venta` (CASCADE) | No | | |
| medio | VARCHAR(15) | | No | | choices: EFECTIVO, DEBITO, CREDITO, TRANSFERENCIA |
| monto | INTEGER | | No | | CLP; CHECK > 0 |
| referencia | VARCHAR(40) | | Sí | '' | últimos dígitos / N° operación (manual) |

Regla: Σ `monto` de pagos = `Venta.total` (validado en servicio). Un pago EFECTIVO por venta genera el `MovimientoCaja`.

### 7.4 `AutorizacionDescuento`
| Campo | Tipo | FK | Null | Notas |
|---|---|---|---|---|
| linea_venta | BIGINT | → `LineaVenta` (CASCADE) | Sí | null si descuento global |
| venta | BIGINT | → `Venta` (CASCADE) | No | |
| solicitado_por | BIGINT | → `Usuario` (PROTECT) | No | vendedor |
| autorizado_por | BIGINT | → `Usuario` (PROTECT) | No | supervisor/admin |
| porcentaje | DECIMAL(5,2) | | No | CHECK 0–100 |
| monto | INTEGER | | No | CLP; CHECK ≥ 0 |
| creado_en | DATETIME | | No | |

Se crea solo cuando el descuento supera el tope del rol (D7, tope en `ParametroSistema`).

### 7.5 `DevolucionVenta` / `LineaDevolucion` (D8 — anulación mismo día)
`DevolucionVenta`: `venta` (FK PROTECT), `motivo` VARCHAR(200), `autorizada_por` (FK Usuario PROTECT), `total_devuelto` INTEGER, `creado_en`.
`LineaDevolucion`: `devolucion` (FK CASCADE), `linea_venta` (FK PROTECT), `cantidad` DECIMAL(12,3) CHECK > 0, `movimiento` (FK MovimientoInventario, tipo DEVOLUCION, cantidad +).
> Fase 1: solo el mismo día; marca `Venta.estado=ANULADA` si es devolución total; nota de crédito electrónica fuera de alcance.

---

## 8. Caja (app `caja`)

### 8.1 `Caja`
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| codigo | VARCHAR(20) | | No | | `CAJA-000001`; Unique |
| usuario | BIGINT | → `Usuario` (PROTECT) | No | | responsable (D10) |
| estado | VARCHAR(10) | | No | 'ABIERTA' | choices: ABIERTA, CERRADA |
| monto_inicial | INTEGER | | No | 0 | CLP; CHECK ≥ 0 |
| monto_esperado | INTEGER | | Sí | null | calculado al cerrar |
| monto_contado | INTEGER | | Sí | null | ingresado al cerrar; CHECK ≥ 0 |
| diferencia | INTEGER | | Sí | null | `contado - esperado` (puede ser negativa) |
| observacion_cierre | VARCHAR(300) | | Sí | '' | |
| abierta_en | DATETIME | | No | ahora | |
| cerrada_en | DATETIME | | Sí | null | |

Índices: `codigo` (u), (`usuario`, `estado`).
**Constraint clave (RF-G2) — "una caja ABIERTA por usuario":** MariaDB 10.11 no soporta índices únicos parciales (Django ignora `UniqueConstraint(condition=...)` en MySQL/MariaDB). Se garantiza en la **capa de servicios**: al abrir caja, `select_for_update` sobre las cajas del usuario + validación de que no exista otra `ABIERTA`. Opcional a nivel de BD: columna generada `caja_abierta_usuario` = `usuario` si `estado='ABIERTA'` else `NULL`, con índice único sobre ella.

### 8.2 `MovimientoCaja`
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| caja | BIGINT | → `Caja` (PROTECT) | No | | |
| tipo | VARCHAR(10) | | No | | choices: VENTA, INGRESO, EGRESO |
| monto | INTEGER | | No | | CLP; CHECK > 0 (el tipo define el signo lógico) |
| motivo | VARCHAR(200) | | Sí | '' | obligatorio si INGRESO/EGRESO (servicio) |
| venta | BIGINT | → `Venta` (SET NULL) | Sí | null | si tipo VENTA (pago efectivo) |
| usuario | BIGINT | → `Usuario` (PROTECT) | No | | |
| creado_en | DATETIME | | No | ahora | inmutable |

Índices: (`caja`, `creado_en`), (`tipo`).
`monto_esperado` = `monto_inicial` + Σ(VENTA) + Σ(INGRESO) − Σ(EGRESO).

---

## 9. Boleta electrónica (app `boleta`)

### 9.1 `DocumentoTributario`
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| venta | BIGINT | → `Venta` (PROTECT) | No | | **OneToOne** |
| tipo_dte | SMALLINT | | No | 39 | 39 = boleta electrónica afecta |
| folio | INTEGER | | Sí | null | asignado por el proveedor/MOCK; Unique(si no null) por (`tipo_dte`,`folio`) |
| estado | VARCHAR(12) | | No | 'PENDIENTE' | choices: PENDIENTE, EMITIDO, ACEPTADO, RECHAZADO, ANULADO |
| neto | INTEGER | | No | 0 | snapshot |
| iva | INTEGER | | No | 0 | |
| exento | INTEGER | | No | 0 | |
| total | INTEGER | | No | 0 | |
| emisor_rut | VARCHAR(12) | | No | | de `ParametroSistema` |
| fecha_emision | DATETIME | | Sí | null | |
| intentos | SMALLINT | | No | 0 | reintentos de emisión |
| ultimo_error | VARCHAR(300) | | Sí | '' | |
| creado_en / actualizado_en | DATETIME | | No | auto | |

Índices: `venta` (u), (`estado`, `creado_en`), (`tipo_dte`, `folio`) unique parcial.

### 9.2 `RespuestaProveedorDTE`
| Campo | Tipo | FK | Null | Notas |
|---|---|---|---|---|
| documento | BIGINT | → `DocumentoTributario` (CASCADE) | No | OneToOne |
| payload | JSON (LONGTEXT) | | Sí | respuesta cruda del proveedor/MOCK |
| track_id | VARCHAR(60) | | Sí | id de seguimiento |
| timbre | TEXT | | Sí | TED/PDF417 simulado |
| url_pdf | VARCHAR(300) | | Sí | ruta al PDF/HTML generado |
| recibido_en | DATETIME | | No | |

### 9.3 `EventoDTE` (bitácora append-only)
| Campo | Tipo | FK | Null | Notas |
|---|---|---|---|---|
| documento | BIGINT | → `DocumentoTributario` (CASCADE) | No | |
| evento | VARCHAR(20) | | No | choices: EMISION_INTENTO, EMISION_OK, EMISION_ERROR, ANULACION, CONSULTA |
| detalle | VARCHAR(300) | | Sí | |
| creado_en | DATETIME | | No | |

---

## 10. Alertas (app `alertas`)

### 10.1 `ReglaAlerta` (catálogo configurable)
| Campo | Tipo | Null | Default | Notas |
|---|---|---|---|---|
| tipo | VARCHAR(25) | No | | choices: STOCK_BAJO, SIN_STOCK, REPOSICION, DISCREPANCIA, ERROR_SISTEMA, DTE_FALLIDO |
| activa | BOOLEAN | No | true | |
| severidad | VARCHAR(10) | No | 'WARNING' | choices: INFO, WARNING, CRITICAL |
| umbral | DECIMAL(12,3) | Sí | null | p. ej. margen sobre stock_minimo |
| parametros | JSON (LONGTEXT) | Sí | null | config extra |

Unique: `tipo`.

### 10.2 `Alerta`
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| tipo | VARCHAR(25) | | No | | igual choices que `ReglaAlerta` |
| severidad | VARCHAR(10) | | No | 'WARNING' | |
| estado | VARCHAR(10) | | No | 'NUEVA' | choices: NUEVA, VISTA, RESUELTA |
| mensaje | VARCHAR(300) | | No | | |
| producto | BIGINT | → `Producto` (SET NULL) | Sí | null | |
| usuario | BIGINT | → `Usuario` (SET NULL) | Sí | null | destinatario/relacionado |
| doc_tipo | VARCHAR(20) | | Sí | null | referencia opcional |
| doc_id | BIGINT | | Sí | null | |
| hash_dedupe | VARCHAR(64) | | No | | `tipo+producto+dia` para no duplicar abiertas; Unique con `estado<>RESUELTA` |
| vista_por | BIGINT | → `Usuario` (SET NULL) | Sí | null | |
| resuelta_por | BIGINT | → `Usuario` (SET NULL) | Sí | null | |
| resuelta_en | DATETIME | | Sí | null | |
| creado_en / actualizado_en | DATETIME | | No | auto | |

Índices: (`estado`, `severidad`), (`tipo`, `creado_en`), (`producto`), `hash_dedupe`.

---

## 11. Predicción y reposición

### 11.1 `ModeloPrediccion` (app `prediccion`)
| Campo | Tipo | Null | Default | Notas |
|---|---|---|---|---|
| version | VARCHAR(20) | No | | `demanda_v1`; Unique |
| algoritmo | VARCHAR(40) | No | | 'random_forest', 'naive_estacional', … |
| ruta_artefacto | VARCHAR(300) | No | | `ml/models/demanda_v1.joblib` |
| metricas | JSON (LONGTEXT) | No | | `{mae, rmse, mape, n_train, n_test}` |
| granularidad | VARCHAR(10) | No | 'SEMANAL' | |
| entrenado_en | DATETIME | No | | |
| activo | BOOLEAN | No | false | solo uno activo a la vez |
| notas | VARCHAR(300) | Sí | '' | |

Constraint: índice único parcial "un solo `activo=true`" (o se valida en servicio).

### 11.2 `PrediccionDemanda` (app `prediccion`)
| Campo | Tipo | FK | Null | Notas |
|---|---|---|---|---|
| producto | BIGINT | → `Producto` (CASCADE) | No | |
| modelo | BIGINT | → `ModeloPrediccion` (PROTECT) | No | |
| horizonte_semanas | SMALLINT | | No | CHECK 1–52 |
| demanda_estimada | DECIMAL(12,3) | | No | CHECK ≥ 0 |
| desviacion | DECIMAL(12,3) | | No | 0 | σ estimada |
| generado_en | DATETIME | | No | |

Unique: (`producto`, `modelo`, `horizonte_semanas`, fecha del día). Índice: (`producto`, `generado_en`).

### 11.3 `ParametroReposicion` (app `reposicion`, singleton)
| Campo | Tipo | Null | Default | Notas |
|---|---|---|---|---|
| nivel_servicio_z | DECIMAL(4,2) | No | 1.65 | 95 %; CHECK > 0 |
| horizonte_semanas | SMALLINT | No | 4 | CHECK 1–52 |
| periodo_revision_semanas | DECIMAL(4,2) | No | 1 | `R` |
| min_semanas_historia | SMALLINT | No | 12 | regla de datos mínimos |
| formula_version | VARCHAR(10) | No | 'v1' | |

### 11.4 `RecomendacionReposicion` (app `reposicion`)
| Campo | Tipo | FK | Null | Default | Notas |
|---|---|---|---|---|---|
| producto | BIGINT | → `Producto` (CASCADE) | No | | |
| proveedor | BIGINT | → `Proveedor` (SET NULL) | Sí | null | preferente |
| stock_actual | DECIMAL(12,3) | | No | | snapshot |
| stock_transito | DECIMAL(12,3) | | No | 0 | `T` |
| demanda_estimada | DECIMAL(12,3) | | No | | `d` |
| desviacion_demanda | DECIMAL(12,3) | | No | 0 | `σ_d` |
| lead_time_semanas | DECIMAL(5,2) | | No | | `L` |
| stock_seguridad | DECIMAL(12,3) | | No | | `SS` calculado |
| punto_pedido | DECIMAL(12,3) | | No | | `ROP` |
| cantidad_recomendada | DECIMAL(12,3) | | No | | `Q`; CHECK ≥ 0 |
| motivo | VARCHAR(400) | | No | | texto explicable |
| inputs | JSON (LONGTEXT) | | No | | todos los valores usados |
| formula_version | VARCHAR(10) | | No | | de `ParametroReposicion` |
| modelo | BIGINT | → `ModeloPrediccion` (PROTECT) | Sí | null | modelo usado |
| estado | VARCHAR(12) | | No | 'SUGERIDA' | choices: SUGERIDA, APROBADA, DESCARTADA, ORDENADA |
| generado_en | DATETIME | | No | ahora | |

Índices: (`producto`, `generado_en`), (`estado`, `generado_en`).

---

## 12. Transversales (app `core` / `auditoria`)

### 12.1 `ParametroSistema` (singleton, `core`)
| Campo | Tipo | Null | Default | Notas |
|---|---|---|---|---|
| emisor_rut | VARCHAR(12) | No | '' | para boleta |
| emisor_razon_social | VARCHAR(150) | No | '' | |
| emisor_giro | VARCHAR(120) | No | '' | |
| emisor_direccion | VARCHAR(200) | No | '' | |
| iva_porcentaje | DECIMAL(5,2) | No | 19.00 | |
| redondeo_efectivo | SMALLINT | No | 10 | múltiplo (Chile) |
| tope_descuento_vendedor_pct | DECIMAL(5,2) | No | 5.00 | sobre esto → autorización |
| moneda | VARCHAR(3) | No | 'CLP' | |
| dte_proveedor | VARCHAR(20) | No | 'mock' | |
| actualizado_en | DATETIME | No | auto | |

Se fuerza `id=1` (patrón singleton).

### 12.2 `RegistroAuditoria` (app `auditoria`, **append-only**)
| Campo | Tipo | FK | Null | Notas |
|---|---|---|---|---|
| usuario | BIGINT | → `Usuario` (SET NULL) | Sí | null si acción del sistema/cron |
| accion | VARCHAR(50) | | No | `venta.anular`, `stock.ajuste`, `caja.cierre`, … |
| entidad | VARCHAR(60) | | Sí | `app.Modelo` |
| entidad_id | BIGINT | | Sí | |
| datos_antes | JSON (LONGTEXT) | | Sí | |
| datos_despues | JSON (LONGTEXT) | | Sí | |
| ip | VARCHAR(45) | | Sí | |
| user_agent | VARCHAR(255) | | Sí | |
| request_id | VARCHAR(36) | | Sí | correlación con logs |
| creado_en | DATETIME | | No | ahora |

Índices: (`usuario`, `creado_en`), (`accion`, `creado_en`), (`entidad`, `entidad_id`). Sin `update`/`delete` expuestos. Lectura solo `administrador`.

---

## 13. Resumen de entidades (41)

| Dominio | Entidades |
|---|---|
| Seguridad | Rol, Permiso, RolPermiso, Usuario, IntentoLogin |
| Catálogo | Categoria, Marca, Producto, ProductoProveedor |
| Inventario | Ubicacion, Stock, ParametroInventario, MovimientoInventario |
| Inventario físico | SesionConteo, LineaConteo, AjusteDiscrepancia |
| Proveedores/Compras | Proveedor, OrdenCompra, LineaOrdenCompra, RecepcionCompra, LineaRecepcion |
| Ventas/POS | Venta, LineaVenta, PagoVenta, AutorizacionDescuento, DevolucionVenta, LineaDevolucion |
| Caja | Caja, MovimientoCaja |
| Boleta | DocumentoTributario, RespuestaProveedorDTE, EventoDTE |
| Alertas | ReglaAlerta, Alerta |
| Predicción/Reposición | ModeloPrediccion, PrediccionDemanda, ParametroReposicion, RecomendacionReposicion |
| Transversal | ParametroSistema, RegistroAuditoria |

---

## 14. Notas de compatibilidad MariaDB (hosting: **MariaDB 10.11.19**, confirmado 2026-09-07)

1. **Sin `ArrayField`, `HStoreField`, `JSONB`, rangos ni `distinct on`** (todo PostgreSQL). `JSONField` de Django funciona sobre `LONGTEXT` con `JSON_VALID` → se usa solo para payloads no filtrables.
2. **Índices únicos parciales** (`UniqueConstraint` con `condition`): **no** soportados en MariaDB (Django los ignora en MySQL/MariaDB). "Una caja abierta por usuario" y "un modelo activo" → garantía en la **capa de servicios** (`select_for_update` + validación); opcionalmente columna generada + índice único.
3. **`CHECK` constraints**: soportados (MariaDB 10.2+ → OK en 10.11). Django los crea desde `Meta.constraints`.
4. **`utf8mb4`** en la base y en `OPTIONS['charset']`; `collation` `utf8mb4_ununode_ci` o `utf8mb4_general_ci`.
5. **`sql_mode`** estricto (`STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO`) vía `OPTIONS['init_command']`.
6. **Transacciones**: InnoDB; `ATOMIC_REQUESTS=False` (se controla explícito con `transaction.atomic` en servicios) + `select_for_update` para stock y caja.
7. **`DECIMAL`** para dinero-cantidad; nunca `FLOAT` en inventario/dinero.
8. **Longitud de índice**: claves `VARCHAR` largas (>191 con `utf8mb4`) pueden requerir prefijo; los campos indexados aquí están dimensionados para no superar el límite de InnoDB.
9. **Correlativos** (`folio`, `codigo`): generados en el servicio dentro de la transacción (`select_for_update` sobre un contador o `MAX()+1` con bloqueo), no con secuencias PostgreSQL.

---

## 15. Siguiente paso

**Etapa 3 ✅** proyecto Django creado. **Etapa 4 — Usuarios, roles y seguridad**: materializa la sección 2 de este documento (Rol, Permiso, RolPermiso, Usuario, IntentoLogin) + JWT login/refresh/me + permisos por rol + tests.

> Versión de MariaDB del hosting **confirmada: 10.11.19**. Todos los `CHECK` del modelo son válidos; los índices únicos condicionales se resuelven en servicios.
