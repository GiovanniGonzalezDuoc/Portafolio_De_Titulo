# POS Picking — Documentación técnica

**Proyecto de título — DuocUC, Grupo N.º 01.**
Cliente ficticio: **Liquidadora "Los Europeos"**.
Repositorio: `github.com/GiovanniGonzalezDuoc/pos-picking` (privado).
Producción: **https://systemspickingpos.cl** · API **https://api.systemspickingpos.cl**.

Esta documentación refleja **solo lo realmente implementado**. Lo simulado se
indica como **[MOCK]**. Los capítulos con un documento propio se referencian en
vez de duplicarse.

---

## 1. Descripción general

POS Picking es una plataforma web de gestión comercial para una liquidadora
minorista: punto de venta, inventario en tiempo real, compras y proveedores,
caja, boleta electrónica, un motor de alertas, un dashboard operacional y un
componente de analítica predictiva (predicción de demanda + recomendación de
reposición).

Arquitectura de dos piezas desacopladas:

- **Backend**: API REST en Django + Django REST Framework, base de datos
  MariaDB, autenticación JWT.
- **Frontend**: SPA en Angular (standalone + signals) servida como estático,
  que consume la API.
- **Paquete `ml/`**: código de *machine learning* en Python puro, independiente
  de Django, que el backend invoca para la predicción de demanda.

## 2. Objetivo

Digitalizar la operación de la tienda con un sistema único que cubra la venta
(con lectura de código de barras), el control de stock con trazabilidad
completa, el abastecimiento (compras a proveedores) y la caja, emitiendo la
boleta electrónica correspondiente; y aportar analítica que anticipe la demanda
y sugiera cuándo y cuánto reponer.

## 3. Alcance

**Incluido y funcionando:**

| Módulo | Estado |
|---|---|
| Usuarios, roles y permisos (JWT) | ✅ |
| Catálogo (productos, categorías, marcas) | ✅ |
| Inventario: stock, movimientos (libro mayor), ajustes, parámetros | ✅ |
| POS: carrito, cálculo de totales, pagos múltiples, autorización de descuento | ✅ |
| Lectura de código de barras (lector *keyboard-wedge* + manual) | ✅ |
| Ventas: confirmación transaccional, anulación mismo día | ✅ |
| Caja: apertura, arqueo, ingresos/egresos, cierre con diferencia | ✅ |
| Proveedores y productos-proveedor | ✅ |
| Compras: órdenes, emisión, recepción (parcial/total) | ✅ |
| Boleta electrónica (DTE 39) | ✅ **[MOCK]** — sin integración real con el SII |
| Motor de alertas + reglas configurables | ✅ |
| Dashboard operacional (KPIs) | ✅ |
| Predicción de demanda (ML) | ✅ (dataset sintético; ver §26) |
| Recomendación de reposición | ✅ |
| Frontend completo (todas las pantallas) | ✅ |
| Docker (stack completo) | ✅ |
| Deploy en producción (cPanel) | ✅ |

**Fuera del alcance / diferido:**

- Integración real de boleta electrónica con el SII (hoy MOCK).
- Portal B2B para el cliente mayorista (solo existe la lista de precios).
- Inventario físico / conteo cíclico con regularización de discrepancias
  (`apps.inventario_fisico` — diferido).
- Registro de auditoría dedicado (`apps.auditoria` — diferido; hoy hay logging
  con contexto de petición).
- Multi-local: el modelo lo soporta, pero opera con una sola ubicación.
- Modo offline del POS (requiere conexión).

## 4. Arquitectura

Documento de referencia: **`docs/01-arquitectura.md`**.

```
                         Internet · HTTPS 443
                                │
                     LiteSpeed (cPanel / CloudLinux)
              ┌─────────────────┴──────────────────┐
   systemspickingpos.cl                   api.systemspickingpos.cl
   (SPA Angular estática                  (app Python LSAPI)
    en ~/public_html)                      passenger_wsgi → Django/DRF
        │  fetch + JWT Bearer  ───────────────►  │
        │  (CORS)                                │  ORM
        ▼                                        ▼
   navegador del usuario                   MariaDB 10.11 (socket)
                                                 ▲
                              cron: reintentar_dte · generar_alertas
                                    calcular_reposicion · backup_db.sh
```

- **Capas del backend**: `views` (DRF, sin lógica) → `services.py` (reglas de
  negocio, transacciones) → `models` (ORM). Los *selectors* del dashboard son
  de solo lectura.
- **Transaccionalidad**: las operaciones que tocan stock/dinero usan
  `transaction.atomic` + `select_for_update` (venta, compra, caja, inventario).
  El stock nunca queda negativo (servicio + `CHECK` de BD).
- **Errores**: envoltura unificada `{"error": {"codigo", "mensaje", "detalles",
  "campo"}}` (`apps/core/exceptions.py`).
- **Contexto de petición**: middleware que asigna `X-Request-ID` y alimenta el
  logging (`apps/core/middleware.py`, `apps/usuarios/authentication.py`).

## 5. Tecnologías

| Capa | Tecnología |
|---|---|
| Backend | Python 3.13 · Django 5.2 · Django REST Framework 3.17 · SimpleJWT 5.5 · django-filter · drf-spectacular · WhiteNoise · gunicorn (solo Docker) |
| Base de datos | MariaDB 10.11 (`utf8mb4`, `sql_mode` estricto) · driver **PyMySQL** |
| ML | pandas · numpy · scikit-learn · joblib (paquete `ml/`, Python puro) |
| Frontend | Angular 22 (standalone, signals, zoneless) · Angular Material 3 · TypeScript · RxJS · Vitest · ESLint |
| Infra | Docker + docker-compose · nginx (contenedor frontend) · cPanel/LiteSpeed (producción) |
| Pruebas de carga | k6 |
| Calidad | ruff · pip-audit · ESLint · pytest · vitest |

## 6. Requisitos

**Desarrollo:**

- Python 3.13 y `pip`
- Node.js 20+ y npm (para el frontend)
- Docker + docker-compose **o** una MariaDB local (para SQLite basta `USE_SQLITE=True`)
- Git

**Producción (cPanel):**

- Hosting con "Setup Python App" (CloudLinux Python Selector) — Python 3.11+
- MariaDB/MySQL de cPanel
- Acceso SSH y a la interfaz de cPanel
- Node **no** hace falta en el servidor: el frontend se compila en local

## 7. Instalación

### Backend (desarrollo, SQLite)

```bash
cd backend
python -m venv .venv && .venv/Scripts/activate        # Linux/mac: source .venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env                                   # y completa las claves
USE_SQLITE=True python manage.py migrate
USE_SQLITE=True python manage.py cargar_demo           # datos de demostración
USE_SQLITE=True python manage.py runserver
```

### Frontend

```bash
cd frontend
npm install
npm start            # http://localhost:4200  (consume http://127.0.0.1:8000)
```

### Stack completo con Docker

```bash
cp .env.docker.example .env       # completa DJANGO_SECRET_KEY, JWT_SIGNING_KEY, DB_PASSWORD, DB_ROOT_PASSWORD
docker compose up --build         # http://localhost:8080
```

Ver **`docs/21-docker.md`**.

### Producción

Ver **`docs/21-deploy-v2network.md`** (plan + comandos paso a paso).

## 8. Configuración

`config/settings/` está dividido por entorno:

| Módulo | Uso |
|---|---|
| `base.py` | común a todos |
| `local.py` | desarrollo (`DEBUG=True`, Swagger, CORS a `:4200`) |
| `docker.py` | stack Docker (hereda `prod`, sin TLS) |
| `prod.py` | producción (fail-fast de claves, HSTS, cookies seguras, `FileBasedCache`) |
| `test.py` | tests (SQLite en memoria, hasher rápido, throttling relajado) |

`prod.py` **aborta el arranque** si faltan `DJANGO_SECRET_KEY`,
`JWT_SIGNING_KEY` o `DJANGO_ALLOWED_HOSTS`, o si las claves son el valor por
defecto.

## 9. Variables de entorno

Plantillas: `backend/.env.example` (desarrollo/prod) y `.env.docker.example`
(Docker).

| Variable | Descripción |
|---|---|
| `DJANGO_SETTINGS_MODULE` | `config.settings.{local,docker,prod}` |
| `DJANGO_SECRET_KEY` | clave de Django (**obligatoria en prod**) |
| `JWT_SIGNING_KEY` | clave de firma de los JWT (**obligatoria**, distinta del secret) |
| `DJANGO_DEBUG` | `True`/`False` |
| `DJANGO_ALLOWED_HOSTS` | hosts permitidos, separados por coma |
| `DJANGO_SECURE_SSL_REDIRECT` | forzar HTTPS (prod: `True`) |
| `DJANGO_NUM_PROXIES` | proxies de confianza delante (cPanel: `1`) |
| `DJANGO_ADMIN_URL` | ruta del admin de Django (ofuscable) |
| `DJANGO_LOG_DIR` | carpeta de logs (prod: fuera de `public_html`) |
| `DJANGO_LOGIN_RATE` / `_ANON_RATE` / `_USER_RATE` | *rate limits* de DRF (para pruebas de carga) |
| `USE_SQLITE` | `True` = SQLite; `False` = MariaDB |
| `DB_NAME` / `DB_USER` / `DB_PASSWORD` / `DB_HOST` / `DB_PORT` | conexión MariaDB |
| `JWT_ACCESS_MINUTES` / `JWT_REFRESH_DAYS` | vida de los tokens |
| `LOGIN_MAX_INTENTOS` / `LOGIN_BLOQUEO_MINUTOS` | bloqueo por fuerza bruta |
| `CORS_ALLOWED_ORIGINS` / `CSRF_TRUSTED_ORIGINS` | orígenes del frontend |
| `DTE_PROVEEDOR` | `mock` (único implementado) |
| `PREDICCION_PERMITIR_SINTETICO` | permite el dataset sintético cuando no hay histórico real |

`config/__init__.py` fija además `OPENBLAS_NUM_THREADS=1` (y OMP/MKL/NUMEXPR) y
registra PyMySQL como `MySQLdb`.

## 10. Estructura del proyecto

```
ProyectoPortafolio/
├── backend/
│   ├── config/            settings, urls, wsgi/asgi, passenger_wsgi.py
│   ├── apps/
│   │   ├── core/          modelos base, ParametroSistema, Secuencia,
│   │   │                  exception handler, middleware, validadores (RUT)
│   │   ├── usuarios/      Usuario, Rol, Permiso, IntentoLogin · auth JWT ·
│   │   │                  permisos (35) · matriz rol→permiso
│   │   ├── catalogo/      Categoria, Marca, Producto
│   │   ├── inventario/    Ubicacion, Stock, ParametroInventario,
│   │   │                  MovimientoInventario (libro mayor)
│   │   ├── alertas/       ReglaAlerta, Alerta · motor
│   │   ├── proveedores/   Proveedor, ProductoProveedor
│   │   ├── compras/       OrdenCompra, LineaOrdenCompra, RecepcionCompra, ...
│   │   ├── ventas/        Venta, LineaVenta, PagoVenta, AutorizacionDescuento,
│   │   │                  DevolucionVenta
│   │   ├── caja/          Caja, MovimientoCaja
│   │   ├── boleta/        DocumentoTributario + proveedores/ (puerto DTE) [MOCK]
│   │   ├── dashboard/     selectors (sin modelos)
│   │   ├── prediccion/    ModeloPrediccion, PrediccionDemanda (puente a ml/)
│   │   └── reposicion/    ParametroReposicion, RecomendacionReposicion, formulas
│   ├── deploy/            backup_db.sh
│   ├── requirements.txt / requirements-dev.txt
│   └── Dockerfile / entrypoint.sh
├── frontend/
│   ├── src/app/
│   │   ├── core/          auth (AuthService, guards, interceptores), servicios
│   │   ├── shared/        componentes/pipes/utilidades reutilizables
│   │   ├── layouts/       main-layout, header, sidebar, navegacion.ts
│   │   └── features/      una carpeta por módulo (dashboard, usuarios, catalogo,
│   │                      inventario, alertas, proveedores, compras, ventas,
│   │                      caja, boletas, prediccion, reposicion)
│   ├── Dockerfile / nginx.conf
│   └── deploy/htaccess-spa
├── ml/                    src/{config,dataset,features,evaluate,train,predict}.py
│                          notebooks/, tests/
├── loadtest/              k6/ (smoke, load, login, stress, spike, stock_concurrente)
└── docs/                  esta carpeta
```

## 11. Base de datos MariaDB

- **Motor**: `django.db.backends.mysql` con **PyMySQL** (mysqlclient no compila
  en el hosting compartido). Charset `utf8mb4`, `sql_mode` estricto
  (`STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO`),
  `CONN_MAX_AGE=60`.
- **Índices únicos condicionales**: MariaDB **no** los soporta (Django los
  ignora en MySQL). Las reglas "una caja `ABIERTA` por usuario" y "un solo
  `ModeloPrediccion` activo" se garantizan en la **capa de servicios**
  (`select_for_update` + validación), no con un índice.
- **`CHECK` constraints**: soportadas y usadas (p. ej. stock ≥ 0, cantidades ≥ 0).
- **Correlativos**: `core.Secuencia` (fila por nombre) con bloqueo de fila para
  folios de venta y códigos de orden de compra.
- **Migraciones**: ~24 archivos, incluyendo *data migrations* idempotentes que
  cargan permisos, roles, parámetros del sistema y reglas de alerta.
- Producción: `zmgtmpop_pospicking` / usuario `zmgtmpop_pos`.

## 12. Modelo de datos

Documento de referencia: **`docs/02-modelo-datos.md`**.

Entidades principales por dominio:

- **Seguridad**: `Usuario` (custom, `AUTH_USER_MODEL`), `Rol` (M2M `Permiso`),
  `Permiso` (código `modulo.accion`), `IntentoLogin`.
- **Catálogo**: `Categoria`, `Marca`, `Producto` (SKU único, código de barras
  único opcional, precios CLP enteros con IVA incluido, `precio_mayorista`).
- **Inventario**: `Ubicacion`, `Stock` (por producto+ubicación),
  `ParametroInventario` (mínimo, punto de reposición, stock de seguridad,
  múltiplo de compra), `MovimientoInventario` (**append-only**: guarda
  `stock_antes`/`stock_despues`, tipo, documento origen, usuario).
- **Proveedores**: `Proveedor` (RUT validado, `lead_time_dias`),
  `ProductoProveedor` (costo, código del proveedor, preferente).
- **Compras**: `OrdenCompra` (`BORRADOR → EMITIDA → RECIBIDA_PARCIAL →
  RECIBIDA | ANULADA`), `LineaOrdenCompra`, `RecepcionCompra`, `LineaRecepcion`.
- **Ventas**: `Venta` (folio, estado, `es_mayorista`, FK `caja`), `LineaVenta`
  (descripción y precios "congelados" al momento de la venta), `PagoVenta`
  (medio, monto), `AutorizacionDescuento`, `DevolucionVenta` + `LineaDevolucion`.
- **Caja**: `Caja` (una `ABIERTA` por usuario), `MovimientoCaja`
  (`INGRESO`/`EGRESO`, ligado a venta si es efectivo).
- **Boleta**: `DocumentoTributario` (1:1 con `Venta`, DTE 39),
  `RespuestaProveedorDTE`, `EventoDTE`.
- **Predicción**: `ModeloPrediccion` (versión, algoritmo, métricas, activo),
  `PrediccionDemanda` (producto, horizonte, demanda estimada, desviación, fuente).
- **Reposición**: `ParametroReposicion` (singleton: Z, horizonte, período de
  revisión), `RecomendacionReposicion` (`SUGERIDA → APROBADA | DESCARTADA →
  ORDENADA`, con todos los *inputs* de la fórmula).
- **Core**: `ParametroSistema` (singleton: datos del emisor, IVA %, redondeo
  efectivo, tope de descuento del vendedor, moneda, proveedor DTE), `Secuencia`.

## 13. API REST

- **Base**: `/api/v1/`. Convención DRF con *slash* final (`APPEND_SLASH`).
- **Autenticación**: `Authorization: Bearer <access>` (JWT). Sin cookies.
- **Paginación** estándar: `{conteo, paginas, pagina_actual, siguiente,
  anterior, resultados}` (25 por página).
- **Filtros**: `django-filter` + `SearchFilter` + `OrderingFilter`.
- **Errores**: envoltura unificada (§4).
- **Throttling**: `login` 10/min, `anon` 60/min, `user` 2000/h,
  `prediccion_calcular` 60/h (todos configurables por entorno).
- **Documentación OpenAPI**: `drf-spectacular`. `/api/v1/schema/`,
  `/api/v1/docs/` (Swagger UI) y `/redoc/` **solo con `DEBUG=True`**; en
  producción se genera con `manage.py spectacular`.

### Endpoints (resumen)

| Prefijo | Recurso / acciones |
|---|---|
| `auth/` | `login/`, `refresh/`, `logout/`, `me/`, `cambiar-password/` |
| `usuarios/` | CRUD + `activar` `desactivar` `resetear-password` |
| `roles/` | listar/ver + `permisos/` (PUT) |
| `permisos/` | catálogo (solo lectura) |
| `catalogo/categorias/` · `catalogo/marcas/` | CRUD + `activar` |
| `catalogo/productos/` | CRUD + `activar` + `por-codigo/{c}/` + `por-sku/{s}/` |
| `inventario/ubicaciones/` `stock/` `parametros/` | consultas / CRUD |
| `inventario/movimientos/` | historial + `registrar/` + `ajustar/` |
| `proveedores/` | CRUD + `activar` `productos` `asociar-producto` `quitar-producto` |
| `compras/ordenes/` | CRUD + `emitir` `anular` `recibir` `recepciones` |
| `compras/recepciones/` | historial |
| `ventas/` | listar/ver + `calcular/` + `create` (confirmar) + `anular/` |
| `cajas/` | listar/ver + `abrir/` `mi-caja/` `cerrar` `ingreso` `egreso` `arqueo` `movimientos` |
| `boletas/` | listar/ver + `imprimir` (HTML) `reintentar` `anular` |
| `alertas/` | listar/ver + `resumen/` `marcar-vista` `resolver` `resolver-varias/` |
| `reglas-alerta/` | listar/ver + editar |
| `dashboard/` | `resumen/` `ventas/` `productos-top/` `inventario/` `compras/` |
| `prediccion/modelos/` | listar/ver + `entrenar/` `sincronizar/` |
| `prediccion/demanda/` | listar/ver + `calcular/` |
| `reposicion/recomendaciones/` | listar/ver + `generar/` `aprobar` `descartar` `generar-orden/` |
| `reposicion/parametros/` | ver / editar |
| `health/` | *healthcheck* público |

## 14. Autenticación

- **JWT** (`rest_framework_simplejwt`): `access` de 15 min, `refresh` de 1 día.
- **Rotación de refresh** activada (`ROTATE_REFRESH_TOKENS`) +
  *blacklist* del anterior (`BLACKLIST_AFTER_ROTATION`).
- `POST /auth/login/` → `{access, refresh, usuario}` (incluye permisos efectivos).
- `POST /auth/refresh/` → nuevo par `{access, refresh}`.
- `POST /auth/logout/` → *blacklist* del refresh.
- **La autorización se resuelve siempre contra la BD**, nunca contra el claim
  del token: un cambio de rol tiene efecto inmediato.
- Clase de autenticación propia `JWTAuthAuditoria`: además de validar el token,
  registra el usuario en el contexto de la petición para los logs.
- **Bloqueo por fuerza bruta**: `IntentoLogin` cuenta los fallos por usuario;
  tras `LOGIN_MAX_INTENTOS` en `LOGIN_BLOQUEO_MINUTOS` responde `429`. Cubre
  también `/admin/login/` (vía las señales `user_login_failed`/`user_logged_in`).
- Al **cambiar o resetear** la contraseña se ponen en *blacklist* todos los
  refresh vigentes del usuario.
- **Frontend**: `access` en memoria, `refresh` en `localStorage`; el
  interceptor renueva el token ante un `401` y reintenta una vez; si el refresh
  falla, cierra la sesión.

## 15. Roles y permisos

- **35 permisos** con código `modulo.accion` (fuente única:
  `apps/usuarios/permisos.py`), cargados por *data migration*.
- **4 roles**: `administrador` (todos), `bodeguero`, `vendedor`, `mayorista`
  (reservado, solo `catalogo.ver`).
- Clases DRF: `TienePermiso.para("x")` y `PermisoPorAccion` (dict acción→código).
  **Fail-closed**: si una acción no declara permiso, se niega.
- `Usuario.tiene_permiso(codigo)` revalida `is_active` y `rol.activo`;
  `is_superuser` concede todo.
- El *scoping* de datos ("solo mis ventas/boletas") se basa en el permiso
  `dashboard.ver_completo`, no en el nombre del rol.

## 16. Productos

- `Categoria`, `Marca` y `Producto` con CRUD completo; `DELETE` **desactiva**
  (no borra).
- Producto: `sku` único, `codigo_barras` único opcional (se normaliza a
  mayúsculas sin espacios; `NULL` si vacío), `unidad_medida`
  (UN/KG/LT/MT/CJ), `precio_venta` y `precio_mayorista` (enteros CLP con IVA
  incluido), `costo_referencial`, `afecto_iva`.
- Endpoints de POS: `por-codigo/{codigo}/` (404 si no existe, 409 si inactivo)
  y `por-sku/{sku}/`.
- Permisos: `catalogo.ver` / `catalogo.administrar`.

## 17. Inventario

- **Stock por producto + ubicación**. `MovimientoInventario` es un **libro
  mayor append-only**: cada movimiento registra `stock_antes`, `stock_despues`,
  tipo, motivo, documento de origen y usuario.
- Servicio central `apps/inventario/services.py`: `registrar_movimiento`,
  `entrada`, `salida`, `ajustar_a_cantidad`. Todo con `transaction.atomic` +
  `select_for_update`.
- **El stock nunca queda negativo**: lo impide el servicio y, como red de
  seguridad, un `CHECK` de BD → `409 stock_insuficiente`.
- `ParametroInventario` por producto: `stock_minimo`, `punto_reposicion`,
  `stock_seguridad`, `multiplo_compra`.
- Ajustes manuales requieren `inventario.ajustar`; los movimientos, `inventario.mover`.

## 18. Trazabilidad

Toda variación de stock deja un `MovimientoInventario` con su origen tipado
(`COMPRA`, `VENTA`, `DEVOLUCION`, `AJUSTE_POSITIVO/NEGATIVO`, `CONTEO`,
`TRASPASO_*`) y el documento asociado (`doc_tipo`/`doc_id`). El historial es
consultable por SKU, tipo y fecha en `/api/v1/inventario/movimientos/` y en la
pantalla **Movimientos** del frontend. Además, cada petición lleva un
`X-Request-ID` que aparece en los logs (`~/pos-backend/logs/app.log`).

## 19. POS

Pantalla `/pos` del frontend:

- **Lectura de código de barras**: `EscanerCodigoBarras` detecta un lector
  *keyboard-wedge* por la velocidad de tecleo (< 50 ms entre teclas) + Enter
  final. La escritura manual nunca alcanza ese umbral, así que no colisiona.
  Alternativa manual: escribir el código/SKU/nombre y pulsar «Agregar».
- Flujo por cada lectura: buscar → verificar que exista (404) → que esté activo
  (409) → verificar stock disponible contra lo que ya hay en el carrito →
  agregar / sumar cantidad. **No se agregan productos inválidos.**
- Carrito con cantidad y descuento por línea, *toggle* de precio mayorista.
- Totales en vivo vía `POST /ventas/calcular/` (no persiste).
- Pagos múltiples con validación de cuadre (pagado == total a cobrar).
- Si el descuento supera el tope del vendedor, exige **autorización de un
  supervisor** (usuario + contraseña con `ventas.autorizar_descuento`).
- Al confirmar, abre la **boleta** para imprimir.
- Exige una **caja abierta**.

## 20. Ventas

- `POST /ventas/` (`confirmar_venta`): transacción que descuenta stock
  (`select_for_update` → sin sobreventa), registra los pagos (deben cuadrar),
  crea el `MovimientoCaja` por cada pago en efectivo, crea el
  `DocumentoTributario` en estado `PENDIENTE` y, **tras el commit**, intenta
  emitir la boleta ([MOCK], §28). Si la emisión falla, la venta queda
  consistente y el cron reintenta.
- `POST /ventas/calcular/`: *preview* de neto, IVA, exento, descuentos,
  redondeo y total a cobrar, sin persistir.
- `POST /ventas/{id}/anular/`: solo el **mismo día**, por rol autorizado;
  reingresa el stock (`DEVOLUCION`) y marca la boleta anulada.
- El vendedor ve solo sus ventas; el resto ve todas (`dashboard.ver_completo`).
- Parámetros de negocio en `ParametroSistema`: IVA 19 %, redondeo a $10, tope
  de descuento del vendedor 5 %.

## 21. Caja

- `Caja` ligada al **usuario**: una sola `ABIERTA` a la vez (garantía en el
  servicio con bloqueo de fila).
- `abrir_caja(monto_inicial)`, `registrar_movimiento` (ingreso/egreso),
  `arqueo` y `cerrar_caja(monto_contado)` → calcula:
  `saldo_esperado = inicial + Σ ventas_efectivo + Σ ingresos − Σ egresos` y la
  `diferencia` contra lo contado.
- `confirmar_venta` exige caja abierta (`409 caja_no_abierta`).
- Pantalla `/caja`: apertura, arqueo en vivo, ingreso/egreso, cierre con
  diferencia, historial de movimientos.

## 22. Compras

- `OrdenCompra`: `BORRADOR → EMITIDA → RECIBIDA_PARCIAL → RECIBIDA | ANULADA`.
- `crear_orden` / `emitir_orden` / `anular_orden` / `recibir` (transaccional).
  **Crear y emitir NO tocan stock**; solo `recibir` genera el
  `MovimientoInventario` (tipo `COMPRA`), actualiza `costo_referencial` y
  recalcula el estado (parcial vs total).
- `stock_en_transito` alimenta la recomendación de reposición.
- Código de orden por `core.Secuencia`.
- Pantallas `/compras` (lista + "Nueva orden") y `/compras/:id` (detalle con
  emitir/anular/recibir y las recepciones).

## 23. Proveedores

- `Proveedor` con RUT validado (módulo 11), `lead_time_dias` (→ `lead_time_semanas`).
- `ProductoProveedor`: costo, código del proveedor, `es_preferente`.
- CRUD (`DELETE` desactiva) + acciones `productos`, `asociar-producto`,
  `quitar-producto`. Permisos `proveedores.ver` / `proveedores.administrar`.

## 24. Alertas

Documento de referencia: **`docs/00-analisis-requisitos.md` (Módulo I)**.

- `ReglaAlerta` (una fila por tipo: activa, severidad, `holgura_pct`), editable
  con `alertas.configurar`.
- `motor.py` + comando `generar_alertas` (cron cada 15 min): escanea el
  inventario y crea `STOCK_BAJO`, `SIN_STOCK`, `REPOSICION`; **cierra**
  automáticamente las que se normalizan.
- `Alerta`: estados `NUEVA → VISTA → RESUELTA`, con deduplicación diaria por
  tipo+producto.
- API: filtros, `/resumen`, `marcar-vista`, `resolver`, `resolver-varias`.
- El servicio de boleta genera una alerta `DTE_FALLIDO` tras agotar los reintentos.

## 25. Dashboard

- `apps/dashboard/selectors.py` (sin modelos): `kpis_ventas`, `serie_ventas`
  (`Trunc` día/semana/mes), `productos_mas_vendidos`, `kpis_inventario`
  (valorizado + rotación), `kpis_compras`, `kpis_reposicion`, `estado_caja`,
  `kpis_alertas`. Todo con `aggregate`/`annotate` (sin N+1, verificado con
  `assertNumQueries`).
- `GET /dashboard/resumen|ventas|productos-top` con `dashboard.ver` (el
  vendedor ve solo lo suyo); `/inventario|compras` con `dashboard.ver_completo`.
- Fechas `desde`/`hasta` validadas → `400 fecha_invalida` si el formato es incorrecto.

## 26. Predicción de demanda

Documentos de referencia: **`docs/13-prediccion-demanda.md`** (paquete `ml/`) y
**`docs/14-reposicion.md`**.

- **Paquete `ml/`** (Python puro, sin Django): dataset, features, entrenamiento
  y predicción. `train.py` compara baselines (naive estacional, media móvil,
  ridge, random forest), hace *split* temporal de 12 semanas y elige por MAE.
  Random Forest ganó (MAE ≈ 9,15). El artefacto se guarda como
  `ml/models/demanda_actual.joblib` + `.metrics.json`.
- **Datos [SINTÉTICOS]**: no hay volumen de ventas real, así que el modelo se
  entrena con un **dataset sintético realista** marcado como tal (decisión
  D13). `historia_real()` usa `ventas.LineaVenta` cuando hay ≥ `MIN_SEMANAS_
  HISTORIA` semanas con ventas (6 por defecto, configurable con
  `ML_MIN_SEMANAS_HISTORIA`; 12 es el alcance completo — RF-K8); si no, cae al
  sintético (si `PREDICCION_PERMITIR_SINTETICO`). La arquitectura está lista
  para reentrenar con datos reales.
- Granularidad: **semanal por producto** (D12).
- `apps/prediccion`: `ModeloPrediccion` (metadatos), `PrediccionDemanda`
  (resultado). Comandos `entrenar_demanda`, `predecir_demanda`.
- API: `prediccion/modelos/` (`entrenar`, `sincronizar`), `prediccion/demanda/`
  (`calcular`, con *throttle* propio de 60/h; admite `minimo_semanas` para
  probar el mecanismo de RF-K8 con un umbral puntual sin cambiar la
  configuración general).
- No se predice un producto con menos semanas de historia que el mínimo
  configurado (`422 datos_insuficientes`).

## 27. Recomendación de reposición

- `apps/reposicion/formulas.py` — **fórmula pura v1** (sin Django):
  - Stock de seguridad: `SS = Z · σ · √(L + R)`
  - Punto de pedido: `ROP = d · (L + R) + SS`
  - Cantidad a pedir: `Q = ⌈ max(0, ROP − (stock + tránsito)) / m ⌉ · m`
  - con `Z` (nivel de servicio), `σ` (desviación de la demanda), `L` (lead
    time), `R` (período de revisión), `d` (demanda por semana), `m` (múltiplo
    de compra). Guarda todos los *inputs* y un `motivo` legible.
- `ParametroReposicion` (singleton) configurable con `reposicion.ejecutar`.
- `RecomendacionReposicion`: `SUGERIDA → APROBADA | DESCARTADA → ORDENADA`.
- **No recomienda** sin predicción de demanda ni sin proveedor.
- `generar_orden_compra(ids)` agrupa recomendaciones APROBADAS del **mismo
  proveedor** y crea una `OrdenCompra` en borrador.
- Comando `calcular_reposicion` (cron diario 06:30). API:
  `reposicion/recomendaciones/` (`generar`, `aprobar`, `descartar`,
  `generar-orden`).

## 28. Boleta electrónica — **[MOCK]**

- `apps/boleta`: `DocumentoTributario` (1:1 con `Venta`, **DTE 39** – boleta
  electrónica), `RespuestaProveedorDTE`, `EventoDTE`.
- **Integración simulada** (decisión D4): puerto `ProveedorDTE` +
  implementación `ProveedorDTEMock` que asigna un folio incremental y un timbre
  ficticio y acepta al instante. **No hay conexión real con el SII.**
  `DTE_MOCK_FORZAR_FALLO` / `DTE_MOCK_FALLA_PROB` permiten simular fallos.
- Estados: `PENDIENTE → EMITIDO → ACEPTADO | RECHAZADO | ANULADO`.
- `confirmar_venta` crea el documento `PENDIENTE` dentro de la transacción y,
  tras el commit, llama a `emitir_seguro` (si falla, la venta queda
  consistente). El comando `reintentar_dte` (cron cada 10 min) reprocesa los
  pendientes; tras `MAX_INTENTOS` marca `DTE_FALLIDO` y genera una alerta.
- `GET /boletas/{id}/imprimir/` devuelve el **HTML** de la boleta (todos los
  valores dinámicos escapados); el frontend lo muestra en un `<iframe sandbox>`
  sin `allow-scripts`.
- La representación indica **"Documento simulado — no válido tributariamente"**.

## 29. Testing

Documento de referencia: **`docs/18-auditoria-testing.md`**.

- **Backend**: **249 tests** (pytest + pytest-django), ~96 % de líneas.
  Cubre unidad, integración (transacciones + `select_for_update`), API (todos
  los ViewSets), autenticación, permisos por rol, inventario (no negativo),
  ventas, compras, caja, alertas, dashboard (sin N+1), predicción y reposición.
- **Paquete `ml/`**: 5 tests (`pytest ml/tests`).
- **Frontend**: **30 tests** (Vitest) — pipes, `token-storage`, guards
  (`authGuard`, `invitadoGuard`, `permisoGuard`), interceptores (`error`,
  `jwt` con el flujo 401→refresh→reintento→logout), `api.service`, detector de
  código de barras.
- **Calidad**: `ruff` (backend), ESLint (frontend), `pip-audit` (sin CVE).
- Flujos identificados para E2E (Cypress/Playwright, fuera de alcance por ahora):
  login+refresh, venta completa en el POS, descuento con autorización,
  apertura/cierre de caja, recepción de compra, reposición→OC, guard por rol.

## 30. Seguridad

Documento de referencia: **`docs/19-auditoria-seguridad.md`** (auditoría de 22
hallazgos + remediación; 20 corregidos).

Controles implementados:

- **JWT** con rotación + *blacklist*; autorización siempre contra la BD.
- **Contraseñas**: hasher PBKDF2, validadores (mínimo 8, común, numérica,
  similitud), nunca se registran.
- **Autorización** *deny-by-default* (`IsAuthenticated` global + matriz de
  permisos *fail-closed*).
- **Sin SQL crudo** — 100 % ORM (sin `raw`/`extra`/`cursor`).
- **XSS**: Angular escapa por defecto; la única inserción de HTML (la boleta)
  va con el backend escapando **y** un `<iframe sandbox>` sin `allow-scripts`.
- **Fuerza bruta**: bloqueo por `IntentoLogin` + *throttling* DRF; `NUM_PROXIES`
  fijado para que no se evada con `X-Forwarded-For`.
- **Producción**: HSTS, `SECURE_SSL_REDIRECT`, cookies `Secure`, `nosniff`,
  `X-Frame-Options: DENY`, `Referrer-Policy`. `prod.py` no arranca sin las
  claves. Admin en ruta ofuscable. Cache de *throttling* compartida
  (`FileBasedCache`).
- **Secretos**: `.env` y llaves fuera de git (verificado en la historia);
  `.dockerignore` correcto.
- **Dependencias**: `pip-audit` limpio; Django 5.2.17 / DRF 3.17.2 al día.

Pendiente de hardening operativo (fuera del código): 2FA de la cuenta cPanel,
SSH solo-llave.

## 31. Pruebas de carga

Documento de referencia: **`loadtest/README.md`**.

- Herramienta **k6**. Escenarios: `smoke`, `load` (día normal, 30→60 VUs),
  `login` (tasa constante), `stress` (0→500 VUs), `spike` (5→120 en 10 s),
  `stock_concurrente` (40 VUs vendiendo el mismo SKU → verifica que **no hay
  sobreventa**).
- `manage.py seed_carga` prepara usuarios y catálogo de carga.
- **SLO**: lectura p95 < 500 ms, cálculo < 900 ms, escritura < 1500 ms, login
  < 1500 ms, *error rate* < 1 %, invariante de no-sobreventa.
- Se corre contra `docker-compose` (MariaDB) o *staging*, **nunca** contra el
  cPanel de producción (términos del hosting compartido).
- Baseline local (SQLite, no representativo de escritura): lecturas p95 ≈ 20 ms
  sin N+1; el camino de escritura de ventas es pesado (~0,8 s incluso a 1 VU) y
  debe medirse sobre MariaDB.

## 32. Docker

Documento de referencia: **`docs/21-docker.md`**.

- Stack: `db` (MariaDB 10.11, volumen `db_data`) + `backend` (multi-stage
  `python:3.12-slim`, gunicorn, usuario no-root, *healthcheck*) + `frontend`
  (multi-stage `node:22` → `nginx:1.27-alpine` que sirve la SPA y hace de
  *reverse-proxy* a `/api/ /admin/ /static/`).
- **Sin Redis** (no hay Celery/Channels).
- Redes internas, volúmenes con persistencia, *healthchecks*, `depends_on` con
  condición, `restart: unless-stopped`. Secretos solo por `.env` (nada
  hardcodeado).
- `docker compose up --build` levanta todo desde cero en `http://localhost:8080`.
- `docker-compose.dev.yml` expone MariaDB y afloja *throttles* para el flujo
  habitual (runserver + `npm start` en el host).

## 33. Deployment en V2Network

Documento de referencia: **`docs/21-deploy-v2network.md`** (plan completo +
comandos paso a paso + 5 ajustes reales que hubo que hacer).

- **Hosting**: cPanel + LiteSpeed + CloudLinux 9.8 (compartido). Sin
  root/Docker en el servidor.
- **Backend**: cPanel "Setup Python App" (LSAPI) con Python 3.13, venv en
  `~/virtualenv/pos-backend/3.13`, código en `~/pos-backend/`,
  `passenger_wsgi.py` → `config.settings.prod`, `.env` (chmod 600) en el
  *app root*. Reinicio: `touch ~/pos-backend/tmp/restart.txt`.
- **Frontend**: `ng build --configuration cpanel` en local → `dist/` subido a
  `~/public_html/` + `.htaccess` con *fallback* SPA.
- **URLs**: SPA en `systemspickingpos.cl`, API en el subdominio
  `api.systemspickingpos.cl` (evita líos de `SCRIPT_NAME`; CORS habilitado).
- **HTTPS**: AutoSSL (Let's Encrypt) para ambos dominios.
- **BD**: `zmgtmpop_pospicking` de cPanel (driver PyMySQL).
- **Cron**: `reintentar_dte` (10 min), `generar_alertas` (15 min),
  `calcular_reposicion` (06:30), `backup_db.sh` (03:00).
- **Actualizar**: `git pull` en `~/src/pos-picking` → `rsync` a `~/pos-backend/`
  → `touch tmp/restart.txt`.

## 34. Backups

- **`backend/deploy/backup_db.sh`** (cron diario 03:00): `mysqldump
  --single-transaction` de `zmgtmpop_pospicking` (credenciales leídas del
  `.env`) → `~/backups/pospicking_AAAA-MM-DD_HHMM.sql.gz`, **retención 7 días**.
- Antes de cada deploy: `mysqldump` manual + copia de `~/pos-backend`.
- **Rollback**: restaurar `~/pos-backend` desde la copia + `touch
  tmp/restart.txt`; y `zcat backup.sql.gz | mysql zmgtmpop_pospicking` solo si
  una migración falló.
- Adicionalmente, backups de cuenta a nivel del proveedor de hosting.

## 35. Solución de problemas

| Síntoma | Causa / solución |
|---|---|
| `pip install mysqlclient` falla (`pkg-config`, `mysql_config`) | El hosting no tiene las cabeceras. Se usa **PyMySQL** (ya en `requirements.txt` + shim en `config/__init__.py`). |
| `OpenBLAS blas_thread_init: pthread_create failed` / comandos colgados | numpy intenta crear ~40 hilos y choca con el límite LVE. `config/__init__.py` fija `OPENBLAS_NUM_THREADS=1`. |
| `manage.py` usa `config.settings.local` en el servidor | No lee el `.env` a tiempo. Prefijar `DJANGO_SETTINGS_MODULE=config.settings.prod` (o `export`). |
| `django.db.utils.OperationalError: (2002 ...)` al migrar | Socket de MariaDB. Probar `DB_HOST=127.0.0.1` en vez de `localhost` (o viceversa). |
| El backend arranca pero da `ImproperlyConfigured` | Falta `DJANGO_SECRET_KEY` / `JWT_SIGNING_KEY` / `DJANGO_ALLOWED_HOSTS` en el `.env` (fail-fast deliberado). |
| `500` al abrir la boleta con nombres raros | Ya mitigado: el HTML escapa todo y el `<iframe>` es `sandbox` sin scripts. |
| `429` inesperados en pruebas de carga | *Throttle* de `login`/`user`. Subir `DJANGO_LOGIN_RATE` / `DJANGO_USER_RATE` en el entorno de prueba. |
| El vendedor no ve un menú/sección | Correcto: el sidebar se filtra por permisos. La autoridad es el backend. |
| Sesión se cierra al recargar dos veces | Ya corregido (Etapa 16): `AuthService.refrescar()` guarda el `refresh` rotado. |
| `301` en llamadas a la API | Falta el *slash* final (DRF `APPEND_SLASH`). `ApiService` lo añade siempre. |
| La documentación Swagger no aparece en producción | Es a propósito: `schema/`/`docs/` solo con `DEBUG=True`. Usar `manage.py spectacular`. |
| Muchos intentos de fuerza bruta por SSH | Activar 2FA en cPanel, cambiar la contraseña, pasar SSH a solo-llave. |
| Predicción responde `422 datos_insuficientes` | El producto tiene < 12 semanas con ventas y no se permite el dataset sintético en ese entorno. |

---

## Anexo — Documentos del proyecto

| Documento | Contenido |
|---|---|
| `docs/00-analisis-requisitos.md` | análisis de requisitos por módulo |
| `docs/01-arquitectura.md` | arquitectura detallada |
| `docs/02-modelo-datos.md` | modelo de datos (entidades y relaciones) |
| `docs/13-prediccion-demanda.md` | paquete `ml/` — predicción de demanda |
| `docs/14-reposicion.md` | fórmulas de reposición |
| `docs/18-auditoria-testing.md` | auditoría de testing |
| `docs/19-auditoria-seguridad.md` | auditoría de seguridad + remediación |
| `docs/21-docker.md` | dockerización |
| `docs/21-deploy-v2network.md` | deployment en cPanel |
| `docs/22-documentacion-tecnica.md` | este documento |
| `docs/DECISIONES.md` | registro de decisiones (D1–D21) |
| `docs/COMO-VER-EL-PROYECTO.md` | guía rápida para explorar el sistema |
| `loadtest/README.md` | estrategia y scripts de pruebas de carga |
