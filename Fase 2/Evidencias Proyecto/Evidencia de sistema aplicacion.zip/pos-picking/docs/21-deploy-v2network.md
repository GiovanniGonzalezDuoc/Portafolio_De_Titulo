# Etapa 21.2 — Deploy en V2Network (cPanel)

**Base:** `Contexto/Promp Claude.md` (Prompt 21.2), reconocimiento del servidor
(2026-09-07), `docs/19-auditoria-seguridad.md`.

> **Reglas de esta etapa:** sin comandos destructivos, no se borra ningún dato,
> se prioriza la seguridad y la persistencia de MariaDB. Este documento es el
> **plan + los comandos paso a paso**; los ejecuta el usuario (o Claude por SSH
> con llave, en los pasos no destructivos).

> ## ✅ Estado: desplegado y funcionando (2026-09-07)
>
> - SPA: **https://systemspickingpos.cl** — login OK, dashboard OK.
> - API: **https://api.systemspickingpos.cl/api/v1/health/** → `200`.
> - BD `zmgtmpop_pospicking` migrada · superusuario creado · AutoSSL en ambos
>   dominios · CORS verificado · cron (DTE / alertas / reposición / backup)
>   activo · backup diario probado.
>
> **Ajustes reales que hubo que hacer (no estaban en el plan inicial):**
>
> 1. **`mysqlclient` no compila** en el venv de cPanel (sin cabeceras MySQL /
>    `pkg-config`). → `PyMySQL` + shim en `config/__init__.py`.
> 2. **`pandas`/`numpy`/`scikit-learn` faltaban en `requirements.txt`** (estaban
>    solo en `-dev`) pero `apps.prediccion` los necesita al cargar la URLconf.
>    → movidos a `requirements.txt` **y** `import pandas` hecho perezoso en
>    `apps/prediccion/services.py` (la web ya no carga el stack de ML).
> 3. **OpenBLAS intentaba crear ~40 hilos** (uno por núcleo del nodo) y chocaba
>    con el límite LVE → los comandos se colgaban. → `config/__init__.py` fija
>    `OPENBLAS_NUM_THREADS=1` (+ OMP/MKL/NUMEXPR) antes de importar numpy.
> 4. `manage.py` no lee `DJANGO_SETTINGS_MODULE` del `.env` a tiempo → hay que
>    exportarlo (`export DJANGO_SETTINGS_MODULE=config.settings.prod`) o
>    pasarlo inline en cada comando/cron.
> 5. La llave SSH de Claude no llegó a funcionar (probable SELinux en `~/.ssh`);
>    todo se hizo con el usuario ejecutando y pegando la salida.

---

## 1. Análisis de infraestructura

| Aspecto | Situación real (reconocimiento) | Decisión |
|---|---|---|
| **Servidor** | Hosting compartido cPanel, nodo `s560.v2nets.com`, IP `216.185.51.20`. LiteSpeed + CloudLinux 9.8 (kernel 5.14 el9). Imunify360 (WAF) activo. | Sin cambios: se usa tal cual. Deploy vía **cPanel "Setup Python App"** (LSAPI) + estático en `public_html`. |
| **CPU** | Nodo: 41 vCPU. Cuenta: límite LVE (ver cPanel → *Resource Usage*; plan compartido ≈ 100–200 % = 1–2 núcleos, ráfagas). | Backend con **pocos procesos** (LSAPI ajusta solo; `Maximum Application Instances` = 3–5). Nada de procesos permanentes pesados. |
| **RAM** | Nodo: 88 GB (52 GB en uso, swap alto). Cuenta: límite LVE PMEM (típico 1–2 GB). | Django arranca en ~90–120 MB/worker. Cabe. Sin Redis. |
| **Almacenamiento** | Volumen del nodo 7 TB (74 %). Uso de la cuenta: 4.3 MB. Cuota: ver cPanel (típico 10–50 GB). | App + venv + estáticos ≈ 250–400 MB. Sobra. |
| **SO** | CloudLinux 9.8 (RHEL9). Sin root/sudo. CageFS (jailed). SELinux. | — |
| **Python** | Disponibles: `/opt/alt/python{27,33..313}`. **3.13 disponible** → iguala el entorno de desarrollo. | Setup Python App con **Python 3.13**. |
| **Node.js** | **No instalado.** | Angular se **compila en local** (`ng build --configuration cpanel`) y se sube `dist/`. |
| **Puertos** | 443 (HTTPS, LiteSpeed) · 54327 (SSH). MariaDB solo socket local. | La app Python no expone puerto (LSAPI). Nada que abrir. |
| **Dominio** | `systemspickingpos.cl` (principal, AutoSSL activo). Sin subdominios. | **Crear `api.systemspickingpos.cl`** para la API. SPA en el dominio principal. |
| **HTTPS** | cPanel **AutoSSL** (Let's Encrypt) ya emite para el dominio principal y `www`. Carpeta `~/ssl`, `.well-known` OK. | AutoSSL cubre el subdominio nuevo automáticamente (puede tardar hasta 1 h). Forzar HTTPS con `SECURE_SSL_REDIRECT` (Django) + redirección en `.htaccess`. |
| **Variables de entorno** | No hay `.env` ni venv. | `~/pos-backend/.env` (**fuera** de `public_html`, permisos `600`). Lo lee `config.settings.prod` vía `DJANGO_ENV_FILE`. |
| **MariaDB** | Servidor 10.11.19, socket local. **Sin bases de datos creadas.** | Crear `zmgtmpop_pospicking` + usuario `zmgtmpop_pos` (cPanel → MySQL Databases). Charset utf8mb4. |
| **Backups** | Backups de cuenta a nivel proveedor (JetBackup, no confirmado). | Añadir **`mysqldump` diario por cron** a `~/backups/` (retención 7 días). Además exportar antes de cada deploy. |
| **Firewall** | Gestionado por el proveedor (CSF/LFD probable) + Imunify360. Sin acceso. | No se toca. SSH: **19+ intentos de fuerza bruta** registrados → pasar a **solo llave** (cPanel → SSH Access) tras el deploy. |
| **Logs** | `~/logs/` (php, etc.), `~/access-logs` → domlogs de Apache/LiteSpeed. | Django → `~/pos-backend/logs/` (rotación ya configurada en `settings.base`). Errores de LSAPI → `~/pos-backend/stderr.log` / cPanel. |
| **Monitoreo** | cPanel *Metrics* / *Errors*; Imunify360. | Endpoint `GET /api/v1/health/` + un chequeo externo (UptimeRobot free, opcional). Cron de alertas/DTE ya existe. |

### Arquitectura del deployment

```
Internet ──HTTPS 443──►  LiteSpeed (cPanel)
                          │
   systemspickingpos.cl ──┤──►  ~/public_html/            SPA Angular (estática)
                          │      └ .htaccess: fallback SPA + cache + headers
                          │
api.systemspickingpos.cl ─┴──►  LSAPI  ──►  ~/pos-backend/passenger_wsgi.py
                                              │  venv: ~/virtualenv/pos-backend/3.13
                                              │  DJANGO_SETTINGS_MODULE=config.settings.prod
                                              │  WhiteNoise sirve /static/ (admin, DRF)
                                              ▼
                                        MariaDB (socket)  zmgtmpop_pospicking
```

- **No hay gunicorn en el servidor**: LSAPI gestiona los procesos WSGI. `gunicorn`
  queda en `requirements.txt` solo para Docker.
- **SPA y API en orígenes distintos** → se usa CORS (ya implementado y probado).
  El build de cPanel (`environment.cpanel.ts`) apunta a `https://api.systemspickingpos.cl/api/v1`.

---

## 2. Preparación en local (antes de tocar el servidor)

```powershell
cd E:\ProyectoPortafolio

# 1. Frontend: build para cPanel (API en el subdominio)
cd frontend
npm ci
ng build --configuration cpanel
#   → dist/frontend/browser/   (esto se sube a ~/public_html/)

# 2. Generar los secretos de producción (guárdalos, se ponen en el .env del servidor)
cd ..\backend
python -c "import secrets; print('DJANGO_SECRET_KEY=' + secrets.token_urlsafe(64))"
python -c "import secrets; print('JWT_SIGNING_KEY=' + secrets.token_urlsafe(64))"
python -c "import secrets; print('DB_PASSWORD=' + secrets.token_urlsafe(24))"

# 3. Verificar que la suite pasa (última red de seguridad)
$env:USE_SQLITE="True"; python -m pytest -q
```

Archivos que se suben al servidor:

| Local | Servidor |
|---|---|
| `backend/` (sin `.venv`, `db.sqlite3`, `__pycache__`, `logs/`, `staticfiles/`) | `~/pos-backend/` |
| `backend/passenger_wsgi.py` | `~/pos-backend/passenger_wsgi.py` |
| `frontend/dist/frontend/browser/*` | `~/public_html/` |
| `frontend/deploy/htaccess-spa` (contenido) | se **añade** a `~/public_html/.htaccess` |

---

## 3. Paso a paso en el servidor

> Prefijo para todo: `ssh -p 54327 zmgtmpop@systemspickingpos.cl`
> (o Claude por SSH con llave para los pasos de solo lectura / no destructivos).

### Paso 1 — MariaDB (cPanel UI o `uapi`)

**cPanel → Databases → MySQL® Databases:**
1. *Create New Database*: `pospicking` → queda `zmgtmpop_pospicking`.
2. *Add New User*: `pos` → queda `zmgtmpop_pos`, con la `DB_PASSWORD` generada.
3. *Add User To Database*: `zmgtmpop_pos` → `zmgtmpop_pospicking`, **ALL PRIVILEGES**.

Equivalente por SSH (no destructivo — falla si ya existe, no borra nada):
```bash
uapi Mysql create_database name=zmgtmpop_pospicking
uapi Mysql create_user name=zmgtmpop_pos password='<DB_PASSWORD>'
uapi Mysql set_privileges_on_database user=zmgtmpop_pos database=zmgtmpop_pospicking privileges=ALL
uapi Mysql list_databases     # verificar
```

### Paso 2 — Subdominio de la API

**cPanel → Domains → Create A New Domain:** `api.systemspickingpos.cl`
- Document Root: dejar el sugerido (`~/api.systemspickingpos.cl`) — no se usará para
  servir archivos (lo maneja LSAPI), pero cPanel lo necesita.
- Esperar a que **AutoSSL** emita el certificado (cPanel → SSL/TLS Status; hasta ~1 h).

### Paso 3 — Setup Python App

**cPanel → Software → Setup Python App → Create Application:**
| Campo | Valor |
|---|---|
| Python version | **3.13** |
| Application root | `pos-backend` |
| Application URL | `api.systemspickingpos.cl` (dominio completo, sin subruta) |
| Application startup file | `passenger_wsgi.py` |
| Application Entry point | `application` |

Al crear, cPanel muestra el comando para entrar al venv, del estilo:
```
source /home/zmgtmpop/virtualenv/pos-backend/3.13/bin/activate && cd /home/zmgtmpop/pos-backend
```

### Paso 4 — Subir el backend

Desde local (rsync respeta `.gitignore`-style con `--exclude`; **no borra** nada
fuera de lo que subimos porque no usamos `--delete`):
```powershell
# Windows: usar el rsync de Git for Windows, o WinSCP/FileZilla al mismo destino.
rsync -avz -e "ssh -p 54327" `
  --exclude ".venv" --exclude "db.sqlite3" --exclude "__pycache__" `
  --exclude "logs" --exclude "staticfiles" --exclude ".pytest_cache" `
  --exclude ".ruff_cache" --exclude ".env" `
  ./backend/ zmgtmpop@systemspickingpos.cl:~/pos-backend/

# El paquete ml/ (predicción de demanda) va VENDIDO dentro de ~/pos-backend/
# para que 'import ml' funcione (settings/base.py lo busca en BASE_DIR/ml).
rsync -avz -e "ssh -p 54327" `
  --exclude "__pycache__" --exclude ".pytest_cache" --exclude ".ruff_cache" `
  --exclude "data" --exclude "models" --exclude "notebooks" `
  ./ml/ zmgtmpop@systemspickingpos.cl:~/pos-backend/ml/
```
Alternativa sin rsync: `scp -P 54327 -r backend/* zmgtmpop@...:~/pos-backend/`
(y `scp -P 54327 -r ml zmgtmpop@...:~/pos-backend/ml`).

> El modelo entrenado (`ml/models/*.joblib`) NO se sube: se genera en el
> servidor con **Predicción → Entrenar** o `python manage.py entrenar_demanda`.
> El entrenamiento usa `ML_N_JOBS=1` por defecto (evita el límite de procesos
> de la cuenta); no hace falta configurarlo.
(y subir `passenger_wsgi.py` aparte).

Alternativa **git** (cPanel trae git): en cPanel → *Git Version Control* → *Create*,
repo `https://github.com/GiovanniGonzalezDuoc/pos-picking` (privado → hace falta
un *Personal Access Token* o *deploy key*); *checkout* a `~/pos-backend`. Luego
`git pull` para actualizar. El `dist/` de Angular igual hay que compilarlo en local.

### Paso 5 — `.env` de producción (en el servidor, fuera de public_html)

```bash
cat > ~/pos-backend/.env <<'EOF'
DJANGO_SETTINGS_MODULE=config.settings.prod
DJANGO_DEBUG=False
DJANGO_SECRET_KEY=<pegar el generado>
JWT_SIGNING_KEY=<pegar el generado>
DJANGO_ALLOWED_HOSTS=api.systemspickingpos.cl
DJANGO_SECURE_SSL_REDIRECT=True
DJANGO_NUM_PROXIES=1
DJANGO_LOG_DIR=/home/zmgtmpop/pos-backend/logs
DJANGO_ADMIN_URL=panel-9x7k2z/

USE_SQLITE=False
DB_NAME=zmgtmpop_pospicking
DB_USER=zmgtmpop_pos
DB_PASSWORD=<pegar el generado>
DB_HOST=localhost
DB_PORT=3306

CORS_ALLOWED_ORIGINS=https://systemspickingpos.cl,https://www.systemspickingpos.cl
CSRF_TRUSTED_ORIGINS=https://systemspickingpos.cl,https://www.systemspickingpos.cl,https://api.systemspickingpos.cl

JWT_ACCESS_MINUTES=15
JWT_REFRESH_DAYS=1
LOGIN_MAX_INTENTOS=5
LOGIN_BLOQUEO_MINUTOS=15

DTE_PROVEEDOR=mock
EOF
chmod 600 ~/pos-backend/.env
```
> `DB_HOST=localhost` con mysqlclient usa el **socket UNIX** local (lo que quiere
> el hosting). Si diera error de socket, probar `DB_HOST=127.0.0.1`.

### Paso 6 — Instalar dependencias, migrar, estáticos, superusuario

```bash
source ~/virtualenv/pos-backend/3.13/bin/activate
cd ~/pos-backend

pip install --upgrade pip
pip install -r requirements.txt
#   El hosting compartido no tiene las cabeceras para compilar `mysqlclient`,
#   por eso se usa `PyMySQL` (registrado como MySQLdb en `config/__init__.py`).
#   pandas/numpy/scikit-learn se instalan como wheels (sin compilar).

python manage.py check --deploy          # no debe haber errores críticos
python manage.py migrate                 # crea el esquema (NO borra nada; BD vacía)
python manage.py collectstatic --noinput # → ~/pos-backend/staticfiles (WhiteNoise)
python manage.py createsuperuser         # admin real (NO usar cargar_demo en prod)
```

### Paso 7 — Arrancar / reiniciar la app

```bash
mkdir -p ~/pos-backend/tmp
touch ~/pos-backend/tmp/restart.txt       # LSAPI recarga la app
```
(o el botón **Restart** en cPanel → Setup Python App).

Verificar:
```bash
curl -s https://api.systemspickingpos.cl/api/v1/health/
#   → {"estado":"ok","servicio":"pos-picking-api"}
```

### Paso 8 — Subir la SPA

```powershell
rsync -avz -e "ssh -p 54327" `
  ./frontend/dist/frontend/browser/ `
  zmgtmpop@systemspickingpos.cl:~/public_html/
```
En el servidor, **conservar** la página placeholder por si acaso y añadir el
`.htaccess` de la SPA **sin borrar el bloque de cPanel**:
```bash
cd ~/public_html
[ -f index.html.cpanel-default ] || mv index.html index.html.cpanel-default 2>/dev/null || true
#   (la SPA sube su propio index.html; la línea de arriba solo guarda el viejo si quedó)
cat >> .htaccess <<'EOF'

# ── SPA Angular (POS Picking) ──────────────────────────────
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteCond %{REQUEST_FILENAME} -f [OR]
  RewriteCond %{REQUEST_FILENAME} -d
  RewriteRule ^ - [L]
  RewriteRule ^ /index.html [L]
</IfModule>
<IfModule mod_headers.c>
  Header always set X-Content-Type-Options "nosniff"
  Header always set X-Frame-Options "DENY"
  Header always set Referrer-Policy "same-origin"
  <FilesMatch "\.(?:js|css|woff2?|png|jpe?g|gif|svg|ico)$">
    Header set Cache-Control "public, max-age=31536000, immutable"
  </FilesMatch>
  <FilesMatch "index\.html$">
    Header set Cache-Control "no-cache, must-revalidate"
  </FilesMatch>
</IfModule>
EOF
```
(contenido íntegro en `frontend/deploy/htaccess-spa`).

### Paso 9 — HTTPS

- cPanel → SSL/TLS Status: confirmar certificado válido para
  `systemspickingpos.cl`, `www` y `api.`.
- Forzar HTTPS en el dominio principal: cPanel → Domains → *Force HTTPS Redirect* (ON).
- La API ya redirige por `SECURE_SSL_REDIRECT=True`.

### Paso 10 — Cron (cPanel → Advanced → Cron Jobs)

| Frecuencia | Comando |
|---|---|
| `*/10 * * * *` | `~/virtualenv/pos-backend/3.13/bin/python ~/pos-backend/manage.py reintentar_dte >> ~/pos-backend/logs/cron.log 2>&1` |
| `*/15 * * * *` | `~/virtualenv/pos-backend/3.13/bin/python ~/pos-backend/manage.py generar_alertas >> ~/pos-backend/logs/cron.log 2>&1` |
| `30 6 * * *` | `~/virtualenv/pos-backend/3.13/bin/python ~/pos-backend/manage.py calcular_reposicion >> ~/pos-backend/logs/cron.log 2>&1` |
| `0 3 * * *` | `~/pos-backend/deploy/backup_db.sh` |

### Paso 11 — Verificación funcional

```bash
curl -s https://api.systemspickingpos.cl/api/v1/health/
curl -s -X POST https://api.systemspickingpos.cl/api/v1/auth/login/ \
     -H 'Content-Type: application/json' \
     -d '{"username":"<superuser>","password":"<clave>"}' | head -c 120
```
Navegador: `https://systemspickingpos.cl` → login → dashboard. Revisar la consola
(sin errores de CORS) y `~/pos-backend/logs/app.log`.

### Paso 12 — Hardening post-deploy

- cPanel → SSH Access → *Manage SSH Keys*: dejar **solo la llave**, deshabilitar
  password (si el proveedor lo permite; si no, pedirlo por ticket). Mitiga los
  intentos de fuerza bruta detectados.
- cPanel → *Two-Factor Authentication* para la cuenta cPanel.
- Cambiar la contraseña de la cuenta cPanel (se compartió en texto plano).
- Confirmar que `~/pos-backend/.env` es `600` y que `~/pos-backend` **no** está
  bajo `public_html` (no lo está).
- `python manage.py check --deploy` sin *warnings* de seguridad.

---

## 4. Backups y rollback

**Antes de cada deploy:**
```bash
mkdir -p ~/backups
mysqldump --single-transaction --routines --triggers zmgtmpop_pospicking \
  | gzip > ~/backups/pospicking_$(date +%F_%H%M).sql.gz
cp -a ~/pos-backend ~/backups/pos-backend_$(date +%F_%H%M)
```

**Rollback:**
```bash
# código
rm -rf ~/pos-backend && cp -a ~/backups/pos-backend_<fecha> ~/pos-backend
touch ~/pos-backend/tmp/restart.txt
# base de datos (solo si una migración salió mal)
zcat ~/backups/pospicking_<fecha>.sql.gz | mysql zmgtmpop_pospicking
```

`backend/deploy/backup_db.sh` hace el dump diario con retención de 7 días.

---

## 5. Checklist

- [ ] `ng build --configuration cpanel` OK en local
- [ ] Secretos generados y guardados (fuera de git)
- [ ] BD `zmgtmpop_pospicking` + usuario con ALL PRIVILEGES
- [ ] Subdominio `api.` creado + AutoSSL emitido
- [ ] Setup Python App (3.13) creada
- [ ] `backend/` subido a `~/pos-backend/` (sin `.venv`, `db.sqlite3`, `.env`)
- [ ] `~/pos-backend/.env` creado, `chmod 600`
- [ ] `pip install -r requirements.txt` OK (o fallback PyMySQL)
- [ ] `migrate` + `collectstatic` + `createsuperuser` OK
- [ ] `restart.txt` → `curl .../health/` responde `ok`
- [ ] SPA subida a `~/public_html/` + `.htaccess` SPA añadido (bloque cPanel intacto)
- [ ] `https://systemspickingpos.cl` carga y hace login contra la API
- [ ] Cron: DTE, alertas, reposición, backup
- [ ] Hardening: SSH solo-llave, 2FA, cambio de contraseña cPanel
- [ ] `check --deploy` limpio
