# Registro de decisiones

Decisiones tomadas durante el proyecto. Si algo cambia, se actualiza aquí con fecha.

## 2026-09-07 — Decisiones iniciales (Etapa 0 → 1)

| # | Tema | Decisión | Estado |
|---|---|---|---|
| D1 | Infraestructura | V2Network = hosting compartido **cPanel** (`systemspickingpos.cl`). Sin root/Docker en servidor. Producción = Passenger + MariaDB de cPanel. Docker solo local. | Confirmada |
| D2 | Repositorio | Monorepo (`backend/`, `frontend/`, `ml/`, `docs/`) en GitHub. | Confirmada |
| D3 | Idioma | Código y comentarios en **español**. | Confirmada |
| D4 | Boleta electrónica (Q1) | Abstracción `ProveedorDTE` + implementación **MOCK**. Integración real pendiente de definir con el proveedor/SII. El usuario consultará. | MOCK ahora / real pendiente |
| D5 | Cliente mayorista (Q2) | Fase 1: solo **lista de precios "mayorista"** en el catálogo, sin portal ni login de cliente. | Provisional |
| D6 | Lector de código de barras (Q3) | Soporte **USB keyboard-wedge** (principal) + **cámara** del celular (alternativa). | Provisional |
| D7 | Descuentos (Q4) | Tope por rol en `ParametroSistema`; sobre el tope, autorización de rol supervisor con registro. | Provisional |
| D8 | Devoluciones/anulaciones (Q5) | Anulación el **mismo día** por rol autorizado (reingresa stock, marca boleta anulada en MOCK). Nota de crédito electrónica fuera de alcance fase 1. | Provisional |
| D9 | Multi-local (Q6) | **Una** ubicación por defecto; modelo preparado para N. | Provisional |
| D10 | Cajas (Q7) | Caja ligada al **usuario** (un vendedor = una caja abierta). | Provisional |
| D11 | Offline (Q8) | El POS **requiere conexión**. Sin modo offline. | Confirmada |
| D12 | Granularidad ML (Q9) | Predicción **semanal por producto**. | Provisional |
| D13 | Datos ML (Q10) | **Dataset sintético** realista para desarrollo/demo, marcado como simulado. Arquitectura lista para re-entrenar con datos reales. | Confirmada |
| D14 | Tareas programadas (Q12) | **Cron de cPanel** ejecutando comandos `manage.py`. | Confirmada |
| D15 | Versiones | Django 5.2 + DRF 3.16 · Python 3.13 (local) · **MariaDB 10.11** · Angular 18+ · Node 20+. | Confirmada (BD) / resto provisional |
| D16 | Motor de BD del hosting | **MariaDB 10.11.19** (CloudLinux `cll-lve`, socket UNIX, `utf8mb4`), verificado en phpMyAdmin el 2026-09-07. Falta confirmar versión de Python del "Setup Python App". | Confirmada |
| D17 | Frontend | **Angular 22** (standalone + signals, zoneless) + Angular Material 3 (tema azure) + ESLint + Vitest. Node 24. La CLI instalada trae la 22; se usa esa. Build de producción ~115 kB transfer inicial. | Confirmada |
| D18 | Estado del frontend | Sin librería de estado (NgRx). Servicios + signals + RxJS. Se documentó como mejora futura si crece. | Confirmada |
| D19 | Lector de código de barras (Etapa 17) | Detección por **velocidad de tecleo** (keyboard-wedge): `<50 ms` entre teclas + Enter final + largo `≥3`. Sin librería. La cámara del móvil (D6) queda como mejora futura. Alternativa manual: botón «Agregar». | Confirmada |
| D20 | Testing (Etapa 18) | Objetivo de cobertura backend **≥95 %** líneas (hoy 96 %, 249 tests). Frontend: guards + interceptores + servicios core con Vitest (30 tests). E2E (Cypress/Playwright) documentado pero fuera de alcance hasta después del deploy. `prediccion/services.historia_real` se prueba cuando haya ventas reales. | Confirmada |
| D21 | Pruebas de carga (Etapa 20) | Herramienta **k6** (scripts JS, un binario, umbrales integrados). Se corre contra `docker-compose` (MariaDB) o *staging*, **nunca** contra el cPanel de producción (ToS del hosting compartido). Throttles de DRF (`login`/`anon`/`user`) hechos configurables por env (`DJANGO_*_RATE`) para poder cargar desde una sola IP. `SLO`: lectura p95 <500 ms, escritura p95 <1500 ms, error rate <1 %, sin sobreventa. | Confirmada |

> "Provisional" = asumido por defecto para no bloquear; el usuario puede cambiarlo.

## Nota MariaDB 10.11 — índices únicos condicionales

MariaDB (cualquier versión) **no** soporta índices/constraints únicos parciales al estilo PostgreSQL. Django ignora `UniqueConstraint(condition=...)` en MySQL/MariaDB. Por lo tanto:
- "una sola caja `ABIERTA` por usuario" y "un solo `ModeloPrediccion` activo" se garantizan en la **capa de servicios** (`select_for_update` + validación), no con un índice de BD.
- `CHECK` constraints **sí** están soportados (MariaDB 10.2+) → se usan normalmente.
