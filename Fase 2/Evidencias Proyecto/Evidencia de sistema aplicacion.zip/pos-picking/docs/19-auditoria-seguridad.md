# Etapa 19 — Auditoría de seguridad

**Base:** `Contexto/Promp Claude.md` (Prompt 19.1).
**Fecha:** 2026-09-07.
**Alcance:** backend Django/DRF (`backend/`), frontend Angular (`frontend/`),
Docker de desarrollo, configuración y dependencias.
**Regla de la etapa:** el Prompt 19.1 pide solo el diagnóstico. A petición
explícita del usuario, tras entregar la tabla se aplicó la remediación:
ver **§6. Correcciones aplicadas**.

> **Estado:** 20 de 22 hallazgos corregidos. S21 (`localStorage`) es un
> trade-off aceptado y documentado; S22 (clave SSH local) es higiene fuera
> del código.

Método: revisión manual de configuración (`config/settings/*`), autenticación y
permisos (`apps/usuarios`), manejo de errores y contexto (`apps/core`), todos los
`views.py`/`serializers.py`, plantillas y render de HTML, `Dockerfile` /
`docker-compose.yml`, `requirements*.txt`, `.gitignore` / historia de git y
`npm audit`.

---

## 1. Resumen

| Severidad | Hallazgos |
|---|---|
| Crítica | 0 |
| Alta | 2 (S1, S2) |
| Media | 8 (S3–S10) |
| Baja | 10 (S11–S20) |
| Informativa | 2 (S21, S22) |

No se encontraron vulnerabilidades explotables sin autenticación **con la
configuración de producción correcta**. Los dos hallazgos altos son: (a) un
XSS almacenado en la representación de la boleta y (b) un fallo abierto si el
`.env` de producción no define la clave secreta.

Aspectos **bien resueltos**: ORM en todo el código (sin SQL crudo), hashing y
validación de contraseñas estándar, rotación + blacklist de JWT, autorización
resuelta siempre contra la base de datos (no contra el claim del token),
deny-by-default global (`IsAuthenticated`), serializers de usuario que no
exponen `is_superuser`/`user_permissions`/`groups`, manejo de errores sin
trazas, cabeceras de seguridad en producción (HSTS, cookies seguras, nosniff,
XFO), secretos fuera de git y `.dockerignore` correcto. Ver §4.

---

## 2. Tabla de hallazgos

| # | Riesgo | Severidad | Archivo | Problema | Impacto |
|---|---|---|---|---|---|
| **S1** | XSS almacenado en la boleta | **Alta** | `apps/boleta/services.py` (`representacion_html`, ~L161) + `frontend/src/app/features/ventas/boleta-dialog.ts` | El HTML se arma con f-strings **sin escapar** (`ln.descripcion`, `emisor_rut`, `timbre`, folios). El frontend lo inyecta con `DomSanitizer.bypassSecurityTrustHtml()` en un `<iframe srcdoc>` **sin atributo `sandbox`** → el contenido se ejecuta en el mismo origen del POS. | Un usuario con `catalogo.administrar` pone `<img src=x onerror=…>` en el nombre de un producto; al imprimir cualquier boleta que incluya ese ítem, el script corre en el origen del POS: puede leer el `refresh` token de `localStorage`, llamar la API como el cajero y robar la sesión. |
| **S2** | Firma JWT con clave por defecto conocida | **Alta** | `config/settings/base.py` (`SECRET_KEY` L56, `SIMPLE_JWT["SIGNING_KEY"]` L181), `config/settings/prod.py` | `SECRET_KEY` cae a `"inseguro-solo-para-arranque-cambiar"` y `SIGNING_KEY` cae a `SECRET_KEY`. `prod.py` **no aborta** si falta `DJANGO_SECRET_KEY`/`JWT_SIGNING_KEY`. | Si el `.env` del servidor no define la clave, el sistema arranca con una clave pública. Cualquiera puede firmar tokens válidos para cualquier usuario y rol → **bypass total de autenticación y autorización**. |
| **S3** | Rate-limit de login evitable con `X-Forwarded-For` | **Media** | `config/settings/base.py` (`REST_FRAMEWORK`, sin `NUM_PROXIES`) | DRF identifica al cliente por el **primer valor de `X-Forwarded-For`** cuando `NUM_PROXIES` es `None`. Un atacante rota la cabecera y cada valor recibe su propio cubo de `10/min`. | La protección `login: 10/min` deja de frenar la fuerza bruta de credenciales. |
| **S4** | Bloqueo de cuenta por username: DoS dirigido y evasión | **Media** | `apps/usuarios/services.py` (`esta_bloqueado`, L34; `registrar_intento`, L30) | El lockout cuenta intentos fallidos **por `username`** e ignora la IP. (a) Un atacante bloquea a voluntad la cuenta de cualquier empleado con 5 intentos. (b) Evade su propio bloqueo rotando usernames (*password spraying*). | Denegación de servicio a usuarios legítimos (15 min sin acceso); el control no detiene el spraying. |
| **S5** | Login del admin de Django sin lockout ni throttle | **Media** | `config/urls.py` (`admin/`, L51) | El lockout `IntentoLogin` y los throttles DRF cubren **solo** `/api/v1/auth/login/`. `/admin/login/` es una vista Django normal, sin límite de intentos. | Fuerza bruta contra el panel de administración (ruta por defecto) sin ninguna barrera; `is_staff` es asignable vía API (`UsuarioActualizarSerializer`). |
| **S6** | El contexto de auditoría no registra al usuario en la API | **Media** | `apps/core/middleware.py` (`RequestContextMiddleware.__call__`, L29–33) | El middleware fija `usuario_id` al **inicio** de la petición, antes de que corra la autenticación JWT de DRF; `request.user` aún es anónimo. Los logs quedan con `user=-`. | `app.log` no atribuye las acciones al usuario real → se pierde la trazabilidad que justifica el middleware (relevante para la futura `apps.auditoria`). |
| **S7** | Estado de throttling en `LocMemCache` (no compartido) | **Media** | `config/settings/*` (no se define `CACHES`) | Sin backend de cache configurado. En Passenger con varios procesos, el conteo de throttling es **por proceso** y se pierde al reiniciar. | El límite de login efectivo se multiplica por el nº de workers y es inconsistente → el control anti-fuerza-bruta queda diluido en producción. |
| **S8** | "Acción no mapeada ⇒ permitida" en las clases de permiso | **Media** | `apps/usuarios/permissions.py` (`TienePermiso.has_permission` L36, `PermisoPorAccion.has_permission` L55) | Ambas devuelven `True` cuando la acción no está en `permisos_por_accion` (o `codigo is None`). Hoy todas las vistas mapean sus acciones, pero es un *fail-open* por diseño. | Cualquier `@action` nueva que se agregue sin actualizar el dict queda expuesta a **todo usuario autenticado**. |
| **S9** | Sin invalidación de tokens al cambiar/resetear contraseña | **Media** | `apps/usuarios/services.py` (`cambiar_password` L73, `resetear_password` L83) | No se ponen en blacklist los `refresh` vigentes ni se versiona el token al cambiar la clave. | Un `refresh` robado sigue siendo válido hasta 1 día después de que la víctima (o el admin) cambie la contraseña. |
| **S10** | Alcance de datos por rol frágil (comparación por nombre) | **Media** | `apps/ventas/views.py` (`get_queryset`, L45–47) | El filtro "solo mis ventas" se activa con `u.rol.nombre == "vendedor"`. Un rol nuevo con `ventas.ver` y sin `dashboard.ver_completo` vería **todas** las ventas. | Exposición de ventas ajenas (montos, folios, clientes) si se crea cualquier rol operativo con otro nombre. |
| **S11** | Boletas/DTE visibles para todo `boleta.ver` | **Baja** | `apps/boleta/views.py` (`BoletaViewSet`, sin `get_queryset`) | No se filtra por vendedor; cualquier usuario con `boleta.ver` (incluido el vendedor) lista e imprime todas las boletas del negocio. | Exposición de datos tributarios de terceros (folios, totales, RUT emisor). |
| **S12** | `SECURE_PROXY_SSL_HEADER` confía en `X-Forwarded-Proto` | **Baja** | `config/settings/prod.py` (L17) | Se confía en la cabecera de cualquier upstream. Si la app fuera alcanzable sin pasar por LiteSpeed, un cliente la falsea. | Cookies "seguras" servidas sobre HTTP / evasión de `SECURE_SSL_REDIRECT` (bajo en cPanel, donde el acceso directo al puerto de la app no es habitual). |
| **S13** | `X-Request-ID` y `X-Forwarded-For` tomados del cliente | **Baja** | `apps/core/middleware.py` (L26 `CABECERA_REQUEST_ID`, L13 `_obtener_ip`) | El id de correlación y la IP de `IntentoLogin` provienen de cabeceras que el cliente controla, sin validación. | Spoofing/inyección en logs y en el registro de intentos → dificulta el análisis forense. |
| **S14** | Inyección de saltos de línea en logs vía datos de usuario | **Baja** | `apps/usuarios/services.py` (L60, L80, L86), `apps/core/middleware.py` (L35) | `username`, `user_agent`, etc. se registran sin sanear `\n`/`\r`. | Un `username` con saltos de línea puede fabricar entradas de log falsas. |
| **S15** | Documentación OpenAPI pública en producción | **Baja** | `config/urls.py` (L41–47: `schema/`, `docs/`, `redoc/`) | Los tres endpoints se sirven **sin autenticación en todos los entornos** (drf-spectacular usa `AllowAny` por defecto). | Un atacante no autenticado enumera toda la superficie de la API (rutas, parámetros, formatos). |
| **S16** | `demanda/calcular` persiste con solo `prediccion.ver` | **Baja** | `apps/prediccion/views.py` (`PrediccionDemandaViewSet`, permiso de clase) | La acción `calcular` ejecuta inferencia del modelo y **guarda** un `PrediccionDemanda`, pero está gateada solo por `prediccion.ver` (lectura). | Un usuario de solo lectura genera escrituras y carga de CPU de forma ilimitada. |
| **S17** | Entrada malformada en dashboard → HTTP 500 | **Baja** | `apps/dashboard/selectors.py` (`_rango`, L29–30) | `date.fromisoformat(desde)` sin `try/except`; `?desde=abc` lanza `ValueError` no controlado → 500 + `logger.exception`. | Contrato de API pobre y ruido de errores 500 (sin fuga de datos: `DEBUG=False` y mensaje genérico). |
| **S18** | Django detrás de la línea de parches | **Baja** | `backend/requirements.txt` (L3: `Django==5.2.6`) | 5.2.6 (sep-2025) no incluye los *security releases* posteriores de la serie 5.2.x (p. ej. 5.2.7 de oct-2025, con una corrección de inyección SQL relevante para MySQL/MariaDB). | Exposición a vulnerabilidades ya parcheadas aguas arriba; el proyecto usa MariaDB. Aplica también a `Pillow`, `mysqlclient`, etc. |
| **S19** | Sin escaneo automatizado de dependencias | **Baja** | `backend/requirements*.txt`, `frontend/package.json`, CI | No hay `pip-audit`/`safety` ni `npm audit` en el flujo. (`npm audit` hoy = 0 vulnerabilidades; pip sin auditar). | Las CVE nuevas en dependencias pasan desapercibidas. |
| **S20** | Imagen Docker como root y con dependencias de desarrollo | **Baja** (solo dev) | `backend/Dockerfile` | Sin `USER` no privilegiado; instala `requirements-dev.txt`; `CMD` usa `runserver`. `docker-compose.yml` trae credenciales por defecto (`pos_pass`, `root_pass`, `dev-secret-key`). | La imagen está declarada solo para desarrollo; si se reutilizara como base "prod-like" hereda estos problemas. |
| **S21** | `refresh` de larga vida en `localStorage` | **Informativa** | `frontend/src/app/core/auth/token-storage.service.ts` | El `refresh` (1 día) y los datos del usuario viven en `localStorage`, legibles por cualquier script del origen. Es un *trade-off* consciente y documentado. | Amplifica el impacto de cualquier XSS (ver S1): permite robo de sesión persistente en lugar de efímero. |
| **S22** | Clave privada SSH suelta en el árbol de trabajo | **Informativa** | `Contexto/id_rsa` | Hay una clave privada OpenSSH sin cifrar en la carpeta del proyecto. Está en `.gitignore` (`id_rsa*`) y **no** está en la historia de git (verificado). | Si la carpeta se comparte, sincroniza o respalda sin cuidado, la clave se filtra. |

---

## 2.1. Verificación empírica

Hallazgos confirmados en ejecución (backend local, `config.settings.local`):

- **S1** — `apps/boleta/services.py::representacion_html` no llama a `escape()`/`format_html()` e interpola `ln.descripcion` en crudo. Un nombre de producto `<img src=x onerror=…>` produce HTML/JS vivo en la boleta.
- **S3** — 15 intentos de login con `X-Forwarded-For` **fijo** → 10× `401` y luego `429` (throttle `login: 10/min` activo). Los mismos 15 con `X-Forwarded-For` **rotativo** → 15× `401`, **sin `429`**: el throttle se evade cambiando la cabecera.
- **S4** — El `429` observado al repetir un mismo `username` proviene del lockout `IntentoLogin` (5 fallos/15 min), no del throttle. Confirma que se puede bloquear a un empleado a voluntad y que el spraying con usernames distintos no se frena.
- **S15** — `GET /api/v1/schema/` y `GET /api/v1/docs/` responden `200` **sin autenticación**; una ruta de negocio (`/api/v1/catalogo/productos/`) responde `401`.

---

## 3. Verdicto por tema (checklist del Prompt 19.1)

| Tema | Verdicto | Notas |
|---|---|---|
| **JWT** | ⚠️ | Rotación + blacklist + access de 15 min + autorización desde BD = bien. Riesgos: S2 (clave por defecto), S9 (no se invalida al cambiar pass). |
| **Contraseñas** | ✅ | Hasher PBKDF2 (default Django), 4 validadores (`MinimumLength=8`, común, numérica, similitud), `validate_password` en `UsuarioCrearSerializer`/`Cambio`/`Reset`. Nunca se registran valores. |
| **CORS** | ✅ | Orígenes explícitos por `.env` (sin wildcard), `CORS_ALLOW_CREDENTIALS=True` acotado. La SPA usa Bearer, no cookies, así que el riesgo es bajo. Verificar que el `.env` de prod solo liste `https://systemspickingpos.cl`. |
| **CSRF** | ✅ | La API es JWT (sin sesión) → CSRF no aplica a DRF. El admin sí usa `CsrfViewMiddleware`; `CSRF_TRUSTED_ORIGINS` y `CSRF_COOKIE_SECURE` configurados en prod. |
| **SQL Injection** | ✅ | Sin `raw()`/`extra()`/`cursor()`/`RawSQL` en el código (verificado con grep). Todo por ORM y `django_filters`. Único vector residual: S18 (CVE de framework). |
| **XSS** | ⚠️ | Angular escapa por defecto. **S1** es el único punto: `bypassSecurityTrustHtml` + HTML de boleta sin escapar + iframe sin `sandbox`. |
| **Validación de entradas** | ✅ / ⚠️ | Serializers DRF en todos los endpoints de escritura; validación de RUT (módulo 11), `sql_mode` estricto en MariaDB. Excepción: S17 (fechas del dashboard sin validar). |
| **Permisos** | ✅ / ⚠️ | `IsAuthenticated` global + matriz rol→permiso + `tiene_permiso` revalida `is_active`/`rol.activo`. Riesgos de diseño: S8 (*fail-open* si falta mapear), S16 (acción de escritura con permiso de lectura). |
| **Escalamiento de privilegios** | ✅ | Los serializers de usuario **no** exponen `is_superuser`, `user_permissions` ni `groups`. `create_user` recibe solo campos del serializer. `is_staff` sí es editable pero solo por `usuarios.administrar` (rol admin). Sin vía de escalada para roles no-admin. |
| **Exposición de información** | ⚠️ | Errores sin traza, 500 genérico, `DEBUG=False` en prod. Fugas menores: S11 (boletas de terceros), S15 (OpenAPI público), S10 (ventas de terceros si cambia el modelo de roles). |
| **Variables de entorno** | ✅ / ⚠️ | Todo lo sensible por `django-environ`. `.env.example` sin valores reales y con recordatorio de rotar claves. Riesgo: S2 (no hay *fail-fast* si faltan). |
| **Secretos** | ✅ | `.gitignore` cubre `*.pem`, `*.key`, `id_rsa*`, `**/.env`. Sin secretos en la historia de git (verificado con `git log --diff-filter=A`). `.dockerignore` excluye `.env` y `.git`. Nota informativa S22. |
| **Logs** | ⚠️ | Rotación de ficheros, filtro de contexto, sin contraseñas. Problemas: S6 (sin usuario en la API), S13/S14 (spoofing e inyección por cabeceras y campos de usuario). |
| **Rate limiting** | ⚠️ | Throttles definidos (`login 10/min`, `anon 60/min`, `user 2000/h`) + lockout `IntentoLogin`. Debilidades: S3 (XFF), S4 (por username), S5 (admin sin cubrir), S7 (cache no compartida). |
| **Dependencias vulnerables** | ⚠️ | `npm audit` = 0. Pip: S18 (Django atrasado), S19 (sin escaneo automatizado). |
| **Docker** | ✅ (dev) | Solo para desarrollo local (documentado). S20: root + dev deps + credenciales por defecto, aceptable para su uso declarado. Producción es cPanel/Passenger, sin Docker. |
| **MariaDB** | ✅ | `sql_mode` estricto (`STRICT_TRANS_TABLES,NO_ZERO_DATE,…`), `utf8mb4`, credenciales por `.env`, `CONN_MAX_AGE=60`, acceso solo por ORM. Los índices únicos condicionales se garantizan en la capa de servicios (documentado en D16). |
| **API REST** | ✅ / ⚠️ | Deny-by-default, envoltura de error unificada, paginación, `APPEND_SLASH`. Pendientes: S8, S11, S15, S16. |

---

## 4. Controles correctamente implementados

- **Sin SQL crudo** en todo el proyecto — 100 % ORM / `django_filters`.
- **Contraseñas**: hashing PBKDF2, 4 validadores, `validate_password` en los serializers, nunca se loguean.
- **JWT**: `ROTATE_REFRESH_TOKENS` + `BLACKLIST_AFTER_ROTATION` + access de 15 min; la **autorización se resuelve siempre contra la BD** (`usuario.tiene_permiso()`), nunca desde el claim del token → un rol cambiado no requiere invalidar el access.
- **`is_active` revalidado por `JWTAuthentication`** → un usuario desactivado pierde el acceso a la API de inmediato.
- **Autorización**: `IsAuthenticated` global (deny-by-default) + matriz rol→permiso en una sola fuente (`apps/usuarios/permisos.py`) + migraciones de datos idempotentes.
- **Serializers de usuario sin campos peligrosos** (`is_superuser`, `user_permissions`, `groups` no expuestos).
- **IDOR mitigado** en `caja` y `ventas` vía `get_queryset` (el vendedor solo ve/opera lo suyo).
- **Manejo de errores**: sin trazas al cliente, 500 genérico, `logger.exception` server-side, `DEBUG=False` forzado en `prod.py` y `test.py`.
- **Cabeceras de seguridad en producción**: `SECURE_SSL_REDIRECT`, HSTS (30 días, subdominios, preload), `SESSION_COOKIE_SECURE`, `CSRF_COOKIE_SECURE`, `SECURE_CONTENT_TYPE_NOSNIFF`, `X_FRAME_OPTIONS=DENY`, `SECURE_REFERRER_POLICY=same-origin`.
- **Secretos**: nada sensible en git ni en su historia; `.gitignore` y `.dockerignore` correctos.
- **Fuerza bruta**: lockout con `IntentoLogin` + throttles DRF (con las salvedades S3–S7).
- **Frontend**: Angular con escape automático; el único `bypassSecurityTrust*` del código es la boleta (S1).

---

## 5. Plan de remediación priorizado (para la etapa de correcciones)

> No ejecutado en esta etapa. Orden sugerido:

### P0 — antes de exponer el sistema
- **S2**: en `prod.py`, abortar el arranque si `DJANGO_SECRET_KEY` es el valor por defecto o falta; exigir `JWT_SIGNING_KEY` explícito. `SECRET_KEY = env.str("DJANGO_SECRET_KEY")` sin default en prod.
- **S1**: escapar todos los valores interpolados en `representacion_html` (usar `django.utils.html.format_html`/`escape` o una plantilla con autoescape); en `boleta-dialog.ts` añadir `sandbox` al `<iframe>` (sin `allow-same-origin` ni `allow-scripts`; para imprimir basta `allow-modals`/`allow-popups` o abrir el HTML en `about:blank` controlado).

### P1
- **S3 + S5**: fijar `NUM_PROXIES` (o `REST_FRAMEWORK["NUM_PROXIES"]`) según la topología de cPanel/LiteSpeed; añadir lockout/throttle al login del admin (p. ej. `django-axes` o `django-defender`, que además cubre S4).
- **S7**: configurar `CACHES` en prod (cache de BD `django.core.cache.backends.db` o el memcached de cPanel si está disponible) para que throttling y lockout sean consistentes.
- **S9**: al `cambiar_password`/`resetear_password`, poner en blacklist los `OutstandingToken` del usuario (o añadir un `token_version` al payload y validarlo).

### P2
- **S4**: complementar el lockout por username con lockout por IP y *captcha*/backoff tras N fallos globales.
- **S6**: mover el llenado de `usuario_id` a después de la autenticación (middleware de DRF, signal `user_logged_in`, o releer `request.user` en un segundo punto) para no perder la atribución.
- **S8**: cambiar el default de `PermisoPorAccion`/`TienePermiso` a **deny** cuando la acción no está mapeada.
- **S10 / S11**: basar el *scoping* de datos en un permiso (`ventas.ver_todas`, `boleta.ver_todas`) en vez del nombre del rol, y aplicarlo también a `BoletaViewSet`.
- **S16**: gatear `demanda/calcular` con `prediccion.entrenar` o un permiso nuevo `prediccion.calcular`.
- **S18**: subir a la última 5.2.x de Django y revisar el resto de pines.

### P3
- **S12**: documentar/verificar que la app no es alcanzable sin el proxy; si lo fuera, quitar `SECURE_PROXY_SSL_HEADER`.
- **S13 / S14**: validar `X-Request-ID` (formato UUID) y sanear `\n`/`\r` en todo lo que se loguee proveniente del usuario.
- **S15**: servir `schema/`/`docs/`/`redoc/` solo en `local`, o protegerlos con `SPECTACULAR_SETTINGS["SERVE_PERMISSIONS"]`.
- **S17**: validar `desde`/`hasta` en el serializer/vista del dashboard y responder 400.
- **S19**: añadir `pip-audit` y `npm audit --audit-level=high` al flujo de calidad.
- **S20**: si la imagen se promueve a algo más que dev, añadir `USER app`, imagen `requirements.txt` (sin dev) y `gunicorn`.
- **S21 / S22**: aceptar el trade-off del `localStorage` (documentado) y mantener la disciplina con `Contexto/id_rsa` (cifrar en reposo o moverla fuera del proyecto).

---

## 6. Correcciones aplicadas

Segunda pasada (mismo día, a petición del usuario). Tests: **backend 249**,
**ml 5**, **frontend 30**. `ruff` y `ng lint` limpios. `pip-audit` sin
vulnerabilidades.

| # | Corrección | Archivos |
|---|---|---|
| **S1** | `representacion_html` escapa todos los valores dinámicos (`escape`/`format_html_join`). El `<iframe>` de la boleta lleva `sandbox="allow-same-origin allow-modals"` (**sin `allow-scripts`**): la boleta ya no ejecuta JS. Test: `test_representacion_html_escapa_datos_del_producto`. | `apps/boleta/services.py`, `frontend/.../boleta-dialog.ts` |
| **S2** | `prod.py` aborta el arranque (`ImproperlyConfigured`) si falta `DJANGO_SECRET_KEY`, `JWT_SIGNING_KEY` o `DJANGO_ALLOWED_HOSTS`, o si las claves son el valor por defecto. Verificado. | `config/settings/prod.py`, `config/settings/base.py` |
| **S3** | `REST_FRAMEWORK["NUM_PROXIES"] = 1` (env `DJANGO_NUM_PROXIES`). Detrás de LiteSpeed, DRF usa la IP que añade el proxy, no la que falsea el cliente. `_obtener_ip` toma la **última** entrada de `X-Forwarded-For`. | `config/settings/base.py`, `apps/core/middleware.py` |
| **S4 / S5** | El bloqueo por fuerza bruta se conecta a las señales `user_login_failed` / `user_logged_in` → cubre también `/admin/login/`. Formulario de login del admin (`AdminLoginConBloqueo`) que rechaza usuarios bloqueados. Ruta del admin ofuscable (`DJANGO_ADMIN_URL`). Tests: `test_login_fallido_en_admin_cuenta_para_el_bloqueo`. | `apps/usuarios/signals.py`, `apps/usuarios/forms.py`, `apps/usuarios/apps.py`, `config/urls.py` |
| **S6** | `JWTAuthAuditoria` (subclase de `JWTAuthentication`) escribe el id del usuario en el contexto en cuanto valida el token → los logs de la API vuelven a atribuir las acciones. | `apps/usuarios/authentication.py`, `apps/core/middleware.py`, `config/settings/base.py` |
| **S7** | `prod.py` define `CACHES` con `FileBasedCache` (env `DJANGO_CACHE_DIR`) → throttling y bloqueo consistentes entre los procesos de Passenger. | `config/settings/prod.py` |
| **S8** | `PermisoPorAccion` y `TienePermiso` ahora **fail-closed**: acción no mapeada / permiso no declarado ⇒ 403. | `apps/usuarios/permissions.py` |
| **S9** | `cambiar_password` / `resetear_password` ponen en la blacklist todos los `OutstandingToken` del usuario. Tests: `test_cambio_de_password_revoca_los_refresh_vigentes`, `test_reset_de_password_por_admin_revoca_sesiones`. | `apps/usuarios/services.py` |
| **S10 / S11** | El *scoping* "solo lo mío" en `ventas` y `boleta` se basa en `dashboard.ver_completo` (o superuser), no en `rol.nombre`. `BoletaViewSet` gana `get_queryset`. | `apps/ventas/views.py`, `apps/boleta/views.py` |
| **S13** | El `X-Request-ID` entrante se acepta solo si casa `^[A-Za-z0-9._-]{1,64}$`; si no, se genera uno. | `apps/core/middleware.py` |
| **S14** | `Usuario.username` valida con `UnicodeUsernameValidator` (migración `0006`); el `User-Agent` se saca de saltos de línea antes de loguear. | `apps/usuarios/models.py`, `apps/core/middleware.py` |
| **S15** | `schema/` · `docs/` · `redoc/` solo se enrutan con `DEBUG=True`. Tests: `test_schema_no_se_expone_sin_debug` + generación del esquema por API interna. | `config/urls.py`, `apps/core/tests.py` |
| **S16** | `demanda/calcular` usa `ScopedRateThrottle` (`prediccion_calcular: 60/hour`). | `apps/prediccion/views.py`, `config/settings/base.py` |
| **S17** | `_rango` valida las fechas y responde `400 fecha_invalida`. Test: `test_fecha_invalida_devuelve_400`. | `apps/dashboard/selectors.py` |
| **S18** | `Django 5.2.6 → 5.2.17`, `djangorestframework 3.16.1 → 3.17.2` (2 CVE). | `backend/requirements.txt` |
| **S19** | `pip-audit` añadido a `requirements-dev.txt` y a la sección de calidad del README; `pip-audit` en verde. | `backend/requirements-dev.txt`, `backend/README.md` |
| **S20** | El `Dockerfile` crea y usa un usuario `app` no privilegiado. | `backend/Dockerfile` |
| **S12** | Documentado: la app en cPanel solo es alcanzable a través de LiteSpeed; `SECURE_PROXY_SSL_HEADER` es correcto en ese contexto. Sin cambio de código. | — |
| **S21 / S22** | Aceptados. `localStorage` es un trade-off consciente (mitigado por S1: sin `allow-scripts` no hay robo de token vía la boleta). `Contexto/id_rsa` sigue gitignored y fuera de la historia. | — |

Cambio de comportamiento a tener en cuenta:

- La documentación OpenAPI (`/api/v1/docs/`) ya **no** está disponible con
  `DEBUG=False`. Para generarla: `manage.py spectacular --file schema.yml`.
- Cambiar o resetear una contraseña **cierra todas las sesiones** de ese
  usuario (debe volver a iniciar sesión en todos sus dispositivos).
- Producción **no arranca** sin `DJANGO_SECRET_KEY` y `JWT_SIGNING_KEY` en
  `~/.env` (esto es deliberado).
