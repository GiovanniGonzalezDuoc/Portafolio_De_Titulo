# Reglas permanentes — Proyecto POS Picking

> Estas reglas aplican a todo el desarrollo (Claude, Codex, Cursor o cualquier IA/persona).

1. La base de datos oficial es **MariaDB**.
2. El backend usa **Django + Django REST Framework**.
3. El frontend usa **Angular + TypeScript**.
4. La autenticación usa **JWT**.
5. El código debe ser compatible con MariaDB.
6. **NO** usar características específicas de PostgreSQL.
7. Usar **Django ORM** siempre que sea posible.
8. **No** hardcodear credenciales ni secretos (usar variables de entorno).
9. No inventar requisitos.
10. No inventar endpoints.
11. No duplicar funcionalidades existentes.
12. Antes de modificar código existente, revisar su implementación.
13. No modificar módulos no relacionados sin justificarlo.
14. Toda modificación crítica de inventario debe ser **transaccional**.
15. Las operaciones de venta deben mantener consistencia de stock (control de concurrencia).
16. Mantener trazabilidad de operaciones importantes.
17. Toda funcionalidad importante debe tener **tests**.
18. No eliminar tests para hacerlos pasar.
19. No usar datos mock en funcionalidades que ya tienen API real.
20. Mantener una arquitectura modular.
21. Mantener nombres consistentes en todo el proyecto (**código y comentarios en español**).
22. Antes de implementar una funcionalidad grande, explicar el plan.
23. Si hay una decisión técnica importante, explicarla antes de implementarla.
24. No modificar la arquitectura sin justificarlo.
25. Después de cada módulo, verificar que el proyecto siga funcionando.

## Flujo por etapa

```
Implementar → ¿compila? → ¿tests pasan? → ¿funciona? → ¿BD correcta? → git commit → SIGUIENTE
```

## Contexto de infraestructura (verificado 2026-09-07)

- **V2Network = hosting compartido cPanel** (dominio `systemspickingpos.cl`, IP compartida `216.185.51.20`, servidor LiteSpeed, CloudLinux).
- **Motor de BD confirmado: MariaDB 10.11.19** (socket UNIX, `utf8mb4`). phpMyAdmin 5.2.3, PHP 8.4. cPanel `cpsrvd 11.136`.
- Sin root / sin `sudo` / **sin Docker en el servidor**.
- Despliegue de producción: cPanel **"Setup Python App"** (Passenger) + base de datos **MySQL/MariaDB de cPanel** + build estático de Angular. Opcional: **"Git Version Control"** de cPanel.
- **Docker** se usa **solo para desarrollo local**.
- Las pruebas de carga/estrés se ejecutan **desde el equipo local contra el servidor**, no dentro de él.
- Límites del plan: 50 GB disco, 4 GB RAM, 100 procesos, 20 *entry processes*, 1024 IOPS, bases de datos ilimitadas.
