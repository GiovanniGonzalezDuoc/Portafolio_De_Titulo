# Etapa 18 — Auditoría de testing

**Base:** `Contexto/Promp Claude.md` (Prompt 18.1), `docs/REGLAS-PROYECTO.md`.
**Fecha:** 2026-09-07.

Objetivo: revisar la cobertura de pruebas de todo el proyecto, cerrar los huecos
relevantes y dejar identificados los flujos que ameritan pruebas End‑to‑End.
No se eliminó ni se debilitó ningún test existente.

---

## 1. Estado al iniciar la auditoría

| Suite | Tests | Cobertura | Runner |
|---|---|---|---|
| Backend (`apps/`) | 218 | 95 % líneas | pytest + pytest-django + pytest-cov |
| Paquete ML (`ml/`) | 5 | — | pytest (sin Django) |
| Frontend (`frontend/src`) | 12 | — | Vitest + `@angular/build:unit-test` |

Comandos:

```bash
# backend
cd backend && USE_SQLITE=True .venv/Scripts/python.exe -m pytest -q --cov --cov-report=term-missing
# ml
.venv/Scripts/python.exe -m pytest ml/tests -q
# frontend
cd frontend && npm test
```

---

## 2. Huecos detectados y cerrados

### Backend (218 → 243 tests, 95 % → 96 %)

| Área | Hueco | Test agregado |
|---|---|---|
| `proveedores/views.py` (75 %) | acciones `activar`, `productos`, `quitar-producto` sin cubrir; vendedor sin acceso no verificado | `proveedores/tests/test_api.py` (+5) |
| `reposicion/views.py` (80 %) | **ningún** test de API: `generar`, `aprobar`, `descartar`, `generar-orden`, `parametros` GET/PATCH, filtros y permisos | `reposicion/tests/test_api.py` (nuevo, +11) |
| `prediccion/views.py` (86 %) | list de modelos, list + filtro de demanda, `calcular` con producto inexistente (404) y horizonte inválido, `entrenar` OK como admin | `prediccion/tests/test_api.py` (nuevo, +7) |
| `usuarios/managers.py` (54 %) | `create_user` / `create_superuser` (asignación de rol administrador, validación de flags, normalización de email) | `usuarios/tests/test_manager.py` (nuevo, +5) |

### Frontend (12 → 30 tests)

| Área | Hueco | Test agregado |
|---|---|---|
| `core/auth/permiso.guard.ts` | guard sin ninguna prueba | `permiso.guard.spec.ts` (+4) |
| `core/services/api.service.ts` | slash final anti‑301, serialización de params, contexto `SIN_TOAST` de `getSilencioso` | `api.service.spec.ts` (+5) |
| `core/http/error.interceptor.ts` | traducción del envoltorio de error, opt‑out `SIN_TOAST`, silencio de 401, error de red | `error.interceptor.spec.ts` (+4) |
| `core/http/jwt.interceptor.ts` | header `Bearer`, rutas públicas, 401 → refresh → reintento, logout si no hay refresh / si el refresh falla | `jwt.interceptor.spec.ts` (+5) |
| `core/util/escaner-codigo-barras.ts` | (Etapa 17) detección de lector vs. tecleo humano | `escaner-codigo-barras.spec.ts` (+5, ya en Etapa 17) |

### Resultado

```
backend : 243 passed  — 96 % líneas
ml      :   5 passed
frontend:  30 passed   (8 archivos)
```

---

## 3. Cobertura por tipo de prueba

| Tipo | Dónde | Cubierto |
|---|---|---|
| **Unit** | modelos, `services.py`, `formulas.py`, `selectors.py`, pipes, guards, utils | ✅ |
| **Integration** | `services` con `transaction.atomic` + `select_for_update` (venta/compra/caja/inventario), motor de alertas, reposición→OC | ✅ |
| **API** | todos los ViewSets vía `APIClient` con envoltorio de error unificado y paginación | ✅ |
| **Authentication** | `usuarios/tests/test_autenticacion.py` — login, refresh con rotación, logout+blacklist, bloqueo por fuerza bruta, `/me` | ✅ |
| **Permission** | `test_roles_permisos.py` + asserts `403` por rol en cada app (deny‑by‑default `PermisoPorAccion`) | ✅ |
| **Inventory** | `inventario/tests/` — libro mayor, no negativo (servicio + CHECK), 409 `stock_insuficiente`, ajustes | ✅ |
| **Sales** | `ventas/tests/` — cálculo vs. confirmación, cuadre de pagos, autorización de descuento, anulación mismo día | ✅ |
| **Purchase** | `compras/tests/` — BORRADOR→EMITIDA→RECIBIDA(_PARCIAL), recepción mueve stock, correlativos | ✅ |
| **Cash register** | `caja/tests/` — una caja abierta por usuario, arqueo, cierre con diferencia | ✅ |
| **Alert** | `alertas/tests/` — dedup, motor genera/cierra, reglas configurables | ✅ |
| **Dashboard** | `dashboard/tests/test_api.py` — KPIs, alcance por rol (`dashboard.ver` vs `ver_completo`), sin N+1 | ✅ |
| **Prediction** | `prediccion/tests/` + `ml/tests/` — sincronización de modelo, predicción sintética, mínimo de historia, API | ✅ |
| **Replenishment** | `reposicion/tests/` — fórmulas puras v1, recomendación end‑to‑end, API completa | ✅ |
| **Frontend component** | pendiente (ver §5) | ⚠️ parcial |
| **Frontend service** | `api.service`, `token-storage` | ✅ básico |
| **Frontend forms** | validación reactiva cubierta indirectamente; sin spec dedicado de `login` | ⚠️ |
| **Frontend guards** | `authGuard`, `invitadoGuard`, `permisoGuard` | ✅ |
| **Frontend interceptors** | `errorInterceptor`, `jwtInterceptor` (refresh 401 → reintento → logout) | ✅ |

---

## 4. Deuda de pruebas conocida (aceptada)

| Archivo | Cobertura | Motivo |
|---|---|---|
| `prediccion/services.py` | 69 % | `historia_real()` requiere el mínimo configurado (6 por defecto) de `LineaVenta` real; la rama sintética y el contrato ML sí están cubiertos (`ml/tests`). Se probará con datos reales cuando existan. |
| `usuarios/managers.py` líneas de migración | — | `use_in_migrations` ejercitado por las data migrations en cada corrida. |
| `*/admin.py` | 79–91 % | Django admin (no es superficie de la API); bajo riesgo. |

---

## 5. Flujos críticos que deberían tener pruebas End‑to‑End

Prioridad para Cypress/Playwright cuando se aborde la automatización E2E
(no está en el alcance de esta etapa; hoy se validan a mano + con los tests de API):

1. **Login → sesión persistente → refresh rotado → logout.**
   Recarga de página con token vencido; el `refresh` rotado debe guardarse
   (regresión ya corregida en Etapa 16).
2. **Venta completa en el POS:** escanear código de barras → carrito →
   pago(s) que cuadran → confirmar → boleta emitida (mock DTE) → impresión.
3. **Venta con descuento sobre el tope:** exige diálogo de autorización de
   supervisor (usuario + contraseña con `ventas.autorizar_descuento`).
4. **Apertura y cierre de caja:** abrir → ventas en efectivo → arqueo →
   cierre con diferencia; bloqueo de "segunda caja abierta".
5. **Recepción de compra:** crear OC → emitir → recibir (parcial y total) →
   el stock y el `costo_referencial` se actualizan; alerta de stock se cierra.
6. **Reposición → orden de compra:** generar recomendaciones → aprobar →
   "generar orden" → navegar al detalle de la OC creada.
7. **Guard de permisos por rol:** el vendedor no ve Administración /
   Compras / Predicción; acceso directo por URL redirige a `/`.
8. **Manejo de errores de red:** API caída → snackbar "No se pudo conectar",
   sin romper la SPA (GlobalErrorHandler).

---

## 6. Cómo correr todo

```bash
# 1. Backend
cd backend
USE_SQLITE=True .venv/Scripts/python.exe -m pytest -q          # 243 tests
.venv/Scripts/python.exe -m ruff check apps/

# 2. Paquete ML
cd ..
backend/.venv/Scripts/python.exe -m pytest ml/tests -q          # 5 tests

# 3. Frontend
cd frontend
npm test                                                        # 25 tests
npm run ng -- lint
npm run build
```
