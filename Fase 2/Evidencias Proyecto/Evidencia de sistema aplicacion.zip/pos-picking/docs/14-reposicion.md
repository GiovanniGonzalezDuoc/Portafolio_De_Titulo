# Etapa 14 — Recomendación de reposición

**Base:** `docs/00-analisis-requisitos.md` (Módulos K y L), `docs/01-arquitectura.md` §14,
`docs/13-prediccion-demanda.md`.

Dos apps nuevas, integradas con el resto del backend:

| App | Rol |
|---|---|
| `apps/prediccion` | Puente entre el paquete `ml/` y Django: registra el modelo entrenado, construye el histórico semanal de un producto y sirve/persiste las predicciones. |
| `apps/reposicion` | Fórmulas de reposición (algoritmo puro) + integración: recomendaciones explicables, auditables y reproducibles. |

---

## 1. Fórmulas (`apps/reposicion/formulas.py`, versión `v1`)

Todo en **semanas**:

| Símbolo | Significado | Origen |
|---|---|---|
| `d` | demanda semanal estimada | predicción / horizonte |
| `σ_d` | desviación de la demanda semanal | predicción |
| `L` | lead time del proveedor | `Proveedor.lead_time_dias / 7` |
| `R` | período de revisión | `ParametroReposicion.periodo_revision_semanas` (1) |
| `Z` | factor de nivel de servicio | `ParametroReposicion.nivel_servicio_z` (1,65 ≈ 95 %) |
| `S` | stock actual | `inventario.services.stock_de` |
| `T` | stock en tránsito | `compras.services.stock_en_transito` |
| `m` | múltiplo de compra | `ParametroInventario.multiplo_compra` |

```
SS  = Z · σ_d · sqrt(L + R)                (stock de seguridad)
ROP = d · (L + R) + SS                     (punto de pedido)
Q   = max(0, ROP − (S + T))                (cantidad bruta)
Q   = ceil(Q / m) · m                      (redondeo al múltiplo de compra)
```

- **Explicable**: cada término se devuelve y se guarda un `motivo` en texto.
- **Auditable**: `RecomendacionReposicion.inputs` guarda todos los valores usados
  y `formula_version`.
- **Reproducible**: función pura, misma entrada → misma salida.
- **No inventa**: sin predicción válida (RF-K8) o sin proveedor → **no** se genera
  recomendación (se contabiliza aparte).

---

## 2. Flujo

```
manage.py entrenar_demanda   (cron mensual)
   └─ ml.src.train.entrenar()  →  ml/models/demanda_actual.joblib + .metrics.json
   └─ prediccion.services.sincronizar_modelo()  →  ModeloPrediccion(activo=True)

manage.py calcular_reposicion   (cron diario)
   └─ por cada producto activo con proveedor:
        prediccion.services.predecir()  →  PrediccionDemanda   (fuente REAL | SINTETICO)
        formulas.calcular(d, σ, L, R, Z, S, T, m)
        →  RecomendacionReposicion(SUGERIDA)
```

**Histórico de un producto** (`prediccion.services.historia_producto`):
1. Serie semanal real desde `ventas.LineaVenta` (ventas pagadas), rellenando
   semanas sin ventas con 0.
2. Si tiene menos de `MIN_SEMANAS_HISTORIA` (6 por defecto, configurable; 12 en el
   alcance completo) semanas con ventas **y** está permitido
   (`PREDICCION_PERMITIR_SINTETICO`, activo en desarrollo/tests), usa el **dataset
   sintético** de `ml/` — la predicción queda marcada `fuente=SINTETICO`.
3. Si no, `DatosInsuficientes`.

**Regenerar no duplica.** `recomendar_producto()` descarta (`delete`) la
`SUGERIDA` pendiente del mismo producto antes de crear la nueva — sin esto,
correr `calcular_reposicion` (o el botón "Generar recomendaciones") más de
una vez dejaba varias filas `SUGERIDA` del mismo producto en la tabla.
`APROBADA`/`DESCARTADA`/`ORDENADA` no se tocan al regenerar.

---

## 3. API

**Predicción** (`/api/v1/prediccion/`)

| Método · URL | Permiso |
|---|---|
| `GET modelos/` · `GET modelos/{id}/` | `prediccion.ver` |
| `POST modelos/entrenar/` · `POST modelos/sincronizar/` | `prediccion.entrenar` |
| `GET demanda/` (filtros `producto__sku`, `fuente`, `horizonte_semanas`) | `prediccion.ver` |
| `GET demanda/calcular/?producto=SKU&horizonte=4` | `prediccion.ver` |

**Reposición** (`/api/v1/reposicion/`)

| Método · URL | Permiso |
|---|---|
| `GET recomendaciones/` (filtros `estado`, `producto` — búsqueda parcial de SKU, `icontains` —, `proveedor__rut`, `con_compra`) | `reposicion.ver` |
| `POST recomendaciones/generar/` | `reposicion.ejecutar` |
| `POST recomendaciones/{id}/aprobar/` · `/descartar/` | `reposicion.ejecutar` |
| `POST recomendaciones/generar-orden/` `{ids:[…]}` | `compras.crear` — crea una OC borrador agrupada por proveedor |
| `GET/PATCH parametros/` | `reposicion.ver` / `reposicion.ejecutar` |

Estados de la recomendación: `SUGERIDA → APROBADA → ORDENADA`, o `DESCARTADA`.

---

## 4. Ejecutar

```bash
python manage.py entrenar_demanda      # entrena y activa el modelo
python manage.py predecir_demanda      # predicciones de todos los productos
python manage.py calcular_reposicion   # recomendaciones
```

`cargar_demo` ejecuta los tres al final: la demo trae 10 predicciones y 10
recomendaciones.

---

## 5. Cron sugerido (cPanel)

| Frecuencia | Comando |
|---|---|
| `0 3 1 * *` (mensual) | `manage.py entrenar_demanda` |
| `30 3 * * *` (diario) | `manage.py calcular_reposicion` |
