# Etapa 1 — Arquitectura del sistema POS Picking

**Base:** `docs/00-analisis-requisitos.md` y `docs/DECISIONES.md`.
**Fecha:** 2026-09-07
**Restricción clave:** producción en **hosting compartido cPanel** (Passenger + MariaDB de cPanel, sin root, sin Docker en el servidor).

---

## 1. Arquitectura general

Aplicación **cliente–servidor de 3 capas**, desacoplada:

```
┌─────────────────────────┐        HTTPS / JSON         ┌──────────────────────────────┐        SQL         ┌───────────────┐
│  CLIENTE (SPA Angular)   │  ───────────────────────▶   │  API REST (Django + DRF)     │  ──────────────▶   │   MariaDB     │
│  Navegador PC / celular  │  ◀───────────────────────   │  Passenger (WSGI) en cPanel  │  ◀──────────────   │   (InnoDB)    │
└─────────────────────────┘      JWT en cabecera         └──────────────┬───────────────┘                    └───────────────┘
                                                                        │
                                                          ┌─────────────┼──────────────┐
                                                          ▼             ▼              ▼
                                                   ┌────────────┐ ┌───────────┐ ┌────────────────┐
                                                   │ Servicio   │ │ Proveedor │ │ Cron de cPanel │
                                                   │ ML (joblib)│ │ DTE (MOCK)│ │ (manage.py …)  │
                                                   └────────────┘ └───────────┘ └────────────────┘
```

- **Frontend**: Single Page Application en Angular. Se compila (`ng build`) a estáticos y se sirve desde el web server (LiteSpeed) del hosting, en el dominio o un subdominio (`app.systemspickingpos.cl`). No tiene lógica de negocio: consume la API.
- **Backend**: API REST stateless con Django REST Framework. Autenticación por **JWT** (sin sesión de servidor). Toda la lógica de negocio vive aquí, organizada en **apps por dominio** y con una **capa de servicios**.
- **Base de datos**: MariaDB (motor InnoDB, charset `utf8mb4`), provista y gestionada por cPanel.
- **ML**: el modelo se entrena **offline** (notebook) y se guarda como artefacto (`.joblib`). El backend lo carga bajo demanda mediante un servicio y persiste cada predicción.
- **Proveedor DTE**: interfaz abstracta; implementación **MOCK** ahora, real después.
- **Tareas programadas**: comandos de Django (`manage.py`) disparados por el **cron de cPanel** (no hay workers persistentes).

### Estilo arquitectónico del backend (capas dentro de cada app)

```
Request ─▶ URL/Router ─▶ View/ViewSet (delgada) ─▶ Serializer (validación/forma) ─▶ Service (reglas de negocio, transacciones) ─▶ Models/ORM ─▶ MariaDB
                                   │                                                        │
                                   └── Permissions (autorización)                           └── Signals / Auditoría / Alertas
```

- **View/ViewSet**: sin lógica de negocio; orquesta serializer + service + permisos + respuesta.
- **Serializer**: validación de entrada y forma de salida. No accede a reglas de negocio complejas.
- **Service** (`services.py` por app): transacciones, invariantes (stock no negativo, concurrencia), efectos secundarios (movimientos, alertas, auditoría). **Es el único lugar que modifica estado crítico.**
- **Model**: datos + validaciones simples + `Meta` (índices, constraints). Métodos de dominio pequeños.

---

## 2. Comunicación Angular → API → MariaDB

**Flujo de una petición típica (ej. confirmar venta):**

1. Angular `POS` arma el payload del carrito y llama `VentasService.confirmar(venta)` (Angular service, `HttpClient`).
2. Un **HTTP interceptor** agrega `Authorization: Bearer <access_token>`.
3. LiteSpeed recibe `POST https://app.systemspickingpos.cl/api/v1/ventas/` y lo pasa a **Passenger → WSGI → Django**.
4. Middleware de Django: CORS, seguridad, logging, contexto de auditoría (usuario + IP).
5. DRF resuelve el router → `VentaViewSet.create` → `IsAuthenticated` + `TienePermiso('ventas.crear')`.
6. `VentaCreateSerializer` valida estructura (productos existen, cantidades > 0…).
7. `ventas.services.confirmar_venta(...)`:
   - abre **transacción** (`transaction.atomic`),
   - bloquea filas de `Stock` de los productos (`select_for_update`),
   - valida stock suficiente,
   - crea `Venta`, `LineaVenta`, `PagoVenta`,
   - descuenta stock y crea `MovimientoInventario` por línea,
   - asocia a la `Caja` abierta y crea `MovimientoCaja` si el pago es efectivo,
   - dispara emisión de boleta **fuera de la transacción crítica** (o marca "pendiente"),
   - registra auditoría,
   - genera alertas de stock bajo si corresponde.
8. Respuesta `201` con la venta y el estado del documento tributario.
9. Angular actualiza la UI, muestra total y ofrece imprimir/descargar la boleta.

**Contrato de datos:** JSON en ambos sentidos. Fechas en ISO 8601 con zona `America/Santiago`. Montos en CLP como enteros (sin decimales). Paginación estándar DRF (`?page=`, `page_size`). Errores con envoltura consistente (ver §7).

**Acceso a MariaDB:** exclusivamente por el **ORM de Django**. Sin SQL crudo salvo casos justificados y parametrizados. Conexión configurada con `CONN_MAX_AGE` moderado (el hosting limita procesos); `OPTIONS` con `charset=utf8mb4` y `sql_mode` estricto.

---

## 3. Módulos del backend (apps Django)

| App | Responsabilidad | Depende de |
|---|---|---|
| `core` | Base models (`TimeStampedModel`, `SoftDelete` si aplica), utilidades, paginación, exception handler, middleware de auditoría, `ParametroSistema`. | — |
| `usuarios` | `Usuario` (modelo custom), autenticación JWT, `/login`, `/refresh`, `/me`, CRUD de usuarios, roles y permisos, throttling de login, `IntentoLogin`. | `core` |
| `catalogo` | `Categoria`, `Marca`, `Producto`, unidad de medida, impuesto, precio venta / precio mayorista, `ProductoProveedor`. Búsqueda por SKU / código de barras. | `core` |
| `inventario` | `Ubicacion`, `Stock`, `MovimientoInventario`, `ParametroInventario`. **Servicio central de stock** (entrada/salida/ajuste transaccional). Genera alertas de stock bajo. | `catalogo`, `core` |
| `inventario_fisico` | `SesionConteo`, `LineaConteo`, `AjusteDiscrepancia`. Comparación y regularización autorizada (llama al servicio de inventario). | `inventario` |
| `proveedores` | `Proveedor` (con lead time), asociación producto–proveedor, historial. | `catalogo`, `core` |
| `compras` | `OrdenCompra`, `LineaOrdenCompra`, `RecepcionCompra`, `LineaRecepcion`. La **recepción** llama al servicio de inventario. Cálculo de stock en tránsito. | `proveedores`, `inventario` |
| `ventas` | POS: `Venta`, `LineaVenta`, `PagoVenta`, descuentos y autorizaciones, `DevolucionVenta`. `confirmar_venta` transaccional con control de concurrencia. | `catalogo`, `inventario`, `caja` |
| `caja` | `Caja`, `MovimientoCaja`, arqueo/cierre con diferencia. Una caja abierta por usuario. | `core`, `usuarios` |
| `boleta` | `DocumentoTributario`, `RespuestaProveedorDTE`, `EventoDTE`. Interfaz `ProveedorDTE` + `ProveedorDTEMock`. Máquina de estados + reintentos. | `ventas`, `core` |
| `alertas` | `Alerta`, `ReglaAlerta`. API de listado/resolución. Motor que consume eventos y corre por cron. | `core` |
| `dashboard` | Endpoints de solo lectura con agregaciones (ventas, inventario, compras, caja, alertas, reposición). Sin modelos propios. | todas (lectura) |
| `prediccion` | `ModeloPrediccion`, `PrediccionDemanda`. Servicio que carga el artefacto `.joblib` y expone predicción. Comando `entrenar_demanda` / `predecir_demanda`. | `ventas`, `catalogo` |
| `reposicion` | `RecomendacionReposicion`, `ParametroReposicion`. Servicio con las fórmulas de ROP / stock de seguridad / cantidad. Comando `calcular_reposicion`. | `prediccion`, `inventario`, `proveedores` |
| `auditoria` | `RegistroAuditoria` (append-only), API de consulta (solo administrador), helpers `registrar(...)`. | `core` |

**Convenciones:**
- URLs: `/api/v1/<recurso>/` (kebab/plural), routers de DRF.
- Un `services.py` por app con lógica de negocio; los ViewSets no hacen queries complejas.
- `selectors.py` opcional para lecturas complejas reutilizables (dashboard).
- Comandos de management por app en `management/commands/`.
- Settings divididos: `settings/base.py`, `settings/local.py`, `settings/prod.py`.

---

## 4. Módulos del frontend (Angular)

```
frontend/src/app/
├── core/                     # se carga una vez
│   ├── auth/                 # AuthService, TokenStorage, modelos de sesión
│   ├── http/                 # interceptors: jwt, error, loading
│   ├── guards/               # authGuard, roleGuard
│   ├── services/             # ApiService base, NotificacionService (toasts)
│   └── config/               # environment, constantes
├── shared/                   # componentes/pipes/directivas reutilizables
│   ├── components/           # tabla-paginada, buscador, confirm-dialog, campo-moneda, badge-estado…
│   ├── pipes/                # clp, fecha-local
│   └── validators/           # rut, enteros positivos…
├── layouts/
│   └── main-layout/          # header + sidebar + <router-outlet>
└── features/                 # una carpeta por dominio, lazy-loaded
    ├── auth/                 # login
    ├── usuarios/
    ├── catalogo/             # productos, categorías, marcas
    ├── inventario/           # stock + parámetros
    ├── movimientos/          # historial / trazabilidad
    ├── inventario-fisico/
    ├── proveedores/
    ├── compras/
    ├── pos/                  # pantalla de venta + carrito + código de barras
    ├── caja/
    ├── alertas/
    ├── dashboard/
    ├── prediccion/
    └── reposicion/
```

- **Componentes standalone** + **routing con lazy loading** por feature (menos JS inicial → mejor en celular).
- **Angular Material** para UI; tema propio con los colores del logo (cian/verde).
- **Formularios reactivos** en todo CRUD.
- **Estado**: servicios con `BehaviorSubject`/signals por feature. **Sin NgRx** (complejidad innecesaria para el alcance; se documenta como opción futura).
- **Comunicación con API**: cada feature tiene su `*.service.ts` tipado (interfaces en `*.model.ts`) que usa el `ApiService` base.
- **Manejo de sesión**: `AuthService` guarda tokens (memoria + `localStorage` para refresh), expone `usuario$` y `permisos`, renueva el access token con el refresh al recibir 401.

---

## 5. Sistema de autenticación

- **Librería:** `djangorestframework-simplejwt`.
- **Flujo:**
  - `POST /api/v1/auth/login/` → `{ access, refresh, usuario }`.
  - `POST /api/v1/auth/refresh/` → nuevo `access` (rotación de refresh + blacklist del anterior).
  - `POST /api/v1/auth/logout/` → blacklist del refresh.
  - `GET /api/v1/auth/me/` → datos del usuario + roles + permisos efectivos.
- **Tiempos:** `access` ≈ 15 min, `refresh` ≈ 1 día (configurable por `.env`).
- **Transporte:** cabecera `Authorization: Bearer <access>`. HTTPS obligatorio.
- **Almacenamiento en el cliente:** `access` en memoria; `refresh` en `localStorage` (aceptado para el alcance; alternativa cookie `HttpOnly` documentada como mejora).
- **Contraseñas:** hasher de Django (PBKDF2 por defecto; Argon2 opcional vía `argon2-cffi`).
- **Anti fuerza bruta:** throttling de DRF en `login` (p. ej. 5/min por IP) + registro en `IntentoLogin` + bloqueo temporal tras N fallos.
- **Usuario inactivo:** no puede autenticarse (validación en el serializer de login).

---

## 6. Sistema de roles y permisos

- **Modelo propio** (no depender solo de `is_staff`/grupos de Django):
  - `Rol` (nombre, descripción, activo).
  - `Permiso` (código `modulo.accion`, ej. `ventas.crear`, `inventario.ajustar`, `caja.cerrar`, `usuarios.administrar`).
  - `Rol` ⟷ `Permiso` (M2M).
  - `Usuario.rol` (FK; un rol por usuario en fase 1).
- **Roles semilla** (data migration): `administrador`, `bodeguero`, `vendedor` (+ `mayorista` reservado).
- **Evaluación en el backend:** clase de permiso DRF `TienePermiso('codigo')` usada en cada ViewSet; matriz rol→permisos documentada y cargada por migración.
- **Frontend:** `roleGuard`/comprobación de `permisos` para mostrar/ocultar menús y botones (defensa en profundidad; la autoridad real es el backend).
- **Regla:** *deny by default* — un endpoint sin permiso declarado se rechaza.

Matriz resumida (detalle en Etapa 2):

| Módulo | admin | bodeguero | vendedor |
|---|---|---|---|
| Usuarios/roles | CRUD | — | — |
| Catálogo | CRUD | ver / (crear-editar) | ver |
| Inventario / ajustes | total | movimientos + solicitar ajuste | — |
| Inventario físico | aprobar | contar | — |
| Compras / proveedores | total | crear + recibir | — |
| POS / ventas | total + anular | — | crear + su historial |
| Caja | todas | — | abrir/cerrar la suya |
| Boleta | ver/reintentar/anular | — | emitir (implícito en venta) |
| Alertas | todas | stock/reposición | ver propias |
| Dashboard | completo | inventario/compras | sus ventas |
| Predicción / reposición | ver + ejecutar | ver | — |
| Auditoría | ver | — | — |

---

## 7. Manejo de errores

**Backend (DRF):**
- **Exception handler personalizado** que unifica todas las respuestas de error:
```json
{
  "error": {
    "codigo": "stock_insuficiente",
    "mensaje": "Stock insuficiente para el producto 'Taladro X'",
    "detalles": { "producto_id": 12, "solicitado": 5, "disponible": 2 },
    "campo": null
  }
}
```
- Excepciones de dominio propias (`ErrorDominio`, `StockInsuficiente`, `CajaNoAbierta`, `DescuentoNoAutorizado`, …) → mapeadas a HTTP 4xx con `codigo` estable.
- Errores de validación de serializer → `400` con `campo` y lista de mensajes.
- Errores no controlados → `500` genérico (sin filtrar traza), pero **logueados** con id de correlación.
- Cada respuesta lleva `X-Request-ID` para cruzar con los logs.

**Frontend (Angular):**
- `errorInterceptor`: captura la respuesta, traduce `error.codigo` a mensaje amigable, muestra `NotificacionService.error(...)`.
- `401` → intenta `refresh`; si falla, cierra sesión y redirige a login.
- `403` → mensaje "no tienes permiso".
- `0`/timeout → "sin conexión con el servidor".
- Errores de formulario (`400` con `campo`) → se marcan en el `FormControl` correspondiente.
- `ErrorHandler` global de Angular para errores de runtime → log + toast genérico.

---

## 8. Validaciones

| Nivel | Qué valida | Dónde |
|---|---|---|
| Frontend (UX) | Requeridos, formatos (RUT, email, enteros positivos), rangos, coherencia de formulario. | Validators de Reactive Forms. **No es la autoridad.** |
| Serializer (DRF) | Tipos, requeridos, unicidad (SKU, código de barras), existencia de FKs, formato de fechas/montos. | `serializers.py` |
| Service (dominio) | Invariantes de negocio: stock no negativo, caja abierta, tope de descuento, no recibir más de lo pedido, no cerrar caja ajena, mínimo de datos para ML. | `services.py` |
| Modelo / BD | `unique`, `unique_together`, `CHECK` (cantidades ≥ 0 donde MariaDB lo permita), `PROTECT`/`RESTRICT` en FKs sensibles, longitudes. | `models.py` + migraciones |

Regla: **toda validación crítica se repite en el service o la BD**, nunca solo en el cliente.

---

## 9. Seguridad (arquitectura)

- **HTTPS forzado** (SSL ya activo): `SECURE_SSL_REDIRECT`, `SECURE_HSTS_SECONDS`, `SESSION/CSRF_COOKIE_SECURE`.
- **CORS** restringido al origen del frontend (`django-cors-headers`, lista blanca por `.env`).
- **JWT** firmado (HS256 con `SECRET_KEY` fuerte, o RS256 si se justifica); rotación + blacklist de refresh.
- **Autorización** *deny by default* por permiso en cada endpoint.
- **Throttling** (DRF) en login y endpoints sensibles.
- **ORM exclusivo** → sin SQL injection; sin `.raw()` salvo justificación parametrizada.
- **Cabeceras de seguridad**: `X-Content-Type-Options`, `X-Frame-Options=DENY`, `Referrer-Policy`, CSP básica (via LiteSpeed o middleware).
- **Secretos** solo en `.env` (en el *home*, fuera de `public_html` y fuera del repo). `.env.example` sin valores reales.
- **Datos sensibles**: nunca loguear contraseñas/tokens/payloads de pago; serializers no exponen `password` ni campos internos.
- **Dependencias**: `pip-audit` y `npm audit` en la etapa de seguridad; versiones fijadas.
- **Auditoría inmutable** de acciones críticas.
- **Backups**: dump de MariaDB por cron + descarga periódica (fuera del servidor).
- **DTE**: la respuesta cruda del proveedor se guarda cifrada/access-controlada; el MOCK no maneja datos reales.

---

## 10. Logs

- **Framework:** `logging` de Python configurado en settings.
- **Handlers:**
  - Consola (desarrollo).
  - Archivo **rotativo** (`RotatingFileHandler`) en `~/logs/app.log` en producción (cPanel da acceso a archivos; sin `journald`).
  - Handler de errores separado (`error.log`, nivel `ERROR`).
- **Formato estructurado** (clave=valor o JSON): timestamp, nivel, logger, `request_id`, `usuario_id`, mensaje.
- **Niveles por entorno**: `DEBUG` local, `INFO`/`WARNING` producción.
- **Qué se loguea**: inicio/fin de operaciones críticas (venta, recepción, cierre de caja, emisión DTE, entrenamiento ML), errores controlados y no controlados, intentos de acceso denegado.
- **Correlación**: `X-Request-ID` generado por middleware y propagado a la respuesta y a los logs.
- **Rotación/limpieza**: por tamaño (p. ej. 5 MB × 5 archivos) para respetar la cuota de disco.

---

## 11. Auditoría

- **Tabla `RegistroAuditoria`** (app `auditoria`), **append-only**:
  `usuario`, `accion` (código), `entidad` (`app.Modelo`), `entidad_id`, `datos_antes` (JSON/texto), `datos_despues`, `ip`, `user_agent`, `fecha`.
- **Cómo se captura:**
  - **Middleware** guarda `usuario` + `ip` + `request_id` en un contexto por request (thread-local / `contextvars`).
  - Los **services** llaman `auditoria.registrar(accion, instancia, antes, despues)` en los puntos críticos (no un logging automático de todo, para que sea legible y barato).
  - Señales (`post_save`/`post_delete`) solo para entidades muy sensibles (usuarios, roles, parámetros, precios).
- **Inmutabilidad:** el modelo no expone `update`/`delete` por API; sin vistas de edición; permiso de lectura solo `administrador`.
- **Consulta:** `GET /api/v1/auditoria/` con filtros por usuario, acción, entidad y rango de fecha (paginado).

Acciones auditadas (mínimo): login/logout, alta/baja/cambio de rol de usuario, cambio de precio, ajuste de stock, autorización de descuento, apertura/cierre de caja, anulación de venta, recepción de compra, regularización de discrepancia, emisión/anulación de DTE, entrenamiento de modelo, cambio de parámetros del sistema.

---

## 12. Integraciones externas (arquitectura)

### 12.1 Código de barras
- **No requiere backend especial.** El lector USB actúa como teclado: el componente POS escucha el `input` (con *debounce* y detección de "ráfaga + Enter") y llama al endpoint de búsqueda `GET /api/v1/catalogo/productos/por-codigo/{codigo}/`.
- Alternativa cámara (celular): librería JS de decodificación (a elegir en Etapa 17) que entrega el mismo `codigo` al mismo flujo.
- Manejo de errores en el cliente: código desconocido, producto inactivo, sin stock, error de red.

### 12.2 Boleta electrónica (DTE)
- **Puerto/adaptador:**
  ```
  ventas.services.confirmar_venta ──▶ boleta.services.emitir(venta)
                                          │
                                          ▼
                                 ProveedorDTE (interfaz)
                                    ├── ProveedorDTEMock   ◀── implementación actual
                                    └── ProveedorDTE<Real> ◀── futuro (LibreDTE / SII / …)
  ```
- **Interfaz** `ProveedorDTE`: `emitir(documento) -> ResultadoDTE`, `anular(documento) -> ResultadoDTE`, `consultar_estado(documento)`.
- **`ProveedorDTEMock`**: genera folio incremental, "timbre" ficticio y un PDF/HTML simple; simula latencia y, opcionalmente, fallos aleatorios para probar reintentos.
- **Configuración**: `DTE_PROVEEDOR=mock` en `.env`; un *factory* devuelve la implementación.
- **Resiliencia**: la venta se confirma aunque el DTE quede `pendiente`; un comando `reintentar_dte` (cron) reprocesa los pendientes; la respuesta cruda se persiste siempre.
- **Estados**: `pendiente → emitido → aceptado | rechazado → anulado`.

### 12.3 Correo (opcional)
- SMTP de cPanel vía `.env` (`EMAIL_HOST`, …). Uso: enviar boleta al cliente, avisos de alertas críticas. Desactivable.

---

## 13. Arquitectura para predicción de demanda

```
                 (offline, notebook)                         (online, Django)
┌────────────────────────────────────────┐      ┌───────────────────────────────────────────┐
│ ml/notebooks/entrenamiento_demanda.ipynb│      │ prediccion/services.py                     │
│  1. cargar ventas (export/CSV o ORM)    │      │  ServicioPrediccion (singleton, lazy):    │
│  2. limpiar + features (calendario…)    │      │   - carga ml/models/demanda_vX.joblib     │
│  3. split temporal (sin leakage)        │─────▶│   - cache en memoria del proceso          │
│  4. baseline vs modelos                 │ .joblib   - predecir(producto, horizonte)        │
│  5. evaluar (MAE/RMSE/MAPE)             │      │   - registra PrediccionDemanda (auditoría)│
│  6. guardar artefacto + métricas JSON   │      └───────────────┬───────────────────────────┘
└────────────────────────────────────────┘                      │
        │                                                        ▼
        ▼                                        GET /api/v1/prediccion/demanda/?producto=&horizonte=
ml/models/demanda_v1.joblib  +  ml/models/demanda_v1.metrics.json          (solo lectura)
        │
        └─▶ registrado en tabla ModeloPrediccion (versión, métricas, ruta, fecha, activo)
```

- **Entrenamiento**: manual en notebook o por comando `manage.py entrenar_demanda` (ejecutable por cron mensual). No se entrena dentro de un request.
- **Carga del modelo**: perezosa y cacheada por proceso (respeta el límite de RAM del hosting; un proceso Passenger carga el `.joblib` una vez).
- **Fuente de datos**: en desarrollo, **dataset sintético** (`ml/data/`), marcado como simulado; en el futuro, export real de `ventas`.
- **Contrato del servicio**: entrada `(producto_id, horizonte_semanas)`, salida `{ demanda_estimada, desviacion, modelo_version, generado_en }`.
- **Regla de datos mínimos**: si el producto tiene menos semanas con ventas que el mínimo configurado (6 por defecto, hasta 12 en el alcance completo — `MIN_SEMANAS_HISTORIA`) → responde `sin_datos_suficientes` (no inventa).
- **Versionado**: cada artefacto es `demanda_vN`; `ModeloPrediccion.activo` indica cuál usa la API.

---

## 14. Arquitectura para recomendación de reposición

```
reposicion/services.py :: calcular_recomendaciones()
  para cada producto activo con proveedor y parámetros:
     d, σ_d  ← ServicioPrediccion.predecir(producto, horizonte)
     L       ← proveedor.lead_time_semanas
     Z       ← ParametroReposicion.nivel_servicio_z
     S       ← Stock.cantidad_actual
     T       ← compras.stock_en_transito(producto)
     SS  = Z * σ_d * sqrt(L + R)
     ROP = d * (L + R) + SS
     Q   = max(0, ROP - (S + T))     # opcional: Q = max(Q, EOQ), redondeo a múltiplo de compra
     → RecomendacionReposicion(producto, S, d, SS, Q, proveedor, motivo_texto, inputs_json, formula_version, fecha)
```

- **Servicio Python puro** (sin dependencias de Django en el cálculo) → testeable de forma aislada y reproducible.
- **Integración Django**: comando `manage.py calcular_reposicion` (cron diario) que persiste `RecomendacionReposicion`; endpoint de solo lectura `GET /api/v1/reposicion/recomendaciones/`.
- **Explicabilidad**: cada fila guarda **todos los inputs** + la **versión de fórmula** + un texto legible.
- **Datos insuficientes**: si no hay predicción válida o falta `lead_time` → no genera recomendación para ese producto (se lista aparte como "sin datos").
- **Acción**: opción de generar borrador de `OrdenCompra` desde recomendaciones aprobadas (rol bodeguero/admin).

---

## 15. Arquitectura de deployment

### 15.1 Producción (cPanel `systemspickingpos.cl`)

```
~/                                   (home: /home/zmgtmpop)
├── .env                             # secretos de producción (NO en git)
├── logs/                            # app.log, error.log (rotativos)
├── pos_backend/                     # repo backend (git deploy o subida)
│   ├── passenger_wsgi.py            # punto de entrada WSGI para Passenger
│   ├── manage.py
│   ├── config/ (settings/…)
│   └── venv/                        # virtualenv creado por "Setup Python App"
├── public_html/                     # dominio raíz → build de Angular (SPA)
│   ├── index.html  + assets/        # ng build --configuration production
│   └── .htaccess                    # fallback SPA + proxy /api hacia la app Python
└── static_django/                   # collectstatic (admin/DRF) servido por LiteSpeed
```

- **Backend**: cPanel → *Setup Python App* → crea venv + `passenger_wsgi.py`. `pip install -r requirements.txt`. Variables desde el panel o leídas de `~/.env` con `python-dotenv`.
- **Base de datos**: cPanel → *MySQL/MariaDB Databases* → crear `zmgtmpop_pospicking` + usuario + password; poner credenciales en `~/.env`.
- **Migraciones / tareas**: `python manage.py migrate`, `collectstatic`, etc. vía **SSH** (si se habilita) o **Terminal de cPanel** o un comando *one-off* del panel.
- **Frontend**: `ng build` en local → subir `dist/` a `public_html/` (o subdominio `app.`). `.htaccess` con *rewrite* SPA y, si el frontend y la API comparten dominio, *reverse proxy* de `/api` a la app Passenger; si van en subdominios distintos, se resuelve por CORS.
- **HTTPS**: ya provisto por el hosting (AutoSSL).
- **Cron de cPanel**:
  | Frecuencia | Comando |
  |---|---|
  | cada 15 min | `manage.py reintentar_dte` |
  | cada hora | `manage.py generar_alertas` |
  | diario | `manage.py calcular_reposicion` |
  | diario | `mysqldump … > ~/backups/db_$(date).sql` (+ rotación) |
  | mensual | `manage.py entrenar_demanda` |
- **Despliegue de cambios**: `git pull` en el server (SSH) **o** *Git Version Control* de cPanel **o** subida por File Manager; luego `migrate` + `collectstatic` + *Restart* de la app Python.

### 15.2 Desarrollo local

- **Opción A (recomendada): Docker Compose** — servicios `db` (MariaDB 10.6, volumen persistente) + `web` (Django con `runserver`), `.env` local. Angular aparte con `ng serve` (proxy a `localhost:8000`).
- **Opción B: sin Docker** — MariaDB nativa (winget) + `venv` + `runserver`.
- **Paridad**: misma versión mayor de MariaDB que el hosting; mismas variables de entorno (`.env.example` como plantilla).

### 15.3 Integración continua (opcional, GitHub Actions)

- En cada push: `lint` (ruff/flake8, eslint) + `pytest` backend + `ng test --watch=false`. No despliega (el hosting compartido no expone webhook seguro simple); el deploy queda manual/documentado.

---

## 16. Decisiones técnicas — justificación

| Decisión | Alternativas | Por qué |
|---|---|---|
| **Capa de servicios** explícita | lógica en views o en models "gordos" | Las reglas de inventario/ventas/caja son transaccionales y se comparten entre POS, compras e inventario físico. Centralizarlas evita duplicación (regla 11 y 14) y facilita los tests unitarios (regla 17). |
| **Modelo de roles/permisos propio** | grupos/permlos de Django, `is_staff` | Los permisos del negocio (`ventas.crear`, `caja.cerrar`) no calzan con los de Django; un modelo propio es explícito, versionable por migración y fácil de mostrar en el frontend. |
| **JWT stateless** (simplejwt) | sesión + cookie | El frontend es una SPA desacoplada, potencialmente en otro subdominio; stateless simplifica el hosting compartido (sin almacenamiento de sesión) y escala mejor. Se documenta el riesgo de `localStorage`. |
| **ML offline + artefacto** | entrenar/servir dentro de Django | El hosting limita RAM/CPU y no permite procesos pesados en requests. Entrenar en notebook (reproducible, regla 13) y cargar un `.joblib` liviano es lo viable. |
| **Servicio de reposición en Python puro** | lógica en el ORM/SQL | Fórmulas matemáticas → más claro y testeable sin BD; cumple "explicable, auditable, reproducible" (RF-L5). |
| **Cron de cPanel** para tareas diferidas | Celery + Redis | No hay workers persistentes ni Redis en shared hosting. Los comandos `manage.py` idempotentes por cron cubren alertas, reposición, reintento DTE y backups. |
| **MariaDB `utf8mb4` + `sql_mode` estricto** | charset por defecto | Soporte de emojis/acentos y detección temprana de datos inválidos. Sin features PostgreSQL (regla 6): `JSONField` se usa con mesura, nada de `ArrayField`/`distinct on`. |
| **Angular standalone + lazy loading** | NgModules clásicos, SPA monolítica | Menos boilerplate, bundle inicial más chico (importa en celular), alineado con Angular actual. |
| **Sin NgRx** | NgRx / NGXS | El estado es mayormente server-state con poca compartición entre features; servicios + RxJS/signals bastan. Se deja como mejora futura si crece. |
| **Docker solo local** | Docker en producción | Imposible en el hosting contratado (D1). Docker aporta paridad de BD en desarrollo sin más. |
| **Monorepo** | repos separados | Un solo lugar para issues, versionado y documentación; el equipo es chico. |

---

## 17. Riesgos arquitectónicos y mitigaciones

| Riesgo | Mitigación |
|---|---|
| Passenger reinicia procesos / pocos *entry processes* | Código sin estado en memoria (salvo cache del modelo ML, que se recarga solo); `CONN_MAX_AGE` moderado; endpoints rápidos y paginados. |
| Sin SSH → despliegue difícil | Confirmar acceso SSH con el proveedor; plan B: *Git Version Control* + Terminal de cPanel + cron para `migrate`. |
| Reverse proxy `/api` en `.htaccess` puede no estar permitido | Alternativa: frontend en subdominio `app.` y API en `api.` (o en el raíz), comunicados por **CORS** (sin proxy). |
| `mysqldump` y cron sujetos a cuotas | Backups comprimidos + rotación (mantener N copias) + descarga externa periódica. |
| Modelo ML crece en RAM | Mantener el artefacto liviano (árboles poco profundos / modelo lineal); si no cabe, precalcular predicciones por cron y servir solo lecturas de tabla. |
| Concurrencia de stock en MariaDB | `transaction.atomic` + `select_for_update` sobre `Stock`; tests de carga del endpoint de venta (Etapa 20). |

---

## 18. Siguiente paso

**Etapa 2 — Modelo entidad-relación completo** (Prompt 2.1): definir todas las entidades con campos, tipos, PK/FK, nullable, default, unique, check, índices, relaciones y cardinalidad, compatible con MariaDB + Django ORM + migraciones. Sobre esa base recién se crea el proyecto Django (Etapa 3).
