# Etapa 13 — Predicción de demanda

**Base:** `docs/00-analisis-requisitos.md` (Módulo K), `docs/DECISIONES.md` (D12, D13).
**Código:** `ml/` (paquete Python **independiente de Django**). Integración con la app en la Etapa 14.

---

## 1. Análisis de datos necesarios

| Fuente | Estado hoy | Plan |
|---|---|---|
| Historial de ventas (`ventas.LineaVenta` + `Venta.creado_en`) | Aún no hay volumen real | **Dataset sintético** realista (`ml/src/dataset.py`), marcado `simulado=True` |
| Precio del producto por semana | Derivable de `LineaVenta.precio_unitario` | En el sintético: precio base + rebajas puntuales (promos) |
| Promociones | No hay módulo de promociones | Se infiere de caídas de precio; a futuro, campo explícito |
| Quiebres de stock | `MovimientoInventario` / `Stock` histórico | En el sintético: bandera `quiebre_stock` (demanda censurada) |
| Calendario (festivos CL) | — | Semana ISO, mes, componentes sin/cos; festivos como mejora futura |

**Cantidad de datos:** se busca ≥ 2 años por producto para capturar una estacionalidad
anual completa. El sintético genera ~130 semanas (2,5 años) para 10 productos = 1.300 filas.

**Regla de datos mínimos (RF-K8):** no se predice un producto con datos reales por
debajo de un mínimo de semanas con ventas (`MIN_SEMANAS_HISTORIA`); si no lo alcanza,
se usa el dataset sintético. El requisito completo (alcance "máximo") es
**12 semanas**; se opera con **6** por defecto mientras se acumula historial real de
la tienda — configurable sin tocar código vía `ML_MIN_SEMANAS_HISTORIA`
(`MIN_SEMANAS_HISTORIA_MAXIMO = 12` queda documentado en `ml/src/config.py`).
Para demostrar el mecanismo (por ejemplo con menos de 6 semanas acumuladas), el
panel de Predicción permite indicar un mínimo puntual solo para una consulta
(`GET prediccion/demanda/calcular/?...&minimo_semanas=N`), sin alterar la
configuración general.

**Bug encontrado al probar con ventas reales (`historia_real()`):** las semanas
se agrupaban con `fecha.dt.to_period("W-MON").dt.start_time`, que en pandas
ancla el **martes** (el día siguiente al lunes de corte), mientras que el
relleno de semanas sin ventas usaba `pd.date_range(..., freq="W-MON")`, que
genera **lunes** reales. Al no coincidir ninguna fecha entre ambos, el
`reindex` no encontraba nada que conservar y **todo el histórico real quedaba
en `unidades = 0`** — silenciosamente, sin error. Con esto sin corregir, ni
bajar RF-K8 ni relajar `lag_52` habría servido: el modelo hubiera predicho
sobre puros ceros. Se corrigió calculando el lunes de cada venta con
aritmética de fechas directa (sin `Period`), y de paso se pasa `creado_en` a
hora local antes de agrupar (mismo tipo de bug que `anular_venta`, ver
`docs/14-reposicion.md`) y se castea `cantidad` a `float` (llegaba como
`Decimal` y rompía la desviación estándar en cuanto había datos reales que
promediar). Ninguna prueba existente lo detectaba porque todas usaban el
dataset sintético; se agregó `test_predecir_con_pocas_semanas_reales_usa_
datos_reales` con ventas reales de verdad para cubrir este camino.

**Historial corto y `lag_52`:** pasar RF-K8 no alcanza por sí solo — la variable
`lag_52` (venta de la misma semana, un año atrás) solo existe con ~53 semanas de
historia. `construir()` (`ml/src/features.py`) antes exigía `lag_52` no nulo para
quedarse con una fila, lo que en la práctica pedía ≥ 53 semanas reales para
predecir con datos propios, sin importar RF-K8. Ahora solo exige `lag_1` (al
menos una semana previa real); los lags más largos que no alcancen historia
quedan en 0 en vez de descartar la fila — con menos señal, no sin ella. Esto
también cambió el conjunto de entrenamiento del sintético (más filas al inicio
de cada producto), de ahí que el MAE de la tabla de resultados haya bajado
levemente respecto a corridas anteriores.

**Nivel de confianza:** cada `PrediccionDemanda` guarda `semanas_con_ventas` y
`nivel_confianza` (`NO_ESTABLE` / `ESTABLE` / `CONFIABLE`), pensado para mostrar
qué tan respaldada está una predicción con datos reales — no solo si el sistema
predijo, sino qué tanto confiar en el número. Sintético siempre es `NO_ESTABLE`.
Umbrales (`ml/src/config.py`, configurables): `< 16` semanas reales →
`NO_ESTABLE`; `16–51` → `ESTABLE`; `≥ 52` (un ciclo anual completo, `lag_52`
real) → `CONFIABLE`.

---

## 2. Variable objetivo

**`unidades`** = unidades vendidas de un producto en una semana.

- **Granularidad:** semanal por producto (decisión D12 — más estable que diaria con
  histórico corto; la reposición razona en semanas de lead time).
- **Horizonte de uso:** la reposición pide demanda a *H* semanas (por defecto 4); se
  obtiene proyectando la demanda semanal estimada × *H* (simple y explicable).

---

## 3. Variables predictoras

Todas se calculan con información disponible **hasta la semana anterior** (sin *leakage*):

| Grupo | Variables |
|---|---|
| Calendario | `mes`, `semana_del_anio`, `sin_semana`, `cos_semana` |
| Comercial | `precio`, `en_promocion` |
| Censura | `quiebre_semana_anterior` |
| Autorregresivas | `lag_1`, `lag_2`, `lag_3`, `lag_4`, `lag_52` |
| Suavizado | `mm_4`, `mm_8` (medias móviles **desplazadas**) |
| Tendencia | `tendencia_4s` (Δ entre dos medias móviles de 4 semanas) |

Definición exacta en `ml/src/features.py` (`COLUMNAS_FEATURES`).

---

## 4. Estrategia de entrenamiento y anti–*data leakage*

- **Split temporal**: train = todo el pasado; test = **últimas 12 semanas**. Nunca se
  usa el futuro para entrenar ni para construir variables.
- Las medias móviles y lags usan `shift(1)` antes de `rolling(...)` → una fila nunca
  ve su propia `unidades`.
- El mejor modelo se **reentrena con todos los datos** antes de guardar el artefacto.
- Semilla fija (`SEMILLA = 42`) → reproducible.

---

## 5. Métricas

- **MAE** (principal, criterio de selección) — error absoluto medio en unidades.
- **RMSE** — penaliza los errores grandes.
- **MAPE** — informativo; poco fiable cerca de 0, por eso se reporta también…
- **sMAPE** — simétrico, más estable para datos de conteo.

---

## 6. Propuesta de modelos (comparados en `ml/src/train.py`)

| Modelo | Rol |
|---|---|
| `baseline_naive_estacional` | Demanda = misma semana del año anterior (`lag_52`). Referencia obligada. |
| `baseline_media_movil` | Demanda = media de las últimas 4 semanas. |
| `ridge` | Regresión lineal regularizada sobre las features escaladas. |
| `random_forest` | Árboles (250, prof. 10). Captura no linealidades y efecto promoción. |

> Series temporales clásicas (SARIMA/Prophet) se dejan como mejora cuando haya
> ≥ 2 años de datos **reales** por producto.

### Resultado con el dataset sintético (holdout 12 semanas)

| Modelo | MAE | RMSE | sMAPE |
|---|---|---|---|
| **random_forest** ✅ | **8.85** | 15.56 | 26.5 % |
| ridge | 11.19 | 17.74 | 42.9 % |
| baseline_media_movil | 12.87 | 22.84 | 32.6 % |
| baseline_naive_estacional | 14.47 | 23.24 | 40.5 % |

(Números tras relajar el requisito de `lag_52` en `construir()` — ver más abajo;
antes del cambio el mismo Random Forest daba MAE ≈ 9.15 con menos filas de
entrenamiento. `manage.py entrenar_demanda` recalcula esta tabla.)

El modelo elegido **supera a ambos baselines**. Artefacto:
`ml/models/demanda_actual.joblib` + `demanda_actual.metrics.json`.

---

## 7. Reproducibilidad

```bash
# desde la raíz del repo, con el venv del backend
backend/.venv/Scripts/python -m ml.src.dataset      # (re)genera el CSV sintético
backend/.venv/Scripts/python -m ml.src.train        # entrena, evalúa y guarda el artefacto
backend/.venv/Scripts/python -m pytest ml/tests     # 5 tests del pipeline
```

Notebook paso a paso: `ml/notebooks/entrenamiento_demanda.ipynb`.

---

## 8. Siguiente paso

**Etapa 14 — Recomendación de reposición**: servicio Python puro con las fórmulas
(stock de seguridad, ROP, cantidad recomendada) usando esta predicción, y luego la
integración con Django (`apps/prediccion` sirve el artefacto; `apps/reposicion`
persiste recomendaciones explicables).
