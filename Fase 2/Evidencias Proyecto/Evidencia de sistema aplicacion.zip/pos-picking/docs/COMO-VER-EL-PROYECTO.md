# Cómo ver el proyecto ahora mismo

Todavía **no hay interfaz visual** (el frontend Angular se construye en la Etapa 15).
Lo que sí puedes ver y **probar** hoy es la **API**, con una consola web interactiva
(Swagger) y el panel de administración de Django.

## 1. Levantar el backend

Abre **PowerShell** en la carpeta del proyecto y ejecuta:

```powershell
cd E:\ProyectoPortafolio\backend
.\run-dev.ps1
```

Ese script:
- crea el entorno virtual si falta,
- aplica las migraciones,
- carga **datos de demostración** (usuarios + catálogo),
- levanta el servidor en `http://127.0.0.1:8000`.

> Si prefieres a mano:
> ```powershell
> .\.venv\Scripts\Activate.ps1
> python manage.py migrate
> python manage.py cargar_demo
> python manage.py runserver
> ```

## 2. Abrir en el navegador

| URL | Qué es |
|---|---|
| **http://127.0.0.1:8000/api/v1/docs/** | **Swagger UI** — lista todos los endpoints y permite probarlos |
| http://127.0.0.1:8000/api/v1/redoc/ | La misma documentación, formato lectura |
| http://127.0.0.1:8000/admin/ | Panel de administración de Django |
| http://127.0.0.1:8000/api/v1/health/ | Chequeo simple (JSON) |

## 3. Usuarios de prueba

| Usuario | Contraseña | Rol | Puede |
|---|---|---|---|
| `admin` | `admin12345` | superusuario | todo + admin de Django |
| `admin_demo` | `demo12345` | administrador | todo por la API |
| `bodega_demo` | `demo12345` | bodeguero | catálogo, inventario, compras |
| `vende_demo` | `demo12345` | vendedor | POS, ver catálogo |

## 4. Probar la API desde Swagger

1. Entra a **http://127.0.0.1:8000/api/v1/docs/**
2. Expande **`POST /api/v1/auth/login/`** → *Try it out* → pon
   `{"username": "admin_demo", "password": "demo12345"}` → *Execute*.
3. Copia el valor de **`access`** de la respuesta.
4. Arriba a la derecha, botón **Authorize** → pega `Bearer <access>` (o solo el token,
   según lo pida) → *Authorize*.
5. Ahora prueba, por ejemplo:
   - `GET /api/v1/auth/me/` — tus datos y permisos
   - `GET /api/v1/catalogo/productos/` — los 10 productos demo
   - `GET /api/v1/catalogo/productos/por-codigo/7801234500017/` — búsqueda por código de barras
   - `GET /api/v1/usuarios/` — con `admin_demo` funciona; si te autenticas como
     `vende_demo` responde **403** (no tiene permiso)

## 5. Ver los datos directamente

En **http://127.0.0.1:8000/admin/** (entra como `admin` / `admin12345`) puedes navegar
Usuarios, Roles, Permisos, Categorías, Marcas y Productos como tablas.

## Notas

- Corre sobre **SQLite** (`backend/db.sqlite3`) para no tener que instalar MariaDB.
  La configuración de producción usa MariaDB 10.11; el código es el mismo.
- El archivo `backend/.env` es local y **no** está en el repositorio.
- Para reiniciar los datos: borra `backend/db.sqlite3` y vuelve a correr el script.
