# Etapa 0 — Análisis del proyecto POS Picking

**Proyecto:** POS Picking — Plataforma inteligente de gestión comercial, inventario y abastecimiento con analítica predictiva.
**Cliente:** Liquidadora Los Europeos ("Valor y ahorro directo").
**Fecha de análisis:** 2026-09-07
**Fuente:** `Contexto/Grupo N° 01.md` + `Contexto/Promp Claude.md`.

> Este documento **no contiene código**. Es la base para la Etapa 1 (Arquitectura) y la Etapa 2 (Modelo de datos).

---

## 1. Resumen ejecutivo

Aplicación web (usable en PC y celular) para una liquidadora / comercio minorista que necesita:

- Registrar ventas rápido en un **punto de venta (POS)** con **lector de código de barras**.
- Controlar **inventario en tiempo real** con **trazabilidad completa** de cada movimiento.
- Gestionar **caja** (apertura, cierre, arqueo, diferencias).
- Gestionar **compras y proveedores**, con actualización de stock **solo al recibir**.
- Realizar **inventario físico** y regularizar **discrepancias** de forma autorizada.
- Emitir **boleta electrónica** (documento tributario, Chile / SII).
- Un **motor de alertas** (stock crítico, agotados, discrepancias, reposición).
- Un **dashboard** operacional con KPIs.
- **Roles y permisos**: administrador del sistema, bodeguero, vendedor y (si se justifica) cliente mayorista.
- **Seguridad y auditoría**: API con login, JWT, cifrado en tránsito, logs, trazabilidad.
- **Componente avanzado**: **predicción de demanda (ML)** + **recomendación de reposición**.
- **Pruebas** (unitarias, integración, funcionales, carga; estrés si se justifica) y **despliegue**.

---

## 2. Requisitos funcionales (RF) por módulo

### Módulo A — Autenticación, usuarios, roles y seguridad
- RF-A1. Login con credenciales (usuario/clave) que devuelve **JWT** (access + refresh).
- RF-A2. Refresh token para renovar la sesión sin volver a loguear.
- RF-A3. Endpoint "usuario actual" (`/me`) con datos del usuario y sus permisos.
- RF-A4. CRUD de usuarios (crear, listar, editar, activar/desactivar).
- RF-A5. Asignación de **rol** a cada usuario.
- RF-A6. Contraseñas almacenadas con hash seguro (nunca en texto plano).
- RF-A7. Cambio de contraseña (propio) y reseteo por administrador.
- RF-A8. Todos los endpoints protegidos; acceso según rol/permiso.
- RF-A9. Estado activo/inactivo de usuario bloquea el login.
- RF-A10. Bloqueo temporal tras N intentos fallidos de login (anti fuerza bruta).

### Módulo B — Catálogo (categorías, marcas, productos)
- RF-B1. CRUD de **categorías**.
- RF-B2. CRUD de **marcas**.
- RF-B3. CRUD de **productos** con: SKU (único), **código de barras** (único), nombre, descripción, categoría, marca, precio de venta, unidad de medida, estado (activo/inactivo), impuesto aplicable.
- RF-B4. Búsqueda de productos por nombre, SKU o código de barras.
- RF-B5. Filtros (categoría, marca, estado, con/sin stock) y paginación.
- RF-B6. Un producto inactivo no se puede vender ni comprar, pero se conserva su historial.
- RF-B7. Precio de compra referencial (último costo) y margen calculado (informativo).

### Módulo C — Inventario en tiempo real y trazabilidad
- RF-C1. Consultar stock actual por producto (y por ubicación si aplica).
- RF-C2. Aumentar / disminuir / ajustar stock, **siempre generando un movimiento**.
- RF-C3. Tipos de movimiento: venta, compra (recepción), devolución, ajuste (+/-), inventario físico, traspaso.
- RF-C4. Cada movimiento registra: producto, cantidad, tipo, motivo, documento origen, **usuario responsable**, fecha/hora, stock antes y después.
- RF-C5. Historial de movimientos consultable y filtrable (por producto, tipo, fecha, usuario).
- RF-C6. Evitar stock negativo en operaciones de salida (salvo ajuste autorizado).
- RF-C7. Operaciones críticas de stock dentro de **transacción** y con **bloqueo de fila** (`select_for_update`) para concurrencia.
- RF-C8. Parámetros por producto: **stock mínimo**, **punto de reposición**, **stock de seguridad**.
- RF-C9. Al cruzar el stock mínimo se genera **alerta** de stock bajo (ver Módulo I).

### Módulo D — Inventario físico y discrepancias
- RF-D1. Crear una **sesión de conteo** (total o parcial por categoría/ubicación).
- RF-D2. Registrar cantidad contada por producto.
- RF-D3. Comparar contra el stock del sistema y calcular **discrepancia** (unidades y valorizada).
- RF-D4. Generar **alerta** por discrepancias relevantes.
- RF-D5. **Regularización autorizada**: aprobar el ajuste (rol permitido) → genera movimientos de ajuste y cierra la sesión.
- RF-D6. Trazabilidad: quién contó, quién autorizó, cuándo, motivo.

### Módulo E — Proveedores y compras
- RF-E1. CRUD de **proveedores** (razón social, RUT, contacto, dirección, **lead time** en días, estado).
- RF-E2. Asociar productos a proveedores (con costo y código del proveedor).
- RF-E3. Crear **orden de compra** con líneas (producto, cantidad, costo unitario).
- RF-E4. Estados de compra: borrador → emitida → recibida (total/parcial) → cerrada / anulada.
- RF-E5. **Crear una compra NO aumenta stock.**
- RF-E6. **Recepción** de compra: valida → aumenta stock → genera movimientos de inventario → cambia estado → registra usuario y fecha → todo en **transacción**.
- RF-E7. Recepción parcial: permite recibir menos de lo pedido y dejar pendiente.
- RF-E8. Historial de compras por proveedor y por producto (para lead time y costo).

### Módulo F — POS y ventas
- RF-F1. Iniciar una venta (requiere **caja abierta** por el vendedor).
- RF-F2. Buscar/agregar productos por **código de barras** o por SKU/nombre.
- RF-F3. Carrito: agregar, modificar cantidad, quitar líneas.
- RF-F4. Calcular subtotal por línea, **descuentos autorizados** (por línea o total), impuestos y total.
- RF-F5. Impuesto: **IVA 19% incluido en el precio** (Chile); la boleta desglosa neto + IVA.
- RF-F6. Redondeo de efectivo a la decena (Chile no circula moneda de $1/$5).
- RF-F7. Registrar **medio(s) de pago**: efectivo, débito, crédito, transferencia (registro manual, sin integración con adquirente en esta versión).
- RF-F8. Confirmar venta = **transacción**: descuenta stock, genera movimientos de inventario, asocia a caja, deja la venta en estado "pagada".
- RF-F9. Control de **concurrencia**: dos ventas simultáneas no pueden vender más stock del disponible.
- RF-F10. No vender productos inactivos ni sin stock suficiente.
- RF-F11. Emitir **boleta electrónica** asociada a la venta (ver Módulo H); si la emisión falla, la venta **no** queda inconsistente.
- RF-F12. **Anulación / devolución** de venta (rol autorizado): reingresa stock (movimiento), registra motivo, genera documento de reversa. *(Alcance a confirmar — ver §9)*.
- RF-F13. Descuentos requieren autorización de un rol supervisor (PIN o usuario autorizador). *(A confirmar — ver §9)*.

### Módulo G — Caja
- RF-G1. **Apertura de caja**: monto inicial, usuario responsable, fecha/hora.
- RF-G2. Solo **una caja abierta por usuario** (y por terminal si aplica) a la vez.
- RF-G3. Registrar **ingresos** y **egresos** manuales de caja con motivo.
- RF-G4. Asociar automáticamente las **ventas en efectivo** a la caja abierta.
- RF-G5. Calcular **saldo esperado** = inicial + ventas efectivo + ingresos − egresos.
- RF-G6. **Cierre de caja**: monto contado real, cálculo de **diferencia** (sobrante/faltante), observaciones.
- RF-G7. Estados de caja: abierta → cerrada. Historial de movimientos y de cierres (arqueos).
- RF-G8. Operaciones de caja dentro de **transacción**.

### Módulo H — Boleta electrónica (DTE)
- RF-H1. Al confirmar una venta se genera un **documento** tipo boleta electrónica (SII Chile, DTE tipo 39).
- RF-H2. Datos del documento: folio, fecha, emisor (RUT, razón social, giro, dirección), detalle (ítems, cantidades, precios, IVA), totales, medio de pago.
- RF-H3. **Integración externa vía abstracción** (interfaz `ProveedorDTE`); implementación inicial **MOCK/SIMULADA**.
- RF-H4. Estados del documento: pendiente → emitido → aceptado / rechazado → anulado.
- RF-H5. Manejo de errores + **reintentos** (cola / reproceso manual) sin bloquear la venta.
- RF-H6. Guardar la **respuesta cruda** del proveedor (folio, timbre, XML/PDF o token) para auditoría.
- RF-H7. Reimpresión / redescarga del documento.
- RF-H8. **No inventar** una API tributaria: la implementación real se conecta después según el proveedor elegido (ver §7 y §9).

### Módulo I — Motor de alertas
- RF-I1. Tipos mínimos: stock bajo, producto sin stock, necesidad de reposición, discrepancia de inventario, error importante del sistema, fallo de emisión de boleta.
- RF-I2. Cada alerta: tipo, severidad (info/warning/critical), mensaje, estado (nueva/vista/resuelta), fecha, producto relacionado, usuario relacionado, documento relacionado.
- RF-I3. Marcar alerta como vista / resuelta (con usuario y fecha).
- RF-I4. Reglas configurables (umbrales) y deduplicación (no repetir la misma alerta abierta).
- RF-I5. Listado con filtros (tipo, severidad, estado, producto, rango de fecha).
- RF-I6. Generación de alertas por eventos (venta, recepción, ajuste) y por proceso programado (cron de cPanel).

### Módulo J — Dashboard operacional
- RF-J1. Ventas del día / rango; comparación con período anterior.
- RF-J2. Productos más vendidos (unidades y monto).
- RF-J3. Ticket promedio, número de ventas, unidades vendidas.
- RF-J4. Productos con stock bajo y sin stock.
- RF-J5. Estado de caja (abierta/cerrada, saldo esperado).
- RF-J6. Compras del período y compras pendientes de recepción.
- RF-J7. Indicadores de inventario: valorización de stock, **rotación**, días de inventario.
- RF-J8. Indicadores de reposición: productos bajo punto de pedido, cantidad sugerida total.
- RF-J9. Alertas abiertas por severidad.
- RF-J10. Consultas optimizadas (aggregations / annotations, sin N+1).

### Módulo K — Predicción de demanda (ML)
- RF-K1. Consolidar **serie histórica** de ventas por producto y por período (día/semana).
- RF-K2. Generar **variables** (calendario, precio, promoción, quiebres de stock, tendencia, estacionalidad).
- RF-K3. Entrenar y comparar modelos: **baseline** (media móvil / naive estacional), **regresión**, **Random Forest**, **serie temporal** (si los datos lo justifican).
- RF-K4. Evaluar con **MAE, RMSE, MAPE**; evitar **data leakage** (split temporal).
- RF-K5. Guardar el **modelo entrenado** (artefacto) + métricas + fecha de entrenamiento.
- RF-K6. Servicio Python que, dado un producto y un horizonte, devuelve la **demanda estimada**.
- RF-K7. Exponer la predicción vía API Django (lectura), guardando el resultado para auditoría.
- RF-K8. **No** generar predicción si no hay datos suficientes (regla de mínimo de historia).
- RF-K9. Notebook reproducible: cargar → limpiar → features → entrenar → validar → evaluar → guardar.

### Módulo L — Recomendación de reposición
- RF-L1. Calcular por producto: **stock de seguridad**, **punto de pedido (ROP)**, **cantidad recomendada de compra**.
- RF-L2. Insumos: stock actual, demanda estimada (Módulo K), variabilidad de demanda, **lead time** del proveedor, stock en tránsito (compras emitidas no recibidas).
- RF-L3. Fórmulas **explícitas y documentadas** (ver §11).
- RF-L4. Cada recomendación registra: producto, stock actual, demanda estimada, stock de seguridad, cantidad recomendada, proveedor sugerido, fecha, **motivo/explicación**.
- RF-L5. La recomendación es **explicable, auditable y reproducible** (guardar inputs y fórmula/versión).
- RF-L6. No recomendar sin datos suficientes.
- RF-L7. Opcional: generar borrador de orden de compra a partir de recomendaciones aprobadas.

### Módulo M — Integración con código de barras
- RF-M1. En el POS, entrada de código de barras desde **lector físico USB (keyboard-wedge)** — el lector "teclea" el código y un Enter.
- RF-M2. Alternativa: **ingreso manual** del código.
- RF-M3. Alternativa (celular): lectura por **cámara** del dispositivo. *(A confirmar — ver §9)*.
- RF-M4. Flujo: código → buscar producto → validar existencia → validar activo → validar stock → agregar al carrito → si ya está, sumar cantidad.
- RF-M5. Manejo de: código desconocido, producto inactivo, sin stock, error de API, lecturas múltiples/rápidas (debounce).

### Módulo N — Trazabilidad y auditoría (transversal)
- RF-N1. **Log de auditoría** de acciones sensibles: login/logout, CRUD de usuarios/roles, cambios de precio, ajustes de stock, autorizaciones de descuento, aperturas/cierres de caja, anulaciones, recepciones de compra, regularización de discrepancias.
- RF-N2. Cada registro: usuario, acción, entidad afectada, valores antes/después (cuando aplique), IP, fecha/hora.
- RF-N3. Los registros de auditoría son **inmutables** (no editar/borrar por API).
- RF-N4. Consulta de auditoría con filtros (usuario, acción, entidad, rango de fecha) — solo administrador.

---

## 3. Requisitos no funcionales (RNF)

| # | Categoría | Requisito |
|---|---|---|
| RNF-1 | Compatibilidad | Todo el modelo y las consultas deben funcionar en **MariaDB** (motor InnoDB). Sin features exclusivas de PostgreSQL (ArrayField, JSONB nativo, `ILIKE`, etc.). |
| RNF-2 | Rendimiento | Endpoints de lectura del POS < 300 ms p95 con catálogo de ~5.000 productos. Dashboard < 1,5 s. |
| RNF-3 | Concurrencia | Ventas concurrentes no producen sobreventa de stock (bloqueo de fila + transacción). |
| RNF-4 | Seguridad | JWT firmado, HTTPS obligatorio, hashing de contraseñas (PBKDF2/Argon2), CORS restringido, rate limiting en login, sin secretos en el repo. |
| RNF-5 | Auditoría | Trazabilidad completa e inmutable de operaciones críticas. |
| RNF-6 | Disponibilidad | Objetivo operativo en horario comercial; el sistema no debe caerse si falla la emisión de boleta (degradación elegante). |
| RNF-7 | Usabilidad | POS operable con teclado + lector, mínimo de clics; responsive para celular. |
| RNF-8 | Mantenibilidad | Arquitectura modular (apps Django por dominio, features Angular por dominio), nombres en español consistentes, cobertura de tests en lógica crítica. |
| RNF-9 | Observabilidad | Logs estructurados de aplicación y de errores; niveles configurables por entorno. |
| RNF-10 | Portabilidad de despliegue | Debe poder ejecutarse en **hosting compartido cPanel** (Passenger + MariaDB de cPanel). Docker solo para desarrollo local. |
| RNF-11 | Configuración | 100% por variables de entorno (`.env`), con `.env.example` documentado. |
| RNF-12 | Internacionalización | Moneda CLP, zona horaria `America/Santiago`, formato de fecha local, idioma español. |
| RNF-13 | Reproducibilidad ML | El entrenamiento debe ser reproducible (semilla fija, versión de datos, notebook + artefacto versionado). |
| RNF-14 | Pruebas | Unitarias + integración + funcionales + carga. Estrés solo si el escenario lo amerita (RF de ventas concurrentes). |
| RNF-15 | Límites del hosting | Respetar cuota: 20 *entry processes*, 100 procesos, 4 GB RAM, 1024 IOPS. Nada de workers persistentes; tareas diferidas vía **cron de cPanel**. |

---

## 4. Módulos del sistema (mapa)

**Backend (apps Django):**
`usuarios` · `roles` (o permisos dentro de `usuarios`) · `catalogo` · `inventario` · `inventario_fisico` · `compras` · `proveedores` · `ventas` (POS) · `caja` · `boleta` (DTE) · `alertas` · `dashboard` · `prediccion` · `reposicion` · `auditoria` · `core` (utilidades, base models, middleware).

**Frontend (features Angular):**
`auth` · `usuarios` · `catalogo` (productos/categorías/marcas) · `inventario` · `movimientos` · `inventario-fisico` · `proveedores` · `compras` · `pos` · `caja` · `alertas` · `dashboard` · `prediccion` · `reposicion` · `core` (interceptors, guards, servicios base) · `shared` (componentes reutilizables) · `layouts`.

**ML (fuera de Django, integrado por servicio):**
`ml/notebooks/` · `ml/src/` (features, entrenamiento, predicción) · `ml/models/` (artefactos) · consumido por la app `prediccion`.

---

## 5. Tipos de usuario y permisos

| Rol | Descripción | Permisos principales |
|---|---|---|
| **Administrador del sistema** | Control total. | Todo: usuarios/roles, catálogo, precios, inventario y ajustes, compras, ventas y anulaciones, caja (todas), boleta, alertas, dashboard completo, auditoría, parámetros de reposición, entrenamiento ML. |
| **Bodeguero** | Gestión de stock y abastecimiento. | Ver catálogo; crear/editar productos (según política); inventario: movimientos, ajustes (solicitar), inventario físico y conteo; compras: crear órdenes y **recibir**; proveedores; alertas de stock/reposición; ver recomendaciones de reposición; dashboard de inventario. **No** vende, **no** maneja caja, **no** administra usuarios. |
| **Vendedor** | Operación del POS. | Abrir/cerrar **su** caja; registrar ventas; buscar productos; aplicar descuentos **hasta un tope** (sobre el tope requiere autorización); emitir boleta; ver su historial de ventas y su arqueo. **No** ajusta stock, **no** compra, **no** ve costos ni auditoría, dashboard limitado (sus ventas). |
| **Cliente mayorista** *(si se justifica)* | Cliente B2B con autoatención. | Portal separado: ver catálogo con **precio mayorista**, stock disponible (sí/no), crear **pedidos** (pre-órdenes) que el local aprueba y factura. **No** ve el back-office. *Alcance a confirmar — ver §9.* |

> Implementación sugerida: modelo `Rol` + `Permiso` propios (no depender solo de `is_staff`), permisos evaluados en los ViewSets vía clases `permissions` de DRF.

---

## 6. Entidades para la base de datos (identificación preliminar)

> Detalle de campos/tipos/índices en la **Etapa 2**. Aquí solo el inventario de entidades y su razón de ser.

**Seguridad**
- `Usuario` (extiende `AbstractBaseUser`), `Rol`, `Permiso`, `RolPermiso` (M2M), `UsuarioRol` (o FK simple si es 1 rol por usuario), `IntentoLogin` (anti fuerza bruta), `RegistroAuditoria`.

**Catálogo**
- `Categoria`, `Marca`, `Producto`, `UnidadMedida` (o choices), `ImpuestoTipo` (o choices), `ProductoProveedor` (costo y código por proveedor).

**Inventario**
- `Ubicacion` (bodega/sala; 1 por defecto, modelo preparado para N), `Stock` (producto × ubicación, cantidad actual), `MovimientoInventario` (tipo, cantidad, motivo, doc origen, usuario, fecha, stock antes/después), `ParametroInventario` (stock mínimo, punto de pedido, stock de seguridad, por producto/ubicación).

**Inventario físico**
- `SesionConteo`, `LineaConteo` (producto, contado, sistema, diferencia), `AjusteDiscrepancia`.

**Compras / proveedores**
- `Proveedor`, `OrdenCompra`, `LineaOrdenCompra`, `RecepcionCompra`, `LineaRecepcion`.

**Ventas / POS**
- `Venta`, `LineaVenta`, `DescuentoVenta` (o campos en línea/venta), `PagoVenta` (medio de pago, monto), `AutorizacionDescuento`, `DevolucionVenta` + `LineaDevolucion` *(según alcance)*.

**Caja**
- `Caja` (apertura/cierre, montos, estado, usuario), `MovimientoCaja` (ingreso/egreso/venta, monto, motivo), `ArqueoCaja` (o campos de cierre en `Caja`).

**Boleta electrónica**
- `DocumentoTributario` (venta, tipo, folio, estado, totales, fecha), `RespuestaProveedorDTE` (payload crudo, folio/timbre, error), `EventoDTE` (bitácora de intentos/reintentos).

**Alertas**
- `Alerta` (tipo, severidad, mensaje, estado, relaciones), `ReglaAlerta` (umbrales configurables).

**Predicción / reposición**
- `SerieDemanda` (opcional, materializada), `ModeloPrediccion` (versión, métricas, ruta del artefacto, fecha), `PrediccionDemanda` (producto, horizonte, valor, modelo, fecha), `RecomendacionReposicion` (producto, stock actual, demanda estimada, stock seguridad, cantidad, proveedor, motivo, fecha), `ParametroReposicion` (nivel de servicio Z, horizonte, etc.).

**Transversal**
- `RegistroAuditoria` (ya listado), `ParametroSistema` (config general: RUT emisor, giro, dirección, IVA %, redondeo, tope de descuento por rol...).

Total preliminar: **~40 entidades**.

---

## 7. Funcionalidades que requieren integración externa

| # | Integración | Naturaleza | En esta versión |
|---|---|---|---|
| INT-1 | **Lector de código de barras** | Hardware USB *keyboard-wedge* (no requiere driver ni API; emite texto + Enter). Opción cámara en celular con librería JS. | Soportado en el frontend. Sin backend especial. |
| INT-2 | **Boleta electrónica (SII Chile, DTE 39)** | Servicio tributario. Opciones reales: proveedor DTE (LibreDTE, SimpleAPI, Facturación.cl, Nubox, etc.) **o** conexión directa al SII con certificado digital y CAF. | **Abstracción `ProveedorDTE` + implementación MOCK.** La real se enchufa después (ver §9). |
| INT-3 | **Medios de pago electrónicos** (Transbank/Getnet) | Adquirente de tarjetas. | **Fuera de alcance**: el medio de pago se registra manualmente. |
| INT-4 | **Envío de correo** (boleta al cliente, notificaciones) | SMTP. cPanel provee cuentas de correo. | Opcional; vía SMTP con variables de entorno. |

---

## 8. Pruebas necesarias

**Backend**
- Unitarias: servicios de inventario, ventas, caja, compras, reposición; fórmulas de impuestos/redondeo; fórmulas de ROP/stock de seguridad.
- Integración: recepción de compra → stock; venta → stock + caja + movimientos; cierre de caja → diferencia; discrepancia → ajuste.
- API: autenticación, refresh, permisos por rol, CRUD con validaciones, filtros/paginación.
- Seguridad: acceso sin token, token expirado, escalamiento de rol, exposición de campos sensibles.
- Concurrencia / carga: ventas simultáneas del mismo producto (no sobreventa); login; consulta de catálogo; búsqueda por código de barras; dashboard.
- Estrés: solo el endpoint de confirmación de venta bajo alta concurrencia.
- ML: split temporal sin leakage; el baseline se supera; el servicio de predicción responde y respeta el mínimo de datos.

**Frontend**
- Componentes (POS, carrito, formularios), servicios HTTP, guards, interceptor JWT, validación de formularios reactivos.
- E2E de flujos críticos: login → abrir caja → venta con lector → boleta → cierre de caja; recepción de compra; regularización de discrepancia.

**Herramientas sugeridas:** `pytest` + `pytest-django` (o `unittest` de Django), `DRF APITestCase`, **k6** o **Locust** para carga (ejecutado desde local contra el server), Jasmine/Karma o Jest para Angular, Playwright/Cypress para E2E.

---

## 9. Requisitos ambiguos / decisiones a confirmar

> Según la regla del roadmap: **indicar la ambigüedad antes de asumir**. Propongo un valor por defecto para no bloquear.

| # | Tema | Ambigüedad | Propuesta por defecto |
|---|---|---|---|
| Q1 | **Boleta electrónica** | No hay proveedor definido. ¿Tienen RUT de empresa en el SII, certificado digital y CAF? ¿O usarán un proveedor (LibreDTE/SimpleAPI/…)? | Abstracción + **MOCK** ahora. Dejar `LibreDTE` como candidato para la integración real (tiene ambiente de pruebas gratuito). |
| Q2 | **Rol "cliente mayorista"** | El spec dice "si se justifica". ¿Login real con portal de pedidos, o solo un tipo de precio? | **Fase 1:** solo lista de precios "mayorista" en el catálogo, sin portal. **Fase 2 (si hay tiempo):** portal de pedidos. |
| Q3 | **Lector de código de barras** | ¿Lector físico USB, cámara del celular, o ambos? | **Ambos**: soporte USB *keyboard-wedge* (principal) + lectura por cámara como alternativa. |
| Q4 | **Descuentos autorizados** | ¿Quién autoriza y cómo? | Tope de descuento por rol en `ParametroSistema`; sobre el tope, un usuario con rol autorizador confirma (registro en `AutorizacionDescuento`). |
| Q5 | **Devoluciones / anulaciones de venta** | ¿Entran en el alcance? ¿Con nota de crédito electrónica? | Anulación **el mismo día** por rol autorizado (reingresa stock, marca boleta anulada en el MOCK). Nota de crédito electrónica: fuera de alcance fase 1. |
| Q6 | **Multi-local / multi-bodega** | El spec habla de "el local" (singular). | **Una** ubicación por defecto; modelo preparado para N (campo `ubicacion`), sin UI de multi-local en fase 1. |
| Q7 | **Terminales / cajas físicas** | ¿Varias cajas simultáneas? ¿Caja ligada a terminal o a usuario? | Caja ligada al **usuario** (un vendedor = una caja abierta). Varias cajas simultáneas de distintos vendedores: permitido. |
| Q8 | **Operación offline del POS** | El sistema es "en línea". ¿Necesita seguir vendiendo sin internet? | **No.** Requiere conexión. |
| Q9 | **Granularidad de la predicción** | ¿Diaria o semanal? ¿Por producto o por categoría? | **Semanal por producto** (más estable con datos limitados); diaria si el volumen lo permite. |
| Q10 | **Origen de datos para ML** | Al inicio no habrá histórico real de ventas. | Generar un **dataset sintético** realista para desarrollo/demo del modelo, claramente marcado como simulado. |
| Q11 | **Despliegue** | El roadmap pide Docker en el server + V2Network. | **Confirmado:** V2Network es cPanel compartido → Docker solo local; producción con Passenger + MariaDB de cPanel. |
| Q12 | **Tareas programadas** (alertas, recalcular reposición, reintento DTE) | Sin workers persistentes en el hosting. | **Cron de cPanel** ejecutando comandos de management de Django. |

---

## 10. Requisitos de seguridad (detalle)

- Autenticación JWT (access corto ~15 min, refresh ~1 día); rotación de refresh y blacklist al logout.
- Autorización por rol/permiso en cada endpoint (deny by default).
- Hash de contraseñas con el framework de Django (PBKDF2 por defecto; Argon2 opcional).
- HTTPS forzado (el dominio ya tiene SSL activo); `SECURE_*` settings, HSTS.
- CORS restringido al dominio del frontend; CSRF gestionado (API JWT stateless + protección en endpoints de sesión si los hubiera).
- Rate limiting en `/login` y endpoints sensibles (DRF throttling).
- Validación y saneamiento de entrada en serializers; uso exclusivo del ORM (evita SQL injection); sin `raw()` salvo justificación.
- Escapado en frontend (Angular escapa por defecto) — evitar `innerHTML` sin sanitizar.
- Secretos solo en `.env` (fuera del repo); `.env.example` sin valores reales.
- Logs sin datos sensibles (no loggear contraseñas, tokens ni payloads completos de pago).
- Cabeceras de seguridad (`X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, CSP básica).
- Auditoría inmutable de acciones críticas (§2, Módulo N).
- Revisión de dependencias (`pip-audit` / `npm audit`) en la etapa de seguridad.

---

## 11. Predicción de demanda y recomendación de reposición (detalle)

### 11.1 Predicción de demanda
- **Variable objetivo:** unidades vendidas por producto por período (semana).
- **Granularidad:** semanal por producto (ver Q9).
- **Predictoras candidatas:** semana del año, mes, festivos, tendencia, media móvil de N semanas, precio, indicador de promoción, semanas con quiebre de stock (para no aprender demanda censurada), categoría/marca (para modelos globales).
- **Anti data leakage:** split **temporal** (train = pasado, test = futuro); las features de una semana usan solo información disponible hasta esa semana.
- **Baseline:** naive estacional (demanda = misma semana del año anterior) o media móvil.
- **Modelos a comparar:** baseline → regresión lineal/regularizada → Random Forest / Gradient Boosting → serie temporal (SARIMA/Prophet) si hay ≥ ~2 años de datos.
- **Métricas:** MAE, RMSE, MAPE (MAPE solo cuando la demanda no es cercana a 0).
- **Regla de datos mínimos:** no predecir con datos reales si el producto tiene menos semanas de historia con ventas que el mínimo configurado (alcance completo: ~12 semanas; en operación, 6 mientras se acumula historial real — ver `docs/13-prediccion-demanda.md`).
- **Artefacto:** modelo serializado (`joblib`) + JSON de métricas + fecha/commit de entrenamiento.

### 11.2 Recomendación de reposición (fórmulas)
Sea:
- `d` = demanda semanal estimada (Módulo K)
- `σ_d` = desviación estándar de la demanda semanal
- `L` = lead time del proveedor, en semanas
- `Z` = factor del nivel de servicio (p. ej. 95 % → Z ≈ 1,65) — parámetro configurable
- `S` = stock actual
- `T` = stock en tránsito (compras emitidas no recibidas)
- `R` = período de revisión, en semanas (p. ej. 1)

Entonces:
```
Stock de seguridad:   SS  = Z * σ_d * sqrt(L + R)
Punto de pedido:      ROP = d * (L + R) + SS
Cantidad recomendada: Q   = max(0, ROP - (S + T))
```
- Opcional EOQ (si se conocen costo de pedido `Co` y costo de mantención `Ch`): `EOQ = sqrt(2 * D_anual * Co / Ch)`; se recomienda `Q = max(Q, EOQ)` redondeado al múltiplo de compra del proveedor.
- **Explicabilidad:** cada recomendación guarda `d`, `σ_d`, `L`, `Z`, `S`, `T`, la fórmula/versión y un texto ("Stock 4 u bajo el punto de pedido 11 u; lead time 2 sem; se sugiere comprar 9 u al proveedor X").
- **Regla de datos mínimos:** no recomendar si no hay predicción válida o falta el lead time del proveedor.

---

## 12. Requisitos de despliegue

- **Producción:** hosting compartido cPanel `systemspickingpos.cl`.
  - Backend Django vía **"Setup Python App"** (Passenger, Python 3.x del hosting), en un virtualenv gestionado por cPanel.
  - Base de datos: **MariaDB de cPanel** (crear DB + usuario + privilegios desde el panel).
  - Migraciones y tareas: comandos `manage.py` ejecutados por **SSH** (si se habilita) o por **cron de cPanel** / terminal de cPanel.
  - Frontend Angular: `ng build` → subir el contenido de `dist/` a `public_html/` (o servir bajo un subdominio `app.systemspickingpos.cl`).
  - Variables de entorno: archivo `.env` en el home (fuera de `public_html`), leído por la app; **nunca** en el repo.
  - Archivos estáticos de Django: `collectstatic` a una carpeta servida por el web server.
  - SSL: ya activo para el dominio.
- **Desarrollo local:** Docker Compose (Django + MariaDB) **o** MariaDB nativa + virtualenv; Angular con `ng serve`.
- **Tareas programadas** (cron cPanel): generación de alertas, recálculo de recomendaciones, reintento de emisión DTE, (re)entrenamiento del modelo.
- **Pendiente de confirmar:** si el plan incluye **acceso SSH/shell**. Si no, el despliegue se hace por **"Git Version Control"** de cPanel + File Manager + cron.

---

## 13. Riesgos y supuestos

| Riesgo | Impacto | Mitigación |
|---|---|---|
| Hosting compartido sin SSH ni procesos persistentes | Alto (limita despliegue y tareas async) | Usar Passenger + cron de cPanel; validar acceso SSH cuanto antes. |
| Sin histórico real de ventas para ML | Medio | Dataset sintético realista + arquitectura lista para re-entrenar con datos reales. |
| Integración DTE real depende de terceros / certificados | Medio | Abstracción + MOCK; decisión de proveedor documentada como pendiente (Q1). |
| Límite de 20 *entry processes* / 4 GB RAM | Medio | Consultas optimizadas, paginación, sin cargar el modelo ML en cada request (cache en memoria del proceso o precálculo por cron). |
| Concurrencia de ventas y stock | Alto | Transacciones + `select_for_update`; tests de carga específicos. |
| Compatibilidad MariaDB vs. supuestos PostgreSQL | Medio | Regla explícita; revisión de cada migración; evitar `JSONField` complejo, `distinct on`, etc. |

**Supuestos:** un local / una bodega; CLP; IVA 19 % incluido; operación en línea; lector USB como principal; anulación el mismo día; predicción semanal por producto.

---

## 14. Siguiente paso

**Etapa 1 — Arquitectura** (Prompt 1.1): con este análisis como base, definir arquitectura general, comunicación Angular → API → MariaDB, módulos de back y front, autenticación, roles, manejo de errores, validaciones, seguridad, logs, auditoría, integraciones, arquitectura de predicción y de reposición, y arquitectura de despliegue **adaptada a cPanel**.

> Antes de avanzar a la Etapa 1, revisar y responder las **decisiones del §9**.
