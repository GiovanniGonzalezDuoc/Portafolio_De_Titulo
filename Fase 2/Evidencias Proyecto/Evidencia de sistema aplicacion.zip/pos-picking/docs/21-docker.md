# Etapa 21.1 — Docker

Dockerización del stack completo para **levantar y verificar** todo el sistema
con un comando. **Producción NO usa Docker** (es cPanel/Passenger — ver
`docs/21-deploy-v2network.md`); aquí Docker es para desarrollo y como
documentación ejecutable de la arquitectura.

---

## Arquitectura

```
                    :8080 (host)
                       │
              ┌────────▼─────────┐
              │  frontend        │  nginx  →  sirve la SPA de Angular
              │  (nginx:alpine)  │         →  proxy /api/ /admin/ /static/  ─┐
              └──────────────────┘                                          │
                                                            red "interna"   │
              ┌──────────────────┐                                          │
              │  backend         │  gunicorn (3 workers) + Django  ◀────────┘
              │  (python:3.12)   │  WhiteNoise sirve /static/
              └────────┬─────────┘
                       │  DB_HOST=db
              ┌────────▼─────────┐
              │  db              │  MariaDB 10.11  (volumen db_data)
              │  (mariadb:10.11) │  utf8mb4 · sql_mode estricto
              └──────────────────┘
```

- **Sin Redis**: el proyecto no usa Celery, Channels ni cache distribuida. El
  throttling/bloqueo usa `FileBasedCache` (settings `prod`/`docker`), suficiente
  para un despliegue de un solo nodo.
- **Nginx**: un único contenedor (`frontend`) hace de servidor de la SPA y de
  *reverse-proxy* al backend. No hace falta un contenedor nginx aparte.
- **Redes**: todo en la red `interna`; solo `frontend` publica un puerto.
- **Volúmenes**: `db_data` (persistencia de MariaDB), `static_files`
  (`collectstatic`), `backend_logs`.
- **Healthchecks**: `db` (`healthcheck.sh`), `backend` (`/api/v1/health/` con la
  stdlib de Python), `frontend` (`/healthz`).
- **Dependencias**: `backend` espera a `db` *healthy*; `frontend` espera a que
  `backend` haya arrancado. Además `entrypoint.sh` del backend espera al puerto
  de MariaDB, migra y hace `collectstatic` antes de arrancar gunicorn.
- **Reinicio**: `restart: unless-stopped` en los tres servicios.

## Imágenes

| Servicio | Dockerfile | Base | Notas |
|---|---|---|---|
| backend | `backend/Dockerfile` | `python:3.12-slim` | multi-stage (build compila *wheels*, runtime solo `libmariadb3`); usuario `app` no-root; gunicorn |
| frontend | `frontend/Dockerfile` | `node:22-alpine` → `nginx:1.27-alpine` | multi-stage; `npm ci` + `ng build`; nginx sirve `dist/frontend/browser` |
| db | — | `mariadb:10.11` oficial | igual versión que el hosting (MariaDB 10.11.19) |

## Secretos

Nada hardcodeado. Todo viene de `.env` (no versionado). Obligatorias:
`DJANGO_SECRET_KEY`, `JWT_SIGNING_KEY`, `DB_PASSWORD`, `DB_ROOT_PASSWORD`.
Plantilla: **`.env.docker.example`**.

```powershell
python -c "import secrets; print(secrets.token_urlsafe(64))"   # una por cada clave
```

`config.settings.docker` hereda de `prod` (fail-fast de claves, MariaDB,
cabeceras) y solo desactiva lo que exige TLS (no hay HTTPS entre nginx y el
navegador en local).

---

## Cómo levantarlo (desde cero)

```powershell
cd E:\ProyectoPortafolio
cp .env.docker.example .env          # y completa DJANGO_SECRET_KEY, JWT_SIGNING_KEY, DB_PASSWORD, DB_ROOT_PASSWORD
docker compose up --build            # primera vez tarda (compila wheels + ng build)
```

- App: **http://localhost:8080**
- API: **http://localhost:8080/api/v1/health/**
- Admin: **http://localhost:8080/admin/**

Cargar datos de demo / de prueba:

```powershell
docker compose exec backend python manage.py cargar_demo
docker compose exec backend python manage.py seed_carga        # para las pruebas de carga
```

Parar / limpiar:

```powershell
docker compose down                  # conserva los datos (volúmenes)
docker compose down -v               # BORRA la BD (volumen db_data) — usar con cuidado
```

### Desarrollo del backend con recarga

```powershell
docker compose -f docker-compose.yml -f docker-compose.dev.yml up -d db
cd backend
$env:USE_SQLITE="False"; $env:DB_HOST="127.0.0.1"; $env:DB_PORT="3307"
$env:DJANGO_SETTINGS_MODULE="config.settings.local"
python manage.py runserver
# en otra terminal:
cd frontend && npm start             # http://localhost:4200
```

---

## Verificación

Checklist de que el stack funciona (correr tras `docker compose up --build`):

```powershell
docker compose ps                                   # los 3 servicios "healthy"/"running"
curl http://localhost:8080/api/v1/health/           # {"estado":"ok",...}
curl http://localhost:8080/                         # HTML de la SPA (index.html)
docker compose exec backend python manage.py check --deploy
docker compose exec db mysql -upos_user -p"$env:DB_PASSWORD" pos_picking -e "SHOW TABLES;"
docker compose exec backend python manage.py cargar_demo
# login en el navegador: http://localhost:8080  → admin_demo / demo12345
```

Validaciones estáticas ya realizadas (sin daemon Docker en la máquina de
desarrollo):

- `docker-compose.yml` y `docker-compose.dev.yml` — YAML válido.
- `config.settings.docker` carga con `DEBUG=False`, sin SSL redirect, MariaDB.
- `python manage.py collectstatic` — 154 archivos, sin errores.
- `from config.wsgi import application` — OK (`WSGIHandler`).
- `npm run build` (frontend) — bundle de producción OK.
- Backend: 249 tests · `ruff` limpio.

> Pendiente: `docker compose up --build` en una máquina con Docker (aquí no hay
> Docker Desktop; requiere WSL2). Los Dockerfiles y el compose están listos para
> ese paso.
