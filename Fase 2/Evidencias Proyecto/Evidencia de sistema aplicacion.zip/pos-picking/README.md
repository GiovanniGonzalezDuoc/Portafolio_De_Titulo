# POS Picking — Liquidadora Los Europeos

Plataforma integral de gestión comercial: POS, inventario en tiempo real, compras,
caja, boleta electrónica, alertas, dashboard y analítica predictiva (predicción de
demanda + recomendación de reposición).

## Stack

| Capa | Tecnología |
|---|---|
| Frontend | Angular + TypeScript + Angular Material |
| Backend | Python + Django + Django REST Framework |
| Base de datos | MariaDB |
| Auth | JWT |
| Infra | Docker (solo desarrollo local) · cPanel/Passenger (producción) · Git |

## Estructura

```
ProyectoPortafolio/
├── backend/        # Proyecto Django + DRF
├── frontend/       # Proyecto Angular
├── ml/             # Paquete de Machine Learning (predicción de demanda)
├── loadtest/       # Pruebas de carga (k6)
├── docs/           # Documentación del proyecto
└── Contexto/       # Especificación original y material del cliente
```

## Estado

**Proyecto completo — 22 etapas — en producción.**

- **App**: https://systemspickingpos.cl · **API**: https://api.systemspickingpos.cl
- Backend, frontend, ML, Docker, pruebas y deploy en cPanel/LiteSpeed hechos.
- Boleta electrónica: **MOCK** (sin integración real con el SII).

Documentación técnica completa: **[`docs/22-documentacion-tecnica.md`](docs/22-documentacion-tecnica.md)**.

## Desarrollo

**Backend** (Django + DRF): ver `backend/README.md` — `backend\run-dev.ps1` levanta
la API con datos de demostración en `http://127.0.0.1:8000`
(Swagger en `/api/v1/docs/`).

**Frontend** (Angular): ver `frontend/README.md` — `cd frontend && npm start`
(`http://localhost:4200`).

**Stack completo con Docker**: `cp .env.docker.example .env` (completar claves) →
`docker compose up --build` → `http://localhost:8080`.

Usuarios demo (contraseña `demo12345`): `admin_demo`, `bodega_demo`, `vende_demo`;
superusuario `admin` / `admin12345`.

**ML** (predicción de demanda): ver `ml/README.md`.

## Documentos clave

| Documento | Contenido |
|---|---|
| `docs/22-documentacion-tecnica.md` | documentación técnica completa (35 secciones) |
| `docs/01-arquitectura.md` · `docs/02-modelo-datos.md` | arquitectura y modelo de datos |
| `docs/18-auditoria-testing.md` · `docs/19-auditoria-seguridad.md` | auditorías |
| `docs/21-docker.md` · `docs/21-deploy-v2network.md` | Docker y deploy |
| `docs/DECISIONES.md` | registro de decisiones |
| `loadtest/README.md` | pruebas de carga |
