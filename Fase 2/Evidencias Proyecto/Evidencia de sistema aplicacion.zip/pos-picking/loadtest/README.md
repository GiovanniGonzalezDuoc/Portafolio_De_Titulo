# Pruebas de carga — POS Picking (Etapa 20)

Herramienta: **[k6](https://k6.io)** (Grafana). Scripts en `loadtest/k6/`.

> **Contexto del despliegue.** Producción es **hosting compartido cPanel**
> (V2Network): no se pueden lanzar pruebas de carga contra él (lo prohíben los
> términos del servicio y afecta a otros clientes). Por eso estas pruebas se
> corren contra un entorno propio: `docker-compose` (Django + MariaDB) en local
> o una VM de *staging*. Cuando exista un *staging* real, basta cambiar
> `LT_BASE_URL`.

---

## 1. Estrategia

### Qué se prueba (y por qué)

| Escenario | Endpoint(s) | Riesgo que cubre |
|---|---|---|
| **Login** | `POST /auth/login/` | Hash PBKDF2 caro + registro de intento; cuello de botella en apertura de tienda |
| **Consulta de productos** | `GET /catalogo/productos/?search=` | `SearchFilter` con `icontains`; sin índice full-text |
| **Consulta de inventario** | `GET /inventario/stock/?producto=` | *join* producto+ubicación; consultado en cada línea del POS |
| **Búsqueda por código de barras** | `GET /catalogo/productos/por-codigo/{c}/` | Ruta caliente del POS: 1 lectura por artículo escaneado |
| **Cálculo de venta** | `POST /ventas/calcular/` | Recalculo de totales en cada cambio del carrito (sin persistir) |
| **Creación de ventas** | `POST /ventas/` | Transacción + movimiento de inventario + DTE (mock) + movimiento de caja |
| **Actualización de stock** | `POST /inventario/movimientos/registrar/` | Escritura concurrente con las ventas sobre la misma tabla `Stock` |
| **Dashboard** | `GET /dashboard/resumen/` | Varias agregaciones (`aggregate`/`annotate`); riesgo de N+1 |
| **Consultas de reposición** | `GET /reposicion/recomendaciones/` | *select_related* de producto/proveedor/modelo + filtro `con_compra` |
| **Concurrencia de stock** | `POST /ventas/` sobre **un** SKU | `select_for_update` debe impedir la sobreventa |

### Perfiles de prueba

| Script | Tipo | Perfil | Objetivo |
|---|---|---|---|
| `smoke.js` | humo | 1 VU, 1 iteración | Validar entorno + scripts antes de cargar |
| `load.js` | carga | 0→30 VUs (4 min) → 60 VUs punta (2 min) | Comportamiento en un "día normal" con hora punta |
| `login.js` | carga | tasa constante (10–20 login/s, 2 min) | Latencia/throughput solo de autenticación |
| `stress.js` | estrés | 0→500 VUs escalonado (10 min) | Encontrar el punto de quiebre |
| `spike.js` | pico | 5→120 VUs en 10 s, luego baja | Recuperación tras un pico brusco |
| `stock_concurrente.js` | concurrencia | 40 VUs vendiendo el mismo SKU (1 min) | Verificar que **no hay sobreventa** y medir contención |

### Modelo de carga de `load.js`

Distribución de operaciones (aproxima a una tienda con varias cajas):

```
30 %  búsqueda por código de barras   (escaneo)
15 %  consulta de stock
13 %  consulta de productos
15 %  cálculo de venta
15 %  confirmar venta
 7 %  dashboard
 4 %  consultas de reposición
 1 %  ajuste de stock (bodeguero)
```

`think time` de 0,5–2,5 s entre operaciones.

---

## 2. Requisitos y preparación

### Instalar k6

```powershell
winget install GrafanaLabs.k6      # Windows
# brew install k6                  # macOS
# https://grafana.com/docs/k6/latest/set-up/install-k6/
```

### Levantar el backend a probar

**Opción A — docker-compose (recomendada, MariaDB real):**

```powershell
cd E:\ProyectoPortafolio
docker compose up -d db
# backend con settings de carga (throttle de login alto, cache compartida)
$env:DJANGO_SETTINGS_MODULE = "config.settings.local"
$env:DJANGO_LOGIN_RATE = "10000/min"
$env:DJANGO_ANON_RATE  = "10000/min"
$env:DJANGO_USER_RATE  = "10000000/hour"
# servir con varios workers (NO el runserver de desarrollo):
cd backend
python -m gunicorn config.wsgi --workers 4 --bind 127.0.0.1:8000   # Linux/mac
# en Windows: waitress-serve --port=8000 config.wsgi:application
```

**Opción B — SQLite + runserver (solo para validar los scripts):**
sirve para los escenarios de **lectura**, pero **no** para los de escritura:
SQLite serializa las escrituras y devuelve *"database is locked"* con más de
2–3 clientes concurrentes (ver §5). Los números de escritura de esta opción
**no son representativos**.

### Sembrar datos

```powershell
cd backend
python manage.py cargar_demo                                   # base (admin, categorías…)
python manage.py seed_carga --usuarios 30 --bodegueros 3 --productos 500 --stock 1000000
```

Crea `carga01..carga30` (vendedores, cada uno con caja abierta),
`cargabod01..cargabod03` (bodegueros) y `CARGA-0001..CARGA-0500` con stock alto.
Contraseña de todos: `carga-pass-12345`. Idempotente.

---

## 3. Cómo ejecutar

```powershell
cd E:\ProyectoPortafolio

k6 run loadtest/k6/smoke.js
k6 run loadtest/k6/load.js
k6 run loadtest/k6/login.js
k6 run loadtest/k6/stress.js
k6 run loadtest/k6/spike.js
k6 run -e LT_HOT_STOCK=300 loadtest/k6/stock_concurrente.js

# contra staging:
k6 run -e LT_BASE_URL=https://staging.systemspickingpos.cl loadtest/k6/load.js

# guardando resultados para comparar entre corridas:
k6 run --summary-export loadtest/results/load_$(Get-Date -f yyyyMMdd_HHmm).json loadtest/k6/load.js
k6 run --out json=loadtest/results/load_raw.json loadtest/k6/load.js
```

### Variables de entorno (`-e CLAVE=valor`)

| Variable | Default | Para qué |
|---|---|---|
| `LT_BASE_URL` | `http://127.0.0.1:8000` | URL del backend |
| `LT_USERS` | `20` | Nº de vendedores de carga (debe coincidir con `seed_carga`) |
| `LT_BODEGUEROS` | `3` | Nº de bodegueros de carga |
| `LT_PRODUCTS` | `200` | Nº de productos de carga |
| `LT_HOT_SKU` | `CARGA-0001` | SKU del test de concurrencia |
| `LT_HOT_STOCK` | `300` | Stock inicial en el test de concurrencia |
| `LT_LOGIN_RPS` | `10` | Logins/segundo en `login.js` |

---

## 4. Cómo interpretar los resultados

k6 imprime al final un bloque con métricas. Las que importan:

| Métrica | Qué es | Dónde mirar |
|---|---|---|
| `http_reqs` … `/s` | **Throughput** (peticiones/segundo) | ¿aguanta el volumen esperado? |
| `iterations …/s` | Operaciones de negocio completas por segundo | equivale a "ventas/consultas por segundo" |
| `http_req_duration` `p(95)` / `p(99)` | **Latencia**: el 95 %/99 % de las peticiones tardan menos que esto | comparar con los umbrales (§5) |
| `http_req_duration{tipo:lectura\|calculo\|escritura\|login}` | Latencia por tipo de operación | aísla dónde está el problema |
| `http_req_failed` `rate` | **Error rate** (respuestas 4xx/5xx) | debe ser < 1 % (salvo 429 esperados) |
| `checks` `rate` | % de aserciones funcionales correctas | debe ser > 99 % |
| `vus` / `vus_max` | Usuarios concurrentes activos | contexto de la carga |
| `ventas_confirmadas` / `ventas_sin_stock` | Contadores propios | en `stock_concurrente`, la suma de confirmadas debe ser **exactamente** el stock inicial |

**Diagnóstico rápido:**

- **p95 de lectura sube pero el throughput no** → falta un índice o hay N+1.
  Confirmar con el *slow query log* de MariaDB (§6) y `EXPLAIN`.
- **p95 de escritura sube con la concurrencia** → contención del
  `select_for_update` sobre `Stock`. Es esperable hasta cierto punto; si es
  excesivo, revisar el tiempo que la transacción mantiene la fila bloqueada
  (emisión de DTE, movimiento de caja).
- **`http_req_failed` con muchos 429** → se alcanzó el throttle (`login`,
  `user`). En carga hay que subir `DJANGO_*_RATE`; en producción es correcto.
- **500 con `OperationalError` / "database is locked"** → estás probando sobre
  SQLite. Cambia a MariaDB.
- **La latencia no vuelve a la normalidad tras el pico** (`spike.js`) → el pool
  de conexiones (`CONN_MAX_AGE`) o los workers no se recuperan; revisar
  `--workers` y `--max-requests` de gunicorn.

---

## 5. Umbrales de aceptación (SLO)

Definidos en `loadtest/k6/lib/config.js` (`THRESHOLDS`). k6 marca la corrida
como **fallida** si no se cumplen.

| Operación | p95 | p99 | Error rate |
|---|---|---|---|
| Lectura (productos, stock, código de barras, dashboard, reposición) | < **500 ms** | — | < 1 % |
| Cálculo de venta (`/ventas/calcular/`) | < **900 ms** | — | < 1 % |
| Escritura (confirmar venta, ajuste de stock) | < **1500 ms** | — | < 1 % |
| Login | < **1500 ms** | < 2500 ms | < 1 % |
| Global | < 1200 ms | < 3000 ms | < 1 % |
| Aserciones funcionales (`checks`) | — | — | > **99 %** |

**Capacidad objetivo** (a ajustar cuando haya *staging*): sostener **60 VUs**
(≈ 12–15 operaciones/s con *think time*) durante 10 min cumpliendo los SLO,
que cubre de sobra una tienda con 5–8 cajas activas.

**Invariante que nunca puede romperse** (`stock_concurrente.js`): con N cajas
vendiendo el mismo producto, `ventas_confirmadas == stock_inicial` y el stock
final es exactamente 0. Ni una unidad de más. Complementa a los tests unitarios
`apps/inventario/tests/test_servicio.py::test_el_stock_nunca_queda_negativo`
(CHECK de BD) y `apps/ventas/tests/test_servicio.py::test_venta_sin_stock_falla_y_no_persiste_nada`.

---

## 6. MariaDB — consultas lentas

Al levantar `db` con docker-compose, activar el *slow query log*:

```yaml
# docker-compose.yml → services.db.command:  (añadir)
  - --slow-query-log=1
  - --slow-query-log-file=/var/lib/mysql/slow.log
  - --long-query-time=0.3
  - --log-queries-not-using-indexes=1
```

Durante/después de la corrida:

```powershell
docker compose exec db tail -f /var/lib/mysql/slow.log
docker compose exec db mysqldumpslow -s t /var/lib/mysql/slow.log   # top por tiempo
```

Para una consulta concreta, desde el shell de Django:

```python
from django.db import connection
from apps.dashboard import selectors
selectors.kpis_ventas()
for q in connection.queries[-10:]:
    print(q["time"], q["sql"][:200])
```

Los tests del dashboard ya fijan el nº de queries (`assertNumQueries`) para
detectar regresiones de N+1; el *slow log* cubre el caso de un índice que falta
al crecer el volumen de datos.

---

## 7. Resultados de referencia (baseline)

Corrida de validación — **SQLite + `runserver`**, portátil Windows, k6 local.
Sirve para ver que los scripts funcionan y como piso de latencia de lectura;
**no** es un benchmark (ver §5, opción A para el real).

| Escenario | Config | Resultado |
|---|---|---|
| `smoke.js` | 1 VU | 9/9 checks OK · lectura p95 21 ms · cálculo p95 10 ms · escritura p95 776 ms |
| lectura pura | 20 VUs, 60 s | 1038 iters · 12 req/s · **lectura p95 23 ms** · cálculo p95 16 ms · 0 checks fallidos |
| `stock_concurrente` | 6 VUs, `LT_HOT_STOCK=80` | **sin sobreventa** (80 → 34 con 46 ventas) · pero ~40 % de 500 `database is locked` → **SQLite no soporta la carga de escritura; usar MariaDB** |

Conclusión del baseline: las **lecturas y el cálculo son muy rápidos** (p95 ~20 ms)
y sin N+1. El **camino de escritura de ventas es pesado** (~0,8 s incluso a 1 VU:
calcular + transacción + inventario + DTE mock + caja) y **debe** medirse sobre
MariaDB con varios workers para tener números reales. El invariante de no
sobreventa se sostiene incluso cuando la BD está saturada.
