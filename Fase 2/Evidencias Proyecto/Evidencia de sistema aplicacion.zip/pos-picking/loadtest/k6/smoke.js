// smoke.js — 1 usuario, 1 vuelta a cada endpoint. Valida que el entorno y los
// scripts están bien antes de lanzar una prueba de carga real.
//
//   k6 run loadtest/k6/smoke.js
//
import { sleep } from 'k6';
import { THRESHOLDS, HOT_SKU } from './lib/config.js';
import {
  loginTodos, loginBodegueros,
  verProductos, verStock, buscarPorCodigo, dashboard, reposicion,
  calcularVenta, confirmarVenta, actualizarStock,
} from './lib/helpers.js';

export const options = {
  vus: 1,
  iterations: 1,
  thresholds: { ...THRESHOLDS, http_req_failed: ['rate<0.05'] },
};

export function setup() {
  return { vendedor: loginTodos()[0], bodeguero: loginBodegueros()[0] };
}

export default function (data) {
  verProductos(data.vendedor);
  verStock(data.vendedor, HOT_SKU);
  buscarPorCodigo(data.vendedor);
  calcularVenta(data.vendedor, HOT_SKU);
  confirmarVenta(data.vendedor, HOT_SKU);
  dashboard(data.vendedor);
  reposicion(data.bodeguero);
  actualizarStock(data.bodeguero, HOT_SKU);
  sleep(1);
}
