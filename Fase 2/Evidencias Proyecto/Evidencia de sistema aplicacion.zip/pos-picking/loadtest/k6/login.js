// login.js — Escenario dedicado de autenticación. Mide latencia y throughput
// del endpoint de login (hash PBKDF2 + emisión de JWT + registro de intento).
//
//   k6 run -e LT_LOGIN_RPS=15 loadtest/k6/login.js
//
// Nota: el backend limita el login por IP (throttle `login`). Para medir de
// verdad hay que subir DJANGO_LOGIN_RATE en el entorno de prueba.
//
import { check } from 'k6';
import http from 'k6/http';

import { API, USERS, PASSWORD, USER_PREFIX } from './lib/config.js';
import { loginLatencia } from './lib/helpers.js';

const RPS = parseInt(__ENV.LT_LOGIN_RPS || '10', 10);

export const options = {
  scenarios: {
    login: {
      executor: 'constant-arrival-rate',
      rate: RPS,
      timeUnit: '1s',
      duration: '2m',
      preAllocatedVUs: Math.max(RPS * 2, 20),
      maxVUs: RPS * 10,
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.01'],
    'http_req_duration{name:auth/login}': ['p(95)<1500', 'p(99)<2500'],
  },
};

export default function () {
  const i = 1 + Math.floor(Math.random() * USERS);
  const username = `${USER_PREFIX}${String(i).padStart(2, '0')}`;
  const r = http.post(
    `${API}/auth/login/`,
    JSON.stringify({ username, password: PASSWORD }),
    { headers: { 'Content-Type': 'application/json' }, tags: { name: 'auth/login' } },
  );
  loginLatencia.add(r.timings.duration);
  check(r, {
    'login 200': (x) => x.status === 200,
    'trae access + refresh': (x) => x.status === 200 && !!x.json('access') && !!x.json('refresh'),
  });
}
