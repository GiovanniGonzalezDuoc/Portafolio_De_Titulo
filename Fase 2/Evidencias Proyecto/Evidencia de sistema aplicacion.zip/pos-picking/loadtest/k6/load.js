// load.js — Carga "día normal" del POS. Mezcla realista de operaciones con
// pesos aproximados a los de una tienda con varias cajas trabajando.
//
//   k6 run loadtest/k6/load.js
//   k6 run -e LT_BASE_URL=https://staging.systemspickingpos.cl loadtest/k6/load.js
//
import { sleep } from 'k6';
import exec from 'k6/execution';

import { THRESHOLDS } from './lib/config.js';
import {
  loginTodos, loginBodegueros,
  verProductos, verStock, buscarPorCodigo, dashboard, reposicion,
  calcularVenta, confirmarVenta, actualizarStock,
} from './lib/helpers.js';

export const options = {
  scenarios: {
    pos: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '1m', target: 30 },   // llegada de cajeros
        { duration: '4m', target: 30 },   // jornada estable
        { duration: '1m', target: 60 },   // hora punta
        { duration: '2m', target: 60 },
        { duration: '1m', target: 0 },    // cierre
      ],
      gracefulRampDown: '20s',
    },
  },
  thresholds: THRESHOLDS,
};

export function setup() {
  return { vendedores: loginTodos(), bodegueros: loginBodegueros() };
}

// Distribución de acciones (suma 100). Lecturas dominan, como en un POS real.
function accion() {
  const p = Math.random() * 100;
  if (p < 30) return 'buscar_codigo';   // escaneo en el POS
  if (p < 45) return 'ver_stock';
  if (p < 58) return 'ver_productos';
  if (p < 73) return 'calcular';
  if (p < 88) return 'confirmar_venta';
  if (p < 95) return 'dashboard';
  if (p < 99) return 'reposicion';
  return 'ajuste_stock';
}

export default function (data) {
  const vend = data.vendedores[exec.vu.idInTest % data.vendedores.length];
  const bod = data.bodegueros[exec.vu.idInTest % data.bodegueros.length];

  switch (accion()) {
    case 'buscar_codigo': buscarPorCodigo(vend); break;
    case 'ver_stock': verStock(vend); break;
    case 'ver_productos': verProductos(vend); break;
    case 'calcular': calcularVenta(vend); break;
    case 'confirmar_venta': confirmarVenta(vend); break;
    case 'dashboard': dashboard(vend); break;
    case 'reposicion': reposicion(bod); break;
    case 'ajuste_stock': actualizarStock(bod); break;
  }
  sleep(Math.random() * 2 + 0.5); // think time 0.5–2.5 s
}
