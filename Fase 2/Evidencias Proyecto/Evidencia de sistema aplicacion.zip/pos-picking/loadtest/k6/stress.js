// stress.js — Sube la concurrencia por encima de lo esperado hasta encontrar
// el punto de quiebre (dónde la latencia p95 se dispara o suben los errores).
//
//   k6 run loadtest/k6/stress.js
//
import { sleep } from 'k6';
import exec from 'k6/execution';

import {
  loginTodos, loginBodegueros,
  buscarPorCodigo, verStock, calcularVenta, confirmarVenta, dashboard,
} from './lib/helpers.js';

export const options = {
  scenarios: {
    escalada: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '1m', target: 50 },
        { duration: '2m', target: 100 },
        { duration: '2m', target: 200 },
        { duration: '2m', target: 350 },
        { duration: '2m', target: 500 },
        { duration: '1m', target: 0 },
      ],
      gracefulRampDown: '30s',
    },
  },
  // En stress no se "aprueba/reprueba": se observa. Solo se aborta si el
  // servidor deja de responder del todo.
  thresholds: {
    http_req_failed: [{ threshold: 'rate<0.25', abortOnFail: true, delayAbortEval: '30s' }],
  },
};

export function setup() {
  return { vendedores: loginTodos(), bodegueros: loginBodegueros() };
}

export default function (data) {
  const vend = data.vendedores[exec.vu.idInTest % data.vendedores.length];
  const p = Math.random() * 100;
  if (p < 40) buscarPorCodigo(vend);
  else if (p < 60) verStock(vend);
  else if (p < 80) calcularVenta(vend);
  else if (p < 95) confirmarVenta(vend);
  else dashboard(vend);
  sleep(Math.random() * 0.5);
}
