// spike.js — Salto brusco de tráfico (p. ej. apertura de la tienda o una
// promoción). Mide cuánto tarda el sistema en recuperar la latencia normal.
//
//   k6 run loadtest/k6/spike.js
//
import { sleep } from 'k6';
import exec from 'k6/execution';

import { THRESHOLDS } from './lib/config.js';
import { loginTodos, buscarPorCodigo, calcularVenta, confirmarVenta } from './lib/helpers.js';

export const options = {
  scenarios: {
    pico: {
      executor: 'ramping-vus',
      startVUs: 5,
      stages: [
        { duration: '30s', target: 5 },    // base
        { duration: '10s', target: 120 },  // ¡pico!
        { duration: '1m', target: 120 },
        { duration: '20s', target: 5 },    // vuelta a la base
        { duration: '1m', target: 5 },     // ¿se recuperó la latencia?
      ],
    },
  },
  thresholds: { ...THRESHOLDS, http_req_failed: ['rate<0.05'] },
};

export function setup() {
  return { vendedores: loginTodos() };
}

export default function (data) {
  const vend = data.vendedores[exec.vu.idInTest % data.vendedores.length];
  const p = Math.random() * 100;
  if (p < 55) buscarPorCodigo(vend);
  else if (p < 80) calcularVenta(vend);
  else confirmarVenta(vend);
  sleep(Math.random() * 1 + 0.2);
}
