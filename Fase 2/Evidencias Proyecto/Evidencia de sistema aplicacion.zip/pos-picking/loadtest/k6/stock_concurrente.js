// stock_concurrente.js — Muchas cajas venden EL MISMO producto a la vez.
// Objetivo: verificar que el bloqueo `select_for_update` de `confirmar_venta`
// impide la sobreventa y medir la contención (latencia de las escrituras que
// compiten por la misma fila de stock).
//
//   k6 run -e LT_HOT_STOCK=300 loadtest/k6/stock_concurrente.js
//
// Resultado esperado:
//   ventas_confirmadas == stock inicial   (ni una más)
//   ventas_sin_stock    > 0               (el resto rebota con 409)
//   stock final          == 0             (nunca negativo)
//
import http from 'k6/http';
import { fail } from 'k6';

import { API, HOT_SKU } from './lib/config.js';
import {
  loginTodos, loginBodegueros, headers, confirmarVenta, ventasOk, ventasSinStock,
} from './lib/helpers.js';

const STOCK_INICIAL = parseInt(__ENV.LT_HOT_STOCK || '300', 10);

export const options = {
  scenarios: {
    embestida: {
      executor: 'constant-vus',
      vus: 40,
      duration: '1m',
    },
  },
  thresholds: {
    // No debe haber respuestas distintas de 201 / 409-sin-stock.
    checks: ['rate>0.99'],
    'http_req_duration{name:ventas/confirmar}': ['p(95)<3000'],
  },
};

export function setup() {
  const vendedores = loginTodos();
  const bodeguero = loginBodegueros()[0];

  // Deja el stock del SKU foco en una cantidad pequeña y conocida.
  const r = http.post(
    `${API}/inventario/movimientos/ajustar/`,
    JSON.stringify({ producto: HOT_SKU, cantidad_final: STOCK_INICIAL, motivo: 'setup carga' }),
    headers(bodeguero),
  );
  if (r.status !== 201) fail(`no se pudo fijar el stock de ${HOT_SKU}: ${r.status} ${r.body}`);

  return { vendedores, bodeguero, stockInicial: STOCK_INICIAL };
}

export default function (data) {
  const vend = data.vendedores[(__VU + __ITER) % data.vendedores.length];
  confirmarVenta(vend, HOT_SKU, 1);
}

export function teardown(data) {
  const r = http.get(`${API}/inventario/stock/?producto=${HOT_SKU}`, headers(data.bodeguero));
  const filas = r.json('resultados') || [];
  const stockFinal = filas.reduce((a, f) => a + Number(f.cantidad), 0);

  console.log(`\n─── stock_concurrente ───────────────────────────`);
  console.log(`  stock inicial fijado : ${data.stockInicial}`);
  console.log(`  ventas confirmadas   : ${ventasOk.name} (ver métrica ventas_confirmadas)`);
  console.log(`  stock final          : ${stockFinal}`);
  console.log(`─────────────────────────────────────────────────\n`);

  if (stockFinal < 0) fail(`SOBREVENTA: stock final negativo (${stockFinal})`);
}
