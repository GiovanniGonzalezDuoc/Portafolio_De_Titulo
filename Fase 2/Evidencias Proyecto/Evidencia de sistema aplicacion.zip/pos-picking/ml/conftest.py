"""Permite ejecutar los tests de ML sin Django: agrega la raíz del repo al path."""

import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))
