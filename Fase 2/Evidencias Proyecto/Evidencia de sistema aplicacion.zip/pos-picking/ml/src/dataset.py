"""
Generación de un dataset **sintético** de demanda semanal por producto.

No hay histórico real de ventas todavía (decisión D13). Este generador crea una
serie realista por producto — con tendencia, estacionalidad anual, efecto de
precio y promociones, quiebres de stock y ruido — para desarrollar y validar el
pipeline de ML. Los datos quedan marcados como ``simulado=True``.

Cuando exista histórico real, se reemplaza ``cargar_ventas_reales`` por un export
de la app ``ventas`` con el mismo esquema de columnas.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .config import DATA_RAW, SEMILLA

COLUMNAS = [
    "producto_sku", "categoria", "semana", "anio", "semana_iso",
    "precio", "en_promocion", "quiebre_stock", "unidades", "simulado",
]

_PRODUCTOS_DEMO = [
    # sku, categoria, demanda_base, precio_base, estacionalidad (amplitud 0..1), tendencia_anual
    ("BEB-001", "Bebidas", 120, 790, 0.45, 0.06),
    ("BEB-002", "Bebidas", 80, 1690, 0.40, 0.04),
    ("ABA-001", "Abarrotes", 60, 1290, 0.15, 0.02),
    ("ABA-002", "Abarrotes", 35, 2490, 0.10, 0.01),
    ("ABA-003", "Abarrotes", 45, 990, 0.12, 0.03),
    ("ASE-001", "Aseo", 25, 3490, 0.08, 0.00),
    ("ASE-002", "Aseo", 40, 1190, 0.10, 0.01),
    ("HER-001", "Herramientas", 6, 34990, 0.20, 0.05),
    ("HER-002", "Herramientas", 10, 8990, 0.18, 0.03),
    ("MAS-001", "Mascotas", 18, 9990, 0.05, 0.04),
]


def generar(n_semanas: int = 130, semilla: int = SEMILLA) -> pd.DataFrame:
    """Devuelve un DataFrame con ``n_semanas`` de historia por producto."""
    rng = np.random.default_rng(semilla)
    fin = pd.Timestamp.today().normalize() - pd.Timedelta(days=pd.Timestamp.today().weekday())
    semanas = pd.date_range(end=fin, periods=n_semanas, freq="W-MON")

    filas = []
    for sku, cat, base, precio_base, est_amp, tend in _PRODUCTOS_DEMO:
        # Precio: mayormente estable, con rebajas puntuales (promociones).
        promo = rng.random(n_semanas) < 0.12
        precio = np.where(promo, precio_base * rng.uniform(0.75, 0.9, n_semanas), precio_base)
        precio = np.round(precio / 10) * 10

        t = np.arange(n_semanas)
        tendencia = 1 + tend * (t / 52.0)
        estacional = 1 + est_amp * np.sin(2 * np.pi * (semanas.isocalendar().week.to_numpy() / 52.0))
        elasticidad = (precio_base / precio) ** 0.8          # baja precio -> sube demanda
        lift_promo = np.where(promo, rng.uniform(1.3, 1.8, n_semanas), 1.0)

        mu = base * tendencia * estacional * elasticidad * lift_promo
        unidades = rng.poisson(np.clip(mu, 0.1, None)).astype(float)

        # Quiebres de stock: demanda censurada (se pierde venta).
        quiebre = rng.random(n_semanas) < 0.05
        unidades = np.where(quiebre, np.floor(unidades * rng.uniform(0.0, 0.4, n_semanas)), unidades)

        for i, sem in enumerate(semanas):
            iso = sem.isocalendar()
            filas.append(
                (sku, cat, sem.date().isoformat(), int(iso.year), int(iso.week),
                 int(precio[i]), bool(promo[i]), bool(quiebre[i]), float(unidades[i]), True)
            )

    df = pd.DataFrame(filas, columns=COLUMNAS)
    return df


def guardar_raw(df: pd.DataFrame, nombre: str = "demanda_semanal.csv") -> str:
    ruta = DATA_RAW / nombre
    df.to_csv(ruta, index=False)
    return str(ruta)


def cargar_raw(nombre: str = "demanda_semanal.csv") -> pd.DataFrame:
    ruta = DATA_RAW / nombre
    if not ruta.exists():
        df = generar()
        guardar_raw(df, nombre)
        return df
    return pd.read_csv(ruta, parse_dates=["semana"])


if __name__ == "__main__":
    df = generar()
    print(guardar_raw(df))
    print(df.groupby("producto_sku")["unidades"].describe().round(1))
