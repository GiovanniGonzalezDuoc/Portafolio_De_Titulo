"""Rutas y constantes del paquete de ML."""

from __future__ import annotations

import os
from pathlib import Path

ML_DIR = Path(__file__).resolve().parent.parent
DATA_RAW = ML_DIR / "data" / "raw"
DATA_PROCESSED = ML_DIR / "data" / "processed"
MODELS_DIR = ML_DIR / "models"

for _d in (DATA_RAW, DATA_PROCESSED, MODELS_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# ─── Parámetros del problema ────────────────────────────────
GRANULARIDAD = "SEMANAL"          # ver docs/13-prediccion-demanda.md (decisión D12)
OBJETIVO = "unidades"            # variable a predecir: unidades vendidas por producto/semana

# Regla de datos mínimos (RF-K8): semanas con ventas reales que necesita un
# producto antes de dejar el dataset sintético y predecir con su propio
# histórico. El requisito completo (alcance "máximo") es 12 semanas; se
# puede operar con menos (p. ej. 6, mientras se acumula historial real) sin
# tocar código, vía `ML_MIN_SEMANAS_HISTORIA`. `PrediccionDemandaViewSet.
# calcular` además permite pasar un mínimo puntual solo para esa consulta,
# para poder demostrar el mecanismo en el momento sin cambiar esta variable.
MIN_SEMANAS_HISTORIA_MAXIMO = 12
MIN_SEMANAS_HISTORIA = int(os.environ.get("ML_MIN_SEMANAS_HISTORIA", "6"))

# Nivel de confianza de una predicción con datos reales, según cuántas semanas
# de historia real la respaldan (aparte de si alcanza el mínimo de RF-K8 para
# siquiera intentarlo): por debajo de UMBRAL_CONFIANZA_ESTABLE es "no estable"
# (recién empezando a acumular historial); hasta UMBRAL_CONFIANZA_CONFIABLE es
# "estable"; desde ahí es "confiable" (cubre ~un ciclo anual, así `lag_52` deja
# de depender del relleno en 0). Una predicción con dataset sintético siempre
# se etiqueta "no estable": todavía no está validada con ventas reales.
UMBRAL_CONFIANZA_ESTABLE = int(os.environ.get("ML_UMBRAL_CONFIANZA_ESTABLE", "16"))
UMBRAL_CONFIANZA_CONFIABLE = int(os.environ.get("ML_UMBRAL_CONFIANZA_CONFIABLE", "52"))

SEMILLA = 42

# Nombre base del artefacto entrenado
ARTEFACTO_ACTIVO = "demanda_actual"
