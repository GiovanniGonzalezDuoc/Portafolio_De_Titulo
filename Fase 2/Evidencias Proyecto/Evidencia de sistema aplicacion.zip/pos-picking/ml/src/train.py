"""
Pipeline de entrenamiento de la predicción de demanda.

Pasos: cargar → construir variables → split **temporal** → entrenar candidatos
→ evaluar (MAE/RMSE/MAPE/sMAPE) → elegir el mejor → guardar artefacto + métricas.

Uso::

    python -m ml.src.train              # entrena con el dataset sintético
    python -m ml.src.train --datos ruta.csv
"""

from __future__ import annotations

import argparse
import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from . import config, evaluate
from .config import SEMILLA
from .dataset import cargar_raw
from .features import COLUMNAS_FEATURES, OBJETIVO, construir

SEMANAS_TEST = 12  # últimas N semanas para validación (holdout temporal)

# En hosting compartido (CloudLinux LVE) `n_jobs=-1` intenta lanzar un proceso
# por núcleo del nodo (~40) y choca con el límite de la cuenta. Con 1 basta para
# este volumen; se puede subir con ML_N_JOBS en un entorno con más recursos.
N_JOBS = int(os.environ.get("ML_N_JOBS", "1"))


@dataclass
class Resultado:
    nombre: str
    metricas: dict
    modelo: object


# ─── Modelos candidatos ────────────────────────────────────
class BaselineNaiveEstacional:
    """Predice la demanda de la misma semana del año anterior (lag_52)."""

    col = "lag_52"

    def fit(self, X, y):  # noqa: N803
        self.media_ = float(np.mean(y))
        return self

    def predict(self, X):  # noqa: N803
        v = X[self.col].to_numpy(dtype=float)
        return np.where(v > 0, v, self.media_)


class BaselineMediaMovil:
    col = "mm_4"

    def fit(self, X, y):  # noqa: N803
        self.media_ = float(np.mean(y))
        return self

    def predict(self, X):  # noqa: N803
        v = X[self.col].to_numpy(dtype=float)
        return np.where(v > 0, v, self.media_)


def _candidatos() -> dict:
    return {
        "baseline_naive_estacional": BaselineNaiveEstacional(),
        "baseline_media_movil": BaselineMediaMovil(),
        "ridge": Pipeline([("scaler", StandardScaler()), ("reg", Ridge(alpha=1.0, random_state=SEMILLA))]),
        "random_forest": RandomForestRegressor(
            n_estimators=250, max_depth=10, min_samples_leaf=3,
            random_state=SEMILLA, n_jobs=N_JOBS,
        ),
    }


def split_temporal(df: pd.DataFrame, semanas_test: int = SEMANAS_TEST):
    corte = df["semana"].sort_values().unique()[-semanas_test]
    train = df[df["semana"] < corte]
    test = df[df["semana"] >= corte]
    return train, test, pd.Timestamp(corte)


def entrenar(datos_csv: str | None = None) -> dict:
    crudo = pd.read_csv(datos_csv, parse_dates=["semana"]) if datos_csv else cargar_raw()
    df = construir(crudo)
    train, test, corte = split_temporal(df)

    Xtr, ytr = train[COLUMNAS_FEATURES], train[OBJETIVO].to_numpy(dtype=float)
    Xte, yte = test[COLUMNAS_FEATURES], test[OBJETIVO].to_numpy(dtype=float)

    resultados: list[Resultado] = []
    for nombre, modelo in _candidatos().items():
        modelo.fit(Xtr if _usa_df(modelo) else Xtr.to_numpy(), ytr)
        pred = modelo.predict(Xte if _usa_df(modelo) else Xte.to_numpy())
        pred = np.clip(np.round(pred), 0, None)
        resultados.append(Resultado(nombre, evaluate.resumen(yte, pred), modelo))

    resultados.sort(key=lambda r: r.metricas["mae"])
    mejor = resultados[0]

    # Reentrena el mejor con TODOS los datos antes de guardar.
    modelo_final = _candidatos()[mejor.nombre]
    X_all, y_all = df[COLUMNAS_FEATURES], df[OBJETIVO].to_numpy(dtype=float)
    modelo_final.fit(X_all if _usa_df(modelo_final) else X_all.to_numpy(), y_all)

    version = f"demanda_{datetime.now(timezone.utc):%Y%m%d_%H%M}"
    artefacto = {
        "version": version,
        "algoritmo": mejor.nombre,
        "features": COLUMNAS_FEATURES,
        "objetivo": OBJETIVO,
        "modelo": modelo_final,
    }
    config.MODELS_DIR.mkdir(parents=True, exist_ok=True)
    ruta_modelo = config.MODELS_DIR / f"{config.ARTEFACTO_ACTIVO}.joblib"
    joblib.dump(artefacto, ruta_modelo)

    metricas = {
        "version": version,
        "algoritmo_elegido": mejor.nombre,
        "entrenado_en": datetime.now(timezone.utc).isoformat(),
        "n_train": int(len(train)),
        "n_test": int(len(test)),
        "corte_test": corte.date().isoformat(),
        "comparativa": {r.nombre: r.metricas for r in resultados},
        "metricas_test": mejor.metricas,
        "datos": "sintetico" if datos_csv is None else datos_csv,
    }
    (config.MODELS_DIR / f"{config.ARTEFACTO_ACTIVO}.metrics.json").write_text(
        json.dumps(metricas, indent=2, ensure_ascii=False)
    )
    return metricas


def _usa_df(modelo) -> bool:
    return isinstance(modelo, (BaselineNaiveEstacional, BaselineMediaMovil))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--datos", default=None)
    args = ap.parse_args()
    m = entrenar(args.datos)
    print(json.dumps(m, indent=2, ensure_ascii=False))
