"""
Carga el artefacto entrenado y predice la demanda semanal de un producto.

Este módulo es **puro Python** (sin Django). La app ``prediccion`` de la Etapa 14
lo envuelve en un servicio con caché y persiste los resultados.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

import joblib
import numpy as np
import pandas as pd

from . import config
from .config import MIN_SEMANAS_HISTORIA
from .features import COLUMNAS_FEATURES, construir


@dataclass
class Prediccion:
    sku: str
    horizonte_semanas: int
    demanda_estimada: float
    desviacion: float
    modelo_version: str
    algoritmo: str


@lru_cache(maxsize=1)
def _cargar(ruta: str):
    return joblib.load(ruta)


def _ruta_artefacto() -> str:
    return str(config.MODELS_DIR / f"{config.ARTEFACTO_ACTIVO}.joblib")


def limpiar_cache() -> None:
    _cargar.cache_clear()


def hay_modelo() -> bool:
    return (config.MODELS_DIR / f"{config.ARTEFACTO_ACTIVO}.joblib").exists()


def predecir_semana(historia: pd.DataFrame) -> tuple[float, str, str]:
    """Predice la demanda de la próxima semana para el producto de ``historia``."""
    art = _cargar(_ruta_artefacto())
    feats = construir(historia)
    if feats.empty:
        raise ValueError("Historia insuficiente para predecir.")
    fila = feats.iloc[[-1]][COLUMNAS_FEATURES]
    modelo = art["modelo"]
    X = fila if art["algoritmo"].startswith("baseline") else fila.to_numpy()
    valor = float(np.clip(round(float(modelo.predict(X)[0])), 0, None))
    return valor, art["version"], art["algoritmo"]


def predecir(
    historia: pd.DataFrame, *, horizonte_semanas: int = 4, minimo_semanas: int | None = None
) -> Prediccion:
    """
    Predicción a ``horizonte_semanas`` para un producto.

    Estrategia simple y explicable: se proyecta la demanda semanal (última
    semana estimada) y se multiplica por el horizonte. La desviación se estima
    a partir de la variabilidad histórica reciente.

    ``minimo_semanas`` reemplaza puntualmente a ``MIN_SEMANAS_HISTORIA`` (RF-K8)
    — debe ser el mismo valor con el que se eligió ``historia`` (real o
    sintética) para no rechazarla acá con un umbral distinto.
    """
    minimo = MIN_SEMANAS_HISTORIA if minimo_semanas is None else minimo_semanas
    sku = str(historia["producto_sku"].iloc[0])
    semanas_con_datos = historia["unidades"].gt(0).sum()
    if semanas_con_datos < minimo:
        raise ValueError(
            f"Datos insuficientes para {sku}: {semanas_con_datos} semanas con ventas "
            f"(mínimo {minimo})."
        )

    semanal, version, algoritmo = predecir_semana(historia)
    sigma_semanal = float(historia["unidades"].tail(12).std(ddof=0) or 0.0)

    return Prediccion(
        sku=sku,
        horizonte_semanas=horizonte_semanas,
        demanda_estimada=round(semanal * horizonte_semanas, 3),
        desviacion=round(sigma_semanal * (horizonte_semanas ** 0.5), 3),
        modelo_version=version,
        algoritmo=algoritmo,
    )
