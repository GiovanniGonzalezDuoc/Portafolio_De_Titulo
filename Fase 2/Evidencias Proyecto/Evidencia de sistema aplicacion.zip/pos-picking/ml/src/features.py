"""
Ingeniería de variables para la predicción de demanda.

**Sin data leakage**: todas las variables de una semana se calculan usando
únicamente información disponible **hasta la semana anterior** (lags y medias
móviles desplazadas). El split de validación es temporal (ver ``train.py``).
"""

from __future__ import annotations

import numpy as np
import pandas as pd

LAGS = [1, 2, 3, 4, 52]
VENTANAS_MM = [4, 8]

COLUMNAS_FEATURES = [
    "mes", "semana_del_anio", "sin_semana", "cos_semana",
    "precio", "en_promocion", "quiebre_semana_anterior",
    *[f"lag_{k}" for k in LAGS],
    *[f"mm_{w}" for w in VENTANAS_MM],
    "tendencia_4s",
]
OBJETIVO = "unidades"


def construir(df: pd.DataFrame) -> pd.DataFrame:
    """
    Recibe el dataset crudo (una fila por producto/semana) y devuelve otro con
    las columnas de ``COLUMNAS_FEATURES`` + ``OBJETIVO``, listo para entrenar.
    """
    df = df.copy()
    df["semana"] = pd.to_datetime(df["semana"])
    df = df.sort_values(["producto_sku", "semana"]).reset_index(drop=True)

    df["mes"] = df["semana"].dt.month
    df["semana_del_anio"] = df["semana"].dt.isocalendar().week.astype(int)
    df["sin_semana"] = np.sin(2 * np.pi * df["semana_del_anio"] / 52.0)
    df["cos_semana"] = np.cos(2 * np.pi * df["semana_del_anio"] / 52.0)
    df["en_promocion"] = df["en_promocion"].astype(int)

    g = df.groupby("producto_sku", group_keys=False)

    # Quiebre de la semana anterior (el de la semana actual no se conoce al predecir).
    df["quiebre_semana_anterior"] = g["quiebre_stock"].shift(1).fillna(0).astype(int)

    for k in LAGS:
        df[f"lag_{k}"] = g[OBJETIVO].shift(k)

    for w in VENTANAS_MM:
        df[f"mm_{w}"] = g[OBJETIVO].transform(lambda s, w=w: s.shift(1).rolling(w, min_periods=1).mean())

    df["tendencia_4s"] = g[OBJETIVO].transform(
        lambda s: s.shift(1).rolling(4, min_periods=2).mean() - s.shift(5).rolling(4, min_periods=2).mean()
    )

    columnas = ["producto_sku", "categoria", "semana", OBJETIVO, *COLUMNAS_FEATURES]
    # Solo se exige `lag_1` (al menos una semana previa real): los lags más
    # largos (hasta `lag_52`, la estacionalidad anual) que no alcancen a tener
    # historia quedan en 0 más abajo en vez de descartar la fila entera. Así
    # un producto con poco historial real igual puede predecirse (con menos
    # señal, no sin ella) — antes se exigía `lag_52` y eso obligaba a ~53
    # semanas de historia real para obtener una sola fila utilizable.
    resultado = df[columnas].dropna(subset=["lag_1"]).reset_index(drop=True)
    resultado = resultado.fillna(0)
    return resultado


def matriz_para_prediccion(historia: pd.DataFrame) -> pd.Series:
    """
    Dado el histórico de UN producto (columnas del dataset crudo), devuelve la
    fila de features para predecir la **siguiente** semana.
    """
    with_features = construir(historia)
    if with_features.empty:
        raise ValueError("Historia insuficiente para construir las variables.")
    return with_features.iloc[-1][COLUMNAS_FEATURES]
