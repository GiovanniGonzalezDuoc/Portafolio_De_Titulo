# ml/ — Predicción de demanda

Paquete Python **independiente de Django**. La app `apps/prediccion` (Etapa 14)
carga el artefacto entrenado y sirve las predicciones.

```
ml/
├── src/
│   ├── config.py      rutas y constantes (granularidad, mínimo de datos, semilla)
│   ├── dataset.py     generador de dataset SINTÉTICO (no hay histórico real aún)
│   ├── features.py    ingeniería de variables (temporal, sin data leakage)
│   ├── evaluate.py    MAE, RMSE, MAPE, sMAPE
│   ├── train.py       pipeline: cargar → features → split temporal → comparar → guardar
│   └── predict.py     carga el artefacto y predice (con regla de datos mínimos)
├── notebooks/
│   └── entrenamiento_demanda.ipynb   flujo completo paso a paso
├── data/              raw/ y processed/  (git-ignored salvo .gitkeep)
├── models/            artefactos .joblib + .metrics.json  (git-ignored salvo .gitkeep)
└── tests/             pytest, sin Django
```

## Uso (venv del backend)

```bash
# desde la raíz del repo
backend/.venv/Scripts/python -m ml.src.dataset     # (re)genera data/raw/demanda_semanal.csv
backend/.venv/Scripts/python -m ml.src.train       # entrena y guarda models/demanda_actual.joblib
backend/.venv/Scripts/python -m pytest ml/tests    # 5 tests
```

## Decisiones

- **Granularidad semanal por producto** (D12).
- **Dataset sintético** hasta tener histórico real (D13); mismo esquema de columnas
  que tendrá el export de `ventas`.
- Sin *data leakage*: features desplazadas + split temporal.
- Modelo elegido por menor **MAE** en las últimas 12 semanas; debe superar al baseline.

Análisis completo: `docs/13-prediccion-demanda.md`.
