"""Tests del pipeline de predicción de demanda (paquete ml, sin Django)."""

import numpy as np
import pandas as pd
import pytest
from ml.src import evaluate
from ml.src.dataset import COLUMNAS, generar
from ml.src.features import COLUMNAS_FEATURES, construir


def test_dataset_sintetico_tiene_esquema_y_es_reproducible():
    a = generar(n_semanas=60, semilla=1)
    b = generar(n_semanas=60, semilla=1)
    assert list(a.columns) == COLUMNAS
    assert a.equals(b)                      # misma semilla -> mismo dataset
    assert a["simulado"].all()
    assert (a["unidades"] >= 0).all()


def test_features_sin_data_leakage():
    df = generar(n_semanas=120, semilla=2)
    feats = construir(df)
    assert set(COLUMNAS_FEATURES).issubset(feats.columns)
    assert not feats[COLUMNAS_FEATURES].isna().any().any()

    # lag_1 de una fila == unidades de la fila anterior del mismo producto.
    uno = df[df.producto_sku == "BEB-001"].copy()
    uno["semana"] = pd.to_datetime(uno["semana"])
    uno = uno.sort_values("semana").reset_index(drop=True)
    f_uno = construir(uno).sort_values("semana").reset_index(drop=True)

    fila = f_uno.iloc[10]
    prev = uno.loc[uno["semana"] == fila["semana"] - pd.Timedelta(weeks=1), "unidades"]
    assert not prev.empty
    assert fila["lag_1"] == prev.iloc[0]
    # ninguna feature usa 'unidades' de la MISMA semana
    assert fila["mm_4"] != fila["unidades"] or fila["unidades"] == 0


def test_metricas():
    y = np.array([10, 20, 30, 40])
    p = np.array([12, 18, 33, 39])
    r = evaluate.resumen(y, p)
    assert r["mae"] == 2.0
    assert r["rmse"] > 0
    assert 0 <= r["smape"] <= 200


def test_entrenamiento_supera_al_baseline(tmp_path, monkeypatch):
    from ml.src import config, train

    monkeypatch.setattr(config, "MODELS_DIR", tmp_path)
    df = generar(n_semanas=130, semilla=42)
    csv = tmp_path / "d.csv"
    df.to_csv(csv, index=False)

    m = train.entrenar(str(csv))
    comp = m["comparativa"]
    mejor_mae = m["metricas_test"]["mae"]
    baseline_mae = min(
        comp["baseline_naive_estacional"]["mae"], comp["baseline_media_movil"]["mae"]
    )
    assert mejor_mae <= baseline_mae            # el modelo elegido no es peor que el baseline
    assert (tmp_path / "demanda_actual.joblib").exists()
    assert (tmp_path / "demanda_actual.metrics.json").exists()


def test_prediccion_respeta_minimo_de_datos(tmp_path, monkeypatch):
    from ml.src import config, predict, train

    monkeypatch.setattr(config, "MODELS_DIR", tmp_path)
    df = generar(n_semanas=130, semilla=42)
    csv = tmp_path / "d.csv"
    df.to_csv(csv, index=False)
    train.entrenar(str(csv))
    predict.limpiar_cache()

    hist = df[df.producto_sku == "BEB-001"].copy()
    p = predict.predecir(hist, horizonte_semanas=4)
    assert p.demanda_estimada > 0
    assert p.horizonte_semanas == 4

    pobre = hist.head(5)
    with pytest.raises(ValueError):
        predict.predecir(pobre, horizonte_semanas=4)

    # `minimo_semanas` permite bajar puntualmente el umbral (p. ej. para
    # demostrar el mecanismo con menos historial) sin tocar la configuración.
    p2 = predict.predecir(pobre, horizonte_semanas=4, minimo_semanas=3)
    assert p2.demanda_estimada >= 0
