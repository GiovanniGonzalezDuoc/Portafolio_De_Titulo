# Prepara y levanta el proyecto en local (SQLite, sin MariaDB ni Docker).
param([switch]$SoloPreparar)
$ErrorActionPreference = 'Continue'
$raiz = $PSScriptRoot
$back = Join-Path $raiz 'backend'
$front = Join-Path $raiz 'frontend'

function Falla($m) { Write-Host "ERROR: $m" -ForegroundColor Red; exit 1 }

if (-not (Get-Command python -ErrorAction SilentlyContinue)) { Falla 'No se encontro Python. Instala Python 3.13 y marca "Add to PATH".' }
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { Falla 'No se encontro Node.js. Instala Node.js 24.' }

Set-Location $back
$py = Join-Path $back '.venv\Scripts\python.exe'
if (-not (Test-Path $py)) {
    Write-Host '[1/5] Creando entorno de Python...' -ForegroundColor Cyan
    python -m venv .venv
    if ($LASTEXITCODE -ne 0) { Falla 'No se pudo crear el entorno virtual.' }
}
Write-Host '[2/5] Instalando dependencias del backend...' -ForegroundColor Cyan
& $py -m pip install -q --disable-pip-version-check -r requirements.txt
if ($LASTEXITCODE -ne 0) { Falla 'Fallo la instalacion de dependencias del backend.' }

if (-not (Test-Path '.env')) {
    $k1 = & $py -c "import secrets; print(secrets.token_urlsafe(64))"
    $k2 = & $py -c "import secrets; print(secrets.token_urlsafe(64))"
    $env_ = (Get-Content '.env.example' -Encoding UTF8) `
        -replace '^USE_SQLITE=.*', 'USE_SQLITE=True' `
        -replace '^DJANGO_SECRET_KEY=.*', "DJANGO_SECRET_KEY=$k1" `
        -replace '^JWT_SIGNING_KEY=.*', "JWT_SIGNING_KEY=$k2"
    [IO.File]::WriteAllLines((Join-Path $back '.env'), [string[]]$env_)
}

Write-Host '[3/5] Creando la base de datos y los datos de demostracion...' -ForegroundColor Cyan
& $py manage.py migrate --noinput
if ($LASTEXITCODE -ne 0) { Falla 'Fallaron las migraciones.' }
& $py manage.py cargar_demo
if ($LASTEXITCODE -ne 0) { Falla 'Fallo la carga de datos de demostracion.' }
& $py manage.py shell -c "from django.contrib.auth import get_user_model as g; U=g(); U.objects.filter(username='admin').exists() or U.objects.create_superuser(username='admin', email='admin@example.com', password='admin12345')"
if ($LASTEXITCODE -ne 0) { Falla 'No se pudo crear el superusuario.' }

Write-Host '[4/5] Instalando dependencias del frontend...' -ForegroundColor Cyan
Set-Location $front
if (-not (Test-Path 'node_modules')) {
    npm ci --no-audit --no-fund
    if ($LASTEXITCODE -ne 0) { Falla 'Fallo la instalacion de dependencias del frontend.' }
}
if ($SoloPreparar) { Write-Host 'Preparacion terminada.' -ForegroundColor Green; exit 0 }

Write-Host '[5/5] Levantando la aplicacion (se abriran dos ventanas; no las cierres)...' -ForegroundColor Cyan
Start-Process -FilePath $py -ArgumentList 'manage.py','runserver','127.0.0.1:8000' -WorkingDirectory $back
Start-Process -FilePath 'cmd.exe' -ArgumentList '/k','npm start' -WorkingDirectory $front
Write-Host 'Esperando a que la aplicacion responda...'
for ($i = 0; $i -lt 120; $i++) {
    try { Invoke-WebRequest -UseBasicParsing 'http://localhost:4200' -TimeoutSec 2 | Out-Null; break } catch { Start-Sleep 2 }
}
Start-Process 'http://localhost:4200'
Write-Host 'Listo: http://localhost:4200  (usuario admin_demo, clave demo12345)' -ForegroundColor Green