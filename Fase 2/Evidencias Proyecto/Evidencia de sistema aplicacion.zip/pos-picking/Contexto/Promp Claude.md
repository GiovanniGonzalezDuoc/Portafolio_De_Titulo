**🚀 ETAPA 0 — Analizar el proyecto**

Antes de crear código, que la IA entienda exactamente qué hay que construir.

**Prompt 0.1**

Voy a desarrollar el sistema POS Picking descrito en el documento de especificación que tienes disponible.

Antes de escribir cualquier código:

1\. Analiza completamente la especificación.

2\. Extrae todos los requisitos funcionales.

3\. Extrae todos los requisitos no funcionales.

4\. Identifica todos los módulos del sistema.

5\. Identifica los tipos de usuarios y sus permisos.

6\. Identifica las entidades necesarias para la base de datos.

7\. Identifica las relaciones entre las entidades.

8\. Identifica los endpoints API que serán necesarios.

9\. Identifica las funcionalidades que requieren integración externa.

10\. Identifica la funcionalidad de predicción de demanda.

11\. Identifica la funcionalidad de recomendación de reposición.

12\. Identifica las pruebas necesarias.

13\. Identifica los requisitos de seguridad.

14\. Identifica los requisitos de despliegue.

15\. Identifica cualquier requisito relacionado con trazabilidad y auditoría.

La base de datos de producción será MARIADB.

Tecnologías principales:

Frontend:

\- Angular

\- TypeScript

Backend:

\- Python

\- Django

\- Django REST Framework

Base de datos:

\- MariaDB

Autenticación:

\- JWT

Infraestructura:

\- Docker

\- Git

\- V2Network

NO escribas código todavía.

Entrega el resultado organizado por módulos.

Si existe algún requisito ambiguo, indícalo antes de asumir una solución.

**🏗️ ETAPA 1 — Arquitectura**

**Prompt 1.1**

Basándote exclusivamente en la especificación del proyecto POS Picking que analizaste, diseña la arquitectura completa del sistema.

Tecnologías obligatorias:

Frontend:

\- Angular

\- TypeScript

Backend:

\- Python

\- Django

\- Django REST Framework

Base de datos:

\- MariaDB

Autenticación:

\- JWT

Infraestructura:

\- Docker

\- Git

\- V2Network

Define:

1\. Arquitectura general.

2\. Comunicación Angular → API → MariaDB.

3\. Módulos del backend.

4\. Módulos del frontend.

5\. Sistema de autenticación.

6\. Sistema de roles y permisos.

7\. Manejo de errores.

8\. Validaciones.

9\. Seguridad.

10\. Logs.

11\. Auditoría.

12\. Integraciones externas.

13\. Arquitectura para predicción de demanda.

14\. Arquitectura para recomendación de reposición.

15\. Arquitectura de deployment.

La arquitectura debe ser compatible con MariaDB.

No utilices características específicas de PostgreSQL.

No escribas todavía todo el código.

Primero muestra:

\- Diagrama textual.

\- Estructura general.

\- Flujo de datos.

\- Responsabilidad de cada componente.

Después explica las decisiones técnicas.

**🗄️ ETAPA 2 — Modelo de base de datos**

Aquí hay que hacerlo con mucho cuidado.

**Prompt 2.1**

Ahora diseña el modelo entidad-relación completo del sistema POS Picking.

La base de datos de producción será MariaDB.

El modelo debe ser compatible con:

\- MariaDB

\- Django ORM

\- Django migrations

Debe contemplar como mínimo:

\- Usuarios

\- Roles

\- Permisos

\- Productos

\- Categorías

\- Marcas

\- Inventario

\- Movimientos de inventario

\- Ventas

\- Detalle de ventas

\- Caja

\- Movimientos de caja

\- Compras

\- Detalle de compras

\- Proveedores

\- Alertas

\- Auditoría

\- Predicción de demanda

\- Recomendaciones de reposición

Analiza la especificación y agrega otras entidades únicamente cuando sean necesarias.

Para cada entidad indica:

\- Nombre.

\- Campos.

\- Tipo de dato.

\- PK.

\- FK.

\- Nullable.

\- Default.

\- UNIQUE.

\- CHECK cuando MariaDB lo soporte y sea apropiado.

\- Índices.

\- Relaciones.

\- Cardinalidad.

Evita redundancia y normaliza correctamente.

NO escribas todavía código Django.

Entrega primero el modelo y explica las decisiones.

**🗃️ ETAPA 3 — Crear proyecto Django + MariaDB**

**Prompt 3.1**

Vamos a comenzar el backend del proyecto POS Picking.

Crea la estructura inicial de un proyecto Django + Django REST Framework utilizando MariaDB.

Tecnologías:

\- Python

\- Django

\- Django REST Framework

\- MariaDB

\- JWT

\- CORS

\- Docker

\- Variables de entorno

La configuración debe funcionar tanto en desarrollo como posteriormente en producción.

Crea solamente:

\- requirements.txt

\- .env.example

\- .gitignore

\- Dockerfile

\- docker-compose.yml

\- configuración Django

\- configuración MariaDB

\- configuración Django REST Framework

\- configuración CORS

\- configuración JWT

Utiliza variables de entorno para:

DB_NAME

DB_USER

DB_PASSWORD

DB_HOST

DB_PORT

NO hardcodees credenciales.

No crees todavía todos los modelos ni endpoints.

Después explica:

1\. Cómo instalar dependencias.

2\. Cómo levantar MariaDB.

3\. Cómo levantar Django.

4\. Cómo comprobar que Django se conecta correctamente a MariaDB.

5\. Cómo ejecutar las migraciones.

**👤 ETAPA 4 — Usuarios, roles y seguridad**

**Prompt 4.1**

Implementa el módulo de usuarios y seguridad del POS Picking.

La base de datos es MariaDB.

Debe incluir:

\- Usuario.

\- Rol.

\- Permisos.

\- Estado activo/inactivo.

\- Contraseña almacenada de forma segura.

\- JWT.

\- Login.

\- Refresh token.

\- Endpoint de usuario actual.

\- Protección de endpoints.

\- Permisos según rol.

Utiliza los roles definidos en la especificación del proyecto.

Implementa:

1\. Models.

2\. Serializers.

3\. Views/ViewSets.

4\. URLs.

5\. Permissions.

6\. Validaciones.

7\. Tests.

No almacenes contraseñas en texto plano.

No expongas información sensible mediante la API.

Utiliza Django ORM y asegúrate de que las migraciones funcionen correctamente sobre MariaDB.

Después indica cómo probar cada endpoint.

**📦 ETAPA 5 — Catálogo de productos**

**Prompt 5.1**

Implementa el módulo de catálogo del POS Picking.

Debe incluir:

\- Categorías.

\- Marcas.

\- Productos.

\- SKU.

\- Código de barras.

\- Nombre.

\- Descripción.

\- Precio.

\- Estado.

\- Información adicional requerida por la especificación.

Implementa:

\- Models.

\- Serializers.

\- Views/ViewSets.

\- URLs.

\- Validaciones.

\- Filtros.

\- Búsqueda.

\- Paginación.

\- Permisos.

\- Tests.

El código debe utilizar Django ORM y ser compatible con MariaDB.

Los endpoints deben seguir una convención REST consistente.

No modifiques módulos anteriores salvo que sea estrictamente necesario.

Si necesitas modificar otro módulo, explica primero por qué.

**📊 ETAPA 6 — Inventario**

Esta es una de las partes más importantes.

**Prompt 6.1**

Implementa el módulo de inventario del POS Picking.

Debe permitir:

\- Consultar stock.

\- Aumentar stock.

\- Disminuir stock.

\- Ajustar stock.

\- Registrar movimientos.

\- Registrar motivo del movimiento.

\- Asociar movimiento al usuario.

\- Mantener trazabilidad.

\- Evitar stock negativo cuando corresponda.

\- Consultar historial.

\- Buscar por producto.

\- Generar alertas de stock bajo.

Reglas importantes:

1\. Toda modificación del stock debe generar un movimiento de inventario.

2\. Las operaciones críticas deben utilizar transacciones.

3\. Debemos evitar inconsistencias de stock.

4\. Debemos registrar quién realizó la operación.

5\. Debemos mantener fecha y hora de la operación.

Implementa:

\- Models.

\- Serializers.

\- Services.

\- Views/ViewSets.

\- URLs.

\- Permissions.

\- Validaciones.

\- Tests.

Utiliza Django ORM compatible con MariaDB.

No modifiques otros módulos innecesariamente.

**🛒 ETAPA 7 — Proveedores y compras**

**Prompt 7.1**

Implementa el módulo de proveedores y compras.

Debe permitir:

\- CRUD de proveedores.

\- Crear compras.

\- Agregar productos a una compra.

\- Registrar cantidades.

\- Registrar precios.

\- Estados de compra.

\- Recepción de compra.

\- Actualización automática del inventario al recibir una compra.

\- Trazabilidad del usuario.

Regla importante:

Crear una compra NO debe aumentar automáticamente el stock.

El stock debe aumentar solamente cuando la compra sea recibida.

La recepción debe:

1\. Validar la compra.

2\. Actualizar stock.

3\. Registrar movimientos de inventario.

4\. Cambiar el estado de la compra.

5\. Registrar usuario y fecha.

6\. Ejecutarse dentro de una transacción.

Implementa:

\- Models.

\- Serializers.

\- Services.

\- Views.

\- URLs.

\- Permissions.

\- Validaciones.

\- Tests.

Utiliza Django ORM compatible con MariaDB.

**💰 ETAPA 8 — POS y ventas**

**Prompt 8.1**

Implementa el módulo POS y ventas.

Debe permitir:

1\. Crear una venta.

2\. Buscar productos por SKU.

3\. Buscar productos por código de barras.

4\. Agregar productos al carrito.

5\. Modificar cantidades.

6\. Eliminar productos.

7\. Calcular subtotal.

8\. Aplicar descuentos cuando corresponda.

9\. Calcular impuestos según la especificación.

10\. Calcular total.

11\. Registrar medio de pago.

12\. Confirmar venta.

13\. Descontar stock automáticamente.

14\. Registrar movimientos de inventario.

15\. Mantener trazabilidad del vendedor.

16\. Evitar vender productos sin stock.

La confirmación de la venta debe ejecutarse mediante una transacción.

Debes considerar correctamente la concurrencia para evitar que dos ventas permitan vender más stock del disponible.

Implementa:

\- Models.

\- Serializers.

\- Services.

\- Views.

\- URLs.

\- Permissions.

\- Validaciones.

\- Tests.

Los tests deben cubrir:

\- Venta correcta.

\- Producto inexistente.

\- Producto inactivo.

\- Stock insuficiente.

\- Venta con múltiples productos.

\- Cálculo de totales.

\- Descuento de stock.

\- Registro de movimientos.

\- Error durante la transacción.

Utiliza Django ORM compatible con MariaDB.

**💵 ETAPA 9 — Caja**

**Prompt 9.1**

Implementa el módulo de caja del POS Picking.

Debe permitir:

\- Apertura de caja.

\- Cierre de caja.

\- Saldo inicial.

\- Registrar ingresos.

\- Registrar egresos.

\- Asociar ventas a caja.

\- Calcular saldo esperado.

\- Registrar diferencia al cierre.

\- Historial de movimientos.

\- Usuario responsable.

Define correctamente los estados de caja.

Evita múltiples cajas abiertas cuando la especificación indique que no está permitido.

Las operaciones críticas deben utilizar transacciones.

Implementa:

\- Models.

\- Serializers.

\- Services.

\- Views.

\- URLs.

\- Permissions.

\- Validaciones.

\- Tests.

Utiliza Django ORM compatible con MariaDB.

Prueba especialmente:

\- Apertura.

\- Venta.

\- Ingreso.

\- Egreso.

\- Cierre.

\- Diferencia de caja.

\- Intento de abrir una caja ya abierta.

**🧾 ETAPA 10 — Boleta electrónica**

Esta parte conviene hacerla cuando ventas y caja ya estén funcionando.

**Prompt 10.1**

Implementa la arquitectura del módulo de boleta electrónica según la especificación.

Antes de programar:

1\. Identifica qué integración externa requiere el sistema.

2\. Identifica qué información necesita la boleta.

3\. Define el flujo desde la venta hasta la emisión.

4\. Define los estados del documento.

5\. Define manejo de errores.

6\. Define reintentos.

7\. Define trazabilidad.

8\. Define cómo guardar la respuesta del proveedor.

NO inventes una API tributaria.

Si la especificación no entrega un proveedor concreto, crea una abstracción mediante un servicio/interfaz para poder conectarlo posteriormente.

Implementa inicialmente una integración MOCK/SIMULADA.

La venta no debe quedar en un estado inconsistente si la emisión de la boleta falla.

Implementa:

\- Models.

\- Services.

\- API.

\- Estados.

\- Manejo de errores.

\- Tests.

Todo debe ser compatible con MariaDB.

**🔔 ETAPA 11 — Alertas**

**Prompt 11.1**

Implementa el módulo de alertas del POS Picking.

Analiza primero la especificación y determina todos los tipos de alerta requeridos.

Como mínimo considera:

\- Stock bajo.

\- Producto sin stock.

\- Necesidad de reposición.

\- Errores importantes del sistema.

Cada alerta debe poder almacenar cuando corresponda:

\- Tipo.

\- Severidad.

\- Mensaje.

\- Estado.

\- Fecha.

\- Producto relacionado.

\- Usuario relacionado.

Implementa:

\- Models.

\- Serializers.

\- Services.

\- Views.

\- URLs.

\- Filters.

\- Permissions.

\- Tests.

Las alertas deben poder marcarse como vistas/resueltas cuando corresponda.

Utiliza MariaDB y Django ORM.

**📈 ETAPA 12 — Dashboard**

**Prompt 12.1**

Implementa los endpoints necesarios para el dashboard del POS Picking.

El dashboard debe utilizar datos reales de la base de datos.

Analiza e implementa las métricas requeridas por la especificación, incluyendo cuando corresponda:

\- Ventas del día.

\- Ventas por período.

\- Productos más vendidos.

\- Stock bajo.

\- Productos sin stock.

\- Compras.

\- Estado de caja.

\- Alertas.

\- Indicadores de inventario.

\- Indicadores relacionados con reposición.

Optimiza las consultas.

Evita realizar cientos de queries innecesarias.

Utiliza:

\- Django ORM.

\- Aggregations.

\- Annotations.

\- Índices adecuados.

Todo debe funcionar sobre MariaDB.

Implementa endpoints específicos para el dashboard y agrega tests.

**🧠 ETAPA 13 — Predicción de demanda**

Ahora entra la IA/ML.

**Prompt 13.1 — Preparar datos**

Ahora implementaremos el módulo de predicción de demanda.

Antes de crear un modelo de Machine Learning:

1\. Analiza los datos históricos disponibles.

2\. Determina qué variable debemos predecir.

3\. Determina la granularidad temporal.

4\. Identifica variables relevantes.

5\. Identifica datos faltantes.

6\. Identifica outliers.

7\. Determina cuántos datos necesitamos.

8\. Define entrenamiento y prueba.

9\. Define cómo evitar data leakage.

10\. Define un baseline.

NO entrenes todavía ningún modelo.

Entrega:

\- Análisis de datos necesarios.

\- Variable objetivo.

\- Variables predictoras.

\- Estrategia de entrenamiento.

\- Métricas.

\- Propuesta de modelos.

**Prompt 13.2 — Entrenar modelo**

Diseña e implementa un sistema de Machine Learning para predecir la demanda de productos.

Compara:

\- Baseline.

\- Regresión.

\- Random Forest u otro modelo apropiado.

\- Modelo de series temporales si los datos lo justifican.

Evalúa mediante métricas apropiadas como:

\- MAE.

\- RMSE.

\- MAPE cuando sea apropiado.

Evita data leakage.

Explica por qué se selecciona el modelo final.

Genera un notebook reproducible para:

1\. Cargar datos.

2\. Limpiar datos.

3\. Crear variables.

4\. Entrenar.

5\. Validar.

6\. Evaluar.

7\. Guardar el modelo.

No mezcles todavía el entrenamiento con Django.

**📦 ETAPA 14 — Recomendación de reposición**

**Prompt 14.1**

Implementa el sistema de recomendación de reposición utilizando la predicción de demanda.

La recomendación debe considerar cuando los datos estén disponibles:

\- Stock actual.

\- Demanda estimada.

\- Stock de seguridad.

\- Lead time del proveedor.

\- Punto de pedido.

\- Cantidad recomendada de compra.

Define claramente las fórmulas.

La recomendación debe ser:

\- Explicable.

\- Auditable.

\- Reproducible.

Por cada recomendación quiero poder conocer:

\- Producto.

\- Stock actual.

\- Demanda estimada.

\- Stock de seguridad.

\- Cantidad recomendada.

\- Fecha.

\- Motivo de la recomendación.

Implementa primero el algoritmo como servicio Python.

Después intégralo con Django.

No generes recomendaciones sin datos suficientes.

**🖥️ ETAPA 15 — Crear frontend Angular**

Ahora empezamos la interfaz.

**Prompt 15.1**

Ahora construye el frontend Angular del POS Picking.

Utiliza:

\- Angular.

\- TypeScript.

\- Angular Material.

\- Reactive Forms.

\- HttpClient.

\- Interceptors.

\- Guards.

\- Services.

\- Components reutilizables.

Crea una arquitectura modular.

Utiliza una estructura similar a:

src/

├── app/

│   ├── core/

│   ├── shared/

│   ├── layouts/

│   └── features/

Dentro de features organiza los módulos funcionales.

Primero crea solamente:

\- Layout principal.

\- Header.

\- Sidebar.

\- Login.

\- Routing.

\- Auth Guard.

\- JWT interceptor.

\- Manejo global de errores.

\- Estructura de servicios.

\- Manejo de sesión.

NO construyas todavía todas las pantallas.

El frontend debe consumir posteriormente la API real de Django.

No utilices datos mock salvo que sea estrictamente necesario para una prueba temporal.

**👤 ETAPA 16 — Pantallas Angular**

Aquí recomiendo **una pantalla/módulo por prompt**.

**Usuarios**

Implementa la pantalla Angular de gestión de usuarios.

Debe consumir la API real de Django.

Incluye:

\- Listado.

\- Búsqueda.

\- Filtros.

\- Crear.

\- Editar.

\- Activar/desactivar.

\- Asignación de rol.

\- Validaciones.

\- Manejo de errores.

\- Loading states.

\- Mensajes de éxito/error.

No utilices datos mock.

Respeta la arquitectura Angular existente.

Después haces lo mismo para:

Productos

Categorías

Marcas

Inventario

Movimientos

Proveedores

Compras

POS

Caja

Alertas

Dashboard

Predicción

Reposición

**No le pidas todas las pantallas en un solo prompt.**

**📷 ETAPA 17 — Código de barras**

**Prompt 17.1**

Implementa la lectura de códigos de barras en el POS Angular.

El flujo debe ser:

Lector

↓

Código de barras

↓

Angular

↓

API Django

↓

Producto

↓

Carrito

Debe existir también una alternativa para ingresar el código manualmente.

Cuando se recibe un código:

1\. Buscar producto.

2\. Verificar que exista.

3\. Verificar que esté activo.

4\. Verificar stock.

5\. Agregarlo al carrito.

6\. Actualizar cantidad si ya existe.

Maneja:

\- Código desconocido.

\- Producto inactivo.

\- Producto sin stock.

\- Error de API.

\- Error de lectura.

\- Múltiples lecturas.

No permitas agregar productos inválidos al carrito.

**🧪 ETAPA 18 — Testing completo**

**Prompt 18.1**

Realiza una auditoría completa de testing del proyecto POS Picking.

Backend:

\- Unit tests.

\- Integration tests.

\- API tests.

\- Authentication tests.

\- Permission tests.

\- Inventory tests.

\- Sales tests.

\- Purchase tests.

\- Cash register tests.

\- Alert tests.

\- Dashboard tests.

\- Prediction tests.

\- Replenishment tests.

Frontend:

\- Component tests.

\- Service tests.

\- Authentication tests.

\- Form validation tests.

\- Guards.

\- Interceptors.

Además identifica los flujos críticos que deberían tener pruebas End-to-End.

No elimines ni modifiques tests existentes solamente para hacerlos pasar.

Si un test falla:

1\. Identifica la causa.

2\. Explica el problema.

3\. Corrige el código.

4\. Ejecuta nuevamente el test.

**🔐 ETAPA 19 — Auditoría de seguridad**

**Prompt 19.1**

Realiza una auditoría completa de seguridad del proyecto POS Picking.

Revisa:

\- JWT.

\- Contraseñas.

\- CORS.

\- CSRF.

\- SQL Injection.

\- XSS.

\- Validación de entradas.

\- Permisos.

\- Escalamiento de privilegios.

\- Exposición de información.

\- Variables de entorno.

\- Secretos.

\- Logs.

\- Rate limiting.

\- Dependencias vulnerables.

\- Docker.

\- MariaDB.

\- API REST.

NO modifiques código todavía.

Entrega una tabla:

RIESGO

SEVERIDAD

ARCHIVO

PROBLEMA

IMPACTO

SOLUCIÓN PROPUESTA

Después de revisar el informe te indicaré que implementes las correcciones.

**Prompt 19.2**

Ahora corrige los problemas de seguridad identificados en la auditoría anterior.

Reglas:

\- No elimines funcionalidades.

\- No reduzcas seguridad para solucionar errores.

\- No hardcodees secretos.

\- No modifiques módulos no relacionados sin justificación.

\- Mantén compatibilidad con MariaDB.

Después ejecuta nuevamente las pruebas.

**⚡ ETAPA 20 — Pruebas de carga**

**Prompt 20.1**

Diseña pruebas de carga para el POS Picking.

Debemos probar especialmente:

\- Login.

\- Consulta de productos.

\- Consulta de inventario.

\- Búsqueda por código de barras.

\- Creación de ventas.

\- Actualización de stock.

\- Dashboard.

\- Consultas de reposición.

Utiliza una herramienta apropiada como Locust o k6.

Define:

\- Usuarios concurrentes.

\- Requests por segundo.

\- Duración.

\- Latencia.

\- Error rate.

\- Throughput.

Presta especial atención a:

\- MariaDB.

\- Consultas lentas.

\- Actualización concurrente de stock.

\- Endpoints de ventas.

Entrega:

1\. Estrategia.

2\. Scripts.

3\. Cómo ejecutarlos.

4\. Cómo interpretar resultados.

5\. Umbrales de aceptación.

**🐳 ETAPA 21 — Docker + Deploy V2Network**

Aquí haría primero Docker.

**Prompt 21.1 — Docker**

Dockeriza completamente el proyecto POS Picking.

La arquitectura debe utilizar:

\- Angular.

\- Django.

\- MariaDB.

\- Nginx cuando corresponda.

\- Redis solamente si realmente es necesario.

Configura:

\- Dockerfiles.

\- docker-compose.

\- Variables de entorno.

\- Redes.

\- Volúmenes.

\- Persistencia de MariaDB.

\- Healthchecks.

\- Migraciones.

\- Dependencias entre servicios.

\- Reinicio de servicios cuando corresponda.

El proyecto debe poder levantarse desde cero mediante Docker Compose.

No hardcodees:

\- Passwords.

\- JWT secrets.

\- Credenciales de MariaDB.

\- API keys.

Verifica que el sistema completo funcione dentro de Docker.

**Prompt 21.2 — V2Network**

Necesito desplegar el proyecto POS Picking en V2Network.

La base de datos de producción será MariaDB.

Antes de darme comandos específicos, analiza la infraestructura necesaria.

Determina:

\- Servidor.

\- CPU.

\- RAM.

\- Almacenamiento.

\- Sistema operativo.

\- Puertos.

\- Dominio.

\- HTTPS.

\- Variables de entorno.

\- MariaDB.

\- Backups.

\- Firewall.

\- Logs.

\- Monitoreo.

Diseña primero el plan de deployment.

Después entrega los comandos paso a paso.

NO ejecutes ni propongas comandos destructivos.

No elimines datos existentes.

Prioriza seguridad y persistencia de MariaDB.

**📚 ETAPA 22 — Documentación final**

**Prompt 22.1**

Genera la documentación técnica completa del proyecto POS Picking.

La documentación debe reflejar solamente funcionalidades realmente implementadas.

Incluye:

1\. Descripción general.

2\. Objetivo.

3\. Alcance.

4\. Arquitectura.

5\. Tecnologías.

6\. Requisitos.

7\. Instalación.

8\. Configuración.

9\. Variables de entorno.

10\. Estructura del proyecto.

11\. Base de datos MariaDB.

12\. Modelo de datos.

13\. API REST.

14\. Autenticación.

15\. Roles y permisos.

16\. Productos.

17\. Inventario.

18\. Trazabilidad.

19\. POS.

20\. Ventas.

21\. Caja.

22\. Compras.

23\. Proveedores.

24\. Alertas.

25\. Dashboard.

26\. Predicción de demanda.

27\. Recomendación de reposición.

28\. Boleta electrónica.

29\. Testing.

30\. Seguridad.

31\. Pruebas de carga.

32\. Docker.

33\. Deployment en V2Network.

34\. Backups.

35\. Solución de problemas.

No inventes funcionalidades.

Cuando una funcionalidad esté simulada/mock, indícalo claramente.

**🔥 PERO HAY UNA REGLA MÁS IMPORTANTE**

Como vas a usar una IA para desarrollar prácticamente todo, **no le entregues los 22 prompts de una vez**.

Haz:

PROMPT 0

↓

Revisar resultado

↓

PROMPT 1

↓

Revisar

↓

PROMPT 2

↓

Revisar

↓

...

↓

PROMPT 22

Y después de **cada etapa**:

¿Compila?

↓

¿Tests pasan?

↓

¿Funciona?

↓

¿La BD está correcta?

↓

¿Git commit?

↓

SIGUIENTE

**🧠 Una instrucción que debes pegar al principio del proyecto**

Esta te recomiendo dejarla como **regla permanente para Claude/Codex/Cursor**:

REGLAS DEL PROYECTO POS PICKING

1\. La base de datos oficial es MariaDB.

2\. El backend utiliza Django + Django REST Framework.

3\. El frontend utiliza Angular + TypeScript.

4\. La autenticación utiliza JWT.

5\. El código debe ser compatible con MariaDB.

6\. NO utilizar características específicas de PostgreSQL.

7\. Utilizar Django ORM siempre que sea posible.

8\. No hardcodear credenciales ni secretos.

9\. No inventar requisitos.

10\. No inventar endpoints.

11\. No duplicar funcionalidades existentes.

12\. Antes de modificar código existente, revisar su implementación.

13\. No modificar módulos no relacionados sin justificarlo.

14\. Toda modificación crítica de inventario debe ser transaccional.

15\. Las operaciones de venta deben mantener consistencia de stock.

16\. Mantener trazabilidad de operaciones importantes.

17\. Toda funcionalidad importante debe tener tests.

18\. No eliminar tests para hacer que pasen.

19\. No utilizar datos mock en funcionalidades que ya tienen API real.

20\. Mantener una arquitectura modular.

21\. Mantener nombres consistentes en todo el proyecto.

22\. Antes de implementar una funcionalidad grande, explicar el plan.

23\. Si existe una decisión técnica importante, explicarla antes de implementarla.

24\. No modificar la arquitectura sin justificarlo.

25\. Después de cada módulo, verificar que el proyecto siga funcionando.

**🏆 Y el orden real que te recomiendo**

No pienses en los 22 pasos como **22 días** ni necesariamente como 22 sesiones.

Dentro de cada etapa habrá varias tareas.

La estructura sería:

POS PICKING

│

▼

┌──────────────────┐

│ ESPECIFICACIÓN   │

└────────┬─────────┘

↓

ARQUITECTURA

↓

MODELO BD

↓

┌─────────────────┐

│     BACKEND     │

├─────────────────┤

│ Auth            │

│ Productos       │

│ Inventario      │

│ Compras         │

│ Ventas          │

│ Caja            │

│ Alertas         │

│ Dashboard       │

└────────┬────────┘

↓

ANGULAR

↓

┌─────────────────┐

│      POS        │

│ Código barras   │

│ Inventario      │

│ Caja            │

│ Dashboard       │

└────────┬────────┘

↓

IA / PREDICCIÓN

↓

REPOSICIÓN

↓

TESTS

↓

SEGURIDAD

↓

CARGA/STRESS

↓

DOCKER

↓

V2NETWORK

↓

DOCUMENTACIÓN
