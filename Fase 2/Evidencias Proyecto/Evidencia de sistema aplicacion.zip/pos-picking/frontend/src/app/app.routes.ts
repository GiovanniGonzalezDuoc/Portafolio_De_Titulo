import { Routes } from '@angular/router';

import { authGuard, invitadoGuard } from './core/auth/auth.guard';
import { landingGuard } from './core/auth/landing';
import { permisoGuard } from './core/auth/permiso.guard';

export const routes: Routes = [
  {
    path: 'login',
    canActivate: [invitadoGuard],
    loadComponent: () => import('./features/auth/login/login').then((m) => m.Login),
  },
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./layouts/main-layout/main-layout').then((m) => m.MainLayout),
    children: [
      { path: '', pathMatch: 'full', canActivate: [landingGuard], children: [] },
      {
        path: 'dashboard',
        canActivate: [permisoGuard],
        data: { permiso: 'dashboard.ver' },
        loadComponent: () =>
          import('./features/dashboard/dashboard-home').then((m) => m.DashboardHome),
      },
      {
        path: 'usuarios',
        canActivate: [permisoGuard],
        data: { permiso: 'usuarios.ver' },
        loadComponent: () =>
          import('./features/usuarios/usuarios-lista').then((m) => m.UsuariosLista),
      },
      {
        path: 'roles',
        canActivate: [permisoGuard],
        data: { permiso: 'roles.ver' },
        loadComponent: () =>
          import('./features/usuarios/roles-lista').then((m) => m.RolesLista),
      },
      {
        path: 'catalogo',
        canActivate: [permisoGuard],
        data: { permiso: 'catalogo.ver' },
        loadComponent: () =>
          import('./features/catalogo/productos-lista').then((m) => m.ProductosLista),
      },
      {
        path: 'categorias',
        canActivate: [permisoGuard],
        data: { permiso: 'catalogo.ver' },
        loadComponent: () => import('./features/catalogo/categorias').then((m) => m.Categorias),
      },
      {
        path: 'marcas',
        canActivate: [permisoGuard],
        data: { permiso: 'catalogo.ver' },
        loadComponent: () => import('./features/catalogo/marcas').then((m) => m.Marcas),
      },
      {
        path: 'ofertas',
        canActivate: [permisoGuard],
        data: { permiso: 'ofertas.ver', exceptoRoles: ['mayorista'] },
        loadComponent: () =>
          import('./features/ofertas/ofertas-lista').then((m) => m.OfertasLista),
      },
      {
        path: 'catalogo-mayorista',
        canActivate: [permisoGuard],
        data: { permiso: 'ofertas.ver', soloRoles: ['mayorista'] },
        loadComponent: () =>
          import('./features/ofertas/catalogo-mayorista').then((m) => m.CatalogoMayorista),
      },
      {
        path: 'inventario',
        canActivate: [permisoGuard],
        data: { permiso: 'inventario.ver' },
        loadComponent: () =>
          import('./features/inventario/stock-lista').then((m) => m.StockLista),
      },
      {
        path: 'movimientos',
        canActivate: [permisoGuard],
        data: { permiso: 'inventario.ver' },
        loadComponent: () =>
          import('./features/inventario/movimientos-lista').then((m) => m.MovimientosLista),
      },
      {
        path: 'alertas',
        canActivate: [permisoGuard],
        data: { permiso: 'alertas.ver' },
        loadComponent: () =>
          import('./features/alertas/alertas-lista').then((m) => m.AlertasLista),
      },
      {
        path: 'proveedores',
        canActivate: [permisoGuard],
        data: { permiso: 'proveedores.ver' },
        loadComponent: () =>
          import('./features/proveedores/proveedores-lista').then((m) => m.ProveedoresLista),
      },
      {
        path: 'compras',
        canActivate: [permisoGuard],
        data: { permiso: 'compras.ver' },
        loadComponent: () => import('./features/compras/compras-lista').then((m) => m.ComprasLista),
      },
      {
        path: 'compras/:id',
        canActivate: [permisoGuard],
        data: { permiso: 'compras.ver' },
        loadComponent: () => import('./features/compras/orden-detalle').then((m) => m.OrdenDetalle),
      },
      {
        path: 'pos',
        canActivate: [permisoGuard],
        data: { permiso: 'ventas.crear' },
        loadComponent: () => import('./features/ventas/pos').then((m) => m.Pos),
      },
      {
        path: 'ventas',
        canActivate: [permisoGuard],
        data: { permiso: 'ventas.ver' },
        loadComponent: () => import('./features/ventas/ventas-lista').then((m) => m.VentasLista),
      },
      {
        path: 'caja',
        canActivate: [permisoGuard],
        data: { permiso: 'caja.operar' },
        loadComponent: () => import('./features/caja/caja-vista').then((m) => m.CajaVista),
      },
      {
        path: 'caja/cierres',
        canActivate: [permisoGuard],
        data: { permiso: 'caja.operar' },
        loadComponent: () => import('./features/caja/cierres-lista').then((m) => m.CierresLista),
      },
      {
        // La antigua pantalla de Boletas se fusionó en Ventas.
        path: 'boletas',
        redirectTo: 'ventas',
        pathMatch: 'full',
      },
      {
        path: 'prediccion',
        canActivate: [permisoGuard],
        data: { permiso: 'prediccion.ver' },
        loadComponent: () =>
          import('./features/prediccion/prediccion-panel').then((m) => m.PrediccionPanel),
      },
      {
        path: 'reposicion',
        canActivate: [permisoGuard],
        data: { permiso: 'reposicion.ver' },
        loadComponent: () =>
          import('./features/reposicion/reposicion-panel').then((m) => m.ReposicionPanel),
      },
    ],
  },
  {
    path: '**',
    loadComponent: () =>
      import('./features/no-encontrado/no-encontrado').then((m) => m.NoEncontrado),
  },
];
