import { registerLocaleData } from '@angular/common';
import localeEsCl from '@angular/common/locales/es-CL';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import {
  ApplicationConfig,
  ErrorHandler,
  LOCALE_ID,
  inject,
  provideAppInitializer,
  provideBrowserGlobalErrorListeners,
} from '@angular/core';
import { MAT_DATE_LOCALE, provideNativeDateAdapter } from '@angular/material/core';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { provideRouter, withComponentInputBinding } from '@angular/router';

import { inicializarSesion } from './core/auth/session.bootstrap';
import { errorInterceptor } from './core/http/error.interceptor';
import { jwtInterceptor } from './core/http/jwt.interceptor';
import { loadingInterceptor } from './core/http/loading.interceptor';
import { GlobalErrorHandler } from './core/global-error-handler';
import { TemaService } from './core/services/tema.service';
import { routes } from './app.routes';

registerLocaleData(localeEsCl, 'es-CL');

export const appConfig: ApplicationConfig = {
  providers: [
    { provide: LOCALE_ID, useValue: 'es-CL' },
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes, withComponentInputBinding()),
    provideHttpClient(
      withInterceptors([loadingInterceptor, errorInterceptor, jwtInterceptor]),
    ),
    provideAnimationsAsync(),
    provideNativeDateAdapter(),
    { provide: MAT_DATE_LOCALE, useValue: 'es-CL' },
    provideAppInitializer(() => {
      inject(TemaService); // aplica la preferencia de tema al arrancar
    }),
    provideAppInitializer(inicializarSesion),
    { provide: ErrorHandler, useClass: GlobalErrorHandler },
  ],
};
