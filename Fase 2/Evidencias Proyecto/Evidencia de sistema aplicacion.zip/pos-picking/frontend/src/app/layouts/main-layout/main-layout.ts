import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Component, inject, signal, viewChild } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSidenav, MatSidenavModule } from '@angular/material/sidenav';
import { RouterOutlet } from '@angular/router';
import { map } from 'rxjs';

import { LoadingService } from '../../core/services/loading.service';
import { Header } from '../header/header';
import { Sidebar } from '../sidebar/sidebar';

@Component({
  selector: 'app-main-layout',
  imports: [RouterOutlet, MatSidenavModule, MatProgressBarModule, Header, Sidebar],
  templateUrl: './main-layout.html',
  styleUrl: './main-layout.scss',
})
export class MainLayout {
  private readonly breakpoints = inject(BreakpointObserver);
  private readonly loading = inject(LoadingService);

  readonly sidenav = viewChild.required(MatSidenav);
  readonly cargando = this.loading.cargando;

  /** En pantallas chicas el menú se muestra "por encima" y arranca cerrado. */
  readonly esMovil = toSignal(
    this.breakpoints.observe([Breakpoints.XSmall, Breakpoints.Small]).pipe(map((r) => r.matches)),
    { initialValue: false },
  );

  private readonly _abiertoManual = signal(true);

  get modo(): 'over' | 'side' {
    return this.esMovil() ? 'over' : 'side';
  }

  get abierto(): boolean {
    return this.esMovil() ? this.sidenav().opened : this._abiertoManual();
  }

  alternar(): void {
    if (this.esMovil()) {
      this.sidenav().toggle();
    } else {
      this._abiertoManual.update((v) => !v);
    }
  }

  cerrarSiMovil(): void {
    if (this.esMovil()) {
      this.sidenav().close();
    }
  }
}
