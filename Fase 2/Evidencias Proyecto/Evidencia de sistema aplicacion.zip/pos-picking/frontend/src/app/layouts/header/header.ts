import { TitleCasePipe } from '@angular/common';
import { Component, inject, output } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTooltipModule } from '@angular/material/tooltip';

import { AuthService } from '../../core/auth/auth.service';
import { TemaService } from '../../core/services/tema.service';

@Component({
  selector: 'app-header',
  imports: [
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatTooltipModule,
    TitleCasePipe,
  ],
  templateUrl: './header.html',
  styleUrl: './header.scss',
})
export class Header {
  private readonly auth = inject(AuthService);
  readonly tema = inject(TemaService);

  /** El layout escucha este evento para abrir/cerrar el sidenav en móvil. */
  readonly alternarMenu = output<void>();

  readonly usuario = this.auth.usuario;

  cerrarSesion(): void {
    this.auth.logout();
  }
}
