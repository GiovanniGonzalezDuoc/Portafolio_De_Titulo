import { Component, computed, inject } from '@angular/core';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { RouterLink, RouterLinkActive } from '@angular/router';

import { AuthService } from '../../core/auth/auth.service';
import { GrupoNav, NAVEGACION, puedeVerItem } from '../navegacion';

@Component({
  selector: 'app-sidebar',
  imports: [MatListModule, MatIconModule, RouterLink, RouterLinkActive],
  templateUrl: './sidebar.html',
  styleUrl: './sidebar.scss',
})
export class Sidebar {
  private readonly auth = inject(AuthService);

  /** Grupos con al menos un ítem visible para el usuario. */
  readonly grupos = computed<GrupoNav[]>(() => {
    this.auth.permisos(); // dependencia reactiva
    const ctx = {
      rol: this.auth.usuario()?.rol ?? null,
      tieneAlgunPermiso: (...c: string[]) => this.auth.tieneAlgunPermiso(...c),
    };
    return NAVEGACION.map((g) => ({
      titulo: g.titulo,
      items: g.items.filter((i) => puedeVerItem(i, ctx)),
    })).filter((g) => g.items.length > 0);
  });
}
