/**
 * Menú lateral. Cada ítem declara el permiso que lo habilita; el sidebar
 * oculta los que el usuario no puede ver. Algunos ítems además se limitan
 * a ciertos roles (`soloRoles`) o se ocultan para otros (`exceptoRoles`).
 */
export interface ItemNav {
  etiqueta: string;
  icono: string;
  ruta: string;
  permiso?: string | string[];
  /** Si está, solo estos roles ven el ítem. */
  soloRoles?: string[];
  /** Si está, todos los roles menos estos ven el ítem. */
  exceptoRoles?: string[];
  /** Exigir coincidencia exacta de ruta para marcarlo activo (ej: /caja vs /caja/cierres). */
  exacto?: boolean;
}

export interface GrupoNav {
  titulo: string;
  items: ItemNav[];
}

export const NAVEGACION: GrupoNav[] = [
  {
    titulo: 'General',
    items: [{ etiqueta: 'Dashboard', icono: 'dashboard', ruta: '/dashboard', permiso: 'dashboard.ver' }],
  },
  {
    titulo: 'Catálogo',
    items: [
      {
        etiqueta: 'Ofertas mayoristas',
        icono: 'local_offer',
        ruta: '/catalogo-mayorista',
        permiso: 'ofertas.ver',
        soloRoles: ['mayorista'],
      },
    ],
  },
  {
    titulo: 'Ventas',
    items: [
      { etiqueta: 'Punto de venta', icono: 'point_of_sale', ruta: '/pos', permiso: 'ventas.crear' },
      { etiqueta: 'Ventas', icono: 'receipt_long', ruta: '/ventas', permiso: ['ventas.ver', 'boleta.ver'] },
      { etiqueta: 'Caja', icono: 'account_balance_wallet', ruta: '/caja', permiso: 'caja.operar', exacto: true },
      { etiqueta: 'Cierres de caja', icono: 'assessment', ruta: '/caja/cierres', permiso: 'caja.operar' },
    ],
  },
  {
    titulo: 'Inventario',
    items: [
      { etiqueta: 'Productos', icono: 'inventory_2', ruta: '/catalogo', permiso: 'catalogo.ver' },
      { etiqueta: 'Categorías', icono: 'category', ruta: '/categorias', permiso: 'catalogo.ver' },
      { etiqueta: 'Marcas', icono: 'sell', ruta: '/marcas', permiso: 'catalogo.ver' },
      {
        etiqueta: 'Ofertas',
        icono: 'local_offer',
        ruta: '/ofertas',
        permiso: 'ofertas.ver',
        exceptoRoles: ['mayorista'],
      },
      { etiqueta: 'Stock', icono: 'warehouse', ruta: '/inventario', permiso: 'inventario.ver' },
      { etiqueta: 'Movimientos', icono: 'swap_vert', ruta: '/movimientos', permiso: 'inventario.ver' },
      { etiqueta: 'Proveedores', icono: 'local_shipping', ruta: '/proveedores', permiso: 'proveedores.ver' },
      { etiqueta: 'Compras', icono: 'shopping_cart', ruta: '/compras', permiso: 'compras.ver' },
    ],
  },
  {
    titulo: 'Analítica',
    items: [
      { etiqueta: 'Alertas', icono: 'notifications', ruta: '/alertas', permiso: 'alertas.ver' },
      { etiqueta: 'Predicción', icono: 'insights', ruta: '/prediccion', permiso: 'prediccion.ver' },
      { etiqueta: 'Reposición', icono: 'inventory', ruta: '/reposicion', permiso: 'reposicion.ver' },
    ],
  },
  {
    titulo: 'Administración',
    items: [
      { etiqueta: 'Usuarios', icono: 'group', ruta: '/usuarios', permiso: 'usuarios.ver' },
      { etiqueta: 'Roles', icono: 'admin_panel_settings', ruta: '/roles', permiso: 'roles.ver' },
    ],
  },
];

/** Contexto mínimo del usuario para decidir la visibilidad de un ítem. */
export interface ContextoNav {
  rol: string | null;
  tieneAlgunPermiso(...codigos: string[]): boolean;
}

/** True si el usuario puede ver el ítem (permiso + reglas de rol). */
export function puedeVerItem(item: ItemNav, ctx: ContextoNav): boolean {
  if (item.soloRoles && !item.soloRoles.includes(ctx.rol ?? '')) {
    return false;
  }
  if (item.exceptoRoles && item.exceptoRoles.includes(ctx.rol ?? '')) {
    return false;
  }
  if (!item.permiso) {
    return true;
  }
  const codigos = Array.isArray(item.permiso) ? item.permiso : [item.permiso];
  return ctx.tieneAlgunPermiso(...codigos);
}
