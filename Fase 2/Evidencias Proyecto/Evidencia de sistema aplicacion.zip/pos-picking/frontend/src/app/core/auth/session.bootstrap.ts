import { inject } from '@angular/core';
import { EMPTY, catchError, switchMap } from 'rxjs';

import { AuthService } from './auth.service';

/**
 * Al iniciar la app: si hay un refresh token guardado, renueva el access token
 * y recarga el usuario (para tener permisos frescos). Si algo falla, se limpia
 * la sesión sin bloquear el arranque.
 */
export function inicializarSesion() {
  const auth = inject(AuthService);
  if (!auth.hayRefreshToken) {
    return EMPTY;
  }
  return auth.refrescar().pipe(
    switchMap(() => auth.cargarUsuarioActual()),
    catchError(() => {
      auth.logout(false);
      return EMPTY;
    }),
  );
}
