import { Injectable } from '@angular/core';

const CLAVE_REFRESH = 'pos_refresh';
const CLAVE_USUARIO = 'pos_usuario';

/**
 * Almacenamiento de tokens.
 *
 * - `access`: solo en memoria (se pierde al recargar y se rehidrata con el
 *   `refresh`).
 * - `refresh` y el usuario: en `localStorage` para mantener la sesión entre
 *   recargas.
 */
@Injectable({ providedIn: 'root' })
export class TokenStorageService {
  private accessEnMemoria: string | null = null;

  get access(): string | null {
    return this.accessEnMemoria;
  }

  get refresh(): string | null {
    return this.leer(CLAVE_REFRESH);
  }

  get usuarioSerializado(): string | null {
    return this.leer(CLAVE_USUARIO);
  }

  guardar(access: string, refresh: string): void {
    this.accessEnMemoria = access;
    this.escribir(CLAVE_REFRESH, refresh);
  }

  guardarAccess(access: string): void {
    this.accessEnMemoria = access;
  }

  guardarUsuario(usuario: unknown): void {
    this.escribir(CLAVE_USUARIO, JSON.stringify(usuario));
  }

  limpiar(): void {
    this.accessEnMemoria = null;
    this.borrar(CLAVE_REFRESH);
    this.borrar(CLAVE_USUARIO);
  }

  private leer(clave: string): string | null {
    try {
      return localStorage.getItem(clave);
    } catch {
      return null;
    }
  }

  private escribir(clave: string, valor: string): void {
    try {
      localStorage.setItem(clave, valor);
    } catch {
      /* modo privado / almacenamiento bloqueado: la sesión vivirá solo en memoria */
    }
  }

  private borrar(clave: string): void {
    try {
      localStorage.removeItem(clave);
    } catch {
      /* noop */
    }
  }
}
