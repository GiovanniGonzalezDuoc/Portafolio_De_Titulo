import { HttpClient, HttpContext, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { NotificacionService } from '../services/notificacion.service';
import { SIN_TOAST, errorInterceptor } from './error.interceptor';

describe('errorInterceptor', () => {
  let http: HttpClient;
  let ctrl: HttpTestingController;
  let errores: string[];

  beforeEach(() => {
    errores = [];
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: NotificacionService, useValue: { error: (m: string) => errores.push(m) } },
      ],
    });
    http = TestBed.inject(HttpClient);
    ctrl = TestBed.inject(HttpTestingController);
  });

  afterEach(() => ctrl.verify());

  it('muestra el mensaje del envoltorio de error del backend', () => {
    http.get('/api/x').subscribe({ error: () => undefined });
    ctrl.expectOne('/api/x').flush(
      { error: { codigo: 'stock_insuficiente', mensaje: 'No hay stock suficiente.', detalles: null, campo: null } },
      { status: 409, statusText: 'Conflict' },
    );
    expect(errores).toEqual(['No hay stock suficiente.']);
  });

  it('no muestra toast si la petición marcó SIN_TOAST', () => {
    http
      .get('/api/x', { context: new HttpContext().set(SIN_TOAST, true) })
      .subscribe({ error: () => undefined });
    ctrl.expectOne('/api/x').flush({ error: { mensaje: 'x' } }, { status: 404, statusText: 'Not Found' });
    expect(errores).toEqual([]);
  });

  it('silencia los 401 (los maneja el flujo de sesión)', () => {
    http.get('/api/x').subscribe({ error: () => undefined });
    ctrl.expectOne('/api/x').flush({}, { status: 401, statusText: 'Unauthorized' });
    expect(errores).toEqual([]);
  });

  it('traduce el error de red (status 0)', () => {
    http.get('/api/x').subscribe({ error: () => undefined });
    ctrl.expectOne('/api/x').error(new ProgressEvent('error'));
    expect(errores[0]).toContain('No se pudo conectar');
  });
});
