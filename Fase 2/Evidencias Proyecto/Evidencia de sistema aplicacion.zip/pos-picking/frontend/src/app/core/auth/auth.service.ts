import { HttpClient } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';

import { environment } from '../../../environments/environment';
import { Credenciales, RespuestaLogin, Usuario } from './auth.models';
import { TokenStorageService } from './token-storage.service';

/**
 * Sesión del usuario: login, logout, refresh y estado reactivo.
 *
 * El estado (`usuario`, `permisos`) se expone como signals para que los
 * componentes y guards reaccionen sin suscripciones manuales.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly tokens = inject(TokenStorageService);
  private readonly base = `${environment.apiUrl}/auth`;

  private readonly _usuario = signal<Usuario | null>(this.rehidratarUsuario());

  readonly usuario = this._usuario.asReadonly();
  readonly autenticado = computed(() => this._usuario() !== null);
  readonly permisos = computed(() => this._usuario()?.permisos ?? []);

  /** ¿La sesión puede intentar renovarse? (hay refresh token guardado). */
  get hayRefreshToken(): boolean {
    return this.tokens.refresh !== null;
  }

  get accessToken(): string | null {
    return this.tokens.access;
  }

  tienePermiso(codigo: string): boolean {
    const p = this.permisos();
    return p.includes(codigo);
  }

  tieneAlgunPermiso(...codigos: string[]): boolean {
    return codigos.some((c) => this.tienePermiso(c));
  }

  login(credenciales: Credenciales): Observable<RespuestaLogin> {
    return this.http.post<RespuestaLogin>(`${this.base}/login/`, credenciales).pipe(
      tap((r) => {
        this.tokens.guardar(r.access, r.refresh);
        this.tokens.guardarUsuario(r.usuario);
        this._usuario.set(r.usuario);
      }),
    );
  }

  /**
   * Renueva el access token con el refresh. El backend rota el refresh
   * (`ROTATE_REFRESH_TOKENS`), así que guardamos también el nuevo si viene.
   * Lo usa el interceptor ante un 401.
   */
  refrescar(): Observable<{ access: string; refresh?: string }> {
    return this.http
      .post<{ access: string; refresh?: string }>(`${environment.apiUrl}/auth/refresh/`, {
        refresh: this.tokens.refresh,
      })
      .pipe(
        tap((r) => {
          if (r.refresh) {
            this.tokens.guardar(r.access, r.refresh);
          } else {
            this.tokens.guardarAccess(r.access);
          }
        }),
      );
  }

  /** Trae los datos del usuario actual (tras rehidratar la sesión). */
  cargarUsuarioActual(): Observable<Usuario> {
    return this.http
      .get<Usuario>(`${this.base}/me/`)
      .pipe(tap((u) => {
        this.tokens.guardarUsuario(u);
        this._usuario.set(u);
      }));
  }

  logout(redirigir = true): void {
    const refresh = this.tokens.refresh;
    if (refresh) {
      this.http.post(`${this.base}/logout/`, { refresh }).subscribe({
        error: () => {
          /* el token igual se descarta localmente */
        },
      });
    }
    this.tokens.limpiar();
    this._usuario.set(null);
    if (redirigir) {
      this.router.navigate(['/login']);
    }
  }

  private rehidratarUsuario(): Usuario | null {
    const crudo = this.tokens.usuarioSerializado;
    if (!crudo) {
      return null;
    }
    try {
      return JSON.parse(crudo) as Usuario;
    } catch {
      return null;
    }
  }
}
