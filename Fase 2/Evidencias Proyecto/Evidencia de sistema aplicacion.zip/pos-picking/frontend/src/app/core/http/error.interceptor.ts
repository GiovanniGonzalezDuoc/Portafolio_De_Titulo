import { HttpContextToken, HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';

import { ErrorApi } from '../models/api.models';
import { NotificacionService } from '../services/notificacion.service';

/**
 * Poner `context: new HttpContext().set(SIN_TOAST, true)` en una petición para
 * que su error NO muestre snackbar (el componente lo maneja).
 */
export const SIN_TOAST = new HttpContextToken<boolean>(() => false);

function mensajeDe(err: HttpErrorResponse): string {
  if (err.status === 0) {
    return 'No se pudo conectar con el servidor.';
  }
  const cuerpo = err.error as Partial<ErrorApi> | string | null;
  if (cuerpo && typeof cuerpo === 'object' && 'error' in cuerpo && cuerpo.error) {
    return cuerpo.error.mensaje;
  }
  if (err.status === 403) {
    return 'No tienes permiso para realizar esta acción.';
  }
  if (err.status === 404) {
    return 'El recurso solicitado no existe.';
  }
  if (err.status >= 500) {
    return 'Ocurrió un error en el servidor. Intenta nuevamente.';
  }
  return err.message || 'Ocurrió un error inesperado.';
}

/** Traduce los errores de la API a mensajes y los muestra (salvo 401 y opt-out). */
export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const noti = inject(NotificacionService);

  return next(req).pipe(
    catchError((err: unknown) => {
      if (err instanceof HttpErrorResponse) {
        const silenciar =
          req.context.get(SIN_TOAST) ||
          err.status === 401 ||
          req.url.includes('/auth/login/'); // el formulario de login muestra su propio error
        if (!silenciar) {
          noti.error(mensajeDe(err));
        }
      }
      return throwError(() => err);
    }),
  );
};
