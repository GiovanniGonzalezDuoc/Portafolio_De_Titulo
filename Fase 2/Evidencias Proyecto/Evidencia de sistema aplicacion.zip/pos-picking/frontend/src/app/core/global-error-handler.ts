import { HttpErrorResponse } from '@angular/common/http';
import { ErrorHandler, Injectable, inject, isDevMode } from '@angular/core';

import { NotificacionService } from './services/notificacion.service';

/** Captura los errores de runtime no manejados (los de HTTP los ven los interceptores). */
@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  private readonly noti = inject(NotificacionService);

  handleError(error: unknown): void {
    if (error instanceof HttpErrorResponse) {
      return; // ya lo maneja errorInterceptor
    }
    if (isDevMode()) {
      console.error('[GlobalErrorHandler]', error);
    }
    this.noti.error('Ocurrió un error inesperado en la aplicación.');
  }
}
