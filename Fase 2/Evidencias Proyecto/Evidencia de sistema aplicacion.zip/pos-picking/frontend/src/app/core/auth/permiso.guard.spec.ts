import { TestBed } from '@angular/core/testing';
import { Router, UrlTree } from '@angular/router';

import { NotificacionService } from '../services/notificacion.service';
import { AuthService } from './auth.service';
import { permisoGuard } from './permiso.guard';

function ejecutar(data: Record<string, unknown>, path = 'usuarios') {
  return TestBed.runInInjectionContext(() =>
    permisoGuard({ data, routeConfig: { path } } as never, {} as never),
  );
}

describe('permisoGuard', () => {
  let permisos: string[];
  let rol: string;
  const errores: string[] = [];
  let cerroSesion = false;

  beforeEach(() => {
    permisos = [];
    rol = 'vendedor';
    errores.length = 0;
    cerroSesion = false;
    TestBed.configureTestingModule({
      providers: [
        {
          provide: AuthService,
          useValue: {
            usuario: () => ({ rol }),
            tieneAlgunPermiso: (...cods: string[]) => cods.some((c) => permisos.includes(c)),
            logout: () => { cerroSesion = true; },
          },
        },
        { provide: NotificacionService, useValue: { error: (m: string) => errores.push(m) } },
        {
          provide: Router,
          useValue: {
            createUrlTree: (comandos: unknown[], extras?: unknown) =>
              ({ comandos, extras }) as unknown as UrlTree,
          },
        },
      ],
    });
  });

  it('deja pasar cuando la ruta no exige permiso', () => {
    expect(ejecutar({})).toBe(true);
  });

  it('deja pasar si el usuario tiene el permiso', () => {
    permisos = ['usuarios.ver'];
    expect(ejecutar({ permiso: 'usuarios.ver' })).toBe(true);
  });

  it('acepta una lista de permisos alternativos', () => {
    permisos = ['ventas.ver'];
    expect(ejecutar({ permiso: ['ventas.crear', 'ventas.ver'] })).toBe(true);
  });

  it('si falta el permiso, avisa y manda a la primera pantalla accesible', () => {
    permisos = ['catalogo.ver'];
    const res = ejecutar({ permiso: 'dashboard.ver' }, 'dashboard') as unknown as {
      comandos: string[];
    };
    expect(res.comandos).toEqual(['/catalogo']);
    expect(errores[0]).toContain('permiso');
    expect(cerroSesion).toBe(false);
  });

  it('sin acceso a ninguna pantalla: cierra sesión y va a /login', () => {
    rol = 'ninguno';
    const res = ejecutar({ permiso: 'dashboard.ver' }, 'dashboard') as unknown as {
      comandos: string[];
    };
    expect(res.comandos).toEqual(['/login']);
    expect(cerroSesion).toBe(true);
  });

  it('bloquea una ruta excluida para el rol aunque tenga el permiso', () => {
    rol = 'mayorista';
    permisos = ['ofertas.ver'];
    const res = ejecutar({ permiso: 'ofertas.ver', exceptoRoles: ['mayorista'] }, 'ofertas') as unknown as {
      comandos: string[];
    };
    expect(res.comandos).toEqual(['/catalogo-mayorista']);
    expect(errores[0]).toContain('permiso');
  });

  it('el mayorista pasa a su catálogo (soloRoles)', () => {
    rol = 'mayorista';
    permisos = ['ofertas.ver'];
    expect(
      ejecutar({ permiso: 'ofertas.ver', soloRoles: ['mayorista'] }, 'catalogo-mayorista'),
    ).toBe(true);
  });
});
