import { HttpErrorResponse, HttpInterceptorFn, HttpRequest } from '@angular/common/http';
import { inject } from '@angular/core';
import { Observable, catchError, switchMap, throwError } from 'rxjs';

import { environment } from '../../../environments/environment';
import { AuthService } from '../auth/auth.service';

/** Peticiones de autenticación que NO deben llevar el token ni intentar refrescar. */
const RUTAS_PUBLICAS = ['/auth/login/', '/auth/refresh/'];

/** Refresh compartido: si llegan varios 401 a la vez, todos esperan el mismo. */
let refrescando$: Observable<{ access: string }> | null = null;

function esApi(req: HttpRequest<unknown>): boolean {
  return req.url.startsWith(environment.apiUrl) || req.url.startsWith('/api/');
}

function esPublica(req: HttpRequest<unknown>): boolean {
  return RUTAS_PUBLICAS.some((r) => req.url.includes(r));
}

/**
 * Agrega `Authorization: Bearer <access>` a las peticiones de la API y, ante un
 * 401, intenta renovar el token una vez y reintenta la petición. Si el refresh
 * falla, cierra la sesión.
 */
export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);

  if (!esApi(req) || esPublica(req)) {
    return next(req);
  }

  const conToken = (token: string | null) =>
    token ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }) : req;

  return next(conToken(auth.accessToken)).pipe(
    catchError((err: unknown) => {
      if (!(err instanceof HttpErrorResponse) || err.status !== 401) {
        return throwError(() => err);
      }
      if (!auth.hayRefreshToken) {
        auth.logout();
        return throwError(() => err);
      }

      refrescando$ ??= auth.refrescar();
      return refrescando$.pipe(
        switchMap((r) => {
          refrescando$ = null;
          return next(conToken(r.access));
        }),
        catchError((refreshErr) => {
          refrescando$ = null;
          auth.logout();
          return throwError(() => refreshErr);
        }),
      );
    }),
  );
};
