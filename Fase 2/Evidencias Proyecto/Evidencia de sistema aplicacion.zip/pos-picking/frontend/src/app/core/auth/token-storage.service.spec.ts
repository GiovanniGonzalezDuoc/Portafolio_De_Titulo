import { TokenStorageService } from './token-storage.service';

describe('TokenStorageService', () => {
  let servicio: TokenStorageService;

  beforeEach(() => {
    localStorage.clear();
    servicio = new TokenStorageService();
  });

  it('guarda el access solo en memoria y el refresh en localStorage', () => {
    servicio.guardar('acc', 'ref');
    expect(servicio.access).toBe('acc');
    expect(servicio.refresh).toBe('ref');
    expect(localStorage.getItem('pos_refresh')).toBe('ref');

    // una instancia nueva pierde el access pero conserva el refresh
    const otra = new TokenStorageService();
    expect(otra.access).toBeNull();
    expect(otra.refresh).toBe('ref');
  });

  it('limpiar borra todo', () => {
    servicio.guardar('acc', 'ref');
    servicio.guardarUsuario({ id: 1 });
    servicio.limpiar();
    expect(servicio.access).toBeNull();
    expect(servicio.refresh).toBeNull();
    expect(servicio.usuarioSerializado).toBeNull();
  });
});
