import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

import { NotificacionService } from '../services/notificacion.service';
import { AuthService } from './auth.service';
import { primeraRutaAccesible } from './landing';

/**
 * Guard de permiso por ruta.
 *
 * Uso en las rutas:
 *   { path: 'usuarios', canActivate: [permisoGuard], data: { permiso: 'usuarios.ver' } }
 * o con varios permisos alternativos:
 *   data: { permiso: ['ventas.crear', 'ventas.ver'] }
 *
 * La autoridad real es el backend; esto solo evita mostrar pantallas sin acceso.
 */
export const permisoGuard: CanActivateFn = (ruta) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  const noti = inject(NotificacionService);

  const rol = auth.usuario()?.rol ?? '';
  const soloRoles = ruta.data['soloRoles'] as string[] | undefined;
  const exceptoRoles = ruta.data['exceptoRoles'] as string[] | undefined;
  const rolBloqueado =
    (soloRoles && !soloRoles.includes(rol)) || (exceptoRoles && exceptoRoles.includes(rol));

  const requerido = ruta.data['permiso'] as string | string[] | undefined;
  const codigos = requerido ? (Array.isArray(requerido) ? requerido : [requerido]) : [];
  const tienePermiso = codigos.length === 0 || auth.tieneAlgunPermiso(...codigos);

  if (tienePermiso && !rolBloqueado) {
    return true;
  }
  noti.error('No tienes permiso para acceder a esa sección.');
  // Se redirige a la primera pantalla que sí puede ver (no a `/`, que
  // reenvía a `/dashboard` y provocaría un bucle si tampoco tiene ese permiso).
  const destino = primeraRutaAccesible(auth);
  if (destino) {
    return router.createUrlTree([destino]);
  }
  auth.logout(false);
  return router.createUrlTree(['/login'], { queryParams: { sinacceso: '1' } });
};
