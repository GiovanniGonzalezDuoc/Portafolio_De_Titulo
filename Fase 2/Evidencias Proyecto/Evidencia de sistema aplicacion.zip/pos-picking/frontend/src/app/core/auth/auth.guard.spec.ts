import { TestBed } from '@angular/core/testing';
import { Router, UrlTree } from '@angular/router';

import { authGuard, invitadoGuard } from './auth.guard';
import { AuthService } from './auth.service';

function ejecutar(guard: typeof authGuard, url = '/dashboard') {
  return TestBed.runInInjectionContext(() =>
    guard({} as never, { url } as never),
  );
}

describe('authGuard / invitadoGuard', () => {
  let autenticado = false;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: AuthService, useValue: { autenticado: () => autenticado } },
        {
          provide: Router,
          useValue: {
            createUrlTree: (comandos: unknown[], extras?: unknown) =>
              ({ comandos, extras }) as unknown as UrlTree,
          },
        },
      ],
    });
  });

  it('authGuard deja pasar si hay sesión', () => {
    autenticado = true;
    expect(ejecutar(authGuard)).toBe(true);
  });

  it('authGuard redirige a /login guardando la url', () => {
    autenticado = false;
    const res = ejecutar(authGuard, '/ventas') as unknown as {
      comandos: string[];
      extras: { queryParams: { redir: string } };
    };
    expect(res.comandos).toEqual(['/login']);
    expect(res.extras.queryParams.redir).toBe('/ventas');
  });

  it('invitadoGuard bloquea /login si ya hay sesión', () => {
    autenticado = true;
    const res = ejecutar(invitadoGuard) as unknown as { comandos: string[] };
    expect(res.comandos).toEqual(['/']);
  });
});
