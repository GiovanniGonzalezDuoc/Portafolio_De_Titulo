import { DOCUMENT } from '@angular/common';
import { Injectable, inject } from '@angular/core';
import { Subject } from 'rxjs';

/**
 * Detecta lectores de código de barras tipo *keyboard wedge*: teclean el código
 * muy rápido y lo terminan con Enter. Emite el código completo por `codigos$`.
 *
 * La escritura manual (una tecla cada varios cientos de ms) nunca alcanza la
 * velocidad requerida, así que el buscador del POS puede seguir usando su
 * propio `(keyup.enter)` sin colisionar con el lector.
 */
@Injectable({ providedIn: 'root' })
export class EscanerCodigoBarras {
  /** Códigos leídos por un lector físico. */
  readonly codigos$ = new Subject<string>();

  /** Máximo de ms entre teclas para considerarlas parte de una misma lectura. */
  private readonly PAUSA_MAX_MS = 50;
  /** Largo mínimo aceptable para un código. */
  private readonly LARGO_MIN = 3;

  private buffer = '';
  private ultimaTecla = 0;
  private marcaUltimoEscaneo = 0;

  constructor() {
    const doc = inject(DOCUMENT);
    // `capture` para verlo antes que los handlers de los inputs.
    doc.addEventListener('keydown', (e) => this.alTeclear(e), { capture: true });
  }

  /** ¿Hubo una lectura del lector en los últimos `ms`? Evita procesarla dos veces. */
  escaneoReciente(ms = 400): boolean {
    return Date.now() - this.marcaUltimoEscaneo < ms;
  }

  private alTeclear(e: KeyboardEvent): void {
    const ahora = Date.now();
    const brecha = ahora - this.ultimaTecla;
    this.ultimaTecla = ahora;

    if (e.key === 'Enter') {
      const esLectura = this.buffer.length >= this.LARGO_MIN && brecha < this.PAUSA_MAX_MS;
      if (esLectura) {
        const codigo = this.buffer;
        this.marcaUltimoEscaneo = ahora;
        this.buffer = '';
        this.codigos$.next(codigo);
      } else {
        this.buffer = '';
      }
      return;
    }

    // Solo caracteres imprimibles de un carácter; cualquier combinación con
    // modificadores o tecla especial rompe la secuencia.
    if (e.key.length !== 1 || e.ctrlKey || e.altKey || e.metaKey) {
      this.buffer = '';
      return;
    }

    this.buffer = brecha > this.PAUSA_MAX_MS ? e.key : this.buffer + e.key;
  }
}
