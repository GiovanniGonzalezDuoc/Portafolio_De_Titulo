import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';

import { environment } from '../../../environments/environment';
import { AuthService } from '../auth/auth.service';
import { jwtInterceptor } from './jwt.interceptor';

describe('jwtInterceptor', () => {
  let http: HttpClient;
  let ctrl: HttpTestingController;
  let auth: {
    accessToken: string | null;
    hayRefreshToken: boolean;
    refrescar: ReturnType<typeof vi.fn>;
    logout: ReturnType<typeof vi.fn>;
  };

  beforeEach(() => {
    auth = {
      accessToken: 'acc-1',
      hayRefreshToken: true,
      refrescar: vi.fn(() => of({ access: 'acc-2' })),
      logout: vi.fn(),
    };
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([jwtInterceptor])),
        provideHttpClientTesting(),
        { provide: AuthService, useValue: auth },
      ],
    });
    http = TestBed.inject(HttpClient);
    ctrl = TestBed.inject(HttpTestingController);
  });

  afterEach(() => ctrl.verify());

  it('agrega el header Authorization a las peticiones de la API', () => {
    http.get(`${environment.apiUrl}/catalogo/productos/`).subscribe();
    const req = ctrl.expectOne(`${environment.apiUrl}/catalogo/productos/`);
    expect(req.request.headers.get('Authorization')).toBe('Bearer acc-1');
    req.flush({});
  });

  it('no toca las rutas públicas de auth', () => {
    http.post(`${environment.apiUrl}/auth/login/`, {}).subscribe();
    const req = ctrl.expectOne(`${environment.apiUrl}/auth/login/`);
    expect(req.request.headers.has('Authorization')).toBe(false);
    req.flush({});
  });

  it('ante un 401 refresca el token y reintenta con el nuevo', () => {
    http.get(`${environment.apiUrl}/x/`).subscribe();
    ctrl.expectOne(`${environment.apiUrl}/x/`).flush({}, { status: 401, statusText: 'Unauthorized' });

    expect(auth.refrescar).toHaveBeenCalledTimes(1);
    const reintento = ctrl.expectOne(`${environment.apiUrl}/x/`);
    expect(reintento.request.headers.get('Authorization')).toBe('Bearer acc-2');
    reintento.flush({ ok: true });
  });

  it('cierra la sesión si no hay refresh token', () => {
    auth.hayRefreshToken = false;
    http.get(`${environment.apiUrl}/x/`).subscribe({ error: () => undefined });
    ctrl.expectOne(`${environment.apiUrl}/x/`).flush({}, { status: 401, statusText: 'Unauthorized' });
    expect(auth.logout).toHaveBeenCalled();
  });

  it('cierra la sesión si el refresh falla', () => {
    auth.refrescar = vi.fn(() => throwError(() => new Error('refresh caído')));
    http.get(`${environment.apiUrl}/x/`).subscribe({ error: () => undefined });
    ctrl.expectOne(`${environment.apiUrl}/x/`).flush({}, { status: 401, statusText: 'Unauthorized' });
    expect(auth.logout).toHaveBeenCalled();
  });
});
