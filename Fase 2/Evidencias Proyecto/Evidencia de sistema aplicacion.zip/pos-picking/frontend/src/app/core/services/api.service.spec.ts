import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { environment } from '../../../environments/environment';
import { SIN_TOAST } from '../http/error.interceptor';
import { ApiService } from './api.service';

describe('ApiService', () => {
  let api: ApiService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApiService, provideHttpClient(), provideHttpClientTesting()],
    });
    api = TestBed.inject(ApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('antepone apiUrl y agrega slash final para evitar el 301 de DRF', () => {
    api.get('catalogo/productos').subscribe();
    const req = http.expectOne(`${environment.apiUrl}/catalogo/productos/`);
    expect(req.request.method).toBe('GET');
    req.flush({});
  });

  it('no duplica el slash si el recurso ya lo trae', () => {
    api.get('catalogo/productos/1/').subscribe();
    http.expectOne(`${environment.apiUrl}/catalogo/productos/1/`).flush({});
  });

  it('serializa los parámetros de listado y omite vacíos', () => {
    api.lista('inventario/stock', { page: 2, search: '', bajo_minimo: true }).subscribe();
    const req = http.expectOne(
      (r) => r.url === `${environment.apiUrl}/inventario/stock/`,
    );
    expect(req.request.params.get('page')).toBe('2');
    expect(req.request.params.get('bajo_minimo')).toBe('true');
    expect(req.request.params.has('search')).toBe(false);
    req.flush({ resultados: [], conteo: 0 });
  });

  it('getSilencioso marca el contexto SIN_TOAST', () => {
    api.getSilencioso('catalogo/productos/por-codigo/123').subscribe();
    const req = http.expectOne(`${environment.apiUrl}/catalogo/productos/por-codigo/123/`);
    expect(req.request.context.get(SIN_TOAST)).toBe(true);
    req.flush({});
  });

  it('get normal no activa SIN_TOAST', () => {
    api.get('x').subscribe();
    const req = http.expectOne(`${environment.apiUrl}/x/`);
    expect(req.request.context.get(SIN_TOAST)).toBe(false);
    req.flush({});
  });
});
