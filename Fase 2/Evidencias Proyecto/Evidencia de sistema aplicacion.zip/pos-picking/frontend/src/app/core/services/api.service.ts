import { HttpClient, HttpContext, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { environment } from '../../../environments/environment';
import { SIN_TOAST } from '../http/error.interceptor';
import { Pagina, ParamsListado } from '../models/api.models';

/**
 * Envoltura fina sobre `HttpClient` que antepone `apiUrl` y normaliza los
 * parámetros de listado. Cada feature tiene su propio servicio tipado encima.
 */
@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly http = inject(HttpClient);
  private readonly base = environment.apiUrl;

  lista<T>(recurso: string, params?: ParamsListado): Observable<Pagina<T>> {
    return this.http.get<Pagina<T>>(this.url(recurso), { params: this.aHttpParams(params) });
  }

  get<T>(recurso: string, params?: ParamsListado): Observable<T> {
    return this.http.get<T>(this.url(recurso), { params: this.aHttpParams(params) });
  }

  /**
   * GET cuyo error NO dispara el snackbar global: el componente que llama se
   * encarga de traducir el fallo (lo usa el POS al buscar por código).
   */
  getSilencioso<T>(recurso: string, params?: ParamsListado): Observable<T> {
    return this.http.get<T>(this.url(recurso), {
      params: this.aHttpParams(params),
      context: new HttpContext().set(SIN_TOAST, true),
    });
  }

  /** GET que devuelve texto plano (HTML de la boleta, CSV, …). */
  getTexto(recurso: string): Observable<string> {
    return this.http.get(this.url(recurso), { responseType: 'text' });
  }

  /** GET de un archivo (CSV, PDF…) con su nombre sugerido. */
  descargar(
    recurso: string,
    params?: ParamsListado,
  ): Observable<{ blob: Blob; nombre: string }> {
    return this.http
      .get(this.url(recurso), {
        params: this.aHttpParams(params),
        responseType: 'blob',
        observe: 'response',
      })
      .pipe(
        map((resp) => {
          const cd = resp.headers.get('Content-Disposition') ?? '';
          const m = /filename\*?=(?:UTF-8'')?"?([^"';]+)"?/i.exec(cd);
          return {
            blob: resp.body as Blob,
            nombre: m ? decodeURIComponent(m[1]) : 'descarga',
          };
        }),
      );
  }

  post<T>(recurso: string, cuerpo: unknown): Observable<T> {
    return this.http.post<T>(this.url(recurso), cuerpo);
  }

  put<T>(recurso: string, cuerpo: unknown): Observable<T> {
    return this.http.put<T>(this.url(recurso), cuerpo);
  }

  patch<T>(recurso: string, cuerpo: unknown): Observable<T> {
    return this.http.patch<T>(this.url(recurso), cuerpo);
  }

  delete<T>(recurso: string): Observable<T> {
    return this.http.delete<T>(this.url(recurso));
  }

  private url(recurso: string): string {
    let limpio = recurso.startsWith('/') ? recurso.slice(1) : recurso;
    // DRF usa slash final; lo garantizamos para evitar redirecciones 301.
    if (!limpio.endsWith('/') && !limpio.includes('?')) {
      limpio += '/';
    }
    return `${this.base}/${limpio}`;
  }

  private aHttpParams(params?: ParamsListado): HttpParams {
    let hp = new HttpParams();
    if (!params) {
      return hp;
    }
    for (const [clave, valor] of Object.entries(params)) {
      if (valor !== undefined && valor !== null && valor !== '') {
        hp = hp.set(clave, String(valor));
      }
    }
    return hp;
  }
}
