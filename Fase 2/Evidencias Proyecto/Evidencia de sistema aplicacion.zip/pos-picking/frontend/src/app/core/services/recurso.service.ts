import { inject } from '@angular/core';
import { Observable } from 'rxjs';

import { Pagina, ParamsListado } from '../models/api.models';
import { ApiService } from './api.service';

/**
 * Base para los servicios de recurso REST (usuarios, productos, …).
 * Cada servicio concreto define `path` y agrega los métodos propios.
 */
export abstract class RecursoService<T, TCrear = Partial<T>, TEditar = Partial<T>> {
  protected readonly api = inject(ApiService);
  protected abstract readonly path: string;

  lista(params?: ParamsListado): Observable<Pagina<T>> {
    return this.api.lista<T>(this.path, params);
  }

  obtener(id: number | string): Observable<T> {
    return this.api.get<T>(`${this.path}/${id}`);
  }

  crear(dto: TCrear): Observable<T> {
    return this.api.post<T>(this.path, dto);
  }

  actualizar(id: number | string, dto: TEditar): Observable<T> {
    return this.api.patch<T>(`${this.path}/${id}`, dto);
  }

  eliminar(id: number | string): Observable<void> {
    return this.api.delete<void>(`${this.path}/${id}`);
  }

  /** POST a `<path>/<id>/<accion>/`. */
  accion<R = T>(id: number | string, accion: string, cuerpo: unknown = {}): Observable<R> {
    return this.api.post<R>(`${this.path}/${id}/${accion}`, cuerpo);
  }

  /** GET a `<path>/<id>/<accion>/`. */
  accionGet<R>(id: number | string, accion: string): Observable<R> {
    return this.api.get<R>(`${this.path}/${id}/${accion}`);
  }

  /** POST a `<path>/<accion>/` (acción de colección). */
  accionColeccion<R>(accion: string, cuerpo: unknown = {}): Observable<R> {
    return this.api.post<R>(`${this.path}/${accion}`, cuerpo);
  }
}
