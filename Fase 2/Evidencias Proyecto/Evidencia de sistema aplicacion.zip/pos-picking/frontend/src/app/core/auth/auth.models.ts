/** Modelos de autenticación (apps/usuarios). */

export interface Usuario {
  id: number;
  username: string;
  email: string;
  nombres: string;
  apellidos: string;
  nombre_completo: string;
  rut: string | null;
  rol: string;
  activo: boolean;
  is_staff: boolean;
  permisos: string[];
}

export interface RespuestaLogin {
  access: string;
  refresh: string;
  usuario: Usuario;
}

export interface Credenciales {
  username: string;
  password: string;
}
