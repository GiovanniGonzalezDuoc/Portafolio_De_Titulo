import { Injectable, inject } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

/** Mensajes de éxito / error / información mediante snackbars de Material. */
@Injectable({ providedIn: 'root' })
export class NotificacionService {
  private readonly snack = inject(MatSnackBar);

  exito(mensaje: string): void {
    this.mostrar(mensaje, 'noti-exito', 3000);
  }

  error(mensaje: string): void {
    this.mostrar(mensaje, 'noti-error', 6000);
  }

  info(mensaje: string): void {
    this.mostrar(mensaje, 'noti-info', 4000);
  }

  private mostrar(mensaje: string, clase: string, duracion: number): void {
    this.snack.open(mensaje, 'Cerrar', {
      duration: duracion,
      panelClass: [clase],
      horizontalPosition: 'end',
      verticalPosition: 'top',
    });
  }
}
