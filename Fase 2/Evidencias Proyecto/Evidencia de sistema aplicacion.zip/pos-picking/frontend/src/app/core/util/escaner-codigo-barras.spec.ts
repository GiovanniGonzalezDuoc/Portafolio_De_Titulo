import { TestBed } from '@angular/core/testing';
import { Subscription } from 'rxjs';

import { EscanerCodigoBarras } from './escaner-codigo-barras';

/** Simula una tecla en el documento (lo que hace un lector keyboard-wedge). */
function tecla(key: string): void {
  document.dispatchEvent(new KeyboardEvent('keydown', { key }));
}

/** Teclea `texto` con `gap` ms entre teclas y termina con Enter. */
function escribir(texto: string, gapMs: number): void {
  for (const c of texto) {
    tecla(c);
    vi.advanceTimersByTime(gapMs);
  }
  tecla('Enter');
}

describe('EscanerCodigoBarras', () => {
  let servicio: EscanerCodigoBarras;
  let leidos: string[];
  let sub: Subscription;

  beforeEach(() => {
    vi.useFakeTimers();
    TestBed.configureTestingModule({});
    servicio = TestBed.inject(EscanerCodigoBarras);
    leidos = [];
    sub = servicio.codigos$.subscribe((c) => leidos.push(c));
  });

  afterEach(() => {
    sub.unsubscribe();
    vi.useRealTimers();
  });

  it('emite el código cuando llega rápido y termina en Enter', () => {
    escribir('7801234567890', 10);
    expect(leidos).toEqual(['7801234567890']);
  });

  it('ignora tecleo lento (persona escribiendo)', () => {
    escribir('ABC123', 200);
    expect(leidos).toEqual([]);
  });

  it('ignora secuencias demasiado cortas', () => {
    escribir('12', 10);
    expect(leidos).toEqual([]);
  });

  it('marca escaneoReciente tras una lectura válida', () => {
    escribir('7801234567890', 10);
    expect(servicio.escaneoReciente()).toBe(true);
    vi.advanceTimersByTime(1000);
    expect(servicio.escaneoReciente()).toBe(false);
  });

  it('no mezcla una lectura previa con la siguiente', () => {
    escribir('1111111', 10);
    vi.advanceTimersByTime(5000);
    escribir('2222222', 10);
    expect(leidos).toEqual(['1111111', '2222222']);
  });
});
