import { Injectable, computed, signal } from '@angular/core';

/** Preferencia de tema elegida por el usuario. */
export type PreferenciaTema = 'claro' | 'oscuro' | 'auto';

const CLAVE = 'pos-tema';
const CICLO: readonly PreferenciaTema[] = ['claro', 'oscuro', 'auto'];

/**
 * Modo claro / oscuro de la aplicación.
 *
 * No conmuta clases de CSS: solo ajusta la propiedad `color-scheme` del
 * `<html>`. Los tokens de Angular Material y los colores semánticos de
 * `styles.scss` están definidos con `light-dark(...)`, así que el navegador
 * resuelve el esquema correcto sin más trabajo. El parpadeo inicial lo evita
 * un script inline en `index.html` que aplica la misma preferencia antes del
 * primer render.
 */
@Injectable({ providedIn: 'root' })
export class TemaService {
  private readonly _preferencia = signal<PreferenciaTema>(leerPreferencia());
  readonly preferencia = this._preferencia.asReadonly();

  readonly icono = computed(() => {
    switch (this._preferencia()) {
      case 'claro':
        return 'light_mode';
      case 'oscuro':
        return 'dark_mode';
      default:
        return 'brightness_auto';
    }
  });

  readonly etiqueta = computed(() => {
    switch (this._preferencia()) {
      case 'claro':
        return 'Tema claro';
      case 'oscuro':
        return 'Tema oscuro';
      default:
        return 'Tema automático (según el sistema)';
    }
  });

  constructor() {
    this.aplicar(this._preferencia());
  }

  /** claro → oscuro → automático → claro… */
  ciclar(): void {
    const i = CICLO.indexOf(this._preferencia());
    this.establecer(CICLO[(i + 1) % CICLO.length]);
  }

  establecer(pref: PreferenciaTema): void {
    this._preferencia.set(pref);
    try {
      localStorage.setItem(CLAVE, pref);
    } catch {
      /* modo incógnito / almacenamiento bloqueado */
    }
    this.aplicar(pref);
  }

  private aplicar(pref: PreferenciaTema): void {
    const esquema = pref === 'claro' ? 'light' : pref === 'oscuro' ? 'dark' : 'light dark';
    document.documentElement.style.colorScheme = esquema;
  }
}

function leerPreferencia(): PreferenciaTema {
  try {
    const v = localStorage.getItem(CLAVE);
    if (v === 'claro' || v === 'oscuro' || v === 'auto') {
      return v;
    }
  } catch {
    /* almacenamiento no disponible */
  }
  return 'auto';
}
