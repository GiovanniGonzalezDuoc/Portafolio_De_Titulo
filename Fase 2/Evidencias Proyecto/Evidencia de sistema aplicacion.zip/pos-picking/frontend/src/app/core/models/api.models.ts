/** Tipos comunes de la API POS Picking. */

/** Envoltura de error unificada del backend (apps/core/exceptions.py). */
export interface ErrorApi {
  error: {
    codigo: string;
    mensaje: string;
    detalles: Record<string, unknown> | null;
    campo: string | null;
  };
}

/** Respuesta paginada estándar (apps/core/pagination.py). */
export interface Pagina<T> {
  conteo: number;
  paginas: number;
  pagina_actual: number;
  siguiente: string | null;
  anterior: string | null;
  resultados: T[];
}

export interface ParamsListado {
  page?: number;
  page_size?: number;
  search?: string;
  ordering?: string;
  [clave: string]: string | number | boolean | undefined;
}
