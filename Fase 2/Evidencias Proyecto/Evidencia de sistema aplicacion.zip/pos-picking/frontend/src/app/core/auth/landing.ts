import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

import { NAVEGACION, puedeVerItem } from '../../layouts/navegacion';
import { AuthService } from './auth.service';

/**
 * Primera ruta del menú lateral que el usuario tiene permiso de ver.
 * `null` si la cuenta no puede acceder a ninguna pantalla.
 */
export function primeraRutaAccesible(auth: AuthService): string | null {
  const ctx = {
    rol: auth.usuario()?.rol ?? null,
    tieneAlgunPermiso: (...c: string[]) => auth.tieneAlgunPermiso(...c),
  };
  for (const grupo of NAVEGACION) {
    for (const item of grupo.items) {
      if (puedeVerItem(item, ctx)) {
        return item.ruta;
      }
    }
  }
  return null;
}

/**
 * Guard de la ruta raíz (`/`): manda al usuario a su primera pantalla
 * accesible en vez de asumir que todos pueden ver el dashboard (p. ej. el rol
 * `mayorista` solo ve el catálogo de ofertas). Evita el bucle de redirección
 * `/` → `/dashboard` → guard → `/` → …
 */
export const landingGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  const ruta = primeraRutaAccesible(auth);
  if (ruta) {
    return router.createUrlTree([ruta]);
  }
  // Cuenta sin acceso a ninguna pantalla: se cierra la sesión.
  auth.logout(false);
  return router.createUrlTree(['/login'], { queryParams: { sinacceso: '1' } });
};
