import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

import { NotificacionService } from '../../core/services/notificacion.service';
import { aplicarErrorBackend } from '../../shared/util/form-errores';
import { ParametroReposicion, ReposicionService } from './reposicion.service';

@Component({
  selector: 'app-parametros-dialog',
  imports: [ReactiveFormsModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  template: `
    <h2 mat-dialog-title>Parámetros de reposición</h2>
    <mat-dialog-content>
      <form [formGroup]="form" class="form-vert">
        <mat-form-field appearance="outline">
          <mat-label>Factor de nivel de servicio (Z)</mat-label>
          <input matInput type="number" step="0.01" formControlName="nivel_servicio_z" />
        </mat-form-field>
        <mat-form-field appearance="outline">
          <mat-label>Horizonte de predicción (semanas)</mat-label>
          <input matInput type="number" formControlName="horizonte_semanas" />
        </mat-form-field>
        <mat-form-field appearance="outline">
          <mat-label>Período de revisión (semanas)</mat-label>
          <input matInput type="number" step="0.01" formControlName="periodo_revision_semanas" />
        </mat-form-field>
      </form>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button mat-dialog-close>Cancelar</button>
      <button mat-flat-button color="primary" (click)="guardar()" [disabled]="form.invalid || guardando">
        Guardar
      </button>
    </mat-dialog-actions>
  `,
})
export class ParametrosDialog {
  private readonly fb = inject(FormBuilder);
  private readonly service = inject(ReposicionService);
  private readonly noti = inject(NotificacionService);
  private readonly ref = inject(MatDialogRef<ParametrosDialog>);
  private readonly data = inject<ParametroReposicion>(MAT_DIALOG_DATA);

  guardando = false;

  readonly form = this.fb.nonNullable.group({
    nivel_servicio_z: [+this.data.nivel_servicio_z, [Validators.required, Validators.min(0)]],
    horizonte_semanas: [this.data.horizonte_semanas, [Validators.required, Validators.min(1)]],
    periodo_revision_semanas: [
      +this.data.periodo_revision_semanas,
      [Validators.required, Validators.min(0)],
    ],
  });

  guardar(): void {
    if (this.form.invalid) return;
    this.guardando = true;
    this.service.guardarParametros(this.form.getRawValue()).subscribe({
      next: (p) => {
        this.noti.exito('Parámetros actualizados.');
        this.ref.close(p);
      },
      error: (err: unknown) => {
        this.guardando = false;
        aplicarErrorBackend(this.form, err);
      },
    });
  }
}
