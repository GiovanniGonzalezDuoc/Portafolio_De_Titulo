import { Component, inject } from '@angular/core';

import { AuthService } from '../../core/auth/auth.service';
import { MaestraConfig, MaestraSimple } from './maestra-simple/maestra-simple';
import { CategoriasService } from './catalogo.service';

@Component({
  selector: 'app-categorias',
  imports: [MaestraSimple],
  template: `<app-maestra-simple [config]="config" />`,
})
export class Categorias {
  private readonly service = inject(CategoriasService);
  private readonly auth = inject(AuthService);

  readonly config: MaestraConfig = {
    titulo: 'Categorías',
    subtitulo: 'Clasificación de los productos',
    singular: 'Categoría',
    icono: 'category',
    puedeAdministrar: this.auth.tienePermiso('catalogo.administrar'),
    cargar: (p) => this.service.lista(p),
    crear: (dto) => this.service.crear(dto),
    actualizar: (id, dto) => this.service.actualizar(id, dto),
    desactivar: (id) => this.service.eliminar(id),
    activar: (id) => this.service.activar(id),
  };
}
