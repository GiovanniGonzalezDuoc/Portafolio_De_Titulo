import { DatePipe } from '@angular/common';
import { Component, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';

import { AuthService } from '../../core/auth/auth.service';
import { BadgeEstado } from '../../shared/components/badge-estado/badge-estado';
import { EstadoVacio } from '../../shared/components/estado-vacio/estado-vacio';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { ClpPipe } from '../../shared/pipes/clp.pipe';
import { crearListado } from '../../shared/util/listado';
import { OrdenForm } from './orden-form';
import { ComprasService, OrdenCompra } from './compras.service';

const ESTADOS = ['BORRADOR', 'EMITIDA', 'RECIBIDA_PARCIAL', 'RECIBIDA', 'CERRADA', 'ANULADA'];

@Component({
  selector: 'app-compras-lista',
  imports: [
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
    PageHeader,
    BadgeEstado,
    EstadoVacio,
    ClpPipe,
    DatePipe,
  ],
  templateUrl: './compras-lista.html',
})
export class ComprasLista {
  private readonly service = inject(ComprasService);
  private readonly dialog = inject(MatDialog);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  readonly estados = ESTADOS;
  readonly columnas = ['codigo', 'proveedor', 'fecha', 'total', 'estado', 'ver'];
  readonly puedeCrear = this.auth.tienePermiso('compras.crear');

  readonly filtroEstado = new FormControl('', { nonNullable: true });
  readonly listado = crearListado<OrdenCompra>((p) => this.service.lista(p));

  constructor() {
    this.filtroEstado.valueChanges
      .pipe(takeUntilDestroyed())
      .subscribe((v) => this.listado.filtrar({ estado: v || undefined, ordering: '-creado_en' }));
  }

  paginar(e: PageEvent): void {
    this.listado.irAPagina(e.pageIndex, e.pageSize);
  }

  abrir(o: OrdenCompra): void {
    this.router.navigate(['/compras', o.id]);
  }

  nueva(): void {
    const ref = this.dialog.open(OrdenForm, { width: '800px', maxWidth: '95vw' });
    ref.afterClosed().subscribe((id) => id && this.listado.recargar());
  }
}
