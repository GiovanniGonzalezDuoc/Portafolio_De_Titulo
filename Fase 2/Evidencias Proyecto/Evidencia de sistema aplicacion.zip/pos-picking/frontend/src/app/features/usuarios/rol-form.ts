import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

import { NotificacionService } from '../../core/services/notificacion.service';
import { aplicarErrorBackend } from '../../shared/util/form-errores';
import { Rol } from './usuarios.models';
import { RolesService } from './usuarios.service';

/** Alta y edición de un rol (nombre, descripción, estado). */
@Component({
  selector: 'app-rol-form',
  imports: [
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatCheckboxModule,
    MatButtonModule,
  ],
  template: `
    <h2 mat-dialog-title>{{ rol ? 'Editar rol' : 'Nuevo rol' }}</h2>
    <mat-dialog-content>
      <form [formGroup]="form" class="rol-form">
        <mat-form-field appearance="outline">
          <mat-label>Nombre</mat-label>
          <input matInput formControlName="nombre" placeholder="p. ej. cajero" />
          @if (form.controls.nombre.hasError('required')) { <mat-error>Requerido</mat-error> }
          @if (form.controls.nombre.hasError('backend')) {
            <mat-error>{{ form.controls.nombre.getError('backend') }}</mat-error>
          }
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Descripción (opcional)</mat-label>
          <input matInput formControlName="descripcion" />
        </mat-form-field>

        @if (rol) {
          <mat-checkbox formControlName="activo">Rol activo</mat-checkbox>
        }
      </form>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button mat-dialog-close>Cancelar</button>
      <button mat-flat-button color="primary" (click)="guardar()" [disabled]="guardando()">
        Guardar
      </button>
    </mat-dialog-actions>
  `,
  styles: `
    .rol-form {
      display: flex;
      flex-direction: column;
      gap: 8px;
      min-width: 340px;
      max-width: 100%;
      padding-top: 8px;
    }
  `,
})
export class RolForm {
  private readonly fb = inject(FormBuilder);
  private readonly service = inject(RolesService);
  private readonly noti = inject(NotificacionService);
  private readonly ref = inject(MatDialogRef<RolForm>);
  readonly rol = inject<Rol | null>(MAT_DIALOG_DATA, { optional: true });

  readonly guardando = signal(false);
  readonly form = this.fb.nonNullable.group({
    nombre: [this.rol?.nombre ?? '', [Validators.required, Validators.minLength(2)]],
    descripcion: [this.rol?.descripcion ?? ''],
    activo: [this.rol?.activo ?? true],
  });

  guardar(): void {
    if (this.form.invalid || this.guardando()) return;
    this.guardando.set(true);
    const v = this.form.getRawValue();
    const obs = this.rol
      ? this.service.actualizar(this.rol.id, {
          nombre: v.nombre.trim(),
          descripcion: v.descripcion.trim(),
          activo: v.activo,
        })
      : this.service.crear({ nombre: v.nombre.trim(), descripcion: v.descripcion.trim() });

    obs.subscribe({
      next: (rol) => {
        this.noti.exito(this.rol ? 'Rol actualizado.' : `Rol "${rol.nombre}" creado.`);
        this.ref.close(rol);
      },
      error: (e: unknown) => {
        this.guardando.set(false);
        aplicarErrorBackend(this.form, e);
      },
    });
  }
}
