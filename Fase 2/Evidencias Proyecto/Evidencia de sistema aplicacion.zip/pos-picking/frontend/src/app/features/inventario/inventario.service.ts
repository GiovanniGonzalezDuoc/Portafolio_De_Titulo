import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { ApiService } from '../../core/services/api.service';
import { RecursoService } from '../../core/services/recurso.service';
import {
  MovimientoInventario,
  ParametroInventario,
  Stock,
  Ubicacion,
} from './inventario.models';

@Injectable({ providedIn: 'root' })
export class InventarioService {
  private readonly api = inject(ApiService);

  stock(params?: Record<string, string | number | boolean | undefined>) {
    return this.api.lista<Stock>('inventario/stock', params);
  }

  movimientos(params?: Record<string, string | number | boolean | undefined>) {
    return this.api.lista<MovimientoInventario>('inventario/movimientos', params);
  }

  /** CSV de los movimientos que pasan los filtros (producto/tipo/desde/hasta). */
  exportarMovimientos(params?: Record<string, string | number | boolean | undefined>) {
    return this.api.descargar('inventario/movimientos/exportar', params);
  }

  /** Excel para editar el stock masivamente; respeta los mismos filtros que la lista. */
  exportarStock(params?: Record<string, string | number | boolean | undefined>) {
    return this.api.descargar('inventario/stock/exportar', params);
  }

  importarStock(archivo: File): Observable<ImportarStockResultado> {
    const form = new FormData();
    form.append('archivo', archivo);
    return this.api.post<ImportarStockResultado>('inventario/stock/importar', form);
  }

  registrarMovimiento(dto: {
    producto: string;
    ubicacion?: string;
    tipo: 'AJUSTE_POSITIVO' | 'AJUSTE_NEGATIVO';
    cantidad: string | number;
    motivo: string;
  }): Observable<MovimientoInventario> {
    return this.api.post<MovimientoInventario>('inventario/movimientos/registrar', dto);
  }

  ajustar(dto: {
    producto: string;
    ubicacion?: string;
    cantidad_final: string | number;
    motivo: string;
  }): Observable<MovimientoInventario> {
    return this.api.post<MovimientoInventario>('inventario/movimientos/ajustar', dto);
  }

  ubicaciones(): Observable<{ resultados: Ubicacion[] }> {
    return this.api.lista<Ubicacion>('inventario/ubicaciones', { page_size: 100 });
  }
}

@Injectable({ providedIn: 'root' })
export class ParametrosInventarioService extends RecursoService<ParametroInventario> {
  protected readonly path = 'inventario/parametros';
}

export interface ImportarStockResultado {
  actualizados: number;
  sin_cambios: number;
  total_filas: number;
  con_error: { fila: number; sku: string; motivo: string }[];
}
