import { DatePipe } from '@angular/common';
import { Component, computed, inject, input, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTableModule } from '@angular/material/table';
import { RouterLink } from '@angular/router';

import { AuthService } from '../../core/auth/auth.service';
import { NotificacionService } from '../../core/services/notificacion.service';
import { BadgeEstado } from '../../shared/components/badge-estado/badge-estado';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { pedirTexto } from '../../shared/components/input-dialog/input-dialog';
import { CantidadPipe } from '../../shared/pipes/cantidad.pipe';
import { ClpPipe } from '../../shared/pipes/clp.pipe';
import { guardarArchivo } from '../../shared/util/descargar';
import { OrdenCompra, ComprasService, Recepcion } from './compras.service';
import { RecepcionForm } from './recepcion-form';

@Component({
  selector: 'app-orden-detalle',
  imports: [
    RouterLink,
    MatCardModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
    PageHeader,
    BadgeEstado,
    ClpPipe,
    CantidadPipe,
    DatePipe,
  ],
  templateUrl: './orden-detalle.html',
  styleUrl: './orden-detalle.scss',
})
export class OrdenDetalle {
  readonly id = input.required<string>(); // withComponentInputBinding

  private readonly service = inject(ComprasService);
  private readonly dialog = inject(MatDialog);
  private readonly noti = inject(NotificacionService);
  private readonly auth = inject(AuthService);

  readonly orden = signal<OrdenCompra | null>(null);
  readonly recepciones = signal<Recepcion[]>([]);
  readonly cargando = signal(true);
  readonly enviando = signal(false);

  readonly colLineas = ['producto', 'cantidad', 'recibida', 'costo', 'subtotal'];
  readonly puedeCrear = this.auth.tienePermiso('compras.crear');
  readonly puedeRecibir = this.auth.tienePermiso('compras.recibir');

  /**
   * El flujo real de compras (cotización → orden → seguimiento → llegada)
   * mostrado como pasos, aparte del badge de estado técnico.
   */
  readonly pasosCompra = ['Cotización', 'Orden', 'Seguimiento', 'Llegada'];
  readonly pasoActual = computed(() => {
    switch (this.orden()?.estado) {
      case 'EMITIDA':
        return 1;
      case 'RECIBIDA_PARCIAL':
        return 2;
      case 'RECIBIDA':
      case 'CERRADA':
        return 3;
      default:
        return 0; // BORRADOR (o ANULADA, que se avisa aparte)
    }
  });

  constructor() {
    queueMicrotask(() => this.cargar());
  }

  private cargar(): void {
    this.cargando.set(true);
    this.service.obtener(this.id()).subscribe((o) => {
      this.orden.set(o);
      this.cargando.set(false);
    });
    this.service.recepciones(+this.id()).subscribe((r) => this.recepciones.set(r));
  }

  get puedeEmitir(): boolean {
    return this.orden()?.estado === 'BORRADOR';
  }
  get puedeAnular(): boolean {
    return ['BORRADOR', 'EMITIDA'].includes(this.orden()?.estado ?? '');
  }
  get puedeRecibirOrden(): boolean {
    return ['EMITIDA', 'RECIBIDA_PARCIAL'].includes(this.orden()?.estado ?? '');
  }

  emitir(): void {
    this.service.emitir(+this.id()).subscribe(() => {
      this.noti.exito('Orden emitida.');
      this.cargar();
    });
  }

  async anular(): Promise<void> {
    const motivo = await pedirTexto(this.dialog, {
      titulo: 'Anular orden de compra',
      etiqueta: 'Motivo',
    });
    if (!motivo) return;
    this.service.anular(+this.id(), motivo).subscribe(() => {
      this.noti.exito('Orden anulada.');
      this.cargar();
    });
  }

  recibir(): void {
    const o = this.orden();
    if (!o) return;
    const ref = this.dialog.open(RecepcionForm, { data: o, width: '620px' });
    ref.afterClosed().subscribe((hecho) => hecho && this.cargar());
  }

  subtotal(cantidad: string, costo: number): number {
    return Math.round(+cantidad * costo);
  }

  // ─── PDF / envío al proveedor ─────────────────────────────
  descargarPdf(): void {
    const o = this.orden();
    if (!o) return;
    this.service.descargarPdf(o.id).subscribe(({ blob, nombre }) => {
      guardarArchivo(blob, nombre || `${o.codigo}.pdf`);
    });
  }

  async enviarProveedor(): Promise<void> {
    const o = this.orden();
    if (!o) return;
    const email = await pedirTexto(this.dialog, {
      titulo: 'Enviar cotización al proveedor',
      etiqueta: 'Email del proveedor',
      tipo: 'email',
      placeholder: 'contacto@proveedor.cl',
      valorInicial: o.proveedor_email,
      confirmar: 'Enviar',
    });
    if (email === null) return; // canceló el diálogo
    this.enviando.set(true);
    this.service.enviarProveedor(o.id, email.trim()).subscribe({
      next: (r) => {
        this.enviando.set(false);
        this.noti.exito(`Cotización enviada a ${r.para}.`);
      },
      error: () => this.enviando.set(false),
    });
  }
}
