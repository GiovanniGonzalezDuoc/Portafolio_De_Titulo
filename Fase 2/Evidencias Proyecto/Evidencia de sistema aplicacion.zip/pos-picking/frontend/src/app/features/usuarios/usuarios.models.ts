export interface UsuarioListado {
  id: number;
  username: string;
  email: string;
  nombres: string;
  apellidos: string;
  nombre_completo: string;
  rut: string | null;
  rol: string;
  activo: boolean;
  is_staff: boolean;
  last_login: string | null;
  creado_en: string;
}

export interface UsuarioCrear {
  username: string;
  email?: string;
  nombres: string;
  apellidos: string;
  rut?: string | null;
  rol: string;
  activo?: boolean;
  password: string;
}

export type UsuarioEditar = Omit<UsuarioCrear, 'password' | 'username' | 'activo'>;

export interface Rol {
  id: number;
  nombre: string;
  descripcion: string;
  activo: boolean;
  permisos: string[];
}

export interface Permiso {
  id: number;
  codigo: string;
  modulo: string;
  descripcion: string;
}
