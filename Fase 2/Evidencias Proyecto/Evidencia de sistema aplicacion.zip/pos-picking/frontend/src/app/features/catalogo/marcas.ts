import { Component, inject } from '@angular/core';

import { AuthService } from '../../core/auth/auth.service';
import { MaestraConfig, MaestraSimple } from './maestra-simple/maestra-simple';
import { MarcasService } from './catalogo.service';

@Component({
  selector: 'app-marcas',
  imports: [MaestraSimple],
  template: `<app-maestra-simple [config]="config" />`,
})
export class Marcas {
  private readonly service = inject(MarcasService);
  private readonly auth = inject(AuthService);

  readonly config: MaestraConfig = {
    titulo: 'Marcas',
    subtitulo: 'Marcas comerciales de los productos',
    singular: 'Marca',
    icono: 'sell',
    puedeAdministrar: this.auth.tienePermiso('catalogo.administrar'),
    cargar: (p) => this.service.lista(p),
    crear: (dto) => this.service.crear(dto),
    actualizar: (id, dto) => this.service.actualizar(id, dto),
    desactivar: (id) => this.service.eliminar(id),
    activar: (id) => this.service.activar(id),
  };
}
