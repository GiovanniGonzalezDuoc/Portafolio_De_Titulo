import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-no-encontrado',
  imports: [MatButtonModule, RouterLink],
  template: `
    <div class="nf">
      <h1>404</h1>
      <p>La página que buscas no existe.</p>
      <a mat-flat-button color="primary" routerLink="/">Volver al inicio</a>
    </div>
  `,
  styles: `
    .nf {
      display: grid;
      place-items: center;
      gap: 8px;
      min-height: 60dvh;
      text-align: center;
    }
    h1 {
      font-size: 4rem;
      margin: 0;
      color: var(--mat-sys-primary);
    }
  `,
})
export class NoEncontrado {}
