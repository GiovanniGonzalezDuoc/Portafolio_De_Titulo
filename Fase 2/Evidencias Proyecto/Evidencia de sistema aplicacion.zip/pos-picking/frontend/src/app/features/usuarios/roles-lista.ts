import { TitleCasePipe } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialog } from '@angular/material/dialog';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { firstValueFrom, forkJoin } from 'rxjs';

import { AuthService } from '../../core/auth/auth.service';
import { NotificacionService } from '../../core/services/notificacion.service';
import { confirmar } from '../../shared/components/confirm-dialog/confirm-dialog';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { RolForm } from './rol-form';
import { Permiso, Rol } from './usuarios.models';
import { RolesService } from './usuarios.service';

interface GrupoPermisos {
  modulo: string;
  titulo: string;
  permisos: Permiso[];
}

const ROL_ADMIN = 'administrador';

@Component({
  selector: 'app-roles-lista',
  imports: [
    MatExpansionModule,
    MatCheckboxModule,
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
    PageHeader,
    TitleCasePipe,
  ],
  templateUrl: './roles-lista.html',
  styleUrl: './roles-lista.scss',
})
export class RolesLista {
  private readonly service = inject(RolesService);
  private readonly noti = inject(NotificacionService);
  private readonly auth = inject(AuthService);
  private readonly dialog = inject(MatDialog);

  readonly puedeAdministrar = this.auth.tienePermiso('roles.administrar');
  readonly cargando = signal(true);
  readonly guardando = signal<number | null>(null);

  readonly roles = signal<Rol[]>([]);
  /** Permisos originales por rol, para detectar cambios. */
  private readonly originales = new Map<number, Set<string>>();
  /** Selección editable por rol. */
  readonly seleccion = signal<Record<number, Set<string>>>({});

  readonly grupos = signal<GrupoPermisos[]>([]);

  /** Los 4 roles base del sistema: no se pueden renombrar ni eliminar. */
  private readonly rolesBase = new Set(['administrador', 'bodeguero', 'vendedor', 'mayorista']);

  constructor() {
    forkJoin({ roles: this.service.lista(), permisos: this.service.permisos() })
      .pipe(takeUntilDestroyed())
      .subscribe({
        next: ({ roles, permisos }) => {
          this.aplicarRoles(roles);
          this.grupos.set(this.agrupar(permisos));
          this.cargando.set(false);
        },
        error: () => this.cargando.set(false),
      });
  }

  private aplicarRoles(roles: Rol[]): void {
    this.roles.set(roles);
    this.originales.clear();
    for (const rol of roles) {
      this.originales.set(rol.id, new Set(rol.permisos));
    }
    this.seleccion.set(Object.fromEntries(roles.map((r) => [r.id, new Set(r.permisos)])));
  }

  private recargarRoles(): void {
    this.service.lista().subscribe((roles) => this.aplicarRoles(roles));
  }

  esBase(rol: Rol): boolean {
    return this.rolesBase.has(rol.nombre);
  }

  async nuevoRol(): Promise<void> {
    const creado = await firstValueFrom(this.dialog.open(RolForm).afterClosed());
    if (creado) this.recargarRoles();
  }

  async editarRol(rol: Rol): Promise<void> {
    const editado = await firstValueFrom(this.dialog.open(RolForm, { data: rol }).afterClosed());
    if (editado) this.recargarRoles();
  }

  async eliminarRol(rol: Rol): Promise<void> {
    const ok = await confirmar(this.dialog, {
      titulo: 'Eliminar rol',
      mensaje:
        `¿Eliminar el rol "${rol.nombre}"? Solo se puede si ningún usuario lo tiene ` +
        `asignado.`,
      peligro: true,
    });
    if (!ok) return;
    this.service.eliminar(rol.id).subscribe(() => {
      this.noti.exito(`Rol "${rol.nombre}" eliminado.`);
      this.recargarRoles();
    });
  }

  private agrupar(permisos: Permiso[]): GrupoPermisos[] {
    const mapa = new Map<string, Permiso[]>();
    for (const p of permisos) {
      const lista = mapa.get(p.modulo);
      if (lista) lista.push(p);
      else mapa.set(p.modulo, [p]);
    }
    return [...mapa.entries()]
      .map(([modulo, ps]) => ({
        modulo,
        titulo: modulo.replace(/_/g, ' '),
        permisos: ps.sort((a, b) => a.codigo.localeCompare(b.codigo)),
      }))
      .sort((a, b) => a.modulo.localeCompare(b.modulo));
  }

  esAdmin(rol: Rol): boolean {
    return rol.nombre === ROL_ADMIN;
  }

  tiene(rolId: number, codigo: string): boolean {
    return this.seleccion()[rolId]?.has(codigo) ?? false;
  }

  contar(rolId: number): number {
    return this.seleccion()[rolId]?.size ?? 0;
  }

  cambiado(rolId: number): boolean {
    const actual = this.seleccion()[rolId];
    const original = this.originales.get(rolId);
    if (!actual || !original || actual.size !== original.size) return true;
    for (const c of actual) if (!original.has(c)) return true;
    return false;
  }

  alternar(rolId: number, codigo: string, activo: boolean): void {
    this.seleccion.update((estado) => {
      const set = new Set(estado[rolId]);
      if (activo) set.add(codigo);
      else set.delete(codigo);
      return { ...estado, [rolId]: set };
    });
  }

  deshacer(rol: Rol): void {
    this.seleccion.update((estado) => ({
      ...estado,
      [rol.id]: new Set(this.originales.get(rol.id)),
    }));
  }

  guardar(rol: Rol): void {
    if (this.guardando() !== null || !this.cambiado(rol.id)) return;
    const codigos = [...(this.seleccion()[rol.id] ?? [])];
    this.guardando.set(rol.id);
    this.service.setPermisos(rol.id, codigos).subscribe({
      next: (actualizado) => {
        this.originales.set(rol.id, new Set(actualizado.permisos));
        this.seleccion.update((estado) => ({
          ...estado,
          [rol.id]: new Set(actualizado.permisos),
        }));
        this.roles.update((rs) => rs.map((r) => (r.id === rol.id ? actualizado : r)));
        this.guardando.set(null);
        this.noti.exito(`Permisos de "${rol.nombre}" actualizados.`);
      },
      error: () => this.guardando.set(null),
    });
  }
}
