import { DatePipe } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';

import { AuthService } from '../../core/auth/auth.service';
import { NotificacionService } from '../../core/services/notificacion.service';
import { BadgeEstado } from '../../shared/components/badge-estado/badge-estado';
import { EstadoVacio } from '../../shared/components/estado-vacio/estado-vacio';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { crearListado } from '../../shared/util/listado';
import { Alerta, AlertasService, ResumenAlertas } from './alertas.service';

@Component({
  selector: 'app-alertas-lista',
  imports: [
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatSelectModule,
    MatCheckboxModule,
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
    PageHeader,
    BadgeEstado,
    EstadoVacio,
    DatePipe,
  ],
  templateUrl: './alertas-lista.html',
  styleUrl: './alertas-lista.scss',
})
export class AlertasLista {
  private readonly service = inject(AlertasService);
  private readonly noti = inject(NotificacionService);
  private readonly auth = inject(AuthService);

  readonly columnas = ['sel', 'severidad', 'tipo', 'mensaje', 'estado', 'fecha', 'acciones'];
  readonly puedeResolver = this.auth.tienePermiso('alertas.resolver');

  readonly filtroEstado = new FormControl('', { nonNullable: true });
  readonly filtroSeveridad = new FormControl('', { nonNullable: true });
  readonly seleccion = signal<Set<number>>(new Set());
  readonly resumen = signal<ResumenAlertas | null>(null);

  // Espejo reactivo de los filtros, para marcar el atajo activo del resumen.
  private readonly estadoSig = toSignal(this.filtroEstado.valueChanges, {
    initialValue: this.filtroEstado.value,
  });
  private readonly sevSig = toSignal(this.filtroSeveridad.valueChanges, {
    initialValue: this.filtroSeveridad.value,
  });
  readonly verTodasActivo = computed(() => !this.estadoSig() && !this.sevSig());
  readonly nuevasActivo = computed(() => this.estadoSig() === 'NUEVA');
  readonly criticasActivo = computed(() => this.sevSig() === 'CRITICAL');

  readonly listado = crearListado<Alerta>((p) => this.service.lista(p));

  constructor() {
    this.cargarResumen();
    this.filtroEstado.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.filtroSeveridad.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.aplicar();
  }

  private cargarResumen(): void {
    // Sin takeUntilDestroyed: es una llamada HTTP que se completa sola y este
    // método también se llama fuera del contexto de inyección (tras resolver /
    // marcar vista), donde takeUntilDestroyed() lanzaría NG0203.
    this.service.resumen().subscribe((r) => this.resumen.set(r));
  }

  private aplicar(): void {
    this.listado.filtrar({
      estado: this.filtroEstado.value || undefined,
      severidad: this.filtroSeveridad.value || undefined,
      abiertas: this.filtroEstado.value ? undefined : true,
    });
    this.seleccion.set(new Set());
  }

  paginar(e: PageEvent): void {
    this.listado.irAPagina(e.pageIndex, e.pageSize);
  }

  // ─── Atajos del resumen: filtran la tabla ──────────────────
  verTodas(): void {
    this.filtroSeveridad.setValue('');
    this.filtroEstado.setValue('');
  }
  verNuevas(): void {
    this.filtroSeveridad.setValue('');
    this.filtroEstado.setValue('NUEVA');
  }
  verCriticas(): void {
    this.filtroEstado.setValue('');
    this.filtroSeveridad.setValue('CRITICAL');
  }

  toggle(id: number): void {
    const s = new Set(this.seleccion());
    if (s.has(id)) {
      s.delete(id);
    } else {
      s.add(id);
    }
    this.seleccion.set(s);
  }

  marcarVista(a: Alerta): void {
    this.service.marcarVista(a.id).subscribe(() => this.refrescar());
  }

  resolver(a: Alerta): void {
    this.service.resolver(a.id).subscribe(() => {
      this.noti.exito('Alerta resuelta.');
      this.refrescar();
    });
  }

  resolverSeleccionadas(): void {
    const ids = [...this.seleccion()];
    if (!ids.length) return;
    this.service.resolverVarias(ids).subscribe((r) => {
      this.noti.exito(`${r.resueltas} alertas resueltas.`);
      this.refrescar();
    });
  }

  private refrescar(): void {
    this.listado.recargar();
    this.cargarResumen();
    this.seleccion.set(new Set());
  }
}
