import { Component, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormBuilder, FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatChipsModule } from '@angular/material/chips';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { debounceTime, switchMap } from 'rxjs';

import { NotificacionService } from '../../core/services/notificacion.service';
import { fechaLocalIso } from '../../shared/util/fecha';
import { aplicarErrorBackend } from '../../shared/util/form-errores';
import { CategoriasService, MarcasService, ProductosService } from '../catalogo/catalogo.service';
import { AplicarMasivo, TipoDescuento } from './ofertas.models';
import { OfertasService } from './ofertas.service';

type Alcance = 'producto' | 'categoria' | 'marca' | 'todos';
interface ProductoElegido {
  sku: string;
  nombre: string;
}

@Component({
  selector: 'app-oferta-masiva',
  imports: [
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatAutocompleteModule,
    MatChipsModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatIconModule,
  ],
  templateUrl: './oferta-masiva.html',
})
export class OfertaMasiva {
  private readonly fb = inject(FormBuilder);
  private readonly service = inject(OfertasService);
  private readonly noti = inject(NotificacionService);
  private readonly ref = inject(MatDialogRef<OfertaMasiva>);
  private readonly categoriasSrv = inject(CategoriasService);
  private readonly marcasSrv = inject(MarcasService);
  private readonly productosSrv = inject(ProductosService);
  private readonly data = inject<{ skus?: string[] } | null>(MAT_DIALOG_DATA, { optional: true });

  /** SKUs preseleccionados (opcional, desde la pantalla de productos). */
  readonly skus: string[] = this.data?.skus ?? [];
  readonly esProductosFijos = this.skus.length > 0;
  readonly enviando = signal(false);
  readonly categorias = signal<string[]>([]);
  readonly marcas = signal<string[]>([]);

  // ─── Selección por producto individual ──────────────────────
  readonly buscarProducto = new FormControl('', { nonNullable: true });
  readonly sugerencias = signal<ProductoElegido[]>([]);
  readonly elegidos = signal<ProductoElegido[]>([]);

  readonly form = this.fb.nonNullable.group({
    alcance: ['categoria' as Alcance, Validators.required],
    categoria: [''],
    marca: [''],
    tipo: ['porcentaje' as TipoDescuento, Validators.required],
    valor: [20, [Validators.required, Validators.min(1)]],
    inicia_en: [this.hoy(), Validators.required],
    termina_en: [''],
    descripcion: [''],
  });

  constructor() {
    this.categoriasSrv
      .lista({ activo: 'true', page_size: 200, ordering: 'nombre' })
      .subscribe((p) => this.categorias.set(p.resultados.map((c) => c.nombre)));
    this.marcasSrv
      .lista({ activo: 'true', page_size: 200, ordering: 'nombre' })
      .subscribe((p) => this.marcas.set(p.resultados.map((m) => m.nombre)));

    this.buscarProducto.valueChanges
      .pipe(
        debounceTime(250),
        switchMap((q) => {
          // Al elegir una opción el control puede quedar con el SKU; solo
          // buscamos cuando lo que hay es texto libre.
          const texto = typeof q === 'string' ? q.trim() : '';
          return this.productosSrv.lista({
            search: texto || undefined,
            activo: 'true',
            page_size: 10,
            ordering: 'nombre',
          });
        }),
        takeUntilDestroyed(),
      )
      .subscribe((p) => {
        const yaElegidos = new Set(this.elegidos().map((e) => e.sku));
        this.sugerencias.set(
          p.resultados
            .filter((r) => !yaElegidos.has(r.sku))
            .map((r) => ({ sku: r.sku, nombre: r.nombre })),
        );
      });
  }

  private hoy(): string {
    return fechaLocalIso(new Date());
  }

  /** El autocomplete no escribe nada en el input: los productos van a los chips. */
  mostrarVacio = (): string => '';

  agregarProducto(p: ProductoElegido): void {
    if (!this.elegidos().some((e) => e.sku === p.sku)) {
      this.elegidos.update((xs) => [...xs, p]);
    }
    this.buscarProducto.setValue('');
    this.sugerencias.set([]);
  }

  quitarProducto(sku: string): void {
    this.elegidos.update((xs) => xs.filter((e) => e.sku !== sku));
  }

  aplicar(): void {
    if (this.form.invalid || this.enviando()) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    const dto: AplicarMasivo = {
      tipo: v.tipo,
      valor: v.valor,
      inicia_en: v.inicia_en,
      termina_en: v.termina_en || null,
      descripcion: v.descripcion || undefined,
    };

    if (this.esProductosFijos) {
      dto.productos = this.skus;
    } else if (v.alcance === 'producto') {
      if (this.elegidos().length === 0) {
        this.noti.error('Elige al menos un producto.');
        return;
      }
      dto.productos = this.elegidos().map((e) => e.sku);
    } else if (v.alcance === 'categoria') {
      if (!v.categoria) {
        this.form.controls.categoria.setErrors({ required: true });
        return;
      }
      dto.categoria = v.categoria;
    } else if (v.alcance === 'marca') {
      if (!v.marca) {
        this.form.controls.marca.setErrors({ required: true });
        return;
      }
      dto.marca = v.marca;
    } else {
      dto.todos = true;
    }

    this.enviando.set(true);
    this.service.aplicarMasivo(dto).subscribe({
      next: (r) => {
        this.noti.exito(
          `${r.creadas} ${r.creadas === 1 ? 'oferta creada' : 'ofertas creadas'}` +
            (r.omitidas ? ` · ${r.omitidas} omitidas (no bajaban el precio)` : ''),
        );
        this.ref.close(true);
      },
      error: (err: unknown) => {
        this.enviando.set(false);
        aplicarErrorBackend(this.form, err);
      },
    });
  }
}
