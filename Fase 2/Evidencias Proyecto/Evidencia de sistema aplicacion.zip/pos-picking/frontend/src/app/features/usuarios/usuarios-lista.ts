import { DatePipe, TitleCasePipe } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { debounceTime } from 'rxjs';

import { AuthService } from '../../core/auth/auth.service';
import { NotificacionService } from '../../core/services/notificacion.service';
import { BadgeEstado } from '../../shared/components/badge-estado/badge-estado';
import { EstadoVacio } from '../../shared/components/estado-vacio/estado-vacio';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { confirmar } from '../../shared/components/confirm-dialog/confirm-dialog';
import { pedirTexto } from '../../shared/components/input-dialog/input-dialog';
import { crearListado } from '../../shared/util/listado';
import { UsuarioForm } from './usuario-form';
import { Rol, UsuarioListado } from './usuarios.models';
import { RolesService, UsuariosService } from './usuarios.service';

@Component({
  selector: 'app-usuarios-lista',
  imports: [
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatProgressBarModule,
    PageHeader,
    BadgeEstado,
    EstadoVacio,
    DatePipe,
    TitleCasePipe,
  ],
  templateUrl: './usuarios-lista.html',
})
export class UsuariosLista {
  private readonly service = inject(UsuariosService);
  private readonly rolesService = inject(RolesService);
  private readonly dialog = inject(MatDialog);
  private readonly noti = inject(NotificacionService);
  private readonly auth = inject(AuthService);

  readonly columnas = ['usuario', 'rol', 'estado', 'ultimo_login', 'acciones'];
  readonly puedeAdministrar = this.auth.tienePermiso('usuarios.administrar');

  readonly buscar = new FormControl('', { nonNullable: true });
  readonly filtroRol = new FormControl('', { nonNullable: true });
  readonly filtroActivo = new FormControl('', { nonNullable: true });
  readonly roles = signal<Rol[]>([]);

  readonly listado = crearListado<UsuarioListado>((p) => this.service.lista(p));

  constructor() {
    this.rolesService.lista().pipe(takeUntilDestroyed()).subscribe((r) => this.roles.set(r));

    this.buscar.valueChanges.pipe(debounceTime(300), takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.filtroRol.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.filtroActivo.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
  }

  private aplicar(): void {
    this.listado.filtrar({
      search: this.buscar.value || undefined,
      rol__nombre: this.filtroRol.value || undefined,
      is_active: this.filtroActivo.value || undefined,
    });
  }

  paginar(e: PageEvent): void {
    this.listado.irAPagina(e.pageIndex, e.pageSize);
  }

  nuevo(): void {
    this.abrirForm(null);
  }

  editar(u: UsuarioListado): void {
    this.abrirForm(u);
  }

  private abrirForm(usuario: UsuarioListado | null): void {
    const ref = this.dialog.open(UsuarioForm, {
      data: { usuario, roles: this.roles() },
      width: '640px',
    });
    ref.afterClosed().subscribe((ok) => ok && this.listado.recargar());
  }

  async cambiarEstado(u: UsuarioListado): Promise<void> {
    const activar = !u.activo;
    const ok = await confirmar(this.dialog, {
      titulo: activar ? 'Activar usuario' : 'Desactivar usuario',
      mensaje: `¿${activar ? 'Activar' : 'Desactivar'} a ${u.nombre_completo}?`,
      peligro: !activar,
    });
    if (!ok) return;
    const obs = activar ? this.service.activar(u.id) : this.service.desactivar(u.id);
    obs.subscribe(() => {
      this.noti.exito('Estado actualizado.');
      this.listado.recargar();
    });
  }

  async resetear(u: UsuarioListado): Promise<void> {
    const clave = await pedirTexto(this.dialog, {
      titulo: `Restablecer contraseña de ${u.username}`,
      etiqueta: 'Nueva contraseña',
      tipo: 'password',
      placeholder: 'Mínimo 8 caracteres',
    });
    if (!clave) return;
    this.service
      .resetearPassword(u.id, clave)
      .subscribe(() => this.noti.exito('Contraseña actualizada.'));
  }
}
