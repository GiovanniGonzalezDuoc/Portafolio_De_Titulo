import { TitleCasePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, computed, effect, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { RouterLink } from '@angular/router';
import { Subject, catchError, debounceTime, map, of, switchMap } from 'rxjs';

import { ErrorApi } from '../../core/models/api.models';
import { EscanerCodigoBarras } from '../../core/util/escaner-codigo-barras';
import { NotificacionService } from '../../core/services/notificacion.service';
import { confirmar } from '../../shared/components/confirm-dialog/confirm-dialog';
import { ClpPipe } from '../../shared/pipes/clp.pipe';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { Producto } from '../catalogo/catalogo.models';
import { ProductosService } from '../catalogo/catalogo.service';
import { InventarioService } from '../inventario/inventario.service';
import { CajaService } from '../caja/caja.service';
import { AutorizacionDialog } from './autorizacion-dialog';
import { BoletaDialog } from './boleta-dialog';
import { CalculoVenta, Pago, VentasService } from './ventas.service';

interface LineaCarrito {
  producto: Producto;
  cantidad: number;
  descuento: number;
  /** Si esta línea se cobra a precio mayorista (arranca siguiendo el toggle general). */
  mayorista: boolean;
}

@Component({
  selector: 'app-pos',
  imports: [
    ReactiveFormsModule,
    RouterLink,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatTooltipModule,
    MatAutocompleteModule,
    MatSlideToggleModule,
    MatProgressSpinnerModule,
    PageHeader,
    ClpPipe,
    TitleCasePipe,
  ],
  templateUrl: './pos.html',
})
export class Pos {
  private readonly ventasService = inject(VentasService);
  private readonly productosService = inject(ProductosService);
  private readonly inventarioService = inject(InventarioService);
  private readonly cajaService = inject(CajaService);
  private readonly escaner = inject(EscanerCodigoBarras);
  private readonly noti = inject(NotificacionService);
  private readonly dialog = inject(MatDialog);

  readonly cajaAbierta = signal<boolean | null>(null);
  readonly carrito = signal<LineaCarrito[]>([]);
  /** Stock disponible por SKU, tal como lo devolvió la última consulta. */
  readonly stockPorSku = signal<Record<string, number>>({});
  readonly esMayorista = signal(false);
  readonly calculo = signal<CalculoVenta | null>(null);
  readonly pagos = signal<Pago[]>([]);
  readonly procesando = signal(false);
  /** Hay una búsqueda de producto (lector o manual) en curso. */
  readonly buscandoProducto = signal(false);

  readonly busqueda = new FormControl('', { nonNullable: true });
  readonly sugerencias = signal<Producto[]>([]);
  readonly medios = ['EFECTIVO', 'DEBITO', 'CREDITO', 'TRANSFERENCIA'] as const;
  readonly colCarrito = ['producto', 'cantidad', 'precio', 'mayorista', 'descuento', 'subtotal', 'quitar'];

  private readonly recalcular$ = new Subject<void>();

  readonly aCobrar = computed(() => this.calculo()?.total_a_cobrar ?? 0);

  /**
   * Lo que ese pago cubre del total. Para tarjeta/transferencia es el monto
   * ingresado; para efectivo se deriva: como mucho lo que falta por pagar (el
   * resto de lo entregado es vuelto). Así nunca queda "descuadrado" aunque
   * cambie el total después de agregar el pago.
   */
  montoQueCubre(pago: Pago, indice: number): number {
    if (pago.medio !== 'EFECTIVO') return pago.monto || 0;
    const otros = this.pagos().reduce(
      (a, p, j) => (j === indice || p.medio === 'EFECTIVO' ? a : a + (p.monto || 0)),
      0,
    );
    const necesita = Math.max(0, this.aCobrar() - otros);
    return Math.min(pago.entregado ?? 0, necesita);
  }

  readonly totalPagado = computed(() =>
    this.pagos().reduce((a, p, i) => a + this.montoQueCubre(p, i), 0),
  );

  /** Vuelto a entregar: efectivo recibido por encima de lo que cubre. */
  readonly vuelto = computed(() =>
    this.pagos().reduce(
      (a, p, i) => a + Math.max(0, (p.entregado ?? 0) - this.montoQueCubre(p, i)),
      0,
    ),
  );

  /** Datos calculados por el backend para una línea (precio y subtotal reales). */
  lineaCalc(sku: string) {
    return this.calculo()?.lineas.find((l) => l.producto === sku);
  }
  readonly cuadra = computed(
    () => this.calculo() !== null && this.carrito().length > 0 && this.totalPagado() === this.aCobrar(),
  );

  constructor() {
    this.cajaService.miCaja().subscribe({
      next: () => this.cajaAbierta.set(true),
      error: () => this.cajaAbierta.set(false),
    });

    this.busqueda.valueChanges
      .pipe(
        debounceTime(250),
        switchMap((q) =>
          q && q.length >= 2
            ? this.productosService
                .lista({ search: q, activo: 'true', page_size: 8 })
                .pipe(map((p) => p.resultados))
            : of<Producto[]>([]),
        ),
        takeUntilDestroyed(),
      )
      .subscribe((lista) => this.sugerencias.set(lista));

    this.recalcular$
      .pipe(
        debounceTime(200),
        switchMap(() => {
          const items = this.carrito().map((l) => ({
            producto: l.producto.sku,
            cantidad: l.cantidad,
            descuento_monto: l.descuento || 0,
            mayorista: l.mayorista,
          }));
          if (!items.length) return of(null);
          return this.ventasService
            .calcular({
              items,
              es_mayorista: this.esMayorista(),
              hay_efectivo: this.pagos().some((p) => p.medio === 'EFECTIVO'),
            })
            .pipe(catchError(() => of(null)));
        }),
        takeUntilDestroyed(),
      )
      .subscribe((c) => this.calculo.set(c));

    effect(() => {
      this.carrito();
      this.esMayorista();
      this.pagos();
      this.recalcular$.next();
    });

    // Lector de código de barras (keyboard wedge): va directo al carrito.
    this.escaner.codigos$
      .pipe(takeUntilDestroyed())
      .subscribe((codigo) => this.procesarCodigo(codigo));
  }

  /**
   * `displayWith` del autocomplete: el campo es solo un buscador, así que
   * después de elegir una opción queremos que quede vacío. Devolver siempre
   * '' además evita que el FormControl termine con un objeto Producto dentro
   * (que rompía la app al hacer `.trim()` sobre él en la plantilla).
   */
  readonly mostrarVacio = (): string => '';

  /** Texto del buscador, siempre como string. */
  private textoBusqueda(): string {
    const v = this.busqueda.value as unknown;
    return typeof v === 'string' ? v.trim() : '';
  }

  // ─── Carrito ─────────────────────────────────────────────
  /** Stock conocido del producto; `null` si todavía no se consultó. */
  stockDe(sku: string): number | null {
    const v = this.stockPorSku()[sku];
    return v === undefined ? null : v;
  }

  agregar(p: Producto): void {
    this.busqueda.setValue('');
    this.sugerencias.set([]);
    const actual = this.carrito();
    const i = actual.findIndex((l) => l.producto.id === p.id);
    if (i >= 0) {
      this.setCantidad(i, actual[i].cantidad + 1);
    } else {
      this.carrito.set([
        ...actual,
        { producto: p, cantidad: 1, descuento: 0, mayorista: this.esMayorista() && p.precio_mayorista != null },
      ]);
    }
  }

  /**
   * El toggle general fija el modo por defecto y arrastra a todas las líneas
   * ya cargadas; después cada línea se puede ajustar por separado.
   */
  cambiarMayoristaGeneral(valor: boolean): void {
    this.esMayorista.set(valor);
    this.carrito.update((c) =>
      c.map((l) => ({ ...l, mayorista: valor && l.producto.precio_mayorista != null })),
    );
  }

  setMayoristaLinea(i: number, valor: boolean): void {
    this.carrito.update((c) => c.map((l, idx) => (idx === i ? { ...l, mayorista: valor } : l)));
  }

  /**
   * Flujo del lector: código → producto → validaciones → carrito.
   * También lo usa el Enter del buscador cuando el texto parece un código.
   */
  procesarCodigo(codigo: string): void {
    const limpio = codigo.trim();
    // El lector escribe también en el input: lo limpiamos siempre.
    this.busqueda.setValue('');
    this.sugerencias.set([]);
    if (!limpio || this.buscandoProducto()) return; // ignora lecturas repetidas
    if (this.cajaAbierta() !== true) {
      this.noti.error('Abre una caja antes de escanear productos.');
      return;
    }
    this.buscandoProducto.set(true);
    this.productosService.porCodigo(limpio).subscribe({
      next: (p) => this.agregarConStock(p),
      error: (err: unknown) => {
        this.buscandoProducto.set(false);
        this.reportarErrorBusqueda(limpio, err);
      },
    });
  }

  buscarPorTexto(): void {
    // Si el lector acaba de disparar, su Enter no debe repetir la búsqueda.
    if (this.escaner.escaneoReciente() || this.buscandoProducto()) return;
    const q = this.textoBusqueda();
    if (!q) return;
    this.buscandoProducto.set(true);
    this.productosService.porCodigo(q).subscribe({
      next: (p) => this.agregarConStock(p),
      error: (err: unknown) => {
        if (err instanceof HttpErrorResponse && err.status === 404) {
          this.productosService.porSku(q).subscribe({
            next: (p) => this.agregarConStock(p),
            error: () => {
              this.buscandoProducto.set(false);
              const s = this.sugerencias();
              if (s.length) this.agregarConStock(s[0]);
              else this.noti.error(`Sin resultados para "${q}".`);
            },
          });
        } else {
          this.buscandoProducto.set(false);
          this.reportarErrorBusqueda(q, err);
        }
      },
    });
  }

  /** Traduce el fallo de la búsqueda por código/SKU a un mensaje claro. */
  private reportarErrorBusqueda(codigo: string, err: unknown): void {
    if (err instanceof HttpErrorResponse) {
      const cod = (err.error as Partial<ErrorApi> | null)?.error?.codigo;
      if (err.status === 404 || cod === 'producto_no_encontrado') {
        this.noti.error(`Código no reconocido: ${codigo}`);
        return;
      }
      if (err.status === 409 || cod === 'producto_inactivo') {
        this.noti.error('El producto está inactivo y no puede venderse.');
        return;
      }
      if (err.status === 0) {
        this.noti.error('Sin conexión con el servidor. Reintenta la lectura.');
        return;
      }
    }
    this.noti.error('No se pudo consultar el producto. Reintenta.');
  }

  /** Verifica stock disponible antes de sumar la unidad al carrito. */
  agregarConStock(p: Producto): void {
    // El buscador queda limpio pase lo que pase (evita que el campo se quede
    // con un objeto Producto si el alta se rechaza por stock/estado).
    this.busqueda.setValue('');
    this.sugerencias.set([]);
    if (!p.activo) {
      this.buscandoProducto.set(false);
      this.noti.error('El producto está inactivo y no puede venderse.');
      return;
    }
    const enCarrito = this.carrito().find((l) => l.producto.id === p.id)?.cantidad ?? 0;
    this.inventarioService.stock({ producto: p.sku, page_size: 50 }).subscribe({
      next: (pagina) => {
        this.buscandoProducto.set(false);
        const disponible = pagina.resultados.reduce((a, s) => a + Number(s.cantidad || 0), 0);
        this.stockPorSku.update((m) => ({ ...m, [p.sku]: disponible }));
        if (disponible <= enCarrito) {
          this.noti.error(
            enCarrito > 0
              ? `No queda más stock de ${p.nombre} (disponible: ${disponible}).`
              : `${p.nombre} sin stock.`,
          );
          return;
        }
        this.agregar(p);
        this.noti.exito(`${p.nombre} agregado.`);
      },
      error: () => {
        // Si no se pudo leer el stock, se agrega igual: el backend lo valida al confirmar.
        this.buscandoProducto.set(false);
        this.agregar(p);
        this.noti.info(`${p.nombre} agregado (no se pudo verificar stock).`);
      },
    });
  }

  setCantidad(i: number, valor: number): void {
    let n = Math.max(1, Math.floor(valor || 1));
    const linea = this.carrito()[i];
    const tope = linea ? this.stockDe(linea.producto.sku) : null;
    if (tope !== null && n > tope) {
      n = Math.max(1, tope);
      this.noti.info(
        tope > 0
          ? `Solo quedan ${tope} de ${linea.producto.nombre}.`
          : `${linea.producto.nombre} sin stock disponible.`,
      );
    }
    this.carrito.update((c) => c.map((l, idx) => (idx === i ? { ...l, cantidad: n } : l)));
  }

  /**
   * Handler del campo de cantidad: ajusta el valor (mínimo 1, tope el stock
   * disponible) y lo escribe de vuelta en el input para que no quede "colgado"
   * mostrando un número que ya se corrigió.
   */
  cambiarCantidad(i: number, evento: Event): void {
    const input = evento.target as HTMLInputElement;
    this.setCantidad(i, input.valueAsNumber);
    input.value = String(this.carrito()[i]?.cantidad ?? 1);
  }

  setDescuento(i: number, valor: number): void {
    const d = Math.max(0, Math.floor(valor || 0));
    this.carrito.update((c) => c.map((l, idx) => (idx === i ? { ...l, descuento: d } : l)));
  }

  quitar(i: number): void {
    this.carrito.update((c) => c.filter((_, idx) => idx !== i));
  }

  limpiar(): void {
    this.carrito.set([]);
    this.pagos.set([]);
  }

  /** Vaciar desde el botón: confirma antes, para no borrar la venta por accidente. */
  async vaciar(): Promise<void> {
    if (this.carrito().length === 0) return;
    const ok = await confirmar(this.dialog, {
      titulo: 'Vaciar la venta',
      mensaje: 'Se quitarán todos los productos y pagos de esta venta. ¿Continuar?',
      peligro: true,
      confirmar: 'Vaciar',
    });
    if (ok) this.limpiar();
  }

  // ─── Pagos ───────────────────────────────────────────────
  /** ¿Ya hay un pago registrado con este medio? (solo se permite uno por medio). */
  medioUsado(medio: Pago['medio']): boolean {
    return this.pagos().some((p) => p.medio === medio);
  }

  agregarPago(medio: Pago['medio']): void {
    if (this.medioUsado(medio)) {
      this.noti.info(`Ya hay un pago con ${medio.toLowerCase()}. Ajusta el monto en la línea.`);
      return;
    }
    const falta = Math.max(0, this.aCobrar() - this.totalPagado());
    const pago: Pago =
      medio === 'EFECTIVO' ? { medio, monto: 0, entregado: falta } : { medio, monto: falta };
    this.pagos.update((p) => [...p, pago]);
  }

  /** Ajuste manual del monto de un pago que NO es efectivo. */
  setMontoPago(i: number, monto: number): void {
    this.pagos.update((lista) =>
      this.conAutoResto(
        lista.map((x, idx) => (idx === i ? { ...x, monto: Math.max(0, monto || 0) } : x)),
        i,
      ),
    );
  }

  /** Efectivo: el cajero ingresa lo que entregó el cliente; el vuelto se calcula solo. */
  setEntregado(i: number, entregado: number): void {
    this.pagos.update((lista) =>
      this.conAutoResto(
        lista.map((x, idx) => (idx === i ? { ...x, entregado: Math.max(0, entregado || 0) } : x)),
        i,
      ),
    );
  }

  quitarPago(i: number): void {
    this.pagos.update((lista) => {
      const restante = lista.filter((_, idx) => idx !== i);
      // El último pago que queda absorbe lo que falte para cuadrar.
      return restante.length ? this.conAutoResto(restante, -1) : restante;
    });
  }

  /**
   * Con 2 o más pagos, al editar uno el resto se completa solo en los demás
   * (el último absorbe lo que sobre). Pasar `fijo = -1` para repartir todo.
   */
  private conAutoResto(lista: Pago[], fijo: number): Pago[] {
    const total = this.aCobrar();
    if (lista.length < 2 || !total) return lista;

    const aporte = (p: Pago): number =>
      Math.min(p.medio === 'EFECTIVO' ? (p.entregado ?? 0) : p.monto || 0, total);

    let resto = fijo >= 0 && fijo < lista.length ? Math.max(0, total - aporte(lista[fijo])) : total;
    const otros = lista.map((_, i) => i).filter((i) => i !== fijo);

    return lista.map((p, i) => {
      if (i === fijo) return p;
      const esUltimo = i === otros[otros.length - 1];
      const previo = p.medio === 'EFECTIVO' ? (p.entregado ?? 0) : p.monto || 0;
      const asignar = esUltimo ? resto : Math.min(previo, resto);
      resto = Math.max(0, resto - asignar);
      return p.medio === 'EFECTIVO' ? { ...p, entregado: asignar } : { ...p, monto: asignar };
    });
  }

  // ─── Confirmar ───────────────────────────────────────────
  async confirmar(): Promise<void> {
    if (!this.cuadra() || this.procesando()) return;

    let autorizacion: { username: string; password: string } | undefined;
    if (this.calculo()?.requiere_autorizacion_descuento) {
      const cred = await this.dialog
        .open(AutorizacionDialog, { width: '360px' })
        .afterClosed()
        .toPromise();
      if (!cred) return;
      autorizacion = cred;
    }

    this.procesando.set(true);
    this.ventasService
      .confirmar({
        items: this.carrito().map((l) => ({
          producto: l.producto.sku,
          cantidad: l.cantidad,
          descuento_monto: l.descuento || 0,
          mayorista: l.mayorista,
        })),
        pagos: this.pagos()
          .map((p, i) => ({ medio: p.medio, monto: this.montoQueCubre(p, i) }))
          .filter((p) => p.monto > 0),
        es_mayorista: this.esMayorista(),
        autorizacion,
      })
      .subscribe({
        next: (venta) => {
          this.procesando.set(false);
          this.noti.exito(`Venta ${venta.folio} registrada.`);
          this.limpiar();
          if (venta.documento) {
            this.dialog.open(BoletaDialog, {
              data: { documentoId: venta.documento.id },
              width: '480px',
            });
          }
        },
        error: () => this.procesando.set(false),
      });
  }
}
