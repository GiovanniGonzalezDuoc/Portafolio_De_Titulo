import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-autorizacion-dialog',
  imports: [ReactiveFormsModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  template: `
    <h2 mat-dialog-title>Autorización de descuento</h2>
    <mat-dialog-content>
      <p>El descuento supera el tope del vendedor. Ingresa las credenciales de un supervisor.</p>
      <form [formGroup]="form" class="form-vert">
        <mat-form-field appearance="outline">
          <mat-label>Usuario supervisor</mat-label>
          <input matInput formControlName="username" autocomplete="off" />
        </mat-form-field>
        <mat-form-field appearance="outline">
          <mat-label>Contraseña</mat-label>
          <input matInput type="password" formControlName="password" autocomplete="off" />
        </mat-form-field>
      </form>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button mat-dialog-close>Cancelar</button>
      <button mat-flat-button color="primary" (click)="aceptar()" [disabled]="form.invalid">Autorizar</button>
    </mat-dialog-actions>
  `,
})
export class AutorizacionDialog {
  private readonly fb = inject(FormBuilder);
  private readonly ref = inject(MatDialogRef<AutorizacionDialog>);
  readonly guardando = signal(false);

  readonly form = this.fb.nonNullable.group({
    username: ['', Validators.required],
    password: ['', Validators.required],
  });

  aceptar(): void {
    if (this.form.valid) {
      this.ref.close(this.form.getRawValue());
    }
  }
}
