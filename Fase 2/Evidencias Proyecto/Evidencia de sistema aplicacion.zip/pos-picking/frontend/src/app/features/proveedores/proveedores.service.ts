import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { RecursoService } from '../../core/services/recurso.service';

export interface Proveedor {
  id: number;
  razon_social: string;
  rut: string;
  giro: string;
  contacto_nombre: string;
  contacto_email: string;
  contacto_telefono: string;
  direccion: string;
  lead_time_dias: number;
  activo: boolean;
  productos_asociados: number;
  creado_en: string;
}

export interface ProductoProveedor {
  id: number;
  producto: string;
  producto_nombre: string;
  codigo_proveedor: string;
  costo: number;
  es_preferente: boolean;
}

@Injectable({ providedIn: 'root' })
export class ProveedoresService extends RecursoService<Proveedor> {
  protected readonly path = 'proveedores';

  activar(id: number) {
    return this.accion<Proveedor>(id, 'activar');
  }
  productos(id: number): Observable<ProductoProveedor[]> {
    return this.accionGet<ProductoProveedor[]>(id, 'productos');
  }
  asociarProducto(id: number, dto: { producto: string; costo: number; es_preferente: boolean }) {
    return this.accion<ProductoProveedor>(id, 'asociar-producto', dto);
  }
  quitarProducto(id: number, sku: string) {
    return this.accion<void>(id, 'quitar-producto', { producto: sku });
  }
}
