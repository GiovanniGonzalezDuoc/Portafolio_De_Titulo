import { Component, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTableModule } from '@angular/material/table';
import { Observable, debounceTime } from 'rxjs';

import { AuthService } from '../../core/auth/auth.service';
import { NotificacionService } from '../../core/services/notificacion.service';
import { BadgeEstado } from '../../shared/components/badge-estado/badge-estado';
import { EstadoVacio } from '../../shared/components/estado-vacio/estado-vacio';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { confirmar } from '../../shared/components/confirm-dialog/confirm-dialog';
import { crearListado } from '../../shared/util/listado';
import { ProveedorForm } from './proveedor-form';
import { Proveedor, ProveedoresService } from './proveedores.service';

@Component({
  selector: 'app-proveedores-lista',
  imports: [
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
    PageHeader,
    BadgeEstado,
    EstadoVacio,
  ],
  templateUrl: './proveedores-lista.html',
})
export class ProveedoresLista {
  private readonly service = inject(ProveedoresService);
  private readonly dialog = inject(MatDialog);
  private readonly noti = inject(NotificacionService);
  private readonly auth = inject(AuthService);

  readonly columnas = ['proveedor', 'contacto', 'lead', 'estado', 'acciones'];
  readonly puedeAdministrar = this.auth.tienePermiso('proveedores.administrar');

  readonly buscar = new FormControl('', { nonNullable: true });
  readonly listado = crearListado<Proveedor>((p) => this.service.lista(p));

  constructor() {
    this.buscar.valueChanges
      .pipe(debounceTime(300), takeUntilDestroyed())
      .subscribe((v) => this.listado.filtrar({ search: v || undefined }));
  }

  paginar(e: PageEvent): void {
    this.listado.irAPagina(e.pageIndex, e.pageSize);
  }

  abrir(proveedor: Proveedor | null): void {
    const ref = this.dialog.open(ProveedorForm, { data: proveedor, width: '640px' });
    ref.afterClosed().subscribe((ok) => ok && this.listado.recargar());
  }

  async cambiarEstado(p: Proveedor): Promise<void> {
    const activar = !p.activo;
    const ok = await confirmar(this.dialog, {
      titulo: activar ? 'Activar proveedor' : 'Desactivar proveedor',
      mensaje: `¿${activar ? 'Activar' : 'Desactivar'} "${p.razon_social}"?`,
      peligro: !activar,
    });
    if (!ok) return;
    const obs: Observable<unknown> = activar ? this.service.activar(p.id) : this.service.eliminar(p.id);
    obs.subscribe(() => {
      this.noti.exito('Estado actualizado.');
      this.listado.recargar();
    });
  }
}
