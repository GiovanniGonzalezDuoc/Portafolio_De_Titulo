import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { ApiService } from '../../core/services/api.service';

export interface ItemCarrito {
  producto: string;
  cantidad: number;
  descuento_monto?: number;
  /** null/undefined → sigue el flag de la venta; true/false lo fuerza por línea. */
  mayorista?: boolean | null;
}

export interface Pago {
  medio: 'EFECTIVO' | 'DEBITO' | 'CREDITO' | 'TRANSFERENCIA';
  /** Monto que cubre el total (lo que se registra). */
  monto: number;
  /** Solo efectivo: billete/monto entregado por el cliente (para el vuelto). No se envía al backend. */
  entregado?: number;
  referencia?: string;
}

export interface CalculoVenta {
  neto: number;
  iva: number;
  exento: number;
  descuento_total: number;
  total: number;
  redondeo: number;
  total_a_cobrar: number;
  requiere_autorizacion_descuento: boolean;
  lineas: {
    producto: string;
    descripcion: string;
    cantidad: string;
    precio_unitario: number;
    descuento_monto: number;
    descuento_pct: string;
    afecto_iva: boolean;
    total_linea: number;
  }[];
}

export interface Venta {
  id: number;
  folio: string;
  caja: string | null;
  vendedor: string;
  estado: string;
  estado_display: string;
  es_mayorista: boolean;
  neto: number;
  iva: number;
  exento: number;
  descuento_total: number;
  total: number;
  redondeo: number;
  total_a_cobrar: number;
  motivo_anulacion: string;
  creado_en: string;
  lineas: { producto: string; descripcion: string; cantidad: string; precio_unitario: number; total_linea: number }[];
  pagos: { medio: string; monto: number; referencia: string }[];
  documento: {
    id: number;
    estado: string;
    estado_display: string;
    folio: number | null;
    url_pdf: string;
  } | null;
}

@Injectable({ providedIn: 'root' })
export class VentasService {
  private readonly api = inject(ApiService);

  lista(params?: Record<string, string | number | undefined>) {
    return this.api.lista<Venta>('ventas', params);
  }
  obtener(id: number): Observable<Venta> {
    return this.api.get<Venta>(`ventas/${id}`);
  }
  calcular(dto: { items: ItemCarrito[]; es_mayorista: boolean; hay_efectivo: boolean }): Observable<CalculoVenta> {
    return this.api.post<CalculoVenta>('ventas/calcular', dto);
  }
  confirmar(dto: {
    items: ItemCarrito[];
    pagos: Pago[];
    es_mayorista: boolean;
    autorizacion?: { username: string; password: string };
  }): Observable<Venta> {
    return this.api.post<Venta>('ventas', dto);
  }
  anular(id: number, motivo: string): Observable<Venta> {
    return this.api.post<Venta>(`ventas/${id}/anular`, { motivo });
  }
  reintentarBoleta(documentoId: number): Observable<unknown> {
    return this.api.post(`boletas/${documentoId}/reintentar`, {});
  }
}
