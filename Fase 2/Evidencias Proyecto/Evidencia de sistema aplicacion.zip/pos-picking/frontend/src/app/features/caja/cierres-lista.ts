import { DatePipe, TitleCasePipe } from '@angular/common';
import { Component, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTableModule } from '@angular/material/table';
import { forkJoin } from 'rxjs';

import { EstadoVacio } from '../../shared/components/estado-vacio/estado-vacio';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { ClpPipe } from '../../shared/pipes/clp.pipe';
import { fechaLocalIso as iso } from '../../shared/util/fecha';
import { crearListado } from '../../shared/util/listado';
import { Caja, CajaService } from './caja.service';
import { CierreCajaDialog } from './cierre-caja-dialog';

@Component({
  selector: 'app-cierres-lista',
  imports: [
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
    PageHeader,
    EstadoVacio,
    ClpPipe,
    DatePipe,
    TitleCasePipe,
  ],
  templateUrl: './cierres-lista.html',
})
export class CierresLista {
  private readonly service = inject(CajaService);
  private readonly dialog = inject(MatDialog);

  readonly columnas = ['codigo', 'usuario', 'cerrada', 'esperado', 'contado', 'diferencia', 'ver'];

  readonly desde = new FormControl('', { nonNullable: true });
  readonly hasta = new FormControl('', { nonNullable: true });

  readonly listado = crearListado<Caja>((p) => this.service.lista(p));

  constructor() {
    this.desde.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.hasta.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.aplicar();
  }

  private aplicar(): void {
    this.listado.filtrar({
      estado: 'CERRADA',
      desde: this.desde.value || undefined,
      hasta: this.hasta.value || undefined,
      ordering: '-cerrada_en',
    });
  }

  rango(preset: 'hoy' | 'ayer' | 'mes' | 'mes_pasado' | 'dias30'): void {
    const hoy = new Date();
    let d: Date;
    let h: Date;
    switch (preset) {
      case 'hoy':
        d = h = hoy;
        break;
      case 'ayer':
        d = h = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate() - 1);
        break;
      case 'mes':
        d = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
        h = hoy;
        break;
      case 'mes_pasado':
        d = new Date(hoy.getFullYear(), hoy.getMonth() - 1, 1);
        h = new Date(hoy.getFullYear(), hoy.getMonth(), 0);
        break;
      case 'dias30':
        d = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate() - 29);
        h = hoy;
        break;
    }
    this.desde.setValue(iso(d), { emitEvent: false });
    this.hasta.setValue(iso(h));
  }

  limpiarFechas(): void {
    this.desde.setValue('', { emitEvent: false });
    this.hasta.setValue('');
  }

  paginar(e: PageEvent): void {
    this.listado.irAPagina(e.pageIndex, e.pageSize);
  }

  abrir(c: Caja): void {
    forkJoin({
      arqueo: this.service.arqueo(c.id),
      movimientos: this.service.movimientos(c.id),
    }).subscribe(({ arqueo, movimientos }) => {
      this.dialog.open(CierreCajaDialog, {
        data: { arqueo, movimientos },
        width: '560px',
        maxWidth: '95vw',
      });
    });
  }
}
