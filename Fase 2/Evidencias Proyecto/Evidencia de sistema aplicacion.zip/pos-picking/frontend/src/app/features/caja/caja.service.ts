import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { ParamsListado } from '../../core/models/api.models';
import { ApiService } from '../../core/services/api.service';

export interface Caja {
  id: number;
  codigo: string;
  usuario: string;
  estado: 'ABIERTA' | 'CERRADA';
  estado_display: string;
  monto_inicial: number;
  monto_esperado: number | null;
  monto_contado: number | null;
  diferencia: number | null;
  observacion_cierre: string;
  abierta_en: string;
  cerrada_en: string | null;
}

export interface VentasPorMedio {
  medio: string;
  total: number;
  cantidad: number;
}

export interface ResumenVentasCaja {
  cantidad: number;
  total: number;
  anuladas: number;
  por_medio: VentasPorMedio[];
}

export interface Arqueo {
  codigo: string;
  estado: string;
  usuario: string;
  abierta_en: string | null;
  cerrada_en: string | null;
  monto_inicial: number;
  /** Total vendido en el turno, todos los medios de pago. */
  ventas_total: number;
  ingresos: number;
  egresos: number;
  saldo_esperado: number;
  monto_contado: number | null;
  diferencia: number | null;
  observacion_cierre: string;
  ventas: ResumenVentasCaja;
}

export interface MovimientoCaja {
  id: number;
  tipo: string;
  tipo_display: string;
  monto: number;
  motivo: string;
  venta_folio: string | null;
  usuario: string;
  creado_en: string;
}

@Injectable({ providedIn: 'root' })
export class CajaService {
  private readonly api = inject(ApiService);

  lista(params?: ParamsListado) {
    return this.api.lista<Caja>('cajas', params);
  }
  miCaja(): Observable<Caja> {
    return this.api.get<Caja>('cajas/mi-caja');
  }
  abrir(monto_inicial: number): Observable<Caja> {
    return this.api.post<Caja>('cajas/abrir', { monto_inicial });
  }
  cerrar(id: number, monto_contado: number, observacion?: string): Observable<Caja> {
    return this.api.post<Caja>(`cajas/${id}/cerrar`, { monto_contado, observacion });
  }
  ingreso(id: number, monto: number, motivo: string) {
    return this.api.post<MovimientoCaja>(`cajas/${id}/ingreso`, { monto, motivo });
  }
  egreso(id: number, monto: number, motivo: string) {
    return this.api.post<MovimientoCaja>(`cajas/${id}/egreso`, { monto, motivo });
  }
  arqueo(id: number): Observable<Arqueo> {
    return this.api.get<Arqueo>(`cajas/${id}/arqueo`);
  }
  movimientos(id: number): Observable<MovimientoCaja[]> {
    return this.api.get<MovimientoCaja[]>(`cajas/${id}/movimientos`);
  }
}
