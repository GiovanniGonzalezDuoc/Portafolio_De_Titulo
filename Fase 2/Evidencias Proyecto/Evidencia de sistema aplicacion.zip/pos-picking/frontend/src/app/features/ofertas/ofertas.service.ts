import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { ApiService } from '../../core/services/api.service';
import { RecursoService } from '../../core/services/recurso.service';
import {
  Alcance,
  AplicarMasivo,
  CandidatoVencimiento,
  Oferta,
  ResumenMasivo,
} from './ofertas.models';

@Injectable({ providedIn: 'root' })
export class OfertasService extends RecursoService<Oferta> {
  protected readonly path = 'ofertas';
  private readonly apiRef = inject(ApiService);

  /** Productos que vencen dentro de `dias` días (o ya vencidos): candidatos a oferta. */
  candidatosPorVencer(dias: number): Observable<CandidatoVencimiento[]> {
    return this.apiRef.get<CandidatoVencimiento[]>('catalogo/productos/por-vencer', { dias });
  }

  aplicarMasivo(dto: AplicarMasivo): Observable<ResumenMasivo> {
    return this.accionColeccion<ResumenMasivo>('aplicar-masivo', dto);
  }

  quitarMasivo(alcance: Alcance): Observable<{ desactivadas: number }> {
    return this.accionColeccion<{ desactivadas: number }>('quitar-masivo', alcance);
  }

  activar(id: number) {
    return this.accion<Oferta>(id, 'activar');
  }

  desactivar(id: number) {
    return this.accion<Oferta>(id, 'desactivar');
  }
}
