import { Component, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Observable, debounceTime } from 'rxjs';

import { AuthService } from '../../core/auth/auth.service';
import { NotificacionService } from '../../core/services/notificacion.service';
import { BadgeEstado } from '../../shared/components/badge-estado/badge-estado';
import { EstadoVacio } from '../../shared/components/estado-vacio/estado-vacio';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { confirmar } from '../../shared/components/confirm-dialog/confirm-dialog';
import {
  ToggleAcciones,
  VistaAcciones,
} from '../../shared/components/toggle-acciones/toggle-acciones';
import { verImagen } from '../../shared/components/visor-imagen/visor-imagen';
import { ClpPipe } from '../../shared/pipes/clp.pipe';
import { crearListado } from '../../shared/util/listado';
import { CargaMasivaDialog } from './carga-masiva-dialog';
import { Producto } from './catalogo.models';
import { CategoriasService, MarcasService, ProductosService } from './catalogo.service';
import { ProductoForm } from './producto-form';

@Component({
  selector: 'app-productos-lista',
  imports: [
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatProgressBarModule,
    MatTooltipModule,
    PageHeader,
    BadgeEstado,
    EstadoVacio,
    ToggleAcciones,
    ClpPipe,
  ],
  templateUrl: './productos-lista.html',
})
export class ProductosLista {
  private readonly service = inject(ProductosService);
  private readonly categoriasService = inject(CategoriasService);
  private readonly marcasService = inject(MarcasService);
  private readonly dialog = inject(MatDialog);
  private readonly noti = inject(NotificacionService);
  private readonly auth = inject(AuthService);

  readonly columnas = ['producto', 'marca', 'categoria', 'stock', 'precio', 'estado', 'acciones'];
  readonly puedeAdministrar = this.auth.tienePermiso('catalogo.administrar');
  readonly vistaAcciones = signal<VistaAcciones>('menu');

  readonly buscar = new FormControl('', { nonNullable: true });
  readonly filtroCategoria = new FormControl('', { nonNullable: true });
  readonly filtroMarca = new FormControl('', { nonNullable: true });
  readonly filtroActivo = new FormControl('', { nonNullable: true });

  readonly categorias = signal<string[]>([]);
  readonly marcas = signal<string[]>([]);

  readonly listado = crearListado<Producto>((p) => this.service.lista(p));

  constructor() {
    this.cargarMaestras();

    this.buscar.valueChanges.pipe(debounceTime(300), takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.filtroCategoria.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.filtroMarca.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.filtroActivo.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
  }

  private cargarMaestras(): void {
    this.categoriasService
      .lista({ page_size: 200, ordering: 'nombre' })
      .subscribe((p) => this.categorias.set(p.resultados.map((c) => c.nombre)));
    this.marcasService
      .lista({ page_size: 200, ordering: 'nombre' })
      .subscribe((p) => this.marcas.set(p.resultados.map((m) => m.nombre)));
  }

  private aplicar(): void {
    this.listado.filtrar({
      search: this.buscar.value || undefined,
      categoria: this.filtroCategoria.value || undefined,
      marca: this.filtroMarca.value || undefined,
      activo: this.filtroActivo.value || undefined,
    });
  }

  paginar(e: PageEvent): void {
    this.listado.irAPagina(e.pageIndex, e.pageSize);
  }

  verFoto(p: Producto, ev: Event): void {
    ev.stopPropagation();
    if (p.imagen) verImagen(this.dialog, { url: p.imagen, titulo: `${p.nombre} (${p.sku})` });
  }

  abrir(producto: Producto | null): void {
    const ref = this.dialog.open(ProductoForm, {
      data: { producto, categorias: this.categorias(), marcas: this.marcas() },
      width: '760px',
    });
    ref.afterClosed().subscribe((r: 'guardado' | 'maestras' | undefined) => {
      if (r === 'guardado') this.listado.recargar();
      if (r) this.cargarMaestras(); // se creó categoría/marca desde la ficha
    });
  }

  abrirCargaMasiva(): void {
    const ref = this.dialog.open(CargaMasivaDialog, { width: '640px', maxWidth: '95vw' });
    ref.afterClosed().subscribe((huboCreados: boolean | undefined) => {
      if (huboCreados) {
        this.listado.recargar();
        this.cargarMaestras();
      }
    });
  }

  async cambiarEstado(p: Producto): Promise<void> {
    const activar = !p.activo;
    const ok = await confirmar(this.dialog, {
      titulo: activar ? 'Activar producto' : 'Desactivar producto',
      mensaje: `¿${activar ? 'Activar' : 'Desactivar'} "${p.nombre}"?`,
      peligro: !activar,
    });
    if (!ok) return;
    const obs: Observable<unknown> = activar
      ? this.service.activar(p.id)
      : this.service.desactivar(p.id);
    obs.subscribe(() => {
      this.noti.exito('Estado actualizado.');
      this.listado.recargar();
    });
  }

  /**
   * Borrado definitivo. El backend solo lo permite si el producto no tiene
   * ventas, compras, movimientos ni stock; si no, responde 409 y el
   * interceptor muestra el motivo (hay que desactivarlo).
   */
  async eliminar(p: Producto): Promise<void> {
    const ok = await confirmar(this.dialog, {
      titulo: 'Eliminar producto',
      mensaje:
        `¿Eliminar "${p.nombre}" de forma permanente? Solo se puede si nunca ` +
        `se vendió, compró ni movió. Si tiene historial, desactívalo en su lugar.`,
      peligro: true,
    });
    if (!ok) return;
    this.service.eliminarDefinitivo(p.id).subscribe(() => {
      this.noti.exito('Producto eliminado.');
      this.listado.recargar();
    });
  }
}
