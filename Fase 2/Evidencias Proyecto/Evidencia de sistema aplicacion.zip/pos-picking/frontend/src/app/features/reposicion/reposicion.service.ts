import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { ParamsListado } from '../../core/models/api.models';
import { ApiService } from '../../core/services/api.service';

export type EstadoRecomendacion = 'SUGERIDA' | 'APROBADA' | 'DESCARTADA' | 'ORDENADA';

export interface RecomendacionReposicion {
  id: number;
  producto: string;
  producto_nombre: string;
  proveedor: string | null;
  stock_actual: string;
  stock_transito: string;
  demanda_estimada: string;
  desviacion_demanda: string;
  lead_time_semanas: string;
  stock_seguridad: string;
  punto_pedido: string;
  cantidad_recomendada: string;
  motivo: string;
  inputs: Record<string, unknown>;
  formula_version: string;
  estado: EstadoRecomendacion;
  estado_display: string;
  orden_compra: number | null;
  generado_en: string;
}

export interface ParametroReposicion {
  nivel_servicio_z: string;
  horizonte_semanas: number;
  periodo_revision_semanas: string;
  formula_version: string;
}

export interface ResumenGeneracion {
  generadas: number;
  con_compra_sugerida: number;
  sin_datos_suficientes: number;
  sin_proveedor: number;
  fecha: string;
}

export interface OrdenGenerada {
  id: number;
  numero?: string;
}

@Injectable({ providedIn: 'root' })
export class ReposicionService {
  private readonly api = inject(ApiService);

  recomendaciones(params?: ParamsListado) {
    return this.api.lista<RecomendacionReposicion>('reposicion/recomendaciones', params);
  }

  /**
   * `minimoSemanas` reemplaza puntualmente el mínimo de RF-K8 solo para esta
   * tanda — para demostrar el mecanismo con datos reales escasos sin tocar
   * la configuración general.
   */
  generar(minimoSemanas?: number): Observable<ResumenGeneracion> {
    return this.api.post<ResumenGeneracion>('reposicion/recomendaciones/generar', {
      minimo_semanas: minimoSemanas || undefined,
    });
  }

  aprobar(id: number): Observable<RecomendacionReposicion> {
    return this.api.post<RecomendacionReposicion>(`reposicion/recomendaciones/${id}/aprobar`, {});
  }

  descartar(id: number): Observable<RecomendacionReposicion> {
    return this.api.post<RecomendacionReposicion>(`reposicion/recomendaciones/${id}/descartar`, {});
  }

  generarOrden(ids: number[]): Observable<OrdenGenerada> {
    return this.api.post<OrdenGenerada>('reposicion/recomendaciones/generar-orden', { ids });
  }

  parametros(): Observable<ParametroReposicion> {
    return this.api.get<ParametroReposicion>('reposicion/parametros');
  }

  guardarParametros(dto: Record<string, number>): Observable<ParametroReposicion> {
    return this.api.patch<ParametroReposicion>('reposicion/parametros/1', dto);
  }
}
