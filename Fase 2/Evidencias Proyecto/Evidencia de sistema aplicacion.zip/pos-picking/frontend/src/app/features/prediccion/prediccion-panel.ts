import { DatePipe, DecimalPipe } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { debounceTime } from 'rxjs';

import { AuthService } from '../../core/auth/auth.service';
import { NotificacionService } from '../../core/services/notificacion.service';
import { BadgeEstado } from '../../shared/components/badge-estado/badge-estado';
import { EstadoVacio } from '../../shared/components/estado-vacio/estado-vacio';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { crearListado } from '../../shared/util/listado';
import { ModeloPrediccion, PrediccionDemanda, PrediccionService } from './prediccion.service';

@Component({
  selector: 'app-prediccion-panel',
  imports: [
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatChipsModule,
    MatProgressBarModule,
    MatTooltipModule,
    PageHeader,
    BadgeEstado,
    EstadoVacio,
    DatePipe,
    DecimalPipe,
  ],
  templateUrl: './prediccion-panel.html',
})
export class PrediccionPanel {
  private readonly service = inject(PrediccionService);
  private readonly noti = inject(NotificacionService);
  private readonly auth = inject(AuthService);

  readonly puedeEntrenar = this.auth.tienePermiso('prediccion.entrenar');
  readonly horizontes = [1, 2, 4, 8, 12];
  readonly columnas = [
    'producto', 'horizonte', 'demanda', 'desviacion', 'fuente', 'confianza', 'modelo', 'fecha',
  ];

  readonly modeloActivo = signal<ModeloPrediccion | null>(null);
  readonly entrenando = signal(false);
  readonly calculando = signal(false);
  readonly ultimoCalculo = signal<PrediccionDemanda | null>(null);

  readonly buscarSku = new FormControl('', { nonNullable: true });
  readonly filtroFuente = new FormControl('', { nonNullable: true });
  readonly calcSku = new FormControl('', { nonNullable: true });
  readonly calcHorizonte = new FormControl(4, { nonNullable: true });
  /** Prueba: reemplaza el mínimo de RF-K8 solo para este cálculo (vacío = usa la configuración). */
  readonly calcMinimoSemanas = new FormControl<number | null>(null);

  readonly listado = crearListado<PrediccionDemanda>((p) => this.service.demanda(p));

  constructor() {
    this.cargarModelo();
    this.buscarSku.valueChanges
      .pipe(debounceTime(400), takeUntilDestroyed())
      .subscribe(() => this.aplicar());
    this.filtroFuente.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
  }

  private cargarModelo(): void {
    this.service.modelos({ activo: 'true', page_size: 1 }).subscribe((p) => {
      this.modeloActivo.set(p.resultados[0] ?? null);
    });
  }

  private aplicar(): void {
    this.listado.filtrar({
      producto__sku: this.buscarSku.value.trim().toUpperCase() || undefined,
      fuente: this.filtroFuente.value || undefined,
      ordering: '-generado_en',
    });
  }

  paginar(e: PageEvent): void {
    this.listado.irAPagina(e.pageIndex, e.pageSize);
  }

  entrenar(): void {
    this.entrenando.set(true);
    this.service.entrenar().subscribe({
      next: (m) => {
        this.entrenando.set(false);
        this.modeloActivo.set(m);
        this.noti.exito(`Modelo ${m.version} entrenado y activado.`);
        this.listado.recargar();
      },
      error: () => this.entrenando.set(false),
    });
  }

  calcular(): void {
    const sku = this.calcSku.value.trim().toUpperCase();
    if (!sku) return;
    this.calculando.set(true);
    const minimo = this.calcMinimoSemanas.value;
    this.service.calcular(sku, this.calcHorizonte.value, minimo ?? undefined).subscribe({
      next: (pred) => {
        this.calculando.set(false);
        this.ultimoCalculo.set(pred);
        this.noti.exito(
          `Predicción para ${pred.producto}: ${(+pred.demanda_estimada).toFixed(1)} un. ` +
            `(${pred.nivel_confianza_display.toLowerCase()})`,
        );
        this.listado.recargar();
      },
      error: () => this.calculando.set(false),
    });
  }

  /**
   * Extrae solo las métricas numéricas mostrables. El JSON de entrenamiento
   * mezcla strings, números y objetos anidados (`comparativa`); pasar un
   * objeto al pipe `number` reventaba toda la pantalla.
   */
  metricasModelo(m: ModeloPrediccion): { clave: string; valor: number }[] {
    const raw = (m.metricas ?? {}) as Record<string, unknown>;
    const salida: { clave: string; valor: number }[] = [];

    const elegido = raw['algoritmo_elegido'] as string | undefined;
    const comparativa = raw['comparativa'] as Record<string, Record<string, number>> | undefined;
    const delElegido = elegido ? comparativa?.[elegido] : undefined;
    if (delElegido) {
      for (const k of ['mae', 'rmse', 'mape', 'smape']) {
        if (typeof delElegido[k] === 'number') {
          salida.push({ clave: k.toUpperCase(), valor: delElegido[k] });
        }
      }
    }
    for (const k of ['n_train', 'n_test']) {
      if (typeof raw[k] === 'number') {
        salida.push({ clave: k, valor: raw[k] as number });
      }
    }
    // Fallback: si el JSON tuviera métricas planas, se toman las numéricas.
    if (salida.length === 0) {
      for (const [clave, valor] of Object.entries(raw)) {
        if (typeof valor === 'number') salida.push({ clave, valor });
      }
    }
    return salida;
  }
}
