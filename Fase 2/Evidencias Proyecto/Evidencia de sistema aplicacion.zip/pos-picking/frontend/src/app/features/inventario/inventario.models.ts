export interface Stock {
  id: number;
  producto: number;
  producto_sku: string;
  producto_nombre: string;
  producto_marca: string | null;
  ubicacion: number;
  ubicacion_nombre: string;
  ubicacion_tipo: 'SALA' | 'BODEGA';
  cantidad: string;
  actualizado_en: string;
}

export type TipoMovimiento =
  | 'COMPRA' | 'VENTA' | 'DEVOLUCION'
  | 'AJUSTE_POSITIVO' | 'AJUSTE_NEGATIVO' | 'CONTEO'
  | 'TRASPASO_ENTRADA' | 'TRASPASO_SALIDA';

export interface MovimientoInventario {
  id: number;
  producto: number;
  producto_sku: string;
  ubicacion: number;
  ubicacion_nombre: string;
  tipo: TipoMovimiento;
  tipo_display: string;
  cantidad: string;
  stock_antes: string;
  stock_despues: string;
  motivo: string;
  doc_tipo: string | null;
  doc_id: number | null;
  usuario: number;
  usuario_username: string;
  creado_en: string;
}

export interface Ubicacion {
  id: number;
  nombre: string;
  tipo: string;
  es_principal: boolean;
  activo: boolean;
}

export interface ParametroInventario {
  id: number;
  producto: string;
  ubicacion: string;
  stock_minimo: string;
  punto_reposicion: string;
  stock_seguridad: string;
  multiplo_compra: string;
}
