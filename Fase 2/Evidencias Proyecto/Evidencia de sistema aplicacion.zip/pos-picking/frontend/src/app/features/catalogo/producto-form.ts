import { Component, OnDestroy, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MAT_DIALOG_DATA, MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { catchError, debounceTime, map, of, switchMap, tap } from 'rxjs';

import { NotificacionService } from '../../core/services/notificacion.service';
import { EscanerCodigoBarras } from '../../core/util/escaner-codigo-barras';
import { confirmar } from '../../shared/components/confirm-dialog/confirm-dialog';
import { pedirTexto } from '../../shared/components/input-dialog/input-dialog';
import { verImagen } from '../../shared/components/visor-imagen/visor-imagen';
import { aplicarErrorBackend } from '../../shared/util/form-errores';
import { Producto, UNIDADES } from './catalogo.models';
import { CategoriasService, MarcasService, ProductosService } from './catalogo.service';

/** Valor centinela de la opción "➕ crear nueva…" en los desplegables. */
const NUEVA = '__nueva__';

export interface ProductoFormData {
  producto: Producto | null;
  categorias: string[];
  marcas: string[];
}

@Component({
  selector: 'app-producto-form',
  imports: [
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
  ],
  templateUrl: './producto-form.html',
})
export class ProductoForm implements OnDestroy {
  private readonly fb = inject(FormBuilder);
  private readonly service = inject(ProductosService);
  private readonly categoriasSrv = inject(CategoriasService);
  private readonly marcasSrv = inject(MarcasService);
  private readonly noti = inject(NotificacionService);
  private readonly dialog = inject(MatDialog);
  private readonly ref = inject(MatDialogRef<ProductoForm>);
  private readonly escaner = inject(EscanerCodigoBarras);
  readonly data = inject<ProductoFormData>(MAT_DIALOG_DATA);

  readonly unidades = UNIDADES;
  readonly esNuevo = this.data.producto === null;
  readonly guardando = signal(false);
  readonly titulo = computed(() => (this.esNuevo ? 'Nuevo producto' : 'Editar producto'));

  readonly NUEVA = NUEVA;
  readonly categorias = signal<string[]>([...this.data.categorias]);
  readonly marcas = signal<string[]>([...this.data.marcas]);
  /** ¿Se creó alguna categoría/marca? El listado se refresca al cerrar. */
  private maestrasTocadas = false;
  private ultimaCategoria = this.data.producto?.categoria ?? '';
  private ultimaMarca = this.data.producto?.marca ?? '';

  private readonly p = this.data.producto;
  /** Stock que tenía el producto al abrir la ficha (para detectar bajas). */
  readonly stockOriginal = Math.round(this.p?.stock_total ?? 0);

  // ─── Imagen del producto ───────────────────────────────────
  static readonly TAMANO_MAXIMO_IMAGEN = 5 * 1024 * 1024;
  /** URL a mostrar: la guardada, o la vista previa local de lo recién elegido. */
  readonly imagenUrl = signal<string | null>(this.p?.imagen ?? null);
  /** Archivo elegido pero aún no subido (se sube junto con "Guardar"). */
  private imagenPendiente: File | null = null;
  private previewObjetoUrl: string | null = null;
  readonly subiendoImagen = signal(false);
  readonly form = this.fb.nonNullable.group({
    sku: [this.p?.sku ?? '', Validators.required],
    codigo_barras: [this.p?.codigo_barras ?? ''],
    nombre: [this.p?.nombre ?? '', [Validators.required, Validators.minLength(2)]],
    descripcion: [this.p?.descripcion ?? ''],
    categoria: [this.p?.categoria ?? '', Validators.required],
    marca: [this.p?.marca ?? ''],
    unidad_medida: [this.p?.unidad_medida ?? 'UN'],
    precio_venta: [this.p?.precio_venta ?? 0, [Validators.required, Validators.min(0)]],
    precio_mayorista: [this.p?.precio_mayorista ?? null as number | null],
    costo_referencial: [this.p?.costo_referencial ?? 0, Validators.min(0)],
    afecto_iva: [this.p?.afecto_iva ?? true],
    fecha_vencimiento: [this.p?.fecha_vencimiento ?? ''],
    stock: [this.stockOriginal, [Validators.required, Validators.min(0)]],
  });

  constructor() {
    // Lector de código de barras: el código leído entra al campo "Código de
    // barras" venga de donde venga el foco (el lector teclea + Enter, así que
    // hay que quitar el código de donde haya caído).
    this.escaner.codigos$.pipe(takeUntilDestroyed()).subscribe((codigo) => {
      const c = codigo.trim();
      if (!c) return;
      for (const campo of ['sku', 'nombre', 'descripcion', 'codigo_barras'] as const) {
        const ctrl = this.form.controls[campo];
        if (typeof ctrl.value === 'string' && ctrl.value.includes(c)) {
          ctrl.setValue(ctrl.value.split(c).join(''));
        }
      }
      this.form.controls.codigo_barras.setValue(c);
      this.form.controls.codigo_barras.markAsDirty();
      this.noti.info('Código de barras leído.');
    });

    // Aviso de SKU duplicado al momento (no al guardar).
    this.form.controls.sku.valueChanges
      .pipe(
        debounceTime(350),
        map((v) => (v || '').trim().toUpperCase()),
        tap(() => this.limpiarErrorDuplicado()),
        switchMap((sku) =>
          sku ? this.service.porSku(sku).pipe(catchError(() => of(null))) : of(null),
        ),
        takeUntilDestroyed(),
      )
      .subscribe((existente) => {
        if (existente && existente.id !== this.data.producto?.id) {
          this.form.controls.sku.setErrors({
            ...(this.form.controls.sku.errors ?? {}),
            duplicado: true,
          });
          // Sin esto el <mat-error> no se muestra hasta salir del campo.
          this.form.controls.sku.markAsTouched();
        }
      });
  }

  // ─── Alta rápida de categoría / marca ─────────────────────
  categoriaElegida(valor: string): void {
    if (valor === NUEVA) {
      this.form.controls.categoria.setValue(this.ultimaCategoria, { emitEvent: false });
      this.crearMaestra('categoria');
    } else {
      this.ultimaCategoria = valor;
    }
  }

  marcaElegida(valor: string): void {
    if (valor === NUEVA) {
      this.form.controls.marca.setValue(this.ultimaMarca, { emitEvent: false });
      this.crearMaestra('marca');
    } else {
      this.ultimaMarca = valor;
    }
  }

  private async crearMaestra(cual: 'categoria' | 'marca'): Promise<void> {
    const label = cual === 'categoria' ? 'categoría' : 'marca';
    const nombre = (
      await pedirTexto(this.dialog, {
        titulo: `Nueva ${label}`,
        etiqueta: `Nombre de la ${label}`,
        confirmar: 'Crear',
      })
    )?.trim();
    if (!nombre) return;

    const srv = cual === 'categoria' ? this.categoriasSrv : this.marcasSrv;
    srv.crear({ nombre }).subscribe((creada) => {
      const sig = cual === 'categoria' ? this.categorias : this.marcas;
      sig.update((xs) =>
        xs.includes(creada.nombre)
          ? xs
          : [...xs, creada.nombre].sort((a, b) => a.localeCompare(b, 'es')),
      );
      this.form.controls[cual].setValue(creada.nombre);
      if (cual === 'categoria') this.ultimaCategoria = creada.nombre;
      else this.ultimaMarca = creada.nombre;
      this.maestrasTocadas = true;
      this.noti.exito(`${label[0].toUpperCase()}${label.slice(1)} "${creada.nombre}" creada.`);
    });
  }

  /** Cerrar sin guardar: avisa si igual se crearon categorías/marcas. */
  cancelar(): void {
    this.ref.close(this.maestrasTocadas ? 'maestras' : undefined);
  }

  // ─── Imagen del producto ───────────────────────────────────
  verFoto(): void {
    const url = this.imagenUrl();
    if (url) verImagen(this.dialog, { url, titulo: this.form.controls.nombre.value || undefined });
  }

  elegirImagen(input: HTMLInputElement): void {
    const archivo = input.files?.[0] ?? null;
    input.value = ''; // permite elegir el mismo archivo dos veces seguidas
    if (!archivo) return;
    if (!archivo.type.startsWith('image/')) {
      this.noti.error('Elige un archivo de imagen (JPG, PNG…).');
      return;
    }
    if (archivo.size > ProductoForm.TAMANO_MAXIMO_IMAGEN) {
      this.noti.error('La imagen no puede pesar más de 5 MB.');
      return;
    }
    if (this.previewObjetoUrl) URL.revokeObjectURL(this.previewObjetoUrl);
    this.previewObjetoUrl = URL.createObjectURL(archivo);
    this.imagenUrl.set(this.previewObjetoUrl);
    this.imagenPendiente = archivo;
  }

  /** Quita la selección local, o borra la imagen ya guardada si no hay ninguna pendiente. */
  quitarImagen(): void {
    if (this.imagenPendiente) {
      if (this.previewObjetoUrl) URL.revokeObjectURL(this.previewObjetoUrl);
      this.previewObjetoUrl = null;
      this.imagenPendiente = null;
      this.imagenUrl.set(this.p?.imagen ?? null);
      return;
    }
    if (!this.p || !this.imagenUrl()) return;
    this.service.eliminarImagen(this.p.id).subscribe(() => {
      this.imagenUrl.set(null);
      this.noti.exito('Imagen eliminada.');
    });
  }

  ngOnDestroy(): void {
    if (this.previewObjetoUrl) URL.revokeObjectURL(this.previewObjetoUrl);
  }

  private limpiarErrorDuplicado(): void {
    const ctrl = this.form.controls.sku;
    if (!ctrl.hasError('duplicado')) return;
    const errores = { ...ctrl.errors };
    delete errores['duplicado'];
    ctrl.setErrors(Object.keys(errores).length ? errores : null);
  }

  async guardar(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    const stock = Math.max(0, Math.round(v.stock || 0));

    // Bajar el stock desde la ficha también se confirma y queda registrado.
    if (!this.esNuevo && stock < this.stockOriginal) {
      const ok = await confirmar(this.dialog, {
        titulo: 'Confirmar baja de stock',
        mensaje:
          `Vas a dejar el stock de "${v.nombre}" en ${stock} ` +
          `(baja ${this.stockOriginal - stock}). Queda registrado como ajuste con tu usuario.`,
        peligro: true,
        confirmar: 'Ajustar',
      });
      if (!ok) return;
    }

    this.guardando.set(true);
    const dto = {
      ...v,
      stock,
      codigo_barras: v.codigo_barras || null,
      marca: v.marca || null,
      fecha_vencimiento: v.fecha_vencimiento || null,
      precio_mayorista: v.precio_mayorista === null || (v.precio_mayorista as unknown) === '' ? null : Number(v.precio_mayorista),
    };
    const obs = this.esNuevo
      ? this.service.crear(dto)
      : this.service.actualizar(this.data.producto!.id, dto);
    obs.subscribe({
      next: (guardado) => this.subirImagenPendienteYCerrar(guardado.id),
      error: (err) => {
        this.guardando.set(false);
        aplicarErrorBackend(this.form, err);
      },
    });
  }

  /** Tras crear/editar el producto, sube la imagen elegida (si hay) y cierra. */
  private subirImagenPendienteYCerrar(id: number): void {
    const mensaje = this.esNuevo ? 'Producto creado.' : 'Producto actualizado.';
    if (!this.imagenPendiente) {
      this.noti.exito(mensaje);
      this.ref.close('guardado');
      return;
    }
    this.subiendoImagen.set(true);
    this.service.subirImagen(id, this.imagenPendiente).subscribe({
      next: () => {
        this.noti.exito(mensaje);
        this.ref.close('guardado');
      },
      error: () => {
        this.subiendoImagen.set(false);
        this.guardando.set(false);
        this.noti.error(`${mensaje} La imagen no se pudo subir; puedes reintentarlo editando el producto.`);
        this.ref.close('guardado');
      },
    });
  }
}
