import { Component, inject, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

import { NotificacionService } from '../../core/services/notificacion.service';
import { guardarArchivo } from '../../shared/util/descargar';
import { CargaMasivaResultado, ProductosService } from './catalogo.service';

/**
 * Carga masiva de productos: descargar la plantilla, llenarla y volver a
 * subirla. Cada fila se valida por separado — el reporte dice cuántas se
 * crearon y, si algo falló, en qué fila y por qué.
 */
@Component({
  selector: 'app-carga-masiva-dialog',
  imports: [MatDialogModule, MatButtonModule, MatIconModule, MatProgressSpinnerModule],
  templateUrl: './carga-masiva-dialog.html',
  styleUrl: './carga-masiva-dialog.scss',
})
export class CargaMasivaDialog {
  private readonly service = inject(ProductosService);
  private readonly noti = inject(NotificacionService);
  private readonly ref = inject(MatDialogRef<CargaMasivaDialog>);

  readonly descargando = signal(false);
  readonly subiendo = signal(false);
  readonly resultado = signal<CargaMasivaResultado | null>(null);
  private huboCreados = false;

  descargarPlantilla(): void {
    this.descargando.set(true);
    this.service.descargarPlantillaCargaMasiva().subscribe({
      next: ({ blob, nombre }) => {
        this.descargando.set(false);
        guardarArchivo(blob, nombre || 'plantilla_productos.xlsx');
      },
      error: () => this.descargando.set(false),
    });
  }

  elegirArchivo(input: HTMLInputElement): void {
    const archivo = input.files?.[0] ?? null;
    input.value = '';
    if (!archivo) return;
    this.resultado.set(null);
    this.subiendo.set(true);
    this.service.cargaMasiva(archivo).subscribe({
      next: (r) => {
        this.subiendo.set(false);
        this.resultado.set(r);
        if (r.creados > 0) {
          this.huboCreados = true;
          this.noti.exito(`${r.creados} producto(s) creado(s).`);
        }
        if (r.con_error.length > 0) {
          this.noti.error(`${r.con_error.length} fila(s) con error; revisa el detalle.`);
        }
      },
      error: () => this.subiendo.set(false),
    });
  }

  cerrar(): void {
    this.ref.close(this.huboCreados);
  }

  /** Primer mensaje de error de una fila, para mostrarlo en una línea. */
  primerError(errores: Record<string, string[]>): string {
    const primero = Object.values(errores)[0]?.[0];
    return primero ?? 'Error desconocido.';
  }
}
