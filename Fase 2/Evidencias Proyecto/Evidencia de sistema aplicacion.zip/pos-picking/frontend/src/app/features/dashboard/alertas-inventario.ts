import { Component, computed, input } from '@angular/core';
import { RouterLink } from '@angular/router';

import { DatosBajaRotacion, DatosQuiebre } from './dashboard.service';

type Severidad = 'critica' | 'alta' | 'atencion';

interface FilaAlerta {
  titulo: string;
  detalle: string;
  severidad: Severidad;
  ruta: string;
}

const ETIQUETA: Record<Severidad, string> = { critica: 'Crítica', alta: 'Alta', atencion: 'Atención' };
const MAX_ALERTAS = 5;

/** Máximo 5 incidencias prioritarias, combinando quiebre inminente (IA) y
 * candidatos a oferta por baja rotación, con 3 niveles de severidad. */
@Component({
  selector: 'app-alertas-inventario',
  imports: [RouterLink],
  templateUrl: './alertas-inventario.html',
  styleUrl: './alertas-inventario.scss',
})
export class AlertasInventario {
  readonly quiebre = input.required<DatosQuiebre[]>();
  readonly bajaRotacion = input.required<DatosBajaRotacion[]>();

  readonly etiqueta = ETIQUETA;

  readonly filas = computed<FilaAlerta[]>(() => {
    const deQuiebre = this.quiebre().map((q) => {
      const severidad: Severidad = +q.stock_actual <= 0 ? 'critica' : q.dias_restantes <= 2 ? 'alta' : 'atencion';
      const detalle =
        +q.stock_actual <= 0 ? 'Sin stock' : `Stock para ${Math.max(1, Math.round(q.dias_restantes))} día(s)`;
      return { titulo: q.nombre, detalle, severidad, ruta: '/reposicion', orden: q.dias_restantes };
    });
    const deBajaRotacion = this.bajaRotacion().map((p) => ({
      titulo: p.nombre,
      detalle: 'Rotación bajo objetivo',
      severidad: 'atencion' as Severidad,
      ruta: '/ofertas',
      orden: 999 + +p.stock_actual * -1,
    }));
    return [...deQuiebre, ...deBajaRotacion]
      .sort((a, b) => a.orden - b.orden)
      .slice(0, MAX_ALERTAS)
      .map(({ titulo, detalle, severidad, ruta }) => ({ titulo, detalle, severidad, ruta }));
  });
}
