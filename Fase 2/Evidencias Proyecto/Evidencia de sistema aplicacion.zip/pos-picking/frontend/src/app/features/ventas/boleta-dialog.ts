import { Component, ElementRef, inject, signal, viewChild } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';

import { ApiService } from '../../core/services/api.service';

@Component({
  selector: 'app-boleta-dialog',
  imports: [MatDialogModule, MatButtonModule],
  template: `
    <h2 mat-dialog-title>Boleta</h2>
    <mat-dialog-content>
      @if (html(); as h) {
        <!-- sandbox sin allow-scripts: la boleta nunca ejecuta JS (defensa
             ante XSS aunque el backend fallara al escapar). allow-same-origin
             + allow-modals permiten que el botón Imprimir llame a print(). -->
        <iframe
          #marco
          class="boleta"
          [srcdoc]="h"
          title="Boleta"
          sandbox="allow-same-origin allow-modals"
        ></iframe>
      } @else {
        <p>Cargando documento…</p>
      }
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button mat-dialog-close>Cerrar</button>
      <button mat-flat-button color="primary" (click)="imprimir()" [disabled]="!html()">Imprimir</button>
    </mat-dialog-actions>
  `,
  styles: `.boleta { width: 100%; height: 60vh; border: 1px solid #ddd; border-radius: 4px; }`,
})
export class BoletaDialog {
  private readonly api = inject(ApiService);
  private readonly sanitizer = inject(DomSanitizer);
  private readonly data = inject<{ documentoId: number }>(MAT_DIALOG_DATA);

  readonly marco = viewChild<ElementRef<HTMLIFrameElement>>('marco');
  readonly html = signal<SafeHtml | null>(null);

  constructor() {
    this.api.getTexto(`boletas/${this.data.documentoId}/imprimir`).subscribe((h) => {
      this.html.set(this.sanitizer.bypassSecurityTrustHtml(h));
    });
  }

  imprimir(): void {
    const w = this.marco()?.nativeElement.contentWindow;
    w?.focus();
    w?.print();
  }
}
