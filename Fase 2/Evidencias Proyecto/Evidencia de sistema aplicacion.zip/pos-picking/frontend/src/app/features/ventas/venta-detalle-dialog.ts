import { DatePipe } from '@angular/common';
import { Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';

import { BadgeEstado } from '../../shared/components/badge-estado/badge-estado';
import { CantidadPipe } from '../../shared/pipes/cantidad.pipe';
import { ClpPipe } from '../../shared/pipes/clp.pipe';
import { Venta } from './ventas.service';

/** Detalle de una venta: líneas, totales, pagos y estado de la boleta. */
@Component({
  selector: 'app-venta-detalle-dialog',
  imports: [
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    BadgeEstado,
    ClpPipe,
    CantidadPipe,
    DatePipe,
  ],
  templateUrl: './venta-detalle-dialog.html',
  styleUrl: './venta-detalle-dialog.scss',
})
export class VentaDetalleDialog {
  readonly v = inject<Venta>(MAT_DIALOG_DATA);
}
