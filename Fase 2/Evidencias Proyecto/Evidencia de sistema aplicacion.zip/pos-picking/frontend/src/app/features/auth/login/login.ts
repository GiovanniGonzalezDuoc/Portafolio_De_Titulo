import { HttpErrorResponse } from '@angular/common/http';
import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ActivatedRoute, Router } from '@angular/router';

import { AuthService } from '../../../core/auth/auth.service';
import { ErrorApi } from '../../../core/models/api.models';

@Component({
  selector: 'app-login',
  imports: [
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
  ],
  templateUrl: './login.html',
  styleUrl: './login.scss',
})
export class Login {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly ruta = inject(ActivatedRoute);

  readonly enviando = signal(false);
  readonly error = signal<string | null>(
    this.ruta.snapshot.queryParamMap.get('sinacceso')
      ? 'Tu cuenta no tiene acceso a ninguna sección. Contacta al administrador.'
      : null,
  );
  readonly ocultarClave = signal(true);

  readonly form = this.fb.nonNullable.group({
    username: ['', Validators.required],
    password: ['', Validators.required],
  });

  enviar(): void {
    if (this.form.invalid || this.enviando()) {
      this.form.markAllAsTouched();
      return;
    }
    this.enviando.set(true);
    this.error.set(null);

    this.auth.login(this.form.getRawValue()).subscribe({
      next: () => {
        const redir = this.ruta.snapshot.queryParamMap.get('redir') || '/';
        this.router.navigateByUrl(redir);
      },
      error: (err: unknown) => {
        this.enviando.set(false);
        this.error.set(this.mensajeError(err));
      },
    });
  }

  private mensajeError(err: unknown): string {
    if (err instanceof HttpErrorResponse) {
      const codigo = (err.error as ErrorApi | undefined)?.error?.codigo;
      if (codigo === 'cuenta_bloqueada') {
        return 'Cuenta bloqueada temporalmente por intentos fallidos. Intenta más tarde.';
      }
      if (err.status === 0) {
        return 'No se pudo conectar con el servidor.';
      }
    }
    return 'Usuario o contraseña incorrectos.';
  }
}
