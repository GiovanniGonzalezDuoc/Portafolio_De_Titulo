import { Component, computed, effect, inject, signal } from '@angular/core';

import { AuthService } from '../../core/auth/auth.service';
import { NotificacionService } from '../../core/services/notificacion.service';
import { MetricCard } from '../../shared/components/metric-card/metric-card';
import { MiniBars, PuntoBarra } from '../../shared/components/mini-bars/mini-bars';
import { RankBar } from '../../shared/components/rank-bar/rank-bar';
import { RingChart, SegmentoAnillo } from '../../shared/components/ring-chart/ring-chart';
import { RiskScale } from '../../shared/components/risk-scale/risk-scale';
import { TargetBar } from '../../shared/components/target-bar/target-bar';
import { PuntoTendencia, TrendChart } from '../../shared/components/trend-chart/trend-chart';
import { guardarArchivo } from '../../shared/util/descargar';
import { fechaLocalIso } from '../../shared/util/fecha';
import { AlertasInventario } from './alertas-inventario';
import {
  DashboardService,
  FilaRentabilidad,
  OperacionInventario,
  VentasAnalitica,
} from './dashboard.service';
import { RangoFechas, RangoFechasSelector } from './rango-fechas-selector';
import { TablaRendimiento } from './tabla-rendimiento';

const DIAS_SEMANA = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
const META_MARGEN_PCT = 30;

/**
 * Dashboard reconstruido desde cero según especificación exacta del
 * cliente (ver Contexto/dashboard_pos_picking_profesional.html): dark mode
 * fijo, 6 KPIs, evolución de ventas vs. período anterior, precisión de
 * recepción (equivalente real a "picking" en un negocio de mostrador, no
 * de despacho de pedidos), pedidos por día, margen vs. meta, quiebre de
 * stock, recuperación de productos protagonista, alertas y top rendimiento.
 */
@Component({
  selector: 'app-dashboard-home',
  imports: [
    RangoFechasSelector,
    MetricCard,
    TrendChart,
    RingChart,
    MiniBars,
    TargetBar,
    RiskScale,
    RankBar,
    AlertasInventario,
    TablaRendimiento,
  ],
  templateUrl: './dashboard-home.html',
  styleUrl: './dashboard-home.scss',
})
export class DashboardHome {
  private readonly auth = inject(AuthService);
  private readonly service = inject(DashboardService);
  private readonly noti = inject(NotificacionService);

  readonly usuario = this.auth.usuario;
  readonly puedeVerCompleto = this.auth.tienePermiso('dashboard.ver_completo');

  readonly desde = signal(fechaLocalIso(new Date()));
  readonly hasta = signal(fechaLocalIso(new Date()));
  readonly exportando = signal(false);

  readonly cargando = signal(true);
  readonly ventas = signal<VentasAnalitica | null>(null);
  readonly operacion = signal<OperacionInventario | null>(null);
  readonly rentabilidad = signal<FilaRentabilidad[]>([]);

  private readonly fmtClp = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 });
  private readonly fmtNum = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 0 });
  readonly formatoClp = (v: number): string => this.fmtClp.format(v);
  readonly formatoNum = (v: number): string => this.fmtNum.format(v);
  readonly formatoPct = (v: number): string => `${v.toFixed(1)}%`;

  readonly tendenciaLinea = computed<PuntoTendencia[]>(
    () => this.ventas()?.tendencia.map((p) => ({ periodo: p.periodo, valor: p.monto })) ?? [],
  );
  readonly esRangoHoy = computed(() => this.desde() === this.hasta());
  readonly tendenciaAnterior = computed(() =>
    this.esRangoHoy() ? [] : (this.ventas()?.tendencia_anterior ?? []),
  );

  readonly barrasPedidos = computed<PuntoBarra[]>(() =>
    (this.ventas()?.ventas_por_dia_semana ?? []).map((n, i) => ({ etiqueta: DIAS_SEMANA[i], valor: n })),
  );

  readonly segmentosPrecision = computed<SegmentoAnillo[]>(() => {
    const p = this.ventas()?.precision_recepcion;
    if (!p) return [];
    return [
      { etiqueta: 'Completas', valor: p.precision_pct, color: 'var(--dash-green)' },
      { etiqueta: 'Restante', valor: 100 - p.precision_pct, color: 'var(--dash-border)' },
    ];
  });

  readonly quiebrePct = computed(() => {
    const s = this.operacion()?.salud_inventario;
    if (!s || s.productos_activos === 0) return 0;
    return Math.round((s.productos_sin_stock / s.productos_activos) * 1000) / 10;
  });

  readonly filasRecuperacion = computed(() => {
    const max = 150;
    return this.rentabilidad()
      .filter((f) => f.recuperacion_pct !== null)
      .sort((a, b) => (b.recuperacion_pct ?? 0) - (a.recuperacion_pct ?? 0))
      .slice(0, 12)
      .map((f) => ({
        ...f,
        pct: Math.min(100, ((f.recuperacion_pct ?? 0) / max) * 100),
        color: (f.recuperacion_pct ?? 0) >= 100 ? 'var(--dash-green)' : (f.recuperacion_pct ?? 0) >= 50 ? 'var(--dash-yellow)' : 'var(--dash-red)',
      }));
  });

  readonly metaMargen = META_MARGEN_PCT;

  constructor() {
    effect(() => {
      this.cargar(this.desde(), this.hasta());
    });
  }

  alCambiarRango(r: RangoFechas): void {
    this.desde.set(r.desde);
    this.hasta.set(r.hasta);
  }

  exportar(): void {
    this.exportando.set(true);
    this.service.exportarReporte(this.desde(), this.hasta()).subscribe({
      next: ({ blob, nombre }) => {
        guardarArchivo(blob, nombre || `dashboard_${this.desde()}_a_${this.hasta()}.pdf`);
        this.exportando.set(false);
      },
      error: () => {
        this.noti.error('No se pudo exportar el reporte.');
        this.exportando.set(false);
      },
    });
  }

  private cargar(desde: string, hasta: string): void {
    this.cargando.set(true);
    const completo = this.puedeVerCompleto;
    let pendientes = completo ? 3 : 1;
    const listo = (): void => {
      pendientes -= 1;
      if (pendientes <= 0) this.cargando.set(false);
    };

    this.service.ventasAnalitica(desde, hasta).subscribe({
      next: (r) => {
        this.ventas.set(r);
        listo();
      },
      error: listo,
    });
    if (completo) {
      this.service.operacionInventario().subscribe({
        next: (r) => {
          this.operacion.set(r);
          listo();
        },
        error: listo,
      });
      this.service.rentabilidadAnalitica(desde, hasta, 'recuperacion').subscribe({
        next: (r) => {
          this.rentabilidad.set(r.todas);
          listo();
        },
        error: listo,
      });
    }
  }
}
