import { Component, inject, signal } from '@angular/core';
import { FormArray, FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

import { NotificacionService } from '../../core/services/notificacion.service';
import { OrdenCompra } from './compras.service';
import { ComprasService } from './compras.service';

@Component({
  selector: 'app-recepcion-form',
  imports: [ReactiveFormsModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  templateUrl: './recepcion-form.html',
  styleUrl: './recepcion-form.scss',
})
export class RecepcionForm {
  private readonly fb = inject(FormBuilder);
  private readonly service = inject(ComprasService);
  private readonly noti = inject(NotificacionService);
  private readonly ref = inject(MatDialogRef<RecepcionForm>);
  readonly orden = inject<OrdenCompra>(MAT_DIALOG_DATA);

  readonly guardando = signal(false);
  readonly pendientes = this.orden.lineas.filter((l) => +l.pendiente > 0);

  readonly form = this.fb.nonNullable.group({
    documento_proveedor: [''],
    lineas: this.fb.array(
      this.pendientes.map((l) =>
        this.fb.nonNullable.group({
          linea_orden: [l.id],
          cantidad: [+l.pendiente, [Validators.min(0)]],
          // Precio real al que llega: parte del cotizado en la orden, pero
          // se puede ajustar si cambió (queda registrado en la recepción).
          costo_unitario: [l.costo_unitario, [Validators.min(0)]],
        }),
      ),
    ),
  });

  get lineas(): FormArray {
    return this.form.get('lineas') as FormArray;
  }

  guardar(): void {
    const lineas = this.lineas.getRawValue()
      .filter((l: { cantidad: number }) => l.cantidad > 0)
      .map((l: { linea_orden: number; cantidad: number; costo_unitario: number }) => ({
        linea_orden: l.linea_orden,
        cantidad: l.cantidad,
        costo_unitario: l.costo_unitario,
      }));
    if (!lineas.length) {
      this.noti.error('Indica al menos una cantidad a recibir.');
      return;
    }
    this.guardando.set(true);
    this.service
      .recibir(this.orden.id, {
        documento_proveedor: this.form.controls.documento_proveedor.value || undefined,
        lineas,
      })
      .subscribe({
        next: (r) => {
          this.noti.exito(`Recepción ${r.codigo} registrada.`);
          this.ref.close(true);
        },
        error: () => this.guardando.set(false),
      });
  }
}
