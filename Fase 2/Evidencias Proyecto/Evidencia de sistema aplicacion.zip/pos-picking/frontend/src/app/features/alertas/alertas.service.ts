import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { RecursoService } from '../../core/services/recurso.service';

export interface Alerta {
  id: number;
  tipo: string;
  tipo_display: string;
  severidad: 'INFO' | 'WARNING' | 'CRITICAL';
  estado: 'NUEVA' | 'VISTA' | 'RESUELTA';
  mensaje: string;
  producto: number | null;
  producto_sku: string | null;
  producto_nombre: string | null;
  vista_por: string | null;
  resuelta_por: string | null;
  resuelta_en: string | null;
  creado_en: string;
}

export interface ResumenAlertas {
  abiertas: number;
  nuevas: number;
  por_severidad: Record<string, number>;
  por_tipo: Record<string, number>;
}

@Injectable({ providedIn: 'root' })
export class AlertasService extends RecursoService<Alerta> {
  protected readonly path = 'alertas';

  resumen(): Observable<ResumenAlertas> {
    return this.api.get<ResumenAlertas>('alertas/resumen');
  }
  marcarVista(id: number) {
    return this.accion<Alerta>(id, 'marcar-vista');
  }
  resolver(id: number) {
    return this.accion<Alerta>(id, 'resolver');
  }
  resolverVarias(ids: number[]) {
    return this.accionColeccion<{ resueltas: number }>('resolver-varias', { ids });
  }
}
