import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { ParamsListado } from '../../core/models/api.models';
import { ApiService } from '../../core/services/api.service';

export interface ModeloPrediccion {
  id: number;
  version: string;
  algoritmo: string;
  granularidad: string;
  /** JSON del entrenamiento: mezcla números, strings y objetos anidados. */
  metricas: Record<string, unknown>;
  entrenado_en: string;
  activo: boolean;
  notas: string;
}

export type NivelConfianza = 'NO_ESTABLE' | 'ESTABLE' | 'CONFIABLE';

export interface PrediccionDemanda {
  id: number;
  producto: string;
  modelo: string;
  horizonte_semanas: number;
  demanda_estimada: string;
  desviacion: string;
  fuente: 'REAL' | 'SINTETICO';
  semanas_con_ventas: number;
  nivel_confianza: NivelConfianza;
  nivel_confianza_display: string;
  generado_en: string;
}

@Injectable({ providedIn: 'root' })
export class PrediccionService {
  private readonly api = inject(ApiService);

  modelos(params?: ParamsListado) {
    return this.api.lista<ModeloPrediccion>('prediccion/modelos', params);
  }

  /** Entrena un modelo nuevo y lo sincroniza como activo. */
  entrenar(): Observable<ModeloPrediccion> {
    return this.api.post<ModeloPrediccion>('prediccion/modelos/entrenar', {});
  }

  demanda(params?: ParamsListado) {
    return this.api.lista<PrediccionDemanda>('prediccion/demanda', params);
  }

  /**
   * Calcula (y persiste) la predicción de un producto ahora. `minimoSemanas`
   * reemplaza puntualmente el mínimo de RF-K8 solo para esta consulta — para
   * demostrar el mecanismo con un umbral más bajo sin tocar la configuración.
   */
  calcular(producto: string, horizonte: number, minimoSemanas?: number): Observable<PrediccionDemanda> {
    return this.api.get<PrediccionDemanda>('prediccion/demanda/calcular', {
      producto,
      horizonte,
      minimo_semanas: minimoSemanas || undefined,
    });
  }
}
