import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { RecursoService } from '../../core/services/recurso.service';

export interface LineaOrden {
  id: number;
  producto: string;
  producto_nombre: string;
  cantidad: string;
  cantidad_recibida: string;
  pendiente: string;
  costo_unitario: number;
}

export interface OrdenCompra {
  id: number;
  codigo: string;
  proveedor: string;
  proveedor_rut: string;
  proveedor_email: string;
  estado: string;
  estado_display: string;
  fecha_emision: string | null;
  observacion: string;
  total_estimado: number;
  creada_por: string;
  motivo_anulacion: string;
  creado_en: string;
  actualizado_en: string;
  lineas: LineaOrden[];
}

export interface Recepcion {
  id: number;
  codigo: string;
  orden: string;
  ubicacion: string;
  documento_proveedor: string;
  recibida_por: string;
  creado_en: string;
  lineas: { id: number; producto: string; cantidad: string; costo_unitario: number; movimiento: number }[];
}

export interface CrearOrden {
  proveedor: string;
  observacion?: string;
  lineas: { producto: string; cantidad: number; costo_unitario: number }[];
}

export interface UltimoCosto {
  costo_unitario: number;
  proveedor: string;
  mismo_proveedor: boolean;
  fecha: string;
  orden_codigo: string;
}

export interface PedidoPendiente {
  orden_id: number;
  orden_codigo: string;
  estado: string;
  estado_display: string;
  proveedor: string;
  cantidad_pendiente: string;
}

export interface InfoProductoCompra {
  ultimo_costo: UltimoCosto | null;
  pedido_pendiente: PedidoPendiente | null;
}

@Injectable({ providedIn: 'root' })
export class ComprasService extends RecursoService<OrdenCompra, CrearOrden> {
  protected readonly path = 'compras/ordenes';

  emitir(id: number) {
    return this.accion<OrdenCompra>(id, 'emitir');
  }
  anular(id: number, motivo: string) {
    return this.accion<OrdenCompra>(id, 'anular', { motivo });
  }
  recibir(
    id: number,
    dto: {
      ubicacion?: string;
      documento_proveedor?: string;
      // `costo_unitario` es opcional: el precio real al que llegó, si cambió
      // desde que se cotizó la orden. Sin dato, el backend usa el cotizado.
      lineas: { linea_orden: number; cantidad: number; costo_unitario?: number }[];
    },
  ) {
    return this.accion<Recepcion>(id, 'recibir', dto);
  }
  recepciones(id: number): Observable<Recepcion[]> {
    return this.accionGet<Recepcion[]>(id, 'recepciones');
  }

  /** Último precio de compra del producto y si ya tiene un pedido abierto sin llegar. */
  infoProducto(sku: string, proveedorRut?: string): Observable<InfoProductoCompra> {
    return this.api.get<InfoProductoCompra>(
      `compras/ordenes/info-producto/${encodeURIComponent(sku)}`,
      proveedorRut ? { proveedor: proveedorRut } : undefined,
    );
  }

  /** PDF de la cotización/orden, para descargar y enviar por otro medio. */
  descargarPdf(id: number) {
    return this.api.descargar(`${this.path}/${id}/pdf`);
  }

  /**
   * Envía el PDF por correo al proveedor. `email` reemplaza puntualmente el
   * contacto guardado (sin dato, el backend usa `proveedor.contacto_email`).
   */
  enviarProveedor(id: number, email?: string, mensaje?: string): Observable<{ enviado: boolean; para: string }> {
    return this.accion<{ enviado: boolean; para: string }>(id, 'enviar', { email, mensaje });
  }
}
