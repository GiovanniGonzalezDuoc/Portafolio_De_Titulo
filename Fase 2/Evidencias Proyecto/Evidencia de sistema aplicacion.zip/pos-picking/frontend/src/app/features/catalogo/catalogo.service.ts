import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { ApiService } from '../../core/services/api.service';
import { RecursoService } from '../../core/services/recurso.service';
import { Categoria, Marca, Producto, ProductoEscritura } from './catalogo.models';

@Injectable({ providedIn: 'root' })
export class CategoriasService extends RecursoService<Categoria> {
  protected readonly path = 'catalogo/categorias';
  activar(id: number) {
    return this.accion<Categoria>(id, 'activar');
  }
}

@Injectable({ providedIn: 'root' })
export class MarcasService extends RecursoService<Marca> {
  protected readonly path = 'catalogo/marcas';
  activar(id: number) {
    return this.accion<Marca>(id, 'activar');
  }
}

@Injectable({ providedIn: 'root' })
export class ProductosService extends RecursoService<Producto, ProductoEscritura, ProductoEscritura> {
  protected readonly path = 'catalogo/productos';
  private readonly apiRef = inject(ApiService);

  activar(id: number) {
    return this.accion<Producto>(id, 'activar');
  }

  desactivar(id: number) {
    return this.accion<Producto>(id, 'desactivar');
  }

  /** Borrado definitivo (solo si el producto no tiene ventas/compras/movimientos/stock). */
  eliminarDefinitivo(id: number) {
    return this.eliminar(id);
  }

  /** Búsqueda por código de barras para el POS (el POS maneja el error). */
  porCodigo(codigo: string): Observable<Producto> {
    return this.apiRef.getSilencioso<Producto>(
      `catalogo/productos/por-codigo/${encodeURIComponent(codigo)}`,
    );
  }

  /** Búsqueda por SKU exacto (el POS maneja el error). */
  porSku(sku: string): Observable<Producto> {
    return this.apiRef.getSilencioso<Producto>(
      `catalogo/productos/por-sku/${encodeURIComponent(sku)}`,
    );
  }

  /** Sube (o reemplaza) la foto del producto. */
  subirImagen(id: number, archivo: File): Observable<Producto> {
    const form = new FormData();
    form.append('imagen', archivo);
    return this.apiRef.post<Producto>(`catalogo/productos/${id}/imagen`, form);
  }

  eliminarImagen(id: number): Observable<Producto> {
    return this.apiRef.delete<Producto>(`catalogo/productos/${id}/imagen`);
  }

  descargarPlantillaCargaMasiva(): Observable<{ blob: Blob; nombre: string }> {
    return this.apiRef.descargar('catalogo/productos/plantilla-carga-masiva');
  }

  cargaMasiva(archivo: File): Observable<CargaMasivaResultado> {
    const form = new FormData();
    form.append('archivo', archivo);
    return this.apiRef.post<CargaMasivaResultado>('catalogo/productos/carga-masiva', form);
  }
}

export interface CargaMasivaResultado {
  creados: number;
  total_filas: number;
  con_error: { fila: number; sku: string; errores: Record<string, string[]> }[];
}

