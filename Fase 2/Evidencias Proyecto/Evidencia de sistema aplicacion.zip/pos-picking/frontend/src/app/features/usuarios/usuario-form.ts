import { TitleCasePipe } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';

import { NotificacionService } from '../../core/services/notificacion.service';
import { aplicarErrorBackend } from '../../shared/util/form-errores';
import { Rol, UsuarioListado } from './usuarios.models';
import { UsuariosService } from './usuarios.service';

export interface UsuarioFormData {
  usuario: UsuarioListado | null;
  roles: Rol[];
}

@Component({
  selector: 'app-usuario-form',
  imports: [
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    TitleCasePipe,
  ],
  templateUrl: './usuario-form.html',
})
export class UsuarioForm {
  private readonly fb = inject(FormBuilder);
  private readonly service = inject(UsuariosService);
  private readonly noti = inject(NotificacionService);
  private readonly ref = inject(MatDialogRef<UsuarioForm>);
  readonly data = inject<UsuarioFormData>(MAT_DIALOG_DATA);

  readonly esNuevo = this.data.usuario === null;
  readonly guardando = signal(false);
  readonly titulo = computed(() => (this.esNuevo ? 'Nuevo usuario' : 'Editar usuario'));

  readonly form = this.fb.nonNullable.group({
    username: [{ value: this.data.usuario?.username ?? '', disabled: !this.esNuevo }, Validators.required],
    nombres: [this.data.usuario?.nombres ?? '', Validators.required],
    apellidos: [this.data.usuario?.apellidos ?? '', Validators.required],
    email: [this.data.usuario?.email ?? '', Validators.email],
    rut: [this.data.usuario?.rut ?? ''],
    rol: [this.data.usuario?.rol ?? '', Validators.required],
    password: ['', this.esNuevo ? [Validators.required, Validators.minLength(8)] : []],
  });

  guardar(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.guardando.set(true);
    const v = this.form.getRawValue();

    const obs = this.esNuevo
      ? this.service.crear({
          username: v.username,
          nombres: v.nombres,
          apellidos: v.apellidos,
          email: v.email || undefined,
          rut: v.rut || null,
          rol: v.rol,
          password: v.password,
        })
      : this.service.actualizar(this.data.usuario!.id, {
          nombres: v.nombres,
          apellidos: v.apellidos,
          email: v.email || undefined,
          rut: v.rut || null,
          rol: v.rol,
        });

    obs.subscribe({
      next: () => {
        this.noti.exito(this.esNuevo ? 'Usuario creado.' : 'Usuario actualizado.');
        this.ref.close(true);
      },
      error: (err) => {
        this.guardando.set(false);
        aplicarErrorBackend(this.form, err);
      },
    });
  }
}
