import { DatePipe } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { debounceTime } from 'rxjs';

import { AuthService } from '../../core/auth/auth.service';
import { NotificacionService } from '../../core/services/notificacion.service';
import { BadgeEstado } from '../../shared/components/badge-estado/badge-estado';
import { confirmar } from '../../shared/components/confirm-dialog/confirm-dialog';
import { EstadoVacio } from '../../shared/components/estado-vacio/estado-vacio';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { ClpPipe } from '../../shared/pipes/clp.pipe';
import { crearListado } from '../../shared/util/listado';
import { OfertaMasiva } from './oferta-masiva';
import { CandidatoVencimiento, Oferta } from './ofertas.models';
import { OfertasService } from './ofertas.service';

@Component({
  selector: 'app-ofertas-lista',
  imports: [
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatCheckboxModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatProgressBarModule,
    MatSelectModule,
    MatTabsModule,
    PageHeader,
    BadgeEstado,
    EstadoVacio,
    ClpPipe,
    DatePipe,
  ],
  templateUrl: './ofertas-lista.html',
})
export class OfertasLista {
  private readonly service = inject(OfertasService);
  private readonly noti = inject(NotificacionService);
  private readonly dialog = inject(MatDialog);
  private readonly auth = inject(AuthService);

  readonly puedeAdministrar = this.auth.tienePermiso('ofertas.administrar');
  readonly columnas = computed(() =>
    this.puedeAdministrar
      ? ['producto', 'precios', 'descuento', 'vigencia', 'estado', 'acciones']
      : ['producto', 'precios', 'descuento', 'vigencia', 'estado'],
  );

  readonly buscar = new FormControl('', { nonNullable: true });
  readonly soloVigentes = new FormControl(true, { nonNullable: true });

  readonly listado = crearListado<Oferta>((p) => this.service.lista(p));

  // ─── Candidatos a oferta (productos por vencer) ───────────
  readonly dias = new FormControl(15, { nonNullable: true });
  readonly opcionesDias = [7, 15, 30, 60];
  readonly candidatos = signal<CandidatoVencimiento[]>([]);
  readonly cargandoCandidatos = signal(false);
  readonly colCandidatos = computed(() =>
    this.puedeAdministrar
      ? ['producto', 'vencimiento', 'precio', 'estado', 'accion']
      : ['producto', 'vencimiento', 'precio', 'estado'],
  );
  readonly skusSinOferta = computed(() =>
    this.candidatos().filter((c) => !c.tiene_oferta).map((c) => c.sku),
  );
  private cargados = false;

  constructor() {
    this.buscar.valueChanges
      .pipe(debounceTime(350), takeUntilDestroyed())
      .subscribe(() => this.aplicar());
    this.soloVigentes.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.dias.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => {
      if (this.cargados) this.cargarCandidatos();
    });
  }

  /** Se llama al abrir la pestaña de candidatos (carga perezosa). */
  onTab(indice: number): void {
    if (indice === 1 && !this.cargados) {
      this.cargados = true;
      this.cargarCandidatos();
    }
  }

  private cargarCandidatos(): void {
    this.cargandoCandidatos.set(true);
    this.service.candidatosPorVencer(this.dias.value).subscribe({
      next: (lista) => {
        this.candidatos.set(lista);
        this.cargandoCandidatos.set(false);
      },
      error: () => this.cargandoCandidatos.set(false),
    });
  }

  etiquetaVencimiento(c: CandidatoVencimiento): string {
    if (c.vencido) return `Vencido hace ${Math.abs(c.dias_para_vencer)} d`;
    if (c.dias_para_vencer === 0) return 'Vence hoy';
    return `Vence en ${c.dias_para_vencer} d`;
  }

  claseVencimiento(c: CandidatoVencimiento): string {
    if (c.vencido || c.dias_para_vencer <= 7) return 'peligro';
    if (c.dias_para_vencer <= 15) return 'warn';
    return 'info';
  }

  crearOfertaCandidatos(): void {
    this.abrirOfertaMasiva(this.skusSinOferta());
  }

  crearOfertaUno(c: CandidatoVencimiento): void {
    this.abrirOfertaMasiva([c.sku]);
  }

  private abrirOfertaMasiva(skus: string[]): void {
    if (!skus.length) return;
    this.dialog
      .open(OfertaMasiva, { width: '520px', data: { skus } })
      .afterClosed()
      .subscribe((r) => {
        if (r) {
          this.cargarCandidatos();
          this.listado.recargar();
        }
      });
  }

  private aplicar(): void {
    this.listado.filtrar({
      search: this.buscar.value.trim() || undefined,
      vigente: this.soloVigentes.value ? 'true' : undefined,
      ordering: '-creado_en',
    });
  }

  paginar(e: PageEvent): void {
    this.listado.irAPagina(e.pageIndex, e.pageSize);
  }

  estadoDe(o: Oferta): string {
    if (o.vigente) return 'ok';
    if (!o.activa) return 'neutro';
    const ahora = Date.now();
    if (new Date(o.inicia_en).getTime() > ahora) return 'info'; // programada
    return 'peligro'; // vencida
  }

  etiquetaEstado(o: Oferta): string {
    if (o.vigente) return 'Vigente';
    if (!o.activa) return 'Inactiva';
    if (new Date(o.inicia_en).getTime() > Date.now()) return 'Programada';
    return 'Vencida';
  }

  async crear(): Promise<void> {
    const r = await this.dialog.open(OfertaMasiva, { width: '520px' }).afterClosed().toPromise();
    if (r) this.listado.recargar();
  }

  async quitarPorAlcance(): Promise<void> {
    const cat = await import('../../shared/components/input-dialog/input-dialog').then((m) =>
      m.pedirTexto(this.dialog, {
        titulo: 'Quitar ofertas de una categoría',
        etiqueta: 'Nombre de la categoría (vacío = todas las ofertas)',
        requerido: false,
      }),
    );
    if (cat === null) return;
    const ok = await confirmar(this.dialog, {
      titulo: 'Quitar ofertas',
      mensaje: cat
        ? `Se desactivarán todas las ofertas de la categoría «${cat}». ¿Continuar?`
        : 'Se desactivarán TODAS las ofertas activas. ¿Continuar?',
      peligro: true,
    });
    if (!ok) return;
    this.service
      .quitarMasivo(cat ? { categoria: cat } : { todos: true })
      .subscribe((res) => {
        this.noti.exito(`${res.desactivadas} ofertas desactivadas.`);
        this.listado.recargar();
      });
  }

  activar(o: Oferta): void {
    this.service.activar(o.id).subscribe(() => {
      this.noti.exito('Oferta activada.');
      this.listado.recargar();
    });
  }

  desactivar(o: Oferta): void {
    this.service.desactivar(o.id).subscribe(() => {
      this.noti.info('Oferta desactivada.');
      this.listado.recargar();
    });
  }

  async eliminar(o: Oferta): Promise<void> {
    const ok = await confirmar(this.dialog, {
      titulo: 'Eliminar oferta',
      mensaje: `Eliminar definitivamente la oferta de ${o.producto_nombre}.`,
      peligro: true,
    });
    if (!ok) return;
    this.service.eliminar(o.id).subscribe(() => {
      this.noti.exito('Oferta eliminada.');
      this.listado.recargar();
    });
  }
}
