import { Component, inject, input, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTableModule } from '@angular/material/table';
import { FormControl } from '@angular/forms';
import { Observable, debounceTime } from 'rxjs';

import { Pagina, ParamsListado } from '../../../core/models/api.models';
import { NotificacionService } from '../../../core/services/notificacion.service';
import { BadgeEstado } from '../../../shared/components/badge-estado/badge-estado';
import { EstadoVacio } from '../../../shared/components/estado-vacio/estado-vacio';
import { PageHeader } from '../../../shared/components/page-header/page-header';
import { confirmar } from '../../../shared/components/confirm-dialog/confirm-dialog';
import { aplicarErrorBackend } from '../../../shared/util/form-errores';
import { crearListado } from '../../../shared/util/listado';

interface Simple {
  id: number;
  nombre: string;
  descripcion: string;
  activo: boolean;
}

export interface MaestraConfig {
  titulo: string;
  subtitulo: string;
  singular: string;
  icono: string;
  puedeAdministrar: boolean;
  cargar: (p: ParamsListado) => Observable<Pagina<Simple>>;
  crear: (dto: Partial<Simple>) => Observable<Simple>;
  actualizar: (id: number, dto: Partial<Simple>) => Observable<Simple>;
  desactivar: (id: number) => Observable<unknown>;
  activar: (id: number) => Observable<unknown>;
}

@Component({
  selector: 'app-maestra-simple',
  imports: [
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
    PageHeader,
    BadgeEstado,
    EstadoVacio,
  ],
  templateUrl: './maestra-simple.html',
})
export class MaestraSimple {
  readonly config = input.required<MaestraConfig>();

  private readonly fb = inject(FormBuilder);
  private readonly dialog = inject(MatDialog);
  private readonly noti = inject(NotificacionService);

  readonly columnas = ['nombre', 'estado', 'acciones'];
  readonly buscar = new FormControl('', { nonNullable: true });
  readonly editando = signal<Simple | null>(null);
  readonly mostrarForm = signal(false);
  readonly guardando = signal(false);

  readonly form = this.fb.nonNullable.group({
    nombre: ['', Validators.required],
    descripcion: [''],
  });

  readonly listado = crearListado<Simple>((p) => this.config().cargar(p));

  constructor() {
    this.buscar.valueChanges
      .pipe(debounceTime(300), takeUntilDestroyed())
      .subscribe((v) => this.listado.filtrar({ search: v || undefined }));
  }

  paginar(e: PageEvent): void {
    this.listado.irAPagina(e.pageIndex, e.pageSize);
  }

  nuevo(): void {
    this.editando.set(null);
    this.form.reset({ nombre: '', descripcion: '' });
    this.mostrarForm.set(true);
  }

  editar(item: Simple): void {
    this.editando.set(item);
    this.form.reset({ nombre: item.nombre, descripcion: item.descripcion });
    this.mostrarForm.set(true);
  }

  cancelar(): void {
    this.mostrarForm.set(false);
  }

  guardar(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.guardando.set(true);
    const dto = this.form.getRawValue();
    const actual = this.editando();
    const obs = actual
      ? this.config().actualizar(actual.id, dto)
      : this.config().crear(dto);
    obs.subscribe({
      next: () => {
        this.noti.exito(`${this.config().singular} guardada.`);
        this.guardando.set(false);
        this.mostrarForm.set(false);
        this.listado.recargar();
      },
      error: (err) => {
        this.guardando.set(false);
        aplicarErrorBackend(this.form, err);
      },
    });
  }

  async cambiarEstado(item: Simple): Promise<void> {
    const activar = !item.activo;
    const ok = await confirmar(this.dialog, {
      titulo: activar ? `Activar ${this.config().singular}` : `Desactivar ${this.config().singular}`,
      mensaje: `¿${activar ? 'Activar' : 'Desactivar'} "${item.nombre}"?`,
      peligro: !activar,
    });
    if (!ok) return;
    const obs = activar ? this.config().activar(item.id) : this.config().desactivar(item.id);
    obs.subscribe(() => {
      this.noti.exito('Estado actualizado.');
      this.listado.recargar();
    });
  }
}
