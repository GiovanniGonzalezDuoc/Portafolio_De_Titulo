import { Component, input } from '@angular/core';

import { ClpPipe } from '../../shared/pipes/clp.pipe';
import { CantidadPipe } from '../../shared/pipes/cantidad.pipe';
import { FilaRendimiento } from './dashboard.service';

/** Top productos del período: unidades, ventas, margen y stock actual. */
@Component({
  selector: 'app-tabla-rendimiento',
  imports: [ClpPipe, CantidadPipe],
  templateUrl: './tabla-rendimiento.html',
  styleUrl: './tabla-rendimiento.scss',
})
export class TablaRendimiento {
  readonly filas = input.required<FilaRendimiento[]>();
}
