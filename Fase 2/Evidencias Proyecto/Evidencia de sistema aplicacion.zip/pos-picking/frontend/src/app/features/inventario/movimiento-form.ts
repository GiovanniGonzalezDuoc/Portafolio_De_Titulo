import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MAT_DIALOG_DATA, MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

import { NotificacionService } from '../../core/services/notificacion.service';
import { confirmar } from '../../shared/components/confirm-dialog/confirm-dialog';
import { CantidadPipe } from '../../shared/pipes/cantidad.pipe';
import { aplicarErrorBackend } from '../../shared/util/form-errores';
import { Stock } from './inventario.models';
import { InventarioService } from './inventario.service';

export interface MovimientoFormData {
  stock: Stock;
  modo: 'movimiento' | 'ajuste';
}

@Component({
  selector: 'app-movimiento-form',
  imports: [
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatButtonToggleModule,
    CantidadPipe,
  ],
  templateUrl: './movimiento-form.html',
})
export class MovimientoForm {
  private readonly fb = inject(FormBuilder);
  private readonly service = inject(InventarioService);
  private readonly noti = inject(NotificacionService);
  private readonly dialog = inject(MatDialog);
  private readonly ref = inject(MatDialogRef<MovimientoForm>);
  readonly data = inject<MovimientoFormData>(MAT_DIALOG_DATA);

  readonly guardando = signal(false);
  readonly esAjuste = this.data.modo === 'ajuste';

  readonly form = this.fb.nonNullable.group({
    tipo: ['AJUSTE_POSITIVO' as 'AJUSTE_POSITIVO' | 'AJUSTE_NEGATIVO'],
    cantidad: [null as number | null, [Validators.required, Validators.min(0.001)]],
    motivo: ['', Validators.required],
  });

  async guardar(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();

    // Control anti-robo: toda baja de stock se confirma explícitamente y
    // queda registrada con el usuario y el motivo.
    const actual = Number(this.data.stock.cantidad);
    const esBaja = this.esAjuste ? v.cantidad! < actual : v.tipo === 'AJUSTE_NEGATIVO';
    if (esBaja) {
      const queda = this.esAjuste ? v.cantidad! : actual - v.cantidad!;
      const baja = actual - queda;
      const ok = await confirmar(this.dialog, {
        titulo: 'Confirmar salida de stock',
        mensaje:
          `Vas a descontar ${baja} de "${this.data.stock.producto_nombre}". ` +
          `El stock quedará en ${queda < 0 ? 0 : queda}. Motivo: «${v.motivo}». ` +
          `Queda registrado con tu usuario y la hora.`,
        peligro: true,
        confirmar: 'Descontar',
      });
      if (!ok) return;
    }

    this.guardando.set(true);
    const obs = this.esAjuste
      ? this.service.ajustar({
          producto: this.data.stock.producto_sku,
          ubicacion: this.data.stock.ubicacion_nombre,
          cantidad_final: v.cantidad!,
          motivo: v.motivo,
        })
      : this.service.registrarMovimiento({
          producto: this.data.stock.producto_sku,
          ubicacion: this.data.stock.ubicacion_nombre,
          tipo: v.tipo,
          cantidad: v.cantidad!,
          motivo: v.motivo,
        });

    obs.subscribe({
      next: () => {
        this.noti.exito('Inventario actualizado.');
        this.ref.close(true);
      },
      error: (err) => {
        this.guardando.set(false);
        aplicarErrorBackend(this.form, err);
      },
    });
  }
}
