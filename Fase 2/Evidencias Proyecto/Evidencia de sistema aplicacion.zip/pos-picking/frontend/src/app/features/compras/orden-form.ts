import { DatePipe } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormArray, FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';

import { NotificacionService } from '../../core/services/notificacion.service';
import { CantidadPipe } from '../../shared/pipes/cantidad.pipe';
import { ClpPipe } from '../../shared/pipes/clp.pipe';
import { ProveedoresService } from '../proveedores/proveedores.service';
import { ProductosService } from '../catalogo/catalogo.service';
import { ComprasService, InfoProductoCompra } from './compras.service';

@Component({
  selector: 'app-orden-form',
  imports: [
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    ClpPipe,
    CantidadPipe,
    DatePipe,
  ],
  templateUrl: './orden-form.html',
  styleUrl: './orden-form.scss',
})
export class OrdenForm {
  private readonly fb = inject(FormBuilder);
  private readonly service = inject(ComprasService);
  private readonly proveedoresService = inject(ProveedoresService);
  private readonly productosService = inject(ProductosService);
  private readonly noti = inject(NotificacionService);
  private readonly ref = inject(MatDialogRef<OrdenForm>);

  readonly guardando = signal(false);
  readonly proveedores = signal<{ rut: string; razon_social: string }[]>([]);
  readonly productos = signal<{ sku: string; nombre: string; costo_referencial: number }[]>([]);
  /** Último costo + aviso de pedido pendiente por línea (mismo índice que `lineas`). */
  readonly infoPorLinea = signal<(InfoProductoCompra | null)[]>([null]);

  readonly form = this.fb.nonNullable.group({
    proveedor: ['', Validators.required],
    observacion: [''],
    lineas: this.fb.array([this.nuevaLinea()]),
  });

  get lineas(): FormArray {
    return this.form.get('lineas') as FormArray;
  }

  readonly total = computed(() => this.calcularTotal());
  private readonly recalc = signal(0);

  constructor() {
    this.proveedoresService
      .lista({ activo: 'true', page_size: 200 })
      .pipe(takeUntilDestroyed())
      .subscribe((p) => this.proveedores.set(p.resultados));
    this.productosService
      .lista({ activo: 'true', page_size: 500, ordering: 'nombre' })
      .pipe(takeUntilDestroyed())
      .subscribe((p) => this.productos.set(p.resultados));
    this.form.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.recalc.update((n) => n + 1));

    // Cambiar de proveedor puede cambiar el último costo y el aviso de
    // pedido pendiente de las líneas ya elegidas (son por producto+proveedor).
    this.form.controls.proveedor.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => {
      this.lineas.controls.forEach((ctrl, i) => {
        const sku = (ctrl.value as { producto: string }).producto;
        if (sku) this.cargarInfoLinea(i, sku);
      });
    });
  }

  private nuevaLinea() {
    return this.fb.nonNullable.group({
      producto: ['', Validators.required],
      cantidad: [1, [Validators.required, Validators.min(1)]],
      costo_unitario: [0, [Validators.required, Validators.min(0)]],
    });
  }

  agregarLinea(): void {
    this.lineas.push(this.nuevaLinea());
    this.infoPorLinea.update((xs) => [...xs, null]);
  }
  quitarLinea(i: number): void {
    if (this.lineas.length > 1) {
      this.lineas.removeAt(i);
      this.infoPorLinea.update((xs) => xs.filter((_, idx) => idx !== i));
    }
  }

  onProductoElegido(i: number, sku: string): void {
    const p = this.productos().find((x) => x.sku === sku);
    if (p) {
      // Punto de partida; si hay un costo de la última compra, lo reemplaza abajo.
      this.lineas.at(i).patchValue({ costo_unitario: p.costo_referencial });
    }
    this.cargarInfoLinea(i, sku);
  }

  /** Último costo pagado (prioriza el mismo proveedor) + aviso si ya hay un pedido sin llegar. */
  private cargarInfoLinea(i: number, sku: string): void {
    const proveedorRut = this.form.controls.proveedor.value || undefined;
    this.service.infoProducto(sku, proveedorRut).subscribe((info) => {
      this.infoPorLinea.update((xs) => xs.map((x, idx) => (idx === i ? info : x)));
      if (info.ultimo_costo) {
        this.lineas.at(i).patchValue({ costo_unitario: info.ultimo_costo.costo_unitario });
      }
    });
  }

  private calcularTotal(): number {
    this.recalc();
    return this.lineas.controls.reduce((acc, c) => {
      const v = c.value as { cantidad: number; costo_unitario: number };
      return acc + (v.cantidad || 0) * (v.costo_unitario || 0);
    }, 0);
  }

  guardar(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.guardando.set(true);
    const v = this.form.getRawValue();
    this.service
      .crear({
        proveedor: v.proveedor,
        observacion: v.observacion || undefined,
        lineas: v.lineas.map((l) => ({
          producto: l.producto,
          cantidad: l.cantidad,
          costo_unitario: l.costo_unitario,
        })),
      })
      .subscribe({
        next: (o) => {
          this.noti.exito(`Orden ${o.codigo} creada.`);
          this.ref.close(o.id);
        },
        error: () => this.guardando.set(false),
      });
  }
}
