import { Component, computed, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

import { NotificacionService } from '../../core/services/notificacion.service';
import { aplicarErrorBackend } from '../../shared/util/form-errores';
import { Proveedor } from './proveedores.service';
import { ProveedoresService } from './proveedores.service';

@Component({
  selector: 'app-proveedor-form',
  imports: [ReactiveFormsModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  templateUrl: './proveedor-form.html',
})
export class ProveedorForm {
  private readonly fb = inject(FormBuilder);
  private readonly service = inject(ProveedoresService);
  private readonly noti = inject(NotificacionService);
  private readonly ref = inject(MatDialogRef<ProveedorForm>);
  readonly data = inject<Proveedor | null>(MAT_DIALOG_DATA);

  readonly esNuevo = this.data === null;
  readonly guardando = signal(false);
  readonly titulo = computed(() => (this.esNuevo ? 'Nuevo proveedor' : 'Editar proveedor'));

  readonly form = this.fb.nonNullable.group({
    razon_social: [this.data?.razon_social ?? '', Validators.required],
    rut: [this.data?.rut ?? '', Validators.required],
    giro: [this.data?.giro ?? ''],
    contacto_nombre: [this.data?.contacto_nombre ?? ''],
    contacto_email: [this.data?.contacto_email ?? '', Validators.email],
    contacto_telefono: [this.data?.contacto_telefono ?? ''],
    direccion: [this.data?.direccion ?? ''],
    lead_time_dias: [this.data?.lead_time_dias ?? 7, [Validators.required, Validators.min(0)]],
  });

  guardar(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.guardando.set(true);
    const dto = this.form.getRawValue();
    const obs = this.esNuevo ? this.service.crear(dto) : this.service.actualizar(this.data!.id, dto);
    obs.subscribe({
      next: () => {
        this.noti.exito(this.esNuevo ? 'Proveedor creado.' : 'Proveedor actualizado.');
        this.ref.close(true);
      },
      error: (err) => {
        this.guardando.set(false);
        aplicarErrorBackend(this.form, err);
      },
    });
  }
}
