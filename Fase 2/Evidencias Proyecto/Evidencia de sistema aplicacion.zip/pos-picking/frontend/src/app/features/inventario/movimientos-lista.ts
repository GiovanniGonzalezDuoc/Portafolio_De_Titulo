import { DatePipe } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { debounceTime } from 'rxjs';

import { NotificacionService } from '../../core/services/notificacion.service';
import { EstadoVacio } from '../../shared/components/estado-vacio/estado-vacio';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { CantidadPipe } from '../../shared/pipes/cantidad.pipe';
import { guardarArchivo } from '../../shared/util/descargar';
import { fechaLocalIso as iso } from '../../shared/util/fecha';
import { crearListado } from '../../shared/util/listado';
import { MovimientoInventario } from './inventario.models';
import { InventarioService } from './inventario.service';

const TIPOS = [
  'COMPRA', 'VENTA', 'DEVOLUCION', 'AJUSTE_POSITIVO', 'AJUSTE_NEGATIVO',
  'CONTEO', 'TRASPASO_ENTRADA', 'TRASPASO_SALIDA',
];

@Component({
  selector: 'app-movimientos-lista',
  imports: [
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
    PageHeader,
    EstadoVacio,
    DatePipe,
    CantidadPipe,
  ],
  templateUrl: './movimientos-lista.html',
})
export class MovimientosLista {
  private readonly service = inject(InventarioService);
  private readonly noti = inject(NotificacionService);

  readonly tipos = TIPOS;
  readonly columnas = ['fecha', 'producto', 'tipo', 'cantidad', 'saldo', 'usuario', 'motivo'];

  readonly buscarProducto = new FormControl('', { nonNullable: true });
  readonly filtroTipo = new FormControl('', { nonNullable: true });
  readonly desde = new FormControl('', { nonNullable: true });
  readonly hasta = new FormControl('', { nonNullable: true });

  readonly descargando = signal(false);

  readonly listado = crearListado<MovimientoInventario>((p) => this.service.movimientos(p));

  constructor() {
    this.buscarProducto.valueChanges
      .pipe(debounceTime(400), takeUntilDestroyed())
      .subscribe(() => this.aplicar());
    this.filtroTipo.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.desde.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.hasta.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
  }

  private filtros(): Record<string, string | undefined> {
    return {
      producto: this.buscarProducto.value.trim() || undefined,
      tipo: this.filtroTipo.value || undefined,
      desde: this.desde.value || undefined,
      hasta: this.hasta.value || undefined,
    };
  }

  private aplicar(): void {
    this.listado.filtrar({ ...this.filtros(), ordering: '-creado_en' });
  }

  paginar(e: PageEvent): void {
    this.listado.irAPagina(e.pageIndex, e.pageSize);
  }

  // ─── Atajos de fecha ──────────────────────────────────────
  rango(preset: 'hoy' | 'ayer' | 'mes' | 'mes_pasado' | 'dias30'): void {
    const hoy = new Date();
    let d: Date;
    let h: Date;
    switch (preset) {
      case 'hoy':
        d = h = hoy;
        break;
      case 'ayer':
        d = h = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate() - 1);
        break;
      case 'mes':
        d = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
        h = hoy;
        break;
      case 'mes_pasado':
        d = new Date(hoy.getFullYear(), hoy.getMonth() - 1, 1);
        h = new Date(hoy.getFullYear(), hoy.getMonth(), 0);
        break;
      case 'dias30':
        d = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate() - 29);
        h = hoy;
        break;
    }
    this.desde.setValue(iso(d), { emitEvent: false });
    this.hasta.setValue(iso(h));
  }

  limpiarFechas(): void {
    this.desde.setValue('', { emitEvent: false });
    this.hasta.setValue('');
  }

  // ─── Descarga CSV ─────────────────────────────────────────
  descargar(): void {
    if (this.descargando()) return;
    this.descargando.set(true);
    this.service.exportarMovimientos(this.filtros()).subscribe({
      next: ({ blob, nombre }) => {
        guardarArchivo(blob, nombre || 'reporte_movimientos.xlsx');
        this.descargando.set(false);
      },
      error: () => {
        this.noti.error('No se pudo generar el archivo.');
        this.descargando.set(false);
      },
    });
  }
}
