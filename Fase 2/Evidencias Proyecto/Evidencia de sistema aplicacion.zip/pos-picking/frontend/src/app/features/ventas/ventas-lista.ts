import { DatePipe } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';

import { AuthService } from '../../core/auth/auth.service';
import { NotificacionService } from '../../core/services/notificacion.service';
import { BadgeEstado } from '../../shared/components/badge-estado/badge-estado';
import { EstadoVacio } from '../../shared/components/estado-vacio/estado-vacio';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { pedirTexto } from '../../shared/components/input-dialog/input-dialog';
import { ToggleAcciones, VistaAcciones } from '../../shared/components/toggle-acciones/toggle-acciones';
import { ClpPipe } from '../../shared/pipes/clp.pipe';
import { crearListado } from '../../shared/util/listado';
import { BoletaDialog } from './boleta-dialog';
import { VentaDetalleDialog } from './venta-detalle-dialog';
import { Venta, VentasService } from './ventas.service';

@Component({
  selector: 'app-ventas-lista',
  imports: [
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatTooltipModule,
    MatProgressBarModule,
    PageHeader,
    BadgeEstado,
    EstadoVacio,
    ToggleAcciones,
    ClpPipe,
    DatePipe,
  ],
  templateUrl: './ventas-lista.html',
})
export class VentasLista {
  private readonly service = inject(VentasService);
  private readonly dialog = inject(MatDialog);
  private readonly noti = inject(NotificacionService);
  private readonly auth = inject(AuthService);

  readonly columnas = ['folio', 'fecha', 'vendedor', 'total', 'estado', 'boleta', 'acciones'];
  readonly puedeAnular = this.auth.tienePermiso('ventas.anular');
  readonly puedeReintentar = this.auth.tienePermiso('boleta.reintentar');

  readonly filtroBoleta = new FormControl('', { nonNullable: true });

  /** Cómo se muestran las acciones de cada fila: iconos sueltos o menú "⋮". */
  readonly vistaAcciones = signal<VistaAcciones>('menu');

  readonly listado = crearListado<Venta>((p) => this.service.lista({ ...p, ordering: '-creado_en' }));

  constructor() {
    this.filtroBoleta.valueChanges.pipe(takeUntilDestroyed()).subscribe((v) =>
      this.listado.filtrar({
        documento__estado: v === 'SIN' ? undefined : v || undefined,
        sin_boleta: v === 'SIN' ? true : undefined,
        ordering: '-creado_en',
      }),
    );
  }

  paginar(e: PageEvent): void {
    this.listado.irAPagina(e.pageIndex, e.pageSize);
  }

  /** Boletas que conviene revisar (el SII no las aceptó todavía). */
  boletaConProblema(v: Venta): boolean {
    return !!v.documento && ['PENDIENTE', 'RECHAZADO'].includes(v.documento.estado);
  }

  verDetalle(v: Venta): void {
    this.service.obtener(v.id).subscribe((full) => {
      this.dialog.open(VentaDetalleDialog, { data: full, width: '520px', maxWidth: '95vw' });
    });
  }

  verBoleta(v: Venta): void {
    if (v.documento) {
      this.dialog.open(BoletaDialog, { data: { documentoId: v.documento.id }, width: '480px' });
    }
  }

  reintentarBoleta(v: Venta): void {
    if (!v.documento) return;
    this.service.reintentarBoleta(v.documento.id).subscribe(() => {
      this.noti.exito('Reintento de emisión ejecutado.');
      this.listado.recargar();
    });
  }

  async anular(v: Venta): Promise<void> {
    const motivo = await pedirTexto(this.dialog, {
      titulo: `Anular venta ${v.folio}`,
      etiqueta: 'Motivo de la anulación',
    });
    if (!motivo) return;
    this.service.anular(v.id, motivo).subscribe(() => {
      this.noti.exito('Venta anulada. Stock reintegrado y boleta anulada.');
      this.listado.recargar();
    });
  }
}
