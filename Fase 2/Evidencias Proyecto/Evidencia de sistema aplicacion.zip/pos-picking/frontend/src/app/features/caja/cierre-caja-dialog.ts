import { DatePipe, TitleCasePipe } from '@angular/common';
import { Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';

import { ClpPipe } from '../../shared/pipes/clp.pipe';
import { Arqueo, MovimientoCaja } from './caja.service';

export interface CierreCajaData {
  arqueo: Arqueo;
  movimientos: MovimientoCaja[];
}

@Component({
  selector: 'app-cierre-caja-dialog',
  imports: [
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    ClpPipe,
    DatePipe,
    TitleCasePipe,
  ],
  templateUrl: './cierre-caja-dialog.html',
})
export class CierreCajaDialog {
  readonly data = inject<CierreCajaData>(MAT_DIALOG_DATA);
  readonly colMov = ['fecha', 'tipo', 'monto', 'motivo'];

  get a(): Arqueo {
    return this.data.arqueo;
  }

  get movimientos(): MovimientoCaja[] {
    return this.data.movimientos;
  }

  get cerrada(): boolean {
    return this.a.estado === 'CERRADA';
  }
}
