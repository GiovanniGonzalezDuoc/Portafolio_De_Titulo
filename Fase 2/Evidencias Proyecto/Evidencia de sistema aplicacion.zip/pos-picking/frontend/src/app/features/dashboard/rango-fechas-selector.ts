import { Component, output, signal } from '@angular/core';

import { fechaLocalIso } from '../../shared/util/fecha';

export interface RangoFechas {
  desde: string;
  hasta: string;
}

type Preset = 'hoy' | '7dias' | '30dias' | 'mes';

const ETIQUETAS: Record<Preset, string> = {
  hoy: 'Hoy',
  '7dias': '7 días',
  '30dias': '30 días',
  mes: 'Este mes',
};

/** Selector de rango simple: Hoy / 7 días / 30 días / Este mes + botón
 * "Actualizar" — reemplazo íntegro del selector anterior (toggle-group con
 * "Esta semana"/personalizado), según la especificación del cliente. */
@Component({
  selector: 'app-rango-fechas-selector',
  templateUrl: './rango-fechas-selector.html',
  styleUrl: './rango-fechas-selector.scss',
})
export class RangoFechasSelector {
  readonly rangoChange = output<RangoFechas>();

  readonly presets = Object.keys(ETIQUETAS) as Preset[];
  readonly etiquetas = ETIQUETAS;
  readonly preset = signal<Preset>('hoy');
  readonly actualizando = signal(false);

  constructor() {
    this.emitirRango(this.preset());
  }

  cambiarPreset(valor: string): void {
    const p = valor as Preset;
    this.preset.set(p);
    this.emitirRango(p);
  }

  actualizar(): void {
    this.actualizando.set(true);
    this.emitirRango(this.preset());
    setTimeout(() => this.actualizando.set(false), 700);
  }

  private emitirRango(p: Preset): void {
    const hoy = new Date();
    let desde: Date;
    switch (p) {
      case '7dias':
        desde = new Date(hoy);
        desde.setDate(hoy.getDate() - 6);
        break;
      case '30dias':
        desde = new Date(hoy);
        desde.setDate(hoy.getDate() - 29);
        break;
      case 'mes':
        desde = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
        break;
      default:
        desde = new Date(hoy);
    }
    this.rangoChange.emit({ desde: fechaLocalIso(desde), hasta: fechaLocalIso(hoy) });
  }
}
