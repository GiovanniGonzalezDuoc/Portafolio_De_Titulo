import { Component, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { debounceTime } from 'rxjs';

import { AuthService } from '../../core/auth/auth.service';
import { NotificacionService } from '../../core/services/notificacion.service';
import { EstadoVacio } from '../../shared/components/estado-vacio/estado-vacio';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { CantidadPipe } from '../../shared/pipes/cantidad.pipe';
import { guardarArchivo } from '../../shared/util/descargar';
import { crearListado } from '../../shared/util/listado';
import { CategoriasService, MarcasService } from '../catalogo/catalogo.service';
import { ImportarStockResultado, InventarioService } from './inventario.service';
import { Stock, Ubicacion } from './inventario.models';
import { MovimientoForm } from './movimiento-form';

@Component({
  selector: 'app-stock-lista',
  imports: [
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatProgressBarModule,
    PageHeader,
    EstadoVacio,
    CantidadPipe,
  ],
  templateUrl: './stock-lista.html',
  styleUrl: './stock-lista.scss',
})
export class StockLista {
  private readonly service = inject(InventarioService);
  private readonly dialog = inject(MatDialog);
  private readonly auth = inject(AuthService);
  private readonly categoriasSrv = inject(CategoriasService);
  private readonly marcasSrv = inject(MarcasService);
  private readonly noti = inject(NotificacionService);

  readonly columnas = ['producto', 'marca', 'ubicacion', 'cantidad', 'acciones'];
  readonly puedeMover = this.auth.tienePermiso('inventario.mover');
  readonly puedeAjustar = this.auth.tienePermiso('inventario.ajustar');

  readonly buscar = new FormControl('', { nonNullable: true });
  readonly filtroCategoria = new FormControl('', { nonNullable: true });
  readonly filtroMarca = new FormControl('', { nonNullable: true });
  readonly filtroUbicacion = new FormControl('', { nonNullable: true });
  readonly soloBajoMinimo = new FormControl(false, { nonNullable: true });
  readonly soloSinStock = new FormControl(false, { nonNullable: true });

  readonly categorias = signal<string[]>([]);
  readonly marcas = signal<string[]>([]);
  readonly ubicaciones = signal<Ubicacion[]>([]);
  readonly descargando = signal(false);
  readonly importando = signal(false);
  readonly reporteImportacion = signal<ImportarStockResultado | null>(null);

  readonly listado = crearListado<Stock>((p) => this.service.stock(p));

  constructor() {
    this.categoriasSrv
      .lista({ page_size: 200, ordering: 'nombre' })
      .subscribe((p) => this.categorias.set(p.resultados.map((c) => c.nombre)));
    this.marcasSrv
      .lista({ page_size: 200, ordering: 'nombre' })
      .subscribe((p) => this.marcas.set(p.resultados.map((m) => m.nombre)));
    this.service.ubicaciones().subscribe((p) => this.ubicaciones.set(p.resultados));

    this.buscar.valueChanges.pipe(debounceTime(300), takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.filtroCategoria.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.filtroMarca.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.filtroUbicacion.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.soloBajoMinimo.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.soloSinStock.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
  }

  private filtrosActuales(): Record<string, string | boolean | undefined> {
    return {
      search: this.buscar.value || undefined,
      categoria: this.filtroCategoria.value || undefined,
      marca: this.filtroMarca.value || undefined,
      ubicacion: this.filtroUbicacion.value || undefined,
      bajo_minimo: this.soloBajoMinimo.value || undefined,
      sin_stock: this.soloSinStock.value || undefined,
    };
  }

  private aplicar(): void {
    this.listado.filtrar(this.filtrosActuales());
  }

  paginar(e: PageEvent): void {
    this.listado.irAPagina(e.pageIndex, e.pageSize);
  }

  abrir(stock: Stock, modo: 'movimiento' | 'ajuste'): void {
    const ref = this.dialog.open(MovimientoForm, { data: { stock, modo }, width: '440px' });
    ref.afterClosed().subscribe((ok) => ok && this.listado.recargar());
  }

  // ─── Edición masiva por Excel ──────────────────────────────
  descargarParaEditar(): void {
    this.descargando.set(true);
    this.service.exportarStock(this.filtrosActuales()).subscribe({
      next: ({ blob, nombre }) => {
        this.descargando.set(false);
        guardarArchivo(blob, nombre || 'stock.xlsx');
      },
      error: () => this.descargando.set(false),
    });
  }

  importarArchivo(input: HTMLInputElement): void {
    const archivo = input.files?.[0] ?? null;
    input.value = '';
    if (!archivo) return;
    this.reporteImportacion.set(null);
    this.importando.set(true);
    this.service.importarStock(archivo).subscribe({
      next: (r) => {
        this.importando.set(false);
        this.reporteImportacion.set(r);
        if (r.actualizados > 0) {
          this.noti.exito(`${r.actualizados} producto(s) con stock actualizado.`);
          this.listado.recargar();
        }
        if (r.con_error.length > 0) {
          this.noti.error(`${r.con_error.length} fila(s) con error; revisa el detalle.`);
        }
      },
      error: () => this.importando.set(false),
    });
  }
}
