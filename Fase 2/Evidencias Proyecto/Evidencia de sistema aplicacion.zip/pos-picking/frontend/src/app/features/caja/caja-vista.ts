import { DatePipe, TitleCasePipe } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTableModule } from '@angular/material/table';
import { HttpErrorResponse } from '@angular/common/http';

import { forkJoin } from 'rxjs';

import { NotificacionService } from '../../core/services/notificacion.service';
import { MilesDirective } from '../../shared/directives/miles.directive';
import { ClpPipe } from '../../shared/pipes/clp.pipe';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { confirmar } from '../../shared/components/confirm-dialog/confirm-dialog';
import { Arqueo, Caja, CajaService, MovimientoCaja } from './caja.service';
import { CierreCajaDialog } from './cierre-caja-dialog';

@Component({
  selector: 'app-caja-vista',
  imports: [
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatIconModule,
    MatTableModule,
    MatProgressBarModule,
    MilesDirective,
    PageHeader,
    ClpPipe,
    DatePipe,
    TitleCasePipe,
  ],
  templateUrl: './caja-vista.html',
  styleUrl: './caja-vista.scss',
})
export class CajaVista {
  private readonly service = inject(CajaService);
  private readonly fb = inject(FormBuilder);
  private readonly noti = inject(NotificacionService);
  private readonly dialog = inject(MatDialog);

  readonly cargando = signal(true);
  readonly caja = signal<Caja | null>(null);
  readonly arqueo = signal<Arqueo | null>(null);
  readonly movimientos = signal<MovimientoCaja[]>([]);
  readonly colMov = ['fecha', 'tipo', 'monto', 'motivo'];

  readonly formApertura = this.fb.nonNullable.group({
    monto_inicial: [0, [Validators.required, Validators.min(0)]],
  });
  readonly formMov = this.fb.nonNullable.group({
    tipo: ['INGRESO' as 'INGRESO' | 'EGRESO'],
    monto: [null as number | null, [Validators.required, Validators.min(1)]],
    motivo: ['', Validators.required],
  });

  constructor() {
    queueMicrotask(() => this.cargar());
  }

  private cargar(): void {
    this.cargando.set(true);
    this.service.miCaja().subscribe({
      next: (c) => {
        this.caja.set(c);
        this.cargando.set(false);
        this.refrescarArqueo();
      },
      error: (err: unknown) => {
        this.cargando.set(false);
        if (err instanceof HttpErrorResponse && err.status === 404) {
          this.caja.set(null);
        }
      },
    });
  }

  private refrescarArqueo(): void {
    const c = this.caja();
    if (!c) return;
    this.service.arqueo(c.id).subscribe((a) => this.arqueo.set(a));
    this.service.movimientos(c.id).subscribe((m) => this.movimientos.set(m));
  }

  abrir(): void {
    if (this.formApertura.invalid) return;
    this.service.abrir(this.formApertura.getRawValue().monto_inicial).subscribe(() => {
      this.noti.exito('Caja abierta.');
      this.cargar();
    });
  }

  registrarMov(): void {
    const c = this.caja();
    if (!c || this.formMov.invalid) {
      this.formMov.markAllAsTouched();
      return;
    }
    const v = this.formMov.getRawValue();
    const obs =
      v.tipo === 'INGRESO'
        ? this.service.ingreso(c.id, v.monto!, v.motivo)
        : this.service.egreso(c.id, v.monto!, v.motivo);
    obs.subscribe(() => {
      this.noti.exito('Movimiento registrado.');
      this.formMov.reset({ tipo: v.tipo, monto: null, motivo: '' });
      this.refrescarArqueo();
    });
  }

  async cerrar(): Promise<void> {
    const c = this.caja();
    const a = this.arqueo();
    if (!c || !a) return;
    const esperado = a.saldo_esperado.toLocaleString('es-CL');
    const contadoStr = await import('../../shared/components/input-dialog/input-dialog').then((m) =>
      m.pedirTexto(this.dialog, {
        titulo: `Cerrar ${c.codigo}`,
        etiqueta: `Monto contado (esperado: $${esperado})`,
        miles: true,
      }),
    );
    if (contadoStr === null) return;
    const contado = Number(contadoStr);
    const clp = (n: number | null | undefined) => `$${(n ?? 0).toLocaleString('es-CL')}`;
    const ok = await confirmar(this.dialog, {
      titulo: 'Confirmar cierre',
      mensaje:
        `Contado ${clp(contado)} · esperado ${clp(a.saldo_esperado)} · ` +
        `diferencia ${clp(contado - a.saldo_esperado)}. ¿Cerrar caja?`,
      peligro: contado !== a.saldo_esperado,
    });
    if (!ok) return;
    this.service.cerrar(c.id, contado).subscribe((cerrada) => {
      this.noti.exito(`Caja cerrada. Diferencia: ${clp(cerrada.diferencia)}.`);
      this.mostrarCierre(cerrada.id);
      this.cargar();
    });
  }

  /** Abre el resumen del turno recién cerrado. */
  private mostrarCierre(cajaId: number): void {
    forkJoin({
      arqueo: this.service.arqueo(cajaId),
      movimientos: this.service.movimientos(cajaId),
    }).subscribe(({ arqueo, movimientos }) => {
      this.dialog.open(CierreCajaDialog, {
        data: { arqueo, movimientos },
        width: '560px',
        maxWidth: '95vw',
      });
    });
  }
}
