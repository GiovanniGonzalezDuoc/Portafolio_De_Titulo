import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { ApiService } from '../../core/services/api.service';

export interface KpisVentas {
  monto: number;
  variacion_pct: number | null;
  n_ventas: number;
  unidades: string | number;
  ticket_promedio: number;
}

export interface PuntoVenta {
  periodo: string;
  monto: number;
}

export interface ProductoTop {
  sku: string;
  nombre: string;
  unidades: string | number;
  monto: number;
}

export interface VentasPorMedioPago {
  medio: string;
  medio_display: string;
  monto: number;
}

export interface VentasPorCategoria {
  categoria: string;
  monto: number;
}

export interface DatosMargen {
  margen: number;
  margen_pct: number;
}

export interface DatosRotacionInventario {
  rotacion: number;
  costo_venta: number;
  valorizado: number;
}

export interface DatosAnulaciones {
  anuladas_n: number;
  anuladas_pct: number;
  monto_anulado: number;
}

export interface DatosDescuentos {
  descuento_total: number;
  descuento_pct: number;
  tope_pct: number;
}

export interface MixCliente {
  tipo: string;
  monto: number;
  n: number;
}

export interface PuntoUnidadesSemana {
  semana: string;
  unidades: number;
}

export interface FilaRendimiento {
  sku: string;
  nombre: string;
  categoria: string;
  unidades: string | number;
  ventas: number;
  margen_pct: number;
  stock: string | number;
}

export interface DatosPrecisionRecepcion {
  precision_pct: number;
  lineas_recibidas: number;
  lineas_completas: number;
  lineas_incompletas: number;
}

export interface VentasAnalitica {
  kpis: KpisVentas;
  tendencia: PuntoVenta[];
  top_productos: ProductoTop[];
  por_medio_pago: VentasPorMedioPago[];
  por_categoria: VentasPorCategoria[];
  anulaciones: DatosAnulaciones;
  descuentos: DatosDescuentos;
  mix_cliente: MixCliente[];
  unidades_semana: PuntoUnidadesSemana[];
  /** Alineada por posición con `tendencia` (día 1 vs. día 1...), no por fecha real. */
  tendencia_anterior: number[];
  /** Cantidad de ventas por día de semana (0=lunes) dentro del rango elegido. */
  ventas_por_dia_semana: number[];
  /** Solo con `dashboard.ver_completo` (información de costos). */
  margen?: DatosMargen;
  rotacion_inventario?: DatosRotacionInventario;
  /** Matriz [franja_horaria][dia_semana] de cantidad de ventas, últimos 30 días. */
  mapa_presion?: number[][];
  top_rendimiento?: FilaRendimiento[];
  precision_recepcion?: DatosPrecisionRecepcion;
}

export type MetricaRentabilidad = 'recuperacion' | 'margen';

export interface FilaRentabilidad {
  sku: string;
  nombre: string;
  ingresos: number;
  margen: number;
  costo_compra: number;
  recuperacion_pct: number | null;
}

export interface RentabilidadAnalitica {
  metrica: MetricaRentabilidad;
  mejores: FilaRentabilidad[];
  peores: FilaRentabilidad[];
  /** Listado completo (todos los productos con ventas en el período), para
   * la tabla enterprise — ya viene ordenado por la métrica elegida. */
  todas: FilaRentabilidad[];
}

export interface PuntoRecuperacion {
  periodo: string;
  recuperacion_pct: number | null;
  margen: number;
}

export interface PuntoRotacion {
  periodo: string;
  rotacion: number;
}

export interface DetalleProductoAnalitico {
  sku: string;
  nombre: string;
  serie_recuperacion: PuntoRecuperacion[];
  serie_rotacion: PuntoRotacion[];
}

export interface DatosSaludInventario {
  valorizado: number;
  productos_activos: number;
  productos_normal: number;
  productos_stock_bajo: number;
  productos_sin_stock: number;
}

export interface DatosCicloCompras {
  productos_bajo_punto_pedido: number;
  ordenes_pendientes_recepcion: number;
  unidades_en_transito: string | number;
}

export interface DatosPrediccion {
  productos_activos: number;
  con_prediccion: number;
  sin_prediccion: number;
  no_estable: number;
  estable: number;
  confiable: number;
}

export interface DatosQuiebre {
  sku: string;
  nombre: string;
  stock_actual: string | number;
  dias_restantes: number;
}

export interface DatosBajaRotacion {
  sku: string;
  nombre: string;
  stock_actual: string | number;
  unidades_vendidas: number;
}

export interface DatosProveedor {
  proveedor: string;
  dias_promedio: number;
  n_recepciones: number;
}

export interface DatosUbicacion {
  ubicacion: string;
  valorizado: number;
  productos: number;
}

export interface OperacionInventario {
  salud_inventario: DatosSaludInventario;
  ciclo_compras: DatosCicloCompras;
  prediccion: DatosPrediccion;
  quiebre_inminente: DatosQuiebre[];
  baja_rotacion: DatosBajaRotacion[];
  proveedores: DatosProveedor[];
  por_ubicacion: DatosUbicacion[];
}

@Injectable({ providedIn: 'root' })
export class DashboardService {
  private readonly api = inject(ApiService);

  ventasAnalitica(desde: string, hasta: string): Observable<VentasAnalitica> {
    return this.api.get<VentasAnalitica>('dashboard/ventas-analitica', { desde, hasta });
  }

  rentabilidadAnalitica(
    desde: string,
    hasta: string,
    metrica: MetricaRentabilidad,
  ): Observable<RentabilidadAnalitica> {
    return this.api.get<RentabilidadAnalitica>('dashboard/rentabilidad-analitica', {
      desde,
      hasta,
      metrica,
    });
  }

  detalleProducto(sku: string, desde: string, hasta: string): Observable<DetalleProductoAnalitico> {
    return this.api.get<DetalleProductoAnalitico>(
      `dashboard/rentabilidad-analitica/${encodeURIComponent(sku)}`,
      { desde, hasta },
    );
  }

  operacionInventario(): Observable<OperacionInventario> {
    return this.api.get<OperacionInventario>('dashboard/operacion-inventario');
  }

  exportarReporte(desde: string, hasta: string): Observable<{ blob: Blob; nombre: string }> {
    return this.api.descargar('dashboard/exportar', { desde, hasta });
  }
}
