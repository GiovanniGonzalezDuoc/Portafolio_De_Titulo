import { DatePipe } from '@angular/common';
import { Component, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { debounceTime } from 'rxjs';

import { EstadoVacio } from '../../shared/components/estado-vacio/estado-vacio';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { ClpPipe } from '../../shared/pipes/clp.pipe';
import { crearListado } from '../../shared/util/listado';
import { Oferta } from './ofertas.models';
import { OfertasService } from './ofertas.service';

/**
 * Vista del cliente mayorista: solo el catálogo de ofertas vigentes con los
 * precios mayoristas. Sin acceso a categorías, marcas ni administración.
 */
@Component({
  selector: 'app-catalogo-mayorista',
  imports: [
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatPaginatorModule,
    MatProgressBarModule,
    PageHeader,
    EstadoVacio,
    ClpPipe,
    DatePipe,
  ],
  templateUrl: './catalogo-mayorista.html',
  styleUrl: './catalogo-mayorista.scss',
})
export class CatalogoMayorista {
  private readonly service = inject(OfertasService);

  readonly buscar = new FormControl('', { nonNullable: true });
  readonly listado = crearListado<Oferta>((p) => this.service.lista(p));

  constructor() {
    this.buscar.valueChanges
      .pipe(debounceTime(300), takeUntilDestroyed())
      .subscribe(() => this.aplicar());
    this.aplicar();
  }

  private aplicar(): void {
    this.listado.filtrar({
      vigente: 'true',
      search: this.buscar.value.trim() || undefined,
    });
  }

  paginar(e: PageEvent): void {
    this.listado.irAPagina(e.pageIndex, e.pageSize);
  }

  /** Precio mayorista normal (cae al precio normal si el producto no tiene mayorista). */
  precioBase(o: Oferta): number {
    return o.precio_normal_mayorista ?? o.precio_normal;
  }

  /** Precio mayorista con la oferta aplicada. */
  precioOferta(o: Oferta): number {
    return o.precio_oferta_mayorista ?? o.precio_oferta;
  }

  descuento(o: Oferta): number {
    const base = this.precioBase(o);
    const oferta = this.precioOferta(o);
    if (!base || oferta >= base) {
      return 0;
    }
    return Math.round((1 - oferta / base) * 100);
  }
}
