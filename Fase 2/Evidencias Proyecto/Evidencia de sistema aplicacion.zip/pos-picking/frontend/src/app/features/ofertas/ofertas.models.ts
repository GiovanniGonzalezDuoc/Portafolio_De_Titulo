export interface Oferta {
  id: number;
  producto: string; // SKU
  producto_nombre: string;
  precio_normal: number;
  precio_normal_mayorista: number | null;
  precio_oferta: number;
  precio_oferta_mayorista: number | null;
  descuento_pct: number;
  descripcion: string;
  inicia_en: string;
  termina_en: string | null;
  activa: boolean;
  vigente: boolean;
  lote: string;
  creada_por: string | null;
  creado_en: string;
}

export type TipoDescuento = 'porcentaje' | 'precio_fijo';

/** Alcance de una operación masiva: uno de estos campos. */
export interface Alcance {
  productos?: string[];
  categoria?: string;
  marca?: string;
  todos?: boolean;
}

export interface AplicarMasivo extends Alcance {
  tipo: TipoDescuento;
  valor: number;
  inicia_en?: string;
  termina_en?: string | null;
  descripcion?: string;
}

export interface ResumenMasivo {
  lote: string;
  creadas: number;
  omitidas: number;
  total: number;
}

/** Producto próximo a vencer: candidato a oferta. */
export interface CandidatoVencimiento {
  sku: string;
  nombre: string;
  categoria: string;
  fecha_vencimiento: string;
  dias_para_vencer: number;
  vencido: boolean;
  precio_venta: number;
  stock_total: number;
  tiene_oferta: boolean;
}
