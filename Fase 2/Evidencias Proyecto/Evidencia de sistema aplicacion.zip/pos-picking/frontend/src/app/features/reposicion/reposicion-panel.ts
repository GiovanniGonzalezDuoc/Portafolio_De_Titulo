import { DecimalPipe } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatDialog } from '@angular/material/dialog';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Router, RouterLink } from '@angular/router';
import { debounceTime } from 'rxjs';

import { AuthService } from '../../core/auth/auth.service';
import { NotificacionService } from '../../core/services/notificacion.service';
import { BadgeEstado } from '../../shared/components/badge-estado/badge-estado';
import { confirmar } from '../../shared/components/confirm-dialog/confirm-dialog';
import { EstadoVacio } from '../../shared/components/estado-vacio/estado-vacio';
import { PageHeader } from '../../shared/components/page-header/page-header';
import { crearListado } from '../../shared/util/listado';
import { ParametrosDialog } from './parametros-dialog';
import {
  ParametroReposicion,
  RecomendacionReposicion,
  ReposicionService,
  ResumenGeneracion,
} from './reposicion.service';

@Component({
  selector: 'app-reposicion-panel',
  imports: [
    ReactiveFormsModule,
    RouterLink,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatCardModule,
    MatChipsModule,
    MatProgressBarModule,
    MatTooltipModule,
    PageHeader,
    BadgeEstado,
    EstadoVacio,
    DecimalPipe,
  ],
  templateUrl: './reposicion-panel.html',
  styleUrl: './reposicion-panel.scss',
})
export class ReposicionPanel {
  private readonly service = inject(ReposicionService);
  private readonly noti = inject(NotificacionService);
  private readonly auth = inject(AuthService);
  private readonly dialog = inject(MatDialog);
  private readonly router = inject(Router);

  readonly puedeEjecutar = this.auth.tienePermiso('reposicion.ejecutar');
  readonly puedeCrearOrden = this.auth.tienePermiso('compras.crear');
  readonly columnas = [
    'sel', 'producto', 'proveedor', 'stock', 'demanda', 'punto_pedido',
    'cantidad', 'estado', 'acciones',
  ];

  readonly generando = signal(false);
  readonly ultimoResumen = signal<ResumenGeneracion | null>(null);
  readonly parametros = signal<ParametroReposicion | null>(null);
  readonly seleccion = signal<Set<number>>(new Set());

  readonly buscarSku = new FormControl('', { nonNullable: true });
  readonly filtroEstado = new FormControl('', { nonNullable: true });
  readonly soloConCompra = new FormControl(true, { nonNullable: true });
  /** Prueba: reemplaza el mínimo de RF-K8 solo para esta tanda (vacío = usa la configuración). */
  readonly minimoSemanas = new FormControl<number | null>(null);

  readonly listado = crearListado<RecomendacionReposicion>((p) => this.service.recomendaciones(p));

  readonly totalSeleccion = computed(() => this.seleccion().size);

  constructor() {
    this.cargarParametros();
    this.buscarSku.valueChanges
      .pipe(debounceTime(400), takeUntilDestroyed())
      .subscribe(() => this.aplicar());
    this.filtroEstado.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
    this.soloConCompra.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.aplicar());
  }

  private cargarParametros(): void {
    this.service.parametros().subscribe((p) => this.parametros.set(p));
  }

  private aplicar(): void {
    this.listado.filtrar({
      producto: this.buscarSku.value.trim().toUpperCase() || undefined,
      estado: this.filtroEstado.value || undefined,
      con_compra: this.soloConCompra.value ? 'true' : undefined,
      ordering: '-cantidad_recomendada',
    });
    this.seleccion.set(new Set());
  }

  paginar(e: PageEvent): void {
    this.listado.irAPagina(e.pageIndex, e.pageSize);
  }

  seleccionable(r: RecomendacionReposicion): boolean {
    return (
      this.puedeCrearOrden &&
      +r.cantidad_recomendada > 0 &&
      (r.estado === 'SUGERIDA' || r.estado === 'APROBADA') &&
      !!r.proveedor
    );
  }

  toggle(id: number): void {
    const s = new Set(this.seleccion());
    if (s.has(id)) {
      s.delete(id);
    } else {
      s.add(id);
    }
    this.seleccion.set(s);
  }

  private refrescar(): void {
    this.listado.recargar();
    this.seleccion.set(new Set());
  }

  generar(): void {
    this.generando.set(true);
    this.service.generar(this.minimoSemanas.value ?? undefined).subscribe({
      next: (r) => {
        this.generando.set(false);
        this.ultimoResumen.set(r);
        this.noti.exito(`${r.generadas} recomendaciones · ${r.con_compra_sugerida} con compra sugerida.`);
        this.refrescar();
      },
      error: () => this.generando.set(false),
    });
  }

  aprobar(r: RecomendacionReposicion): void {
    this.service.aprobar(r.id).subscribe(() => {
      this.noti.exito(`${r.producto} aprobado.`);
      this.refrescar();
    });
  }

  descartar(r: RecomendacionReposicion): void {
    this.service.descartar(r.id).subscribe(() => {
      this.noti.info(`${r.producto} descartado.`);
      this.refrescar();
    });
  }

  async generarOrden(): Promise<void> {
    const ids = [...this.seleccion()];
    if (!ids.length) return;
    const ok = await confirmar(this.dialog, {
      titulo: 'Generar orden de compra',
      mensaje: `Se crearán órdenes de compra a partir de ${ids.length} recomendación(es). ¿Continuar?`,
    });
    if (!ok) return;
    this.service.generarOrden(ids).subscribe((orden) => {
      this.noti.exito('Orden de compra generada.');
      this.refrescar();
      if (orden?.id) {
        this.router.navigate(['/compras', orden.id]);
      }
    });
  }

  async editarParametros(): Promise<void> {
    const actuales = this.parametros();
    if (!actuales) return;
    const ref = this.dialog.open(ParametrosDialog, { data: actuales, width: '380px' });
    const r = await ref.afterClosed().toPromise();
    if (r) {
      this.parametros.set(r);
    }
  }
}
