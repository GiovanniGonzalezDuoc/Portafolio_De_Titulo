export interface Categoria {
  id: number;
  nombre: string;
  descripcion: string;
  activo: boolean;
  creado_en: string;
}

export type Marca = Categoria;

export type UnidadMedida = 'UN' | 'KG' | 'LT' | 'MT' | 'CJ';

export interface Producto {
  id: number;
  sku: string;
  codigo_barras: string | null;
  nombre: string;
  descripcion: string;
  categoria: string;
  marca: string | null;
  unidad_medida: UnidadMedida;
  unidad_medida_display: string;
  precio_venta: number;
  precio_mayorista: number | null;
  costo_referencial: number;
  afecto_iva: boolean;
  stock_total: number;
  fecha_vencimiento: string | null;
  imagen: string | null;
  activo: boolean;
  creado_en: string;
  actualizado_en: string;
}

export interface ProductoEscritura {
  sku: string;
  codigo_barras?: string | null;
  nombre: string;
  descripcion?: string;
  categoria: string;
  marca?: string | null;
  unidad_medida?: UnidadMedida;
  precio_venta: number;
  precio_mayorista?: number | null;
  costo_referencial?: number;
  afecto_iva?: boolean;
  fecha_vencimiento?: string | null;
  activo?: boolean;
  /** Al crear: stock inicial. Al editar: cantidad a la que dejar el stock. */
  stock?: number;
}

export const UNIDADES: { valor: UnidadMedida; texto: string }[] = [
  { valor: 'UN', texto: 'Unidad' },
  { valor: 'KG', texto: 'Kilogramo' },
  { valor: 'LT', texto: 'Litro' },
  { valor: 'MT', texto: 'Metro' },
  { valor: 'CJ', texto: 'Caja' },
];
