import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { ApiService } from '../../core/services/api.service';
import { RecursoService } from '../../core/services/recurso.service';
import { Permiso, Rol, UsuarioCrear, UsuarioEditar, UsuarioListado } from './usuarios.models';

@Injectable({ providedIn: 'root' })
export class UsuariosService extends RecursoService<UsuarioListado, UsuarioCrear, UsuarioEditar> {
  protected readonly path = 'usuarios';

  activar(id: number) {
    return this.accion<UsuarioListado>(id, 'activar');
  }
  desactivar(id: number) {
    return this.accion<UsuarioListado>(id, 'desactivar');
  }
  resetearPassword(id: number, password_nuevo: string) {
    return this.accion<void>(id, 'resetear-password', { password_nuevo });
  }
}

@Injectable({ providedIn: 'root' })
export class RolesService {
  private readonly api = inject(ApiService);

  lista(): Observable<Rol[]> {
    return this.api.lista<Rol>('roles', { page_size: 100 }).pipe(map((p) => p.resultados));
  }
  permisos(): Observable<Permiso[]> {
    return this.api.get<Permiso[]>('permisos');
  }
  setPermisos(rolId: number, permisos: string[]): Observable<Rol> {
    return this.api.put<Rol>(`roles/${rolId}/permisos`, { permisos });
  }
  crear(datos: { nombre: string; descripcion?: string }): Observable<Rol> {
    return this.api.post<Rol>('roles', datos);
  }
  actualizar(rolId: number, datos: Partial<Pick<Rol, 'nombre' | 'descripcion' | 'activo'>>): Observable<Rol> {
    return this.api.patch<Rol>(`roles/${rolId}`, datos);
  }
  eliminar(rolId: number): Observable<void> {
    return this.api.delete<void>(`roles/${rolId}`);
  }
}
