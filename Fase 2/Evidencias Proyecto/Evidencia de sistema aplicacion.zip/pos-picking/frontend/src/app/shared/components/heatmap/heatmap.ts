import { Component, computed, input } from '@angular/core';

const DIAS = ['L', 'M', 'X', 'J', 'V', 'S', 'D'];

/**
 * Mapa de calor genérico: matriz `filas x columnas` de números, coloreada con
 * UNA sola escala secuencial (más oscuro/saturado = más alto) — nunca un
 * arcoíris, para no codificar magnitud con hues distintos.
 */
@Component({
  selector: 'app-heatmap',
  template: `
    <div class="hm">
      <div class="hm-grid" [style.grid-template-columns]="'repeat(' + columnas() + ', 1fr)'">
        @for (c of celdas(); track $index) {
          <div class="hm-celda" [style.background]="c.color" [title]="c.valor + ' ventas'"></div>
        }
      </div>
      @if (etiquetasColumna().length > 0) {
        <div class="hm-etiquetas" [style.grid-template-columns]="'repeat(' + columnas() + ', 1fr)'">
          @for (e of etiquetasColumna(); track e) {
            <span>{{ e }}</span>
          }
        </div>
      }
      <div class="hm-leyenda">
        <span>Baja</span>
        <div class="hm-escala">
          @for (n of [0, 1, 2, 3, 4]; track n) {
            <i [style.background]="colorNivel(n)"></i>
          }
        </div>
        <span>Alta</span>
      </div>
    </div>
  `,
  styles: `
    .hm {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .hm-grid {
      display: grid;
      gap: 4px;
    }
    .hm-celda {
      aspect-ratio: 1;
      border-radius: 4px;
      border: 1px solid var(--mat-sys-outline-variant);
      transition: background 0.4s ease;
    }
    .hm-etiquetas {
      display: grid;
      gap: 4px;
      font-size: 0.66rem;
      opacity: 0.6;
      text-align: center;
    }
    .hm-leyenda {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 0.66rem;
      opacity: 0.7;
      margin-top: 4px;
    }
    .hm-escala {
      display: flex;
      gap: 3px;
    }
    .hm-escala i {
      width: 12px;
      height: 8px;
      border-radius: 2px;
      display: block;
    }
  `,
})
export class Heatmap {
  readonly matriz = input.required<number[][]>();
  readonly etiquetasColumna = input<string[]>(DIAS);
  readonly color = input('var(--mat-sys-primary)');

  readonly columnas = computed(() => this.matriz()[0]?.length ?? 7);
  readonly maximo = computed(() => Math.max(...this.matriz().flat(), 1));

  private nivel(valor: number): number {
    if (valor <= 0) return 0;
    return Math.min(4, Math.ceil((valor / this.maximo()) * 4));
  }

  colorNivel(nivel: number): string {
    const pct = [6, 22, 42, 65, 92][nivel];
    return `color-mix(in srgb, ${this.color()} ${pct}%, var(--mat-sys-surface-container-highest))`;
  }

  readonly celdas = computed(() =>
    this.matriz()
      .flat()
      .map((valor) => ({ valor, color: this.colorNivel(this.nivel(valor)) })),
  );
}
