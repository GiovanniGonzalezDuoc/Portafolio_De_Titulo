import { Component, computed, effect, input, signal } from '@angular/core';

export interface PuntoBarra {
  etiqueta: string;
  valor: number;
}

/** Barras verticales simples (una serie) con crecimiento animado y hover. */
@Component({
  selector: 'app-mini-bars',
  template: `
    <div class="mb">
      <svg viewBox="0 0 100 50" preserveAspectRatio="none" role="img">
        @for (b of barras(); track b.etiqueta; let i = $index) {
          <rect
            class="mb-barra"
            [class.mb-hover]="hoverIdx() === i"
            [attr.x]="b.x"
            [attr.width]="anchoBarra()"
            [attr.y]="crecido() ? b.y : 50"
            [attr.height]="crecido() ? b.alto : 0"
            rx="1.2"
            (pointerenter)="hoverIdx.set(i)"
            (pointerleave)="hoverIdx.set(null)"
          />
        }
      </svg>
      <div class="mb-ejes">
        @for (b of barras(); track b.etiqueta) {
          <span>{{ b.etiqueta }}</span>
        }
      </div>
      @if (activo(); as a) {
        <div class="mb-tooltip" [style.left.%]="a.centroPct">
          <strong>{{ formato()(a.valor) }}</strong>
          <span>{{ a.etiqueta }}</span>
        </div>
      }
    </div>
  `,
  styles: `
    .mb {
      position: relative;
    }
    svg {
      width: 100%;
      height: 130px;
      display: block;
      overflow: visible;
    }
    .mb-barra {
      fill: var(--mat-sys-primary);
      transition: height 0.7s cubic-bezier(0.22, 1, 0.36, 1), y 0.7s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.15s ease;
      cursor: pointer;
    }
    .mb-barra.mb-hover {
      fill: var(--acento-lima);
    }
    .mb-ejes {
      display: flex;
      margin-top: 4px;
    }
    .mb-ejes span {
      flex: 1;
      text-align: center;
      font-size: 0.66rem;
      opacity: 0.6;
    }
    .mb-tooltip {
      position: absolute;
      top: -6px;
      transform: translate(-50%, -100%);
      background: var(--mat-sys-inverse-surface);
      color: var(--mat-sys-inverse-on-surface);
      border-radius: 8px;
      padding: 5px 9px;
      font-size: 0.74rem;
      line-height: 1.3;
      display: flex;
      flex-direction: column;
      align-items: center;
      white-space: nowrap;
      pointer-events: none;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
      z-index: 2;
    }
    .mb-tooltip strong {
      font-size: 0.8rem;
      font-weight: 700;
    }
    .mb-tooltip span {
      opacity: 0.85;
    }
  `,
})
export class MiniBars {
  readonly datos = input.required<PuntoBarra[]>();
  readonly formato = input<(v: number) => string>((v) => `${Math.round(v)}`);

  readonly hoverIdx = signal<number | null>(null);
  readonly crecido = signal(false);

  constructor() {
    effect(() => {
      this.datos();
      this.crecido.set(false);
      requestAnimationFrame(() => requestAnimationFrame(() => this.crecido.set(true)));
    });
  }

  readonly anchoBarra = computed(() => {
    const n = this.datos().length || 1;
    return (100 / n) * 0.55;
  });

  readonly barras = computed(() => {
    const n = this.datos().length || 1;
    const max = Math.max(...this.datos().map((d) => d.valor), 1);
    const anchoCelda = 100 / n;
    const ancho = this.anchoBarra();
    return this.datos().map((d, i) => {
      const alto = (d.valor / max) * 44;
      return {
        etiqueta: d.etiqueta,
        valor: d.valor,
        x: i * anchoCelda + (anchoCelda - ancho) / 2,
        y: 48 - alto,
        alto,
      };
    });
  });

  readonly activo = computed(() => {
    const i = this.hoverIdx();
    if (i === null) return null;
    const b = this.barras()[i];
    if (!b) return null;
    const n = this.datos().length || 1;
    const anchoCelda = 100 / n;
    return { ...b, centroPct: i * anchoCelda + anchoCelda / 2 };
  });
}
