import { DestroyRef, Signal, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Observable, Subject, debounceTime, switchMap } from 'rxjs';

import { Pagina, ParamsListado } from '../../core/models/api.models';

export interface EstadoListado<T> {
  readonly datos: Signal<T[]>;
  readonly total: Signal<number>;
  readonly cargando: Signal<boolean>;
  readonly pagina: Signal<number>;
  readonly tamano: Signal<number>;
  irAPagina(indiceCero: number, tamano: number): void;
  filtrar(filtros: ParamsListado): void;
  recargar(): void;
}

/**
 * Encapsula el patrón "listado paginado con filtros" que usan casi todas las
 * pantallas: mantiene página/tamaño/filtros, hace debounce y expone signals.
 *
 * Debe llamarse dentro de un contexto de inyección (constructor/field inicial).
 */
export function crearListado<T>(
  cargar: (params: ParamsListado) => Observable<Pagina<T>>,
): EstadoListado<T> {
  const destroyRef = inject(DestroyRef);

  const datos = signal<T[]>([]);
  const total = signal(0);
  const cargando = signal(false);
  const pagina = signal(1);
  const tamano = signal(25);
  const filtros = signal<ParamsListado>({});

  const disparador = new Subject<void>();

  disparador
    .pipe(
      debounceTime(200),
      switchMap(() => {
        cargando.set(true);
        return cargar({ page: pagina(), page_size: tamano(), ...filtros() });
      }),
      takeUntilDestroyed(destroyRef),
    )
    .subscribe({
      next: (p) => {
        datos.set(p.resultados);
        total.set(p.conteo);
        cargando.set(false);
      },
      error: () => cargando.set(false),
    });

  // Primera carga.
  queueMicrotask(() => disparador.next());

  return {
    datos: datos.asReadonly(),
    total: total.asReadonly(),
    cargando: cargando.asReadonly(),
    pagina: computed(() => pagina() - 1),
    tamano: tamano.asReadonly(),
    irAPagina(indiceCero, t) {
      pagina.set(indiceCero + 1);
      tamano.set(t);
      disparador.next();
    },
    filtrar(f) {
      filtros.set(f);
      pagina.set(1);
      disparador.next();
    },
    recargar() {
      disparador.next();
    },
  };
}
