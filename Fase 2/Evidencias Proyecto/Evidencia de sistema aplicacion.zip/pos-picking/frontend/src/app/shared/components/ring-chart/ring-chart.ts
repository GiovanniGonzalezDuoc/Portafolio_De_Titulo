import { Component, computed, effect, input, signal } from '@angular/core';

export interface SegmentoAnillo {
  etiqueta: string;
  valor: number;
  color: string;
}

const RADIO = 38;
const CIRCUNFERENCIA = 2 * Math.PI * RADIO;

interface ArcoRenderizado extends SegmentoAnillo {
  dasharray: string;
  dashoffset: number;
  pct: number;
}

/**
 * Anillo de desglose (donut) — al pasar el mouse por un segmento, se
 * resalta con brillo y el centro cambia del total a ese segmento. Los
 * arcos crecen desde cero en cada carga/actualización. Reemplazo
 * completo del antiguo `app-donut-chart` (borrado, no reciclado).
 */
@Component({
  selector: 'app-ring-chart',
  template: `
    <div class="rc">
      <svg viewBox="0 0 100 100" role="img" [attr.aria-label]="ariaLabel()">
        <circle class="rc-fondo" cx="50" cy="50" [attr.r]="radio" />
        @for (a of arcos(); track a.etiqueta; let i = $index) {
          <circle
            class="rc-arco"
            [class.rc-atenuado]="hoverIdx() !== null && hoverIdx() !== i"
            [class.rc-resaltado]="hoverIdx() === i"
            cx="50"
            cy="50"
            [attr.r]="radio"
            [attr.stroke]="a.color"
            [style.color]="a.color"
            [attr.stroke-dasharray]="crecido() ? a.dasharray : '0 ' + circunferencia"
            [attr.stroke-dashoffset]="a.dashoffset"
            [attr.aria-label]="a.etiqueta + ': ' + a.valor + ' (' + a.pct + '%)'"
            tabindex="0"
            (pointerenter)="hoverIdx.set(i)"
            (pointerleave)="hoverIdx.set(null)"
            (focus)="hoverIdx.set(i)"
            (blur)="hoverIdx.set(null)"
          />
        }
      </svg>
      <div class="rc-centro">
        @if (segmentoActivo(); as s) {
          <strong>{{ s.valor }}</strong>
          <span class="rc-tenue">{{ s.etiqueta }}</span>
        } @else {
          <strong [class.rc-valor-largo]="(centroTexto()?.length ?? 0) > 6">{{ centroTexto() ?? total() }}</strong>
          @if (centroEtiqueta()) {
            <span class="rc-tenue">{{ centroEtiqueta() }}</span>
          }
        }
      </div>
    </div>
  `,
  styles: `
    .rc {
      position: relative;
      width: 136px;
      height: 136px;
      flex: none;
    }
    svg {
      width: 100%;
      height: 100%;
      transform: rotate(-90deg);
      overflow: visible;
    }
    circle {
      fill: none;
      stroke-width: 11;
    }
    .rc-fondo {
      stroke: var(--mat-sys-surface-container-highest);
    }
    .rc-arco {
      stroke-linecap: round;
      pointer-events: stroke;
      cursor: pointer;
      outline: none;
      transition:
        stroke-dasharray 0.7s cubic-bezier(0.22, 1, 0.36, 1),
        stroke-dashoffset 0.4s ease,
        stroke-width 0.15s ease,
        opacity 0.2s ease;
    }
    .rc-arco.rc-resaltado {
      stroke-width: 14;
      filter: drop-shadow(0 0 6px currentColor);
    }
    .rc-arco.rc-atenuado {
      opacity: 0.28;
    }
    .rc-centro {
      position: absolute;
      inset: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      line-height: 1.2;
      text-align: center;
      padding: 0 8px;
    }
    .rc-centro strong {
      font-family: var(--dash-mono, inherit);
      font-size: 1.25rem;
      font-variant-numeric: tabular-nums;
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .rc-centro strong.rc-valor-largo {
      font-size: 0.86rem;
    }
    .rc-tenue {
      font-size: 0.66rem;
      opacity: 0.65;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      max-width: 100%;
    }
  `,
})
export class RingChart {
  readonly segmentos = input.required<SegmentoAnillo[]>();
  readonly centroTexto = input<string | null>(null);
  readonly centroEtiqueta = input<string | null>(null);

  readonly radio = RADIO;
  readonly circunferencia = CIRCUNFERENCIA;
  readonly hoverIdx = signal<number | null>(null);
  readonly crecido = signal(false);

  constructor() {
    effect(() => {
      this.segmentos();
      this.crecido.set(false);
      requestAnimationFrame(() => requestAnimationFrame(() => this.crecido.set(true)));
    });
  }

  readonly total = computed(() => this.segmentos().reduce((acc, s) => acc + s.valor, 0));
  readonly ariaLabel = computed(() => this.segmentos().map((s) => `${s.etiqueta}: ${s.valor}`).join(', '));

  readonly arcos = computed<ArcoRenderizado[]>(() => {
    const total = this.total();
    if (total <= 0) return [];
    let acumulado = 0;
    const resultado: ArcoRenderizado[] = [];
    for (const s of this.segmentos()) {
      if (s.valor <= 0) continue;
      const largo = (s.valor / total) * CIRCUNFERENCIA;
      resultado.push({
        ...s,
        dasharray: `${largo} ${CIRCUNFERENCIA - largo}`,
        dashoffset: -acumulado,
        pct: Math.round((s.valor / total) * 100),
      });
      acumulado += largo;
    }
    return resultado;
  });

  readonly segmentoActivo = computed<ArcoRenderizado | null>(() => {
    const i = this.hoverIdx();
    const arcosVal = this.arcos();
    return i !== null && arcosVal[i] ? arcosVal[i] : null;
  });
}
