/**
 * Convierte un `Date` a `YYYY-MM-DD` usando sus componentes LOCALES.
 *
 * `Date.toISOString()` siempre devuelve la fecha en UTC — en Chile (UTC-3/-4)
 * eso corre la fecha al día siguiente apenas se pasa cierta hora de la tarde
 * (p. ej. "hoy" a las 22:00 se convierte en "mañana"). Como el backend trata
 * estos strings como fechas de calendario en hora local (``TIME_ZONE =
 * "America/Santiago"``), ese corrimiento hacía que los rangos "hoy / esta
 * semana / este mes" quedaran pidiendo un día sin ventas todavía — se veían
 * en $0 aunque sí hubiera ventas registradas.
 */
export function fechaLocalIso(d: Date): string {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}
