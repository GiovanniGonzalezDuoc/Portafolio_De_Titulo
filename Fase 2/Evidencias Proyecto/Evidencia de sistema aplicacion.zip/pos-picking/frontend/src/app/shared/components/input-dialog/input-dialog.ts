import { Component, inject, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { firstValueFrom } from 'rxjs';

export interface InputDialogData {
  titulo: string;
  etiqueta: string;
  tipo?: 'text' | 'password' | 'number' | 'email';
  placeholder?: string;
  requerido?: boolean;
  confirmar?: string;
  /** Formatea la entrada con separador de miles (`20.000`). Devuelve el número. */
  miles?: boolean;
  /** Precarga el campo (p. ej. el email de contacto ya guardado del proveedor). */
  valorInicial?: string;
}

@Component({
  selector: 'app-input-dialog',
  imports: [MatDialogModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  template: `
    <h2 mat-dialog-title>{{ data.titulo }}</h2>
    <mat-dialog-content>
      <mat-form-field appearance="outline" class="ancho">
        <mat-label>{{ data.etiqueta }}</mat-label>
        <input
          matInput
          [type]="data.miles ? 'text' : (data.tipo ?? 'text')"
          [attr.inputmode]="data.miles ? 'numeric' : null"
          [placeholder]="data.placeholder ?? ''"
          [value]="valor()"
          (input)="alEscribir($any($event.target))"
          (keyup.enter)="aceptar()"
        />
      </mat-form-field>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button mat-dialog-close>Cancelar</button>
      <button
        mat-flat-button
        color="primary"
        (click)="aceptar()"
        [disabled]="data.requerido !== false && !valor().trim()"
      >
        {{ data.confirmar ?? 'Aceptar' }}
      </button>
    </mat-dialog-actions>
  `,
  styles: `.ancho { width: 320px; max-width: 100%; }`,
})
export class InputDialog {
  readonly data = inject<InputDialogData>(MAT_DIALOG_DATA);
  private readonly ref = inject(MatDialogRef<InputDialog>);
  private readonly fmt = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 0 });
  readonly valor = signal(this.data.valorInicial ?? '');

  alEscribir(input: HTMLInputElement): void {
    if (this.data.miles) {
      const digitos = input.value.replace(/\D/g, '');
      const texto = digitos ? this.fmt.format(parseInt(digitos, 10)) : '';
      this.valor.set(texto);
      input.value = texto;
      input.setSelectionRange(texto.length, texto.length);
    } else {
      this.valor.set(input.value);
    }
  }

  aceptar(): void {
    if (this.data.requerido !== false && !this.valor().trim()) return;
    // Con `miles` se devuelve el número en texto plano (sin puntos).
    this.ref.close(this.data.miles ? this.valor().replace(/\D/g, '') : this.valor());
  }
}

/** `await pedirTexto(dialog, { ... })` → string | null (null si cancela). */
export async function pedirTexto(
  dialog: MatDialog,
  data: InputDialogData,
): Promise<string | null> {
  const ref = dialog.open(InputDialog, { data });
  const r = await firstValueFrom(ref.afterClosed());
  return typeof r === 'string' ? r : null;
}
