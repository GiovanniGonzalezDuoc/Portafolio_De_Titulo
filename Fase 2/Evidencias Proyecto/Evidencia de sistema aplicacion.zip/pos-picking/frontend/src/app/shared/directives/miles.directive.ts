import { Directive, ElementRef, HostListener, OnDestroy, OnInit, inject } from '@angular/core';
import { NgControl } from '@angular/forms';
import { Subscription } from 'rxjs';

/**
 * Formatea un input numérico con separador de miles a la chilena
 * (`20000` → `20.000`) mientras se escribe. El valor del `FormControl`
 * sigue siendo un número (o `null` si está vacío).
 *
 * Uso: `<input matInput type="text" inputmode="numeric" appMiles formControlName="monto" />`
 */
@Directive({
  selector: 'input[appMiles]',
})
export class MilesDirective implements OnInit, OnDestroy {
  private readonly el = inject<ElementRef<HTMLInputElement>>(ElementRef);
  private readonly control = inject(NgControl);
  private readonly fmt = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 0 });
  private sub?: Subscription;

  ngOnInit(): void {
    this.pintar(this.control.value);
    this.sub = this.control.control?.valueChanges.subscribe((v) => {
      // Solo re-pinta cuando el cambio viene de fuera (reset, patchValue…),
      // no mientras el usuario teclea en este mismo input.
      if (document.activeElement !== this.el.nativeElement) {
        this.pintar(v);
      }
    });
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
  }

  @HostListener('input')
  onInput(): void {
    const num = this.parsear(this.el.nativeElement.value);
    this.control.control?.setValue(num, { emitEvent: true });
    const texto = num === null ? '' : this.fmt.format(num);
    this.el.nativeElement.value = texto;
    this.el.nativeElement.setSelectionRange(texto.length, texto.length);
  }

  @HostListener('blur')
  onBlur(): void {
    this.pintar(this.control.value);
  }

  private parsear(txt: string): number | null {
    const digitos = (txt || '').replace(/\D/g, '');
    return digitos ? parseInt(digitos, 10) : null;
  }

  private pintar(valor: unknown): void {
    const n =
      typeof valor === 'number' && Number.isFinite(valor)
        ? valor
        : this.parsear(String(valor ?? ''));
    this.el.nativeElement.value = n === null ? '' : this.fmt.format(n);
  }
}
