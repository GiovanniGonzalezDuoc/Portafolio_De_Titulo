import { Pipe, PipeTransform } from '@angular/core';

/**
 * Formatea una cantidad de inventario (viene como string decimal "40.000"
 * desde la API) sin ceros de más: "40", "40,5", "1.234". Evita que "40.000"
 * se lea como cuarenta mil en la interfaz en español.
 */
@Pipe({ name: 'cantidad' })
export class CantidadPipe implements PipeTransform {
  private readonly formato = new Intl.NumberFormat('es-CL', {
    maximumFractionDigits: 3,
  });

  transform(valor: number | string | null | undefined): string {
    if (valor === null || valor === undefined || valor === '') {
      return '0';
    }
    const n = typeof valor === 'string' ? Number(valor) : valor;
    return Number.isFinite(n) ? this.formato.format(n) : String(valor);
  }
}
