import { Component, ElementRef, computed, effect, input, signal, viewChild } from '@angular/core';

export interface PuntoTendencia {
  periodo: string;
  valor: number;
}

const W = 640;
const H = 180;
const PAD = { l: 6, r: 6, t: 12, b: 20 };
const INNER_W = W - PAD.l - PAD.r;
const INNER_H = H - PAD.t - PAD.b;

interface Coord {
  x: number;
  y: number;
  periodo: string;
  valor: number;
}

/** Convierte una serie de puntos en un `d` de SVG suave (Catmull-Rom -> Bézier
 * cúbica, factor de tensión 1/6 estándar) — en vez de segmentos rectos. */
function trazoSuave(pts: Coord[]): string {
  if (pts.length === 0) return '';
  if (pts.length === 1) return `M ${pts[0].x},${pts[0].y}`;
  let d = `M ${pts[0].x},${pts[0].y}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] ?? pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] ?? p2;
    const c1x = p1.x + (p2.x - p0.x) / 6;
    const c1y = p1.y + (p2.y - p0.y) / 6;
    const c2x = p2.x - (p3.x - p1.x) / 6;
    const c2y = p2.y - (p3.y - p1.y) / 6;
    d += ` C ${c1x},${c1y} ${c2x},${c2y} ${p2.x},${p2.y}`;
  }
  return d;
}

/**
 * Línea de tendencia con curva suave, crosshair + tooltip HTML propio (no
 * `<title>` nativo) y trazo animado que se redibuja en cada carga/cambio
 * de rango. Reemplazo completo del antiguo `app-line-chart` (borrado, no
 * reciclado) — mismo tipo de dato de entrada, implementación nueva.
 */
@Component({
  selector: 'app-trend-chart',
  template: `
    @if (puntos().length > 0) {
      <div class="tc">
        <div class="tc-lienzo">
          <svg
            #svgEl
            [attr.viewBox]="'0 0 ' + ancho + ' ' + alto"
            preserveAspectRatio="none"
            role="img"
            [attr.aria-label]="etiqueta()"
            tabindex="0"
            (pointermove)="mover($event)"
            (pointerleave)="salir()"
          >
            <defs>
              <linearGradient [attr.id]="gradId" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" [attr.stop-color]="color()" stop-opacity="0.35" />
                <stop offset="100%" [attr.stop-color]="color()" stop-opacity="0" />
              </linearGradient>
            </defs>
            <path [attr.d]="areaD()" [attr.fill]="'url(#' + gradId + ')'" stroke="none" [style.opacity]="listo() ? 1 : 0" />
            @if (lineaComparacionD(); as dComp) {
              <path
                [attr.d]="dComp"
                fill="none"
                stroke="var(--mat-sys-outline)"
                stroke-width="1.6"
                stroke-dasharray="5 4"
                pathLength="1"
                [style.strokeDashoffset]="listo() ? 0 : 1"
              />
            }
            <path
              [attr.d]="lineaD()"
              fill="none"
              [attr.stroke]="color()"
              stroke-width="2.5"
              stroke-linecap="round"
              pathLength="1"
              [style.strokeDasharray]="1"
              [style.strokeDashoffset]="listo() ? 0 : 1"
              [style.filter]="'drop-shadow(0 0 5px ' + color() + ')'"
            />
            @if (puntoHover(); as p) {
              <line [attr.x1]="p.x" [attr.y1]="pad.t" [attr.x2]="p.x" [attr.y2]="pad.t + innerH" class="tc-crosshair" />
              <circle [attr.cx]="p.x" [attr.cy]="p.y" r="5" [attr.fill]="color()" class="tc-punto-hover" />
            }
          </svg>
          @if (puntoHover(); as p) {
            <div class="tc-tooltip" [style.left.%]="(p.x / ancho) * 100" [style.top.%]="(p.y / alto) * 100">
              <strong>{{ formato()(p.valor) }}</strong>
              <span>{{ p.periodo }}</span>
            </div>
          }
        </div>
        <div class="tc-eje">
          <span>{{ puntos()[0].periodo }}</span>
          @if (puntos().length > 1) {
            <span>{{ puntos()[puntos().length - 1].periodo }}</span>
          }
        </div>
      </div>
    } @else {
      <p class="tc-vacio">Sin datos en este rango.</p>
    }
  `,
  styles: `
    .tc {
      border: 1px solid var(--dash-borde, var(--mat-sys-outline-variant));
      border-radius: var(--radio, 12px);
      padding: 10px 10px 6px;
      background: var(--dash-vidrio, transparent);
    }
    .tc-lienzo {
      position: relative;
    }
    svg {
      width: 100%;
      height: 150px;
      display: block;
      outline: none;
      cursor: crosshair;
      overflow: visible;
    }
    .tc-crosshair {
      stroke: var(--mat-sys-outline);
      stroke-width: 1;
      pointer-events: none;
    }
    .tc-punto-hover {
      stroke: var(--mat-sys-surface);
      stroke-width: 2;
      pointer-events: none;
    }
    .tc-tooltip {
      position: absolute;
      transform: translate(-50%, -130%);
      background: var(--mat-sys-inverse-surface);
      color: var(--mat-sys-inverse-on-surface);
      border-radius: 8px;
      padding: 5px 9px;
      font-size: 0.74rem;
      line-height: 1.3;
      display: flex;
      flex-direction: column;
      align-items: center;
      white-space: nowrap;
      pointer-events: none;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
      z-index: 1;
    }
    .tc-tooltip strong {
      font-family: var(--dash-mono, inherit);
      font-size: 0.84rem;
      font-weight: 700;
    }
    .tc-tooltip span {
      opacity: 0.8;
      font-size: 0.68rem;
    }
    .tc-eje {
      display: flex;
      justify-content: space-between;
      font-size: 0.72rem;
      color: var(--mat-sys-on-surface-variant);
      padding: 4px 2px 0;
    }
    .tc-vacio {
      opacity: 0.65;
      font-size: 0.85rem;
      margin: 12px 0;
    }
  `,
})
export class TrendChart {
  readonly datos = input.required<PuntoTendencia[]>();
  readonly etiqueta = input('Tendencia');
  readonly color = input('var(--mat-sys-primary)');
  readonly formato = input<(v: number) => string>((v) => `${v}`);
  /** Serie de referencia opcional (ej. "período anterior"), alineada por
   * POSICIÓN con `datos` (mismo largo) — se dibuja como línea punteada
   * discreta, sin tooltip propio, compartiendo la escala de la serie principal. */
  readonly datosComparacion = input<number[] | null>(null);

  private static contador = 0;
  readonly gradId = `tc-grad-${TrendChart.contador++}`;

  private readonly svgEl = viewChild<ElementRef<SVGSVGElement>>('svgEl');
  private readonly hoverIndex = signal<number | null>(null);
  readonly listo = signal(false);

  readonly ancho = W;
  readonly alto = H;
  readonly pad = PAD;
  readonly innerH = INNER_H;

  constructor() {
    effect(() => {
      this.datos();
      this.listo.set(false);
      requestAnimationFrame(() => requestAnimationFrame(() => this.listo.set(true)));
    });
  }

  private readonly escala = computed(() => {
    const serie = this.datos();
    const comparacion = this.datosComparacion() ?? [];
    const valores = [...serie.map((p) => p.valor), ...comparacion];
    const max = Math.max(...valores, 1) * 1.1;
    const min = Math.min(0, ...valores);
    const rango = max - min || 1;
    const n = serie.length;
    const px = (i: number): number => PAD.l + (n <= 1 ? INNER_W / 2 : (i / (n - 1)) * INNER_W);
    const py = (v: number): number => PAD.t + INNER_H - ((v - min) / rango) * INNER_H;
    return { px, py };
  });

  readonly puntos = computed<Coord[]>(() => {
    const serie = this.datos();
    if (serie.length === 0) return [];
    const { px, py } = this.escala();
    return serie.map((p, i) => ({ x: px(i), y: py(p.valor), periodo: p.periodo, valor: p.valor }));
  });

  readonly lineaD = computed(() => trazoSuave(this.puntos()));

  readonly lineaComparacionD = computed(() => {
    const comparacion = this.datosComparacion();
    if (!comparacion || comparacion.length === 0) return null;
    const { px, py } = this.escala();
    const pts = comparacion.map((v, i) => ({ x: px(i), y: py(v), periodo: '', valor: v }));
    return trazoSuave(pts);
  });
  readonly areaD = computed(() => {
    const pts = this.puntos();
    if (pts.length === 0) return '';
    const base = PAD.t + INNER_H;
    return `${trazoSuave(pts)} L ${pts[pts.length - 1].x},${base} L ${pts[0].x},${base} Z`;
  });

  readonly puntoHover = computed<Coord | null>(() => {
    const i = this.hoverIndex();
    const pts = this.puntos();
    return i !== null && pts[i] ? pts[i] : null;
  });

  formatear(v: number): string {
    return this.formato()(v);
  }

  mover(evento: PointerEvent): void {
    const el = this.svgEl()?.nativeElement;
    const pts = this.puntos();
    if (!el || pts.length === 0) return;
    const rect = el.getBoundingClientRect();
    const ratio = (evento.clientX - rect.left) / rect.width;
    const xViewBox = ratio * this.ancho;
    let masCercano = 0;
    let distMin = Infinity;
    pts.forEach((p, i) => {
      const dist = Math.abs(p.x - xViewBox);
      if (dist < distMin) {
        distMin = dist;
        masCercano = i;
      }
    });
    this.hoverIndex.set(masCercano);
  }

  salir(): void {
    this.hoverIndex.set(null);
  }
}
