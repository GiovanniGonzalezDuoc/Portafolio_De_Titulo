import { Component, computed, effect, input, signal } from '@angular/core';

/**
 * Medidor semicircular (0-100) — el arco crece desde cero en cada carga o
 * actualización, con el mismo truco de `pathLength="1"` que usan
 * `ring-chart`/`trend-chart` para no depender del largo real del trazo.
 */
@Component({
  selector: 'app-gauge',
  template: `
    <div class="gz">
      <svg viewBox="0 0 200 120" role="img" [attr.aria-label]="etiqueta() + ': ' + valor() + ' de 100'">
        <path class="gz-fondo" d="M25 100 A75 75 0 0 1 175 100" pathLength="1" />
        <path
          class="gz-valor"
          d="M25 100 A75 75 0 0 1 175 100"
          pathLength="1"
          [attr.stroke]="color()"
          [style.color]="color()"
          [style.stroke-dashoffset]="crecido() ? 1 - pctClamp() : 1"
        />
      </svg>
      <div class="gz-texto">
        <strong>{{ valor() }}</strong>
        <span>{{ etiqueta() }}</span>
      </div>
    </div>
  `,
  styles: `
    .gz {
      position: relative;
      display: grid;
      place-items: center;
      width: 100%;
      max-width: 220px;
      margin: 0 auto;
    }
    svg {
      width: 100%;
      overflow: visible;
    }
    path {
      fill: none;
      stroke-width: 15;
      stroke-linecap: round;
      stroke-dasharray: 1;
    }
    .gz-fondo {
      stroke: var(--mat-sys-surface-container-highest);
    }
    .gz-valor {
      transition: stroke-dashoffset 0.9s cubic-bezier(0.22, 1, 0.36, 1);
      filter: drop-shadow(0 0 6px color-mix(in srgb, currentColor 55%, transparent));
    }
    .gz-texto {
      position: absolute;
      bottom: 6px;
      text-align: center;
      line-height: 1.15;
    }
    .gz-texto strong {
      font-family: var(--dash-mono, inherit);
      font-size: 2rem;
      font-variant-numeric: tabular-nums;
    }
    .gz-texto span {
      display: block;
      font-size: 0.72rem;
      opacity: 0.65;
      margin-top: 2px;
    }
  `,
})
export class Gauge {
  readonly valor = input.required<number>();
  readonly etiqueta = input('');
  readonly color = input('var(--mat-sys-primary)');

  readonly crecido = signal(false);
  readonly pctClamp = computed(() => Math.max(0, Math.min(100, this.valor())) / 100);

  constructor() {
    effect(() => {
      this.valor();
      this.crecido.set(false);
      requestAnimationFrame(() => requestAnimationFrame(() => this.crecido.set(true)));
    });
  }
}
