import { Component, effect, input, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

function easeOutCubic(t: number): number {
  return 1 - Math.pow(1 - t, 3);
}

/**
 * Tarjeta de métrica con el número CONTANDO hacia su valor real (no un
 * texto estático) cada vez que cambia — insignia de icono con brillo,
 * franja de color en el borde superior, y variación opcional como pill
 * con flecha. `valor` es el número crudo (no formateado); `formato` lo
 * convierte a texto en cada frame de la animación.
 */
@Component({
  selector: 'app-metric-card',
  imports: [MatIconModule],
  template: `
    <div class="mc" [class.mc-destacada]="destacada()" [style.--mc-color]="color()">
      <div class="mc-anillo"></div>
      <div class="mc-fila">
        <div class="mc-icono">
          <mat-icon>{{ icono() }}</mat-icon>
        </div>
        @if (variacionPct() !== null) {
          <span class="mc-variacion" [class.mc-variacion--neg]="variacionPct()! < 0">
            <mat-icon>{{ variacionPct()! >= 0 ? 'trending_up' : 'trending_down' }}</mat-icon>
            {{ variacionPct()! >= 0 ? '+' : '' }}{{ variacionPct() }}%
          </span>
        }
      </div>
      <span class="mc-etiqueta">{{ etiqueta() }}</span>
      <span class="mc-valor">{{ formato()(mostrado()) }}</span>
    </div>
  `,
  styles: `
    :host {
      display: block;
      height: 100%;
    }
    .mc {
      position: relative;
      height: 100%;
      padding: 16px 16px 14px;
      display: flex;
      flex-direction: column;
      gap: 8px;
      overflow: hidden;
    }
    .mc-anillo {
      position: absolute;
      right: -26px;
      top: -30px;
      width: 78px;
      height: 78px;
      border-radius: 50%;
      border: 1px solid color-mix(in srgb, var(--mc-color) 30%, transparent);
      pointer-events: none;
    }
    .mc-fila {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .mc-icono {
      display: grid;
      place-items: center;
      width: 32px;
      height: 32px;
      border-radius: 9px;
      background: color-mix(in srgb, var(--mc-color) 16%, transparent);
      color: var(--mc-color);
    }
    .mc-icono mat-icon {
      font-size: 17px;
      width: 17px;
      height: 17px;
    }
    .mc-etiqueta {
      font-size: 0.68rem;
      opacity: 0.62;
      font-weight: 700;
      letter-spacing: 0.05em;
      text-transform: uppercase;
    }
    .mc-valor {
      font-family: var(--dash-mono, inherit);
      font-size: 1.4rem;
      font-weight: 700;
      letter-spacing: -0.01em;
      font-variant-numeric: tabular-nums;
    }
    .mc-destacada .mc-valor {
      font-size: 1.85rem;
    }
    .mc-variacion {
      display: inline-flex;
      align-items: center;
      gap: 2px;
      padding: 2px 8px 2px 6px;
      border-radius: 999px;
      font-size: 0.7rem;
      font-weight: 700;
      color: var(--color-positivo);
      background: color-mix(in srgb, var(--color-positivo) 14%, transparent);
    }
    .mc-variacion mat-icon {
      font-size: 14px;
      width: 14px;
      height: 14px;
    }
    .mc-variacion--neg {
      color: var(--color-negativo);
      background: color-mix(in srgb, var(--color-negativo) 14%, transparent);
    }
  `,
})
export class MetricCard {
  readonly icono = input.required<string>();
  readonly etiqueta = input.required<string>();
  readonly valor = input.required<number>();
  readonly formato = input<(v: number) => string>((v) => `${Math.round(v)}`);
  readonly color = input('var(--mat-sys-primary)');
  readonly variacionPct = input<number | null>(null);
  readonly destacada = input(false);

  readonly mostrado = signal(0);

  constructor() {
    let anterior = 0;
    let frame: number | undefined;
    effect((onCleanup) => {
      const objetivo = this.valor();
      const desde = anterior;
      anterior = objetivo;
      const inicio = performance.now();
      const duracion = 700;
      const paso = (ahora: number): void => {
        const t = Math.min(1, (ahora - inicio) / duracion);
        this.mostrado.set(desde + (objetivo - desde) * easeOutCubic(t));
        if (t < 1) frame = requestAnimationFrame(paso);
      };
      frame = requestAnimationFrame(paso);
      onCleanup(() => {
        if (frame) cancelAnimationFrame(frame);
      });
    });
  }
}
