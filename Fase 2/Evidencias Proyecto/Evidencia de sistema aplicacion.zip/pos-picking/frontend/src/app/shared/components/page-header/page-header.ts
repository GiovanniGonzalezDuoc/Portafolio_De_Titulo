import { Component, input } from '@angular/core';

/** Encabezado de página: título + subtítulo + zona de acciones (ng-content). */
@Component({
  selector: 'app-page-header',
  template: `
    <header class="ph">
      <div class="ph-txt">
        <h1>{{ titulo() }}</h1>
        @if (subtitulo()) {
          <p>{{ subtitulo() }}</p>
        }
      </div>
      <div class="ph-acciones">
        <ng-content />
      </div>
    </header>
  `,
  styles: `
    .ph {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
      align-items: flex-end;
      justify-content: space-between;
      margin-bottom: 20px;
      padding-bottom: 14px;
      border-bottom: 1px solid var(--mat-sys-outline-variant);
    }
    h1 {
      margin: 0;
      font-size: 1.6rem;
      font-weight: 600;
      letter-spacing: -0.01em;
    }
    p {
      margin: 4px 0 0;
      opacity: 0.7;
      font-size: 0.9rem;
    }
    .ph-acciones {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }
  `,
})
export class PageHeader {
  readonly titulo = input.required<string>();
  readonly subtitulo = input<string>();
}
