import { Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';

export interface VisorImagenData {
  url: string;
  titulo?: string;
}

/** Diálogo simple para ver a tamaño completo una foto de producto. */
@Component({
  selector: 'app-visor-imagen',
  imports: [MatDialogModule, MatButtonModule, MatIconModule],
  template: `
    <button mat-icon-button class="cerrar" mat-dialog-close aria-label="Cerrar">
      <mat-icon>close</mat-icon>
    </button>
    <img [src]="data.url" [alt]="data.titulo ?? ''" />
    @if (data.titulo) {
      <p class="titulo">{{ data.titulo }}</p>
    }
  `,
  styles: `
    :host {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
      position: relative;
      padding: 8px;
    }
    img {
      max-width: min(80vw, 640px);
      max-height: 75vh;
      object-fit: contain;
      border-radius: 8px;
    }
    .titulo {
      margin: 0;
      font-weight: 600;
      text-align: center;
    }
    .cerrar {
      position: absolute;
      top: -4px;
      right: -4px;
      background: var(--mat-sys-surface-container-high);
    }
  `,
})
export class VisorImagen {
  readonly data = inject<VisorImagenData>(MAT_DIALOG_DATA);
}

/** Helper: `verImagen(dialog, { url, titulo })` — abre la imagen a tamaño completo. */
export function verImagen(dialog: MatDialog, data: VisorImagenData): void {
  dialog.open(VisorImagen, { data, panelClass: 'dialogo-visor-imagen' });
}
