import { Component, effect, input, signal } from '@angular/core';

/**
 * Fila de ranking con barra: crece desde 0 en cada carga/actualización,
 * se resalta al pasar el mouse o el foco, y muestra un tooltip con la
 * etiqueta completa (la visible puede truncarse con "…"). Reemplazo
 * completo del antiguo `app-barra-horizontal` (borrado, no reciclado).
 */
@Component({
  selector: 'app-rank-bar',
  template: `
    <div
      class="rb"
      [class.rb-hover]="hover()"
      tabindex="0"
      (pointerenter)="hover.set(true)"
      (pointerleave)="hover.set(false)"
      (focus)="hover.set(true)"
      (blur)="hover.set(false)"
    >
      <span class="rb-etiqueta">{{ etiqueta() }}</span>
      <div class="rb-pista">
        <div class="rb-relleno" [style.width.%]="listo() ? pct() : 0" [style.background]="color()" [style.boxShadow]="'0 0 8px 0 ' + color()"></div>
      </div>
      <span class="rb-valor">{{ valorTexto() }}</span>

      @if (hover()) {
        <div class="rb-tooltip">
          <strong>{{ etiqueta() }}</strong>
          <span>{{ valorTexto() }}</span>
        </div>
      }
    </div>
  `,
  styles: `
    .rb {
      position: relative;
      display: grid;
      grid-template-columns: 140px 1fr auto;
      align-items: center;
      gap: 10px;
      padding: 4px 8px;
      margin: 0 -8px;
      border-radius: 8px;
      outline: none;
      transition: background-color 0.15s ease;
    }
    .rb.rb-hover {
      background: var(--mat-sys-surface-container-highest);
    }
    .rb-etiqueta {
      font-size: 0.8rem;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      cursor: default;
    }
    .rb-pista {
      height: 9px;
      border-radius: 5px;
      background: var(--mat-sys-surface-container-highest);
      overflow: hidden;
    }
    .rb-relleno {
      height: 100%;
      border-radius: 5px;
      transition: width 0.7s cubic-bezier(0.22, 1, 0.36, 1);
    }
    .rb-valor {
      font-family: var(--dash-mono, inherit);
      font-size: 0.76rem;
      opacity: 0.85;
      white-space: nowrap;
      flex: none;
    }
    .rb-tooltip {
      position: absolute;
      left: 50%;
      bottom: 100%;
      transform: translate(-50%, -6px);
      background: var(--mat-sys-inverse-surface);
      color: var(--mat-sys-inverse-on-surface);
      border-radius: 8px;
      padding: 5px 9px;
      font-size: 0.74rem;
      line-height: 1.3;
      display: flex;
      flex-direction: column;
      align-items: center;
      white-space: normal;
      text-align: center;
      max-width: 260px;
      pointer-events: none;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
      z-index: 2;
    }
    .rb-tooltip strong {
      font-size: 0.8rem;
      font-weight: 700;
    }
    .rb-tooltip span {
      opacity: 0.85;
    }
  `,
})
export class RankBar {
  readonly etiqueta = input.required<string>();
  readonly valorTexto = input.required<string>();
  readonly pct = input.required<number>();
  readonly color = input('var(--mat-sys-primary)');

  readonly hover = signal(false);
  readonly listo = signal(false);

  constructor() {
    effect(() => {
      this.pct();
      this.listo.set(false);
      requestAnimationFrame(() => requestAnimationFrame(() => this.listo.set(true)));
    });
  }
}
