import { Pipe, PipeTransform } from '@angular/core';

/** Formatea un entero en pesos chilenos: 12900 -> "$12.900". */
@Pipe({ name: 'clp' })
export class ClpPipe implements PipeTransform {
  private readonly formato = new Intl.NumberFormat('es-CL', {
    style: 'currency',
    currency: 'CLP',
    maximumFractionDigits: 0,
  });

  transform(valor: number | string | null | undefined): string {
    if (valor === null || valor === undefined || valor === '') {
      return '—';
    }
    const n = typeof valor === 'string' ? Number(valor) : valor;
    return Number.isFinite(n) ? this.formato.format(n) : '—';
  }
}
