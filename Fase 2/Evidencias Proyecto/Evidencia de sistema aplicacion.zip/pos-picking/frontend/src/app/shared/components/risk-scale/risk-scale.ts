import { Component, computed, effect, input, signal } from '@angular/core';

/**
 * Escala horizontal de riesgo con 3 zonas de color (ok/atención/crítico) y
 * una marca vertical en el valor actual — para métricas donde SUBIR es malo
 * (ej. quiebre de stock), a diferencia de `TargetBar` donde subir es bueno.
 */
@Component({
  selector: 'app-risk-scale',
  template: `
    <div class="rs">
      <div
        class="rs-track"
        [style.background]="
          'linear-gradient(90deg, var(--estado-ok-fg) 0 ' +
          pctZonaOk() +
          '%, var(--estado-warn-fg) ' +
          pctZonaOk() +
          '% ' +
          pctZonaAtencion() +
          '%, var(--estado-peligro-fg) ' +
          pctZonaAtencion() +
          '% 100%)'
        "
      >
        <div class="rs-marca" [style.left.%]="listo() ? pctValor() : 0"></div>
      </div>
      <div class="rs-labels">
        @for (t of ticks(); track t) {
          <span>{{ t }}%</span>
        }
      </div>
    </div>
  `,
  styles: `
    .rs-track {
      position: relative;
      height: 12px;
      border-radius: 7px;
      opacity: 0.85;
    }
    .rs-marca {
      position: absolute;
      top: -5px;
      width: 2px;
      height: 22px;
      background: #fff;
      box-shadow:
        0 0 0 1px rgba(0, 0, 0, 0.35),
        0 0 4px rgba(0, 0, 0, 0.4);
      transition: left 0.8s cubic-bezier(0.22, 1, 0.36, 1);
    }
    .rs-labels {
      display: flex;
      justify-content: space-between;
      font-size: 0.68rem;
      opacity: 0.6;
      margin-top: 6px;
    }
  `,
})
export class RiskScale {
  readonly valor = input.required<number>();
  readonly max = input(6);
  readonly zonaOk = input(2);
  readonly zonaAtencion = input(4);

  readonly listo = signal(false);

  constructor() {
    effect(() => {
      this.valor();
      this.listo.set(false);
      requestAnimationFrame(() => requestAnimationFrame(() => this.listo.set(true)));
    });
  }

  readonly ticks = computed(() => {
    const n = 4;
    return Array.from({ length: n }, (_, i) => Math.round((this.max() / (n - 1)) * i));
  });

  private pct(v: number): number {
    return Math.max(0, Math.min(100, (v / this.max()) * 100));
  }

  readonly pctValor = computed(() => this.pct(this.valor()));
  readonly pctZonaOk = computed(() => this.pct(this.zonaOk()));
  readonly pctZonaAtencion = computed(() => this.pct(this.zonaAtencion()));
}
