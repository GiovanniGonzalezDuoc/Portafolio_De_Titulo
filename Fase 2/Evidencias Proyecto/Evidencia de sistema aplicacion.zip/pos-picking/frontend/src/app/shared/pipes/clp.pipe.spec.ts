import { ClpPipe } from './clp.pipe';

describe('ClpPipe', () => {
  const pipe = new ClpPipe();

  it('formatea enteros como pesos chilenos', () => {
    expect(pipe.transform(12900)).toBe('$12.900');
    expect(pipe.transform(0)).toBe('$0');
    expect(pipe.transform('1990')).toBe('$1.990');
  });

  it('devuelve — para valores vacíos o inválidos', () => {
    expect(pipe.transform(null)).toBe('—');
    expect(pipe.transform(undefined)).toBe('—');
    expect(pipe.transform('abc')).toBe('—');
  });
});
