import { Component, computed, input } from '@angular/core';

/** Chip de color según un estado de negocio (venta, orden, caja, DTE, alerta…). */
@Component({
  selector: 'app-badge-estado',
  template: `<span class="badge" [class]="clase()">{{ etiqueta() ?? valor() }}</span>`,
  styles: `
    .badge {
      display: inline-block;
      padding: 3px 10px;
      border-radius: 999px;
      font-size: 0.72rem;
      font-weight: 600;
      letter-spacing: 0.02em;
      line-height: 1.5;
      white-space: nowrap;
      text-transform: capitalize;
      border: 1px solid transparent;
    }
    .ok { background: var(--estado-ok-bg); color: var(--estado-ok-fg); border-color: var(--estado-ok-bd); }
    .info { background: var(--estado-info-bg); color: var(--estado-info-fg); border-color: var(--estado-info-bd); }
    .warn { background: var(--estado-warn-bg); color: var(--estado-warn-fg); border-color: var(--estado-warn-bd); }
    .peligro { background: var(--estado-peligro-bg); color: var(--estado-peligro-fg); border-color: var(--estado-peligro-bd); }
    .neutro { background: var(--estado-neutro-bg); color: var(--estado-neutro-fg); border-color: var(--estado-neutro-bd); }
  `,
})
export class BadgeEstado {
  readonly valor = input.required<string>();
  readonly etiqueta = input<string>();

  private static readonly MAPA: Record<string, string> = {
    // ventas / OC
    PAGADA: 'ok', RECIBIDA: 'ok', EMITIDA: 'info', BORRADOR: 'neutro',
    RECIBIDA_PARCIAL: 'warn', CERRADA: 'neutro', ANULADA: 'peligro',
    // caja
    ABIERTA: 'ok',
    // DTE
    ACEPTADO: 'ok', EMITIDO: 'info', PENDIENTE: 'warn', RECHAZADO: 'peligro', ANULADO: 'peligro',
    // alertas
    NUEVA: 'peligro', VISTA: 'warn', RESUELTA: 'ok',
    CRITICAL: 'peligro', WARNING: 'warn', INFO: 'info',
    // reposición
    SUGERIDA: 'info', APROBADA: 'ok', DESCARTADA: 'neutro', ORDENADA: 'ok',
    // predicción (fuente de datos)
    REAL: 'ok', SINTETICO: 'warn',
    // predicción (nivel de confianza)
    NO_ESTABLE: 'peligro', ESTABLE: 'warn', CONFIABLE: 'ok',
    // recuperación de inversión / rentabilidad por período
    recuperada: 'ok', en_recuperacion: 'info', sin_inversion: 'neutro',
    critica: 'peligro', sin_datos: 'neutro',
    // genéricos
    activo: 'ok', inactivo: 'neutro',
  };

  readonly clase = computed(() => BadgeEstado.MAPA[this.valor()] ?? 'neutro');
}
