import { Component, computed, effect, input, signal } from '@angular/core';

/**
 * Barra horizontal de progreso contra una meta — NO es un gauge/velocímetro:
 * una pista con el valor actual relleno y una marca vertical en la meta.
 */
@Component({
  selector: 'app-target-bar',
  template: `
    <div class="tb">
      <div class="tb-track">
        <div class="tb-relleno" [style.width.%]="listo() ? pctValor() : 0" [style.background]="color()"></div>
        <div class="tb-meta" [style.left.%]="pctMeta()"></div>
      </div>
      <div class="tb-labels">
        <span>{{ min() }}%</span>
        <span>Meta {{ meta() }}%</span>
        <span>{{ max() }}%</span>
      </div>
    </div>
  `,
  styles: `
    .tb-track {
      position: relative;
      height: 16px;
      border-radius: 6px;
      background: var(--mat-sys-surface-container-highest);
      overflow: hidden;
    }
    .tb-relleno {
      height: 100%;
      border-radius: 6px;
      transition: width 0.8s cubic-bezier(0.22, 1, 0.36, 1);
    }
    .tb-meta {
      position: absolute;
      top: -4px;
      width: 2px;
      height: 24px;
      background: #fff;
      box-shadow:
        0 0 0 1px rgba(0, 0, 0, 0.35),
        0 0 4px rgba(0, 0, 0, 0.4);
    }
    .tb-labels {
      display: flex;
      justify-content: space-between;
      font-size: 0.68rem;
      opacity: 0.6;
      margin-top: 6px;
    }
  `,
})
export class TargetBar {
  readonly valor = input.required<number>();
  readonly meta = input.required<number>();
  readonly min = input(0);
  readonly max = input(40);
  readonly color = input('var(--mat-sys-primary)');

  readonly listo = signal(false);

  constructor() {
    effect(() => {
      this.valor();
      this.listo.set(false);
      requestAnimationFrame(() => requestAnimationFrame(() => this.listo.set(true)));
    });
  }

  private pct(v: number): number {
    const rango = this.max() - this.min() || 1;
    return Math.max(0, Math.min(100, ((v - this.min()) / rango) * 100));
  }

  readonly pctValor = computed(() => this.pct(this.valor()));
  readonly pctMeta = computed(() => this.pct(this.meta()));
}
