import { Component, OnInit, input, model } from '@angular/core';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';

export type VistaAcciones = 'iconos' | 'menu';

/**
 * Interruptor "botones sueltos / menú ⋮" para la columna de acciones de un
 * listado. Recuerda la elección del usuario en `localStorage` bajo `clave`
 * (distinta por pantalla).
 *
 *   <app-toggle-acciones clave="pos-ventas-acciones"
 *     [vista]="vistaAcciones()" (vistaChange)="vistaAcciones.set($event)" />
 */
@Component({
  selector: 'app-toggle-acciones',
  imports: [MatButtonToggleModule, MatIconModule, MatTooltipModule],
  template: `
    <mat-button-toggle-group
      hideSingleSelectionIndicator
      aria-label="Cómo mostrar las acciones"
      [value]="vista()"
      (change)="elegir($event.value)"
    >
      <mat-button-toggle value="iconos" matTooltip="Botones sueltos">
        <mat-icon>apps</mat-icon>
      </mat-button-toggle>
      <mat-button-toggle value="menu" matTooltip="Menú de 3 puntos">
        <mat-icon>more_vert</mat-icon>
      </mat-button-toggle>
    </mat-button-toggle-group>
  `,
  styles: `
    :host {
      margin-left: auto;
    }
  `,
})
export class ToggleAcciones implements OnInit {
  readonly clave = input.required<string>();
  readonly vista = model<VistaAcciones>('menu');

  ngOnInit(): void {
    try {
      const guardado = localStorage.getItem(this.clave());
      if (guardado === 'iconos' || guardado === 'menu') {
        this.vista.set(guardado);
      }
    } catch {
      /* almacenamiento no disponible */
    }
  }

  elegir(v: VistaAcciones): void {
    this.vista.set(v);
    try {
      localStorage.setItem(this.clave(), v);
    } catch {
      /* almacenamiento no disponible */
    }
  }
}
