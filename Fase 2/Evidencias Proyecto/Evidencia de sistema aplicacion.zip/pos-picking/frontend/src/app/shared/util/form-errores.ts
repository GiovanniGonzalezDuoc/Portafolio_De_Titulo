import { HttpErrorResponse } from '@angular/common/http';
import { FormGroup } from '@angular/forms';

import { ErrorApi } from '../../core/models/api.models';

/**
 * Traslada un error de validación del backend (400 con `campo`) al control
 * correspondiente del formulario, para mostrarlo como `mat-error`.
 * Devuelve true si lo aplicó a un campo (el interceptor no mostrará toast útil).
 */
export function aplicarErrorBackend(form: FormGroup, err: unknown): boolean {
  if (!(err instanceof HttpErrorResponse) || err.status !== 400) {
    return false;
  }
  const detalle = (err.error as ErrorApi | undefined)?.error;
  if (detalle?.campo && form.get(detalle.campo)) {
    form.get(detalle.campo)!.setErrors({ backend: detalle.mensaje });
    form.get(detalle.campo)!.markAsTouched();
    return true;
  }
  return false;
}
