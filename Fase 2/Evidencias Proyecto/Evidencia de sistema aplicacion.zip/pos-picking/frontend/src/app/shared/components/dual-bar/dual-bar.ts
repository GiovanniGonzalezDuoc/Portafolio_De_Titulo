import { Component, effect, input, signal } from '@angular/core';

/**
 * Fila de comparación "actual vs. esperado" — dos barras finas apiladas
 * bajo una misma etiqueta, cada una con su propio color y ancho relativo
 * a un máximo compartido (pasado por el padre, no calculado acá, porque
 * el máximo depende del set completo de filas).
 */
@Component({
  selector: 'app-dual-bar',
  template: `
    <div class="db" tabindex="0" (pointerenter)="hover.set(true)" (pointerleave)="hover.set(false)" (focus)="hover.set(true)" (blur)="hover.set(false)" [class.db-hover]="hover()">
      <span class="db-etiqueta">{{ etiqueta() }}</span>
      <div class="db-barras">
        <div class="db-fila">
          <div class="db-pista"><div class="db-relleno db-relleno--actual" [style.width.%]="listo() ? pctActual() : 0"></div></div>
          <span class="db-valor">{{ textoActual() }}</span>
        </div>
        <div class="db-fila">
          <div class="db-pista"><div class="db-relleno db-relleno--esperado" [style.width.%]="listo() ? pctEsperado() : 0"></div></div>
          <span class="db-valor db-valor--tenue">{{ textoEsperado() }}</span>
        </div>
      </div>
    </div>
  `,
  styles: `
    .db {
      display: grid;
      grid-template-columns: 140px 1fr;
      align-items: center;
      gap: 10px;
      padding: 5px 8px;
      margin: 0 -8px;
      border-radius: 8px;
      outline: none;
      transition: background-color 0.15s ease;
    }
    .db.db-hover {
      background: var(--mat-sys-surface-container-highest);
    }
    .db-etiqueta {
      font-size: 0.8rem;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      cursor: default;
    }
    .db-barras {
      display: flex;
      flex-direction: column;
      gap: 3px;
    }
    .db-fila {
      display: grid;
      grid-template-columns: 1fr auto;
      align-items: center;
      gap: 8px;
    }
    .db-pista {
      height: 7px;
      border-radius: 4px;
      background: var(--mat-sys-surface-container-highest);
      overflow: hidden;
    }
    .db-relleno {
      height: 100%;
      border-radius: 4px;
      transition: width 0.7s cubic-bezier(0.22, 1, 0.36, 1);
    }
    .db-relleno--actual {
      background: var(--mat-sys-primary);
    }
    .db-relleno--esperado {
      background: var(--mat-sys-outline);
      opacity: 0.6;
    }
    .db-valor {
      font-family: var(--dash-mono, inherit);
      font-size: 0.72rem;
      opacity: 0.85;
      white-space: nowrap;
      flex: none;
      min-width: 62px;
      text-align: right;
    }
    .db-valor--tenue {
      opacity: 0.55;
    }
  `,
})
export class DualBar {
  readonly etiqueta = input.required<string>();
  readonly pctActual = input.required<number>();
  readonly pctEsperado = input.required<number>();
  readonly textoActual = input.required<string>();
  readonly textoEsperado = input.required<string>();

  readonly hover = signal(false);
  readonly listo = signal(false);

  constructor() {
    effect(() => {
      this.pctActual();
      this.pctEsperado();
      this.listo.set(false);
      requestAnimationFrame(() => requestAnimationFrame(() => this.listo.set(true)));
    });
  }
}
