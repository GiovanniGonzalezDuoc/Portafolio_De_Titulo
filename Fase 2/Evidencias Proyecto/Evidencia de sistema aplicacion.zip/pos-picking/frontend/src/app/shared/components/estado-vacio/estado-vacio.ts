import { Component, input } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

/** Mensaje cuando una lista no tiene resultados. */
@Component({
  selector: 'app-estado-vacio',
  imports: [MatIconModule],
  template: `
    <div class="vacio">
      <mat-icon>{{ icono() }}</mat-icon>
      <p>{{ mensaje() }}</p>
      <ng-content />
    </div>
  `,
  styles: `
    .vacio {
      display: grid;
      place-items: center;
      gap: 8px;
      padding: 48px 16px;
      text-align: center;
      opacity: 0.7;
    }
    mat-icon {
      width: 48px;
      height: 48px;
      font-size: 48px;
    }
    p {
      margin: 0;
    }
  `,
})
export class EstadoVacio {
  readonly mensaje = input('Sin resultados');
  readonly icono = input('inbox');
}
