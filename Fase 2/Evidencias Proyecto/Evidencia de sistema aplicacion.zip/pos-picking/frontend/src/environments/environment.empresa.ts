/**
 * Instancia para la empresa (datos reales, BD separada). La SPA vive en
 * https://empresa.systemspickingpos.cl y la API en
 * https://api-empresa.systemspickingpos.cl.
 *
 *   ng build --configuration empresa
 */
export const environment = {
  produccion: true,
  apiUrl: 'https://api-empresa.systemspickingpos.cl/api/v1',
};
