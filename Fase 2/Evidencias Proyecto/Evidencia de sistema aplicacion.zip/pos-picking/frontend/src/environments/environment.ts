/**
 * Producción (caso general): la SPA y la API comparten origen y hay un
 * reverse-proxy delante que enruta /api/ al backend (ver frontend/nginx.conf
 * del stack Docker).
 *
 * El deploy en cPanel usa `environment.cpanel.ts` (API en un subdominio):
 *   ng build --configuration cpanel
 */
export const environment = {
  produccion: true,
  apiUrl: '/api/v1',
};
