/**
 * Deploy en V2Network (cPanel). La SPA vive en https://systemspickingpos.cl y
 * la API en el subdominio https://api.systemspickingpos.cl (app Python de
 * cPanel). El backend habilita este origen con CORS_ALLOWED_ORIGINS.
 *
 *   ng build --configuration cpanel
 */
export const environment = {
  produccion: true,
  apiUrl: 'https://api.systemspickingpos.cl/api/v1',
};
