/** Desarrollo local — API de Django en el puerto 8000. */
export const environment = {
  produccion: false,
  apiUrl: 'http://127.0.0.1:8000/api/v1',
};
