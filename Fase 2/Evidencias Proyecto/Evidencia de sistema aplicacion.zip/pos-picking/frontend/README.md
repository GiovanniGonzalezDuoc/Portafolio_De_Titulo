# POS Picking — Frontend (Angular)

SPA que consume la API REST de Django. **Etapa 15**: estructura base (login,
sesión, navegación, interceptores, manejo de errores). **Etapa 16**: todas las
pantallas de módulo (dashboard, usuarios, catálogo, inventario, alertas,
proveedores, compras, POS, caja, ventas, boletas, predicción, reposición).

## Stack

Angular 22 (standalone + signals) · Angular Material 3 · TypeScript · ESLint ·
Vitest.

## Estructura

```
src/app/
├── core/
│   ├── auth/        AuthService, TokenStorage, guards (authGuard, permisoGuard),
│   │               session.bootstrap (renueva la sesión al cargar)
│   ├── http/        interceptores: loading, error (toast global), jwt (Bearer + refresh)
│   ├── services/    ApiService (wrapper de HttpClient), NotificacionService, LoadingService
│   └── models/      tipos comunes (Pagina<T>, ErrorApi)
├── shared/          ClpPipe · components/ (page-header, confirm-dialog,
│                     input-dialog, estado-vacio, badge-estado) ·
│                     util/ (crearListado, aplicarErrorBackend)
├── layouts/
│   ├── main-layout/ sidenav + header + barra de progreso + <router-outlet>
│   ├── header/      toolbar con menú de usuario / cerrar sesión
│   ├── sidebar/     menú filtrado por permisos del usuario
│   └── navegacion.ts   definición del menú (etiqueta, icono, ruta, permiso)
└── features/
    ├── auth/login/      formulario reactivo → /api/v1/auth/login/
    ├── dashboard/       KPIs operacionales
    ├── usuarios/        usuarios + roles/permisos
    ├── catalogo/        productos, categorías, marcas
    ├── inventario/      stock, movimientos, ajustes
    ├── alertas/         bandeja de alertas + resolución masiva
    ├── proveedores/     proveedores y sus productos
    ├── compras/         órdenes de compra + recepciones (detalle en /compras/:id)
    ├── ventas/          POS (/pos), historial (/ventas), diálogo de boleta
    ├── caja/            apertura, arqueo, ingresos/egresos, cierre
    ├── boletas/         documentos tributarios (DTE 39)
    ├── prediccion/      modelo de demanda + predicciones por producto
    ├── reposicion/      recomendaciones de compra + generación de OC
    └── no-encontrado/   404
```

Patrón de pantalla: `*.models.ts` → `*.service.ts` (extiende `RecursoService`
o usa `ApiService`) → lista con `crearListado` + `MatTable` + `MatPaginator` →
formulario en diálogo con `aplicarErrorBackend` → ruta con `permisoGuard` y
`data.permiso`.

## Cómo correr

Requiere el backend en `http://127.0.0.1:8000` (ver `backend/README.md` o
`backend/run-dev.ps1`).

```bash
cd frontend
npm install          # solo la primera vez
npm start             # ng serve → http://localhost:4200
```

Usuarios demo (contraseña `demo12345`): `admin_demo`, `bodega_demo`, `vende_demo`.
El menú lateral se adapta al rol (el vendedor no ve Administración, etc.).

## Configuración de entorno

| Archivo | `apiUrl` |
|---|---|
| `src/environments/environment.development.ts` | `http://127.0.0.1:8000/api/v1` |
| `src/environments/environment.ts` (producción) | `/api/v1` (misma URL que la SPA en cPanel) |

## Calidad

```bash
npm run ng -- lint    # ESLint (o: ng lint)
npm test              # Vitest (ng test)
npm run build         # build de producción → dist/frontend/
```

## Sesión y seguridad

- `access` token en memoria; `refresh` en `localStorage`.
- `jwtInterceptor` agrega `Authorization: Bearer` y, ante un 401, renueva el
  token una vez y reintenta; si el refresh falla, cierra la sesión.
- `authGuard` protege las rutas; `permisoGuard` (con `data.permiso`) oculta
  secciones sin acceso. La autoridad real es siempre el backend.
- `errorInterceptor` traduce los errores de la API (`error.codigo`/`mensaje`) a
  un snackbar; el formulario de login muestra su propio mensaje.
