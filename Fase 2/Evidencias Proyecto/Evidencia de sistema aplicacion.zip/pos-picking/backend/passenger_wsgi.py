"""
Punto de entrada para el servidor de aplicaciones de cPanel (LiteSpeed LSAPI /
Passenger). Debe estar en la raíz de la "Application" configurada en
cPanel → Setup Python App.

- El código del backend vive en este mismo directorio.
- Los secretos se leen de `.env` en este directorio (fuera de public_html).
- Usa `config.settings.prod` (fail-fast si faltan las claves).
"""

import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.prod")
os.environ.setdefault("DJANGO_ENV_FILE", os.path.join(BASE_DIR, ".env"))

from config.wsgi import application  # noqa: E402, F401  (LSAPI usa este nombre)
