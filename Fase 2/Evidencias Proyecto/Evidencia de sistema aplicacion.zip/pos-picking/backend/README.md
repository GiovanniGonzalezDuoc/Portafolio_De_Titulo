# POS Picking — Backend (Django + DRF + MariaDB)

API REST del sistema POS Picking. Etapa 3: esqueleto del proyecto (sin modelos de negocio todavía).

## Requisitos

- Python 3.11+ (probado con 3.13; producción cPanel según versión del hosting)
- MariaDB 10.6+ — **o** Docker (para desarrollo local)
- En Windows, `mysqlclient` se instala desde wheel (no requiere compilador)

## Estructura

```
backend/
├── config/
│   ├── settings/         base.py · local.py · prod.py · test.py
│   ├── urls.py           rutas raíz — todo bajo /api/v1/
│   ├── wsgi.py / asgi.py
├── apps/
│   └── core/             modelos base, paginación, exception handler,
│                         middleware de request-id, logging con contexto
├── manage.py
├── requirements.txt      dependencias de ejecución
├── requirements-dev.txt  + testing, ruff y librerías de ML
├── Dockerfile            SOLO desarrollo local
├── entrypoint.sh
└── .env.example
```

## Puesta en marcha — Opción A: local con virtualenv

### 1. Dependencias

```powershell
cd backend
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
```

### 2. Variables de entorno

```powershell
copy .env.example .env
```

Edita `.env`:
- `DJANGO_SECRET_KEY` y `JWT_SIGNING_KEY`: genera valores largos
  (`python -c "import secrets; print(secrets.token_urlsafe(64))"`).
- Datos de `DB_*` según tu MariaDB local.
- Para una verificación **sin MariaDB**: `USE_SQLITE=True`.

### 3. Levantar MariaDB (si no usas SQLite)

Con MariaDB instalada localmente, crea la base y el usuario:

```sql
CREATE DATABASE pos_picking CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
CREATE USER 'pos_user'@'localhost' IDENTIFIED BY 'tu-clave';
GRANT ALL PRIVILEGES ON pos_picking.* TO 'pos_user'@'localhost';
FLUSH PRIVILEGES;
```

### 4. Comprobar la conexión y migrar

```powershell
python manage.py check                 # validación del proyecto
python manage.py migrate               # crea las tablas base (auth, sessions, JWT blacklist)
python manage.py createsuperuser        # opcional: acceso al admin
python manage.py runserver
```

Verificación rápida de que Django habla con MariaDB:

```powershell
python manage.py dbshell -c "SELECT VERSION();"
# o
python manage.py shell -c "from django.db import connection; print(connection.vendor, connection.cursor())"
```

### 5. Endpoints disponibles ahora

**Base y documentación**

| URL | Descripción |
|---|---|
| `GET /api/v1/health/` | Healthcheck (`{"estado":"ok",...}`) |
| `GET /api/v1/schema/` · `/docs/` · `/redoc/` | OpenAPI · Swagger UI · ReDoc |
| `/admin/` | Admin de Django |

**Autenticación** (Etapa 4)

| Método · URL | Descripción | Auth |
|---|---|---|
| `POST /api/v1/auth/login/` | `{username, password}` → `{access, refresh, usuario}` | pública |
| `POST /api/v1/auth/refresh/` | `{refresh}` → `{access}` | pública |
| `POST /api/v1/auth/logout/` | `{refresh}` → invalida el token (blacklist) | Bearer |
| `GET /api/v1/auth/me/` | Datos del usuario y permisos efectivos | Bearer |
| `POST /api/v1/auth/cambiar-password/` | `{password_actual, password_nuevo}` | Bearer |

Bloqueo temporal tras `LOGIN_MAX_INTENTOS` fallidos en `LOGIN_BLOQUEO_MINUTOS`.

**Usuarios / roles / permisos** (Etapa 4)

| Método · URL | Permiso requerido |
|---|---|
| `GET/POST /api/v1/usuarios/` · `GET/PUT/PATCH/DELETE /api/v1/usuarios/{id}/` | `usuarios.ver` / `usuarios.administrar` |
| `POST /api/v1/usuarios/{id}/activar/` · `/desactivar/` · `/resetear-password/` | `usuarios.administrar` |
| `GET /api/v1/roles/` · `GET /api/v1/roles/{id}/` | `roles.ver` |
| `PUT /api/v1/roles/{id}/permisos/` | `roles.administrar` |
| `GET /api/v1/permisos/` | `roles.ver` |

`DELETE` de un usuario **no borra**: lo desactiva. Roles semilla:
`administrador`, `bodeguero`, `vendedor`, `mayorista` (33 permisos, cargados por
la migración `usuarios.0002_datos_iniciales`).

**Catálogo** (Etapa 5)

| Método · URL | Permiso |
|---|---|
| `GET/POST /api/v1/catalogo/categorias/` · `/marcas/` · `/productos/` (+ `{id}/`) | `catalogo.ver` / `catalogo.administrar` |
| `POST .../{id}/activar/` | `catalogo.administrar` |
| `GET /api/v1/catalogo/productos/por-codigo/{codigo}/` | `catalogo.ver` — busca por código de barras (POS); 404 si no existe, 409 si inactivo |
| `GET /api/v1/catalogo/productos/por-sku/{sku}/` | `catalogo.ver` |

Productos: filtros (`categoria`, `marca`, `activo`, `afecto_iva`, `unidad_medida`,
`precio_min`, `precio_max`), búsqueda (`?search=` en SKU/nombre/código de barras),
orden (`?ordering=`), paginación (`?page=`, `?page_size=`). `DELETE` desactiva.
Precios en CLP (enteros) con **IVA incluido**. `ProductoProveedor` se agrega en la
Etapa 7 (junto con el modelo `Proveedor`).

**Inventario** (Etapa 6)

| Método · URL | Permiso | Notas |
|---|---|---|
| `GET /api/v1/inventario/stock/` | `inventario.ver` | filtros: `producto`, `ubicacion`, `categoria`, `sin_stock`, `bajo_minimo` |
| `GET /api/v1/inventario/movimientos/` | `inventario.ver` | historial; filtros: `producto`, `tipo`, `usuario`, `desde`, `hasta`, `doc_tipo` |
| `POST /api/v1/inventario/movimientos/registrar/` | `inventario.mover` | `{producto(SKU), ubicacion?, tipo(AJUSTE_POSITIVO/NEGATIVO), cantidad, motivo}` |
| `POST /api/v1/inventario/movimientos/ajustar/` | `inventario.ajustar` | `{producto, ubicacion?, cantidad_final, motivo}` — deja el stock en un valor absoluto |
| `GET/POST /api/v1/inventario/ubicaciones/` `.../parametros/` | ver / ajustar | `parametros`: stock mínimo, punto de reposición, stock de seguridad |

Reglas garantizadas por `apps/inventario/services.py`:
- **toda** variación de stock genera un `MovimientoInventario` (con `stock_antes`/`stock_despues`, usuario y fecha) — libro mayor inmutable;
- `transaction.atomic` + `select_for_update` sobre la fila de `Stock` (sin sobreventa / sin condiciones de carrera);
- el stock **nunca** queda negativo (validación en servicio + `CHECK` en BD) → `409 stock_insuficiente`;
- al quedar en/bajo el mínimo se genera una alerta (`STOCK_BAJO` / `SIN_STOCK`).

**Alertas** (Etapa 11 — motor + reglas)

| Método · URL | Permiso |
|---|---|
| `GET /api/v1/alertas/` — filtros `tipo`, `severidad`, `estado`, `producto`, `desde`, `hasta`, `abiertas` | `alertas.ver` |
| `GET /api/v1/alertas/resumen/` — conteos por severidad y tipo | `alertas.ver` |
| `POST /api/v1/alertas/{id}/marcar-vista/` · `/resolver/` | `alertas.ver` / `alertas.resolver` |
| `POST /api/v1/alertas/resolver-varias/` `{ids:[…]}` | `alertas.resolver` |
| `GET/PATCH /api/v1/reglas-alerta/` | `alertas.ver` / `alertas.configurar` |

Tipos: `STOCK_BAJO`, `SIN_STOCK`, `REPOSICION`, `DISCREPANCIA`, `DTE_FALLIDO`,
`ERROR_SISTEMA`. Cada tipo tiene una `ReglaAlerta` (activa, severidad,
`holgura_pct` — adelanta el aviso de stock bajo). Deduplicación por `hash_dedupe`
mientras la alerta está abierta.

- `apps/alertas/motor.py` + `manage.py generar_alertas` (cron cada hora): escanea
  el inventario, crea alertas de stock/reposición y **cierra** las que ya no
  aplican (stock normalizado).
- `confirmar_venta` genera `STOCK_BAJO` / `SIN_STOCK` al vuelo; tras
  `MAX_INTENTOS` fallidos de emisión de boleta se crea `DTE_FALLIDO`.

**Dashboard** (Etapa 12 — solo lectura, agregados)

| Método · URL | Permiso | Contenido |
|---|---|---|
| `GET /api/v1/dashboard/resumen/` | `dashboard.ver` | ventas hoy vs ayer + estado de caja (propio para el vendedor); admin/bodeguero además inventario, alertas, compras, reposición |
| `GET /api/v1/dashboard/ventas/?desde=&hasta=&agrupacion=dia\|semana\|mes` | `dashboard.ver` | KPIs + serie temporal |
| `GET /api/v1/dashboard/productos-top/?desde=&hasta=&limite=` | `dashboard.ver` | más vendidos (unidades y monto) |
| `GET /api/v1/dashboard/inventario/` | `dashboard.ver_completo` | valorizado, rotación, días de inventario, bajo punto de pedido |
| `GET /api/v1/dashboard/compras/?desde=&hasta=` | `dashboard.ver_completo` | monto, órdenes pendientes de recepción, unidades en tránsito |

`apps/dashboard` no tiene modelos: `selectors.py` con funciones de consulta
(`aggregate` / `annotate` / `Trunc*`, sin N+1) y vistas `APIView` finas. El
vendedor ve solo **sus** ventas y **su** caja; `dashboard.ver_completo` abre todo.

**Predicción de demanda** (Etapa 14 — integración del paquete `ml/`)

| Método · URL | Permiso |
|---|---|
| `GET /api/v1/prediccion/modelos/` · `GET .../demanda/` | `prediccion.ver` |
| `GET /api/v1/prediccion/demanda/calcular/?producto=SKU&horizonte=4` | `prediccion.ver` |
| `POST /api/v1/prediccion/modelos/entrenar/` · `/sincronizar/` | `prediccion.entrenar` |

`apps/prediccion.services` construye la serie semanal de un producto desde
`ventas.LineaVenta` y, si tiene < 12 semanas con ventas y está permitido
(`PREDICCION_PERMITIR_SINTETICO`), cae al dataset sintético de `ml/` (marca
`fuente=SINTETICO`). Comandos: `entrenar_demanda` (cron mensual),
`predecir_demanda`.

**Recomendación de reposición** (Etapa 14)

| Método · URL | Permiso |
|---|---|
| `GET /api/v1/reposicion/recomendaciones/` (filtros `estado`/`producto`/`con_compra`) | `reposicion.ver` |
| `POST /api/v1/reposicion/recomendaciones/generar/` | `reposicion.ejecutar` |
| `POST /api/v1/reposicion/recomendaciones/{id}/aprobar/` · `/descartar/` | `reposicion.ejecutar` |
| `POST /api/v1/reposicion/recomendaciones/generar-orden/` `{ids:[…]}` | `compras.crear` |
| `GET/PATCH /api/v1/reposicion/parametros/` | `reposicion.ver` / `reposicion.ejecutar` |

Fórmulas puras (`apps/reposicion/formulas.py`, `v1`):
`SS = Z·σ·√(L+R)` · `ROP = d·(L+R)+SS` · `Q = ceil(max(0, ROP−(S+T)) / m)·m`.
Cada `RecomendacionReposicion` guarda `inputs` (auditoría), `motivo` (explicación)
y `formula_version`. No se recomienda sin predicción válida ni sin proveedor.
Comando `calcular_reposicion` (cron diario). Detalle: `docs/13-prediccion-demanda.md`
y `docs/14-reposicion.md`.

**Proveedores y compras** (Etapa 7)

| Método · URL | Permiso |
|---|---|
| `GET/POST /api/v1/proveedores/` (+ `{id}/`, `activar/`) | `proveedores.ver` / `proveedores.administrar` |
| `POST /api/v1/proveedores/{id}/asociar-producto/` · `quitar-producto/` · `GET .../productos/` | idem |
| `GET/POST /api/v1/compras/ordenes/` | `compras.ver` / `compras.crear` |
| `POST /api/v1/compras/ordenes/{id}/emitir/` · `anular/` | `compras.crear` |
| `POST /api/v1/compras/ordenes/{id}/recibir/` | `compras.recibir` |
| `GET /api/v1/compras/ordenes/{id}/recepciones/` · `GET /api/v1/compras/recepciones/` | `compras.ver` |

Flujo de la OC: `BORRADOR → EMITIDA → (RECIBIDA_PARCIAL) → RECIBIDA`, o `ANULADA`.
**Crear/emitir una orden NO toca el stock.** Solo `recibir/` lo aumenta, a través
del servicio de inventario (movimiento tipo `COMPRA`), dentro de una transacción:
valida cantidades pendientes, crea `RecepcionCompra`, actualiza `costo_referencial`
del producto y recalcula el estado de la orden. `compras.services.stock_en_transito()`
expone las unidades pedidas y no recibidas (lo usará reposición en la Etapa 14).
`apps/core` incorpora `Secuencia` para los correlativos (`OC-000001`, `REC-000001`, …)
con bloqueo de fila.

**POS y ventas** (Etapa 8)

| Método · URL | Permiso | Notas |
|---|---|---|
| `POST /api/v1/ventas/calcular/` | `ventas.crear` | calcula totales del carrito sin registrar nada (preview del POS) |
| `POST /api/v1/ventas/` | `ventas.crear` | confirma la venta `{items:[{producto(SKU),cantidad,descuento_monto?}], pagos:[{medio,monto,referencia?}], es_mayorista?, autorizacion?}` |
| `GET /api/v1/ventas/` · `GET /api/v1/ventas/{id}/` | `ventas.ver` | el vendedor solo ve **sus** ventas |
| `POST /api/v1/ventas/{id}/anular/` | `ventas.anular` | anulación el **mismo día**; reingresa stock (`DEVOLUCION`) |

`config/urls.py` monta `apps.ventas.urls` en la raíz de `/api/v1/`. Búsqueda de
productos por SKU / código de barras: se usan los endpoints del catálogo
(`productos/por-codigo/{codigo}`, `productos/por-sku/{sku}`).

Cálculo (`apps/ventas/services.py`), con `ParametroSistema` (IVA 19 %, redondeo 10,
tope de descuento del vendedor 5 %):
- precios **con IVA incluido**; la venta guarda el desglose `neto` / `iva` / `exento`;
- descuento por línea; si supera el tope del vendedor exige `autorizacion`
  (`{username, password}` de un usuario con `ventas.autorizar_descuento`) → registra `AutorizacionDescuento`;
- **redondeo a la decena** solo si hay pago en efectivo (`redondeo`, `total_a_cobrar`);
- los pagos deben sumar exactamente `total_a_cobrar`.

`confirmar_venta` es **transaccional**: exige una **caja abierta** del vendedor
(`409 caja_no_abierta`), descuenta stock por el servicio de inventario (movimiento
`VENTA`, `select_for_update` → sin sobreventa ni carreras), crea líneas y pagos,
y por cada pago en efectivo registra un `MovimientoCaja`; si falta stock en
cualquier línea, **nada** se persiste (`409`). La **boleta electrónica** (Etapa 10)
se engancha después.

**Caja** (Etapa 9)

| Método · URL | Permiso | Notas |
|---|---|---|
| `POST /api/v1/cajas/abrir/` | `caja.operar` | `{monto_inicial}` → una sola caja `ABIERTA` por usuario (`409 caja_ya_abierta`) |
| `GET /api/v1/cajas/mi-caja/` | `caja.operar` | la caja abierta del usuario (`404` si no hay) |
| `POST /api/v1/cajas/{id}/ingreso/` · `/egreso/` | `caja.operar` | `{monto, motivo}` (motivo obligatorio; el egreso no puede superar el saldo) |
| `POST /api/v1/cajas/{id}/cerrar/` | `caja.operar` | `{monto_contado, observacion?}` → calcula `monto_esperado` y `diferencia` |
| `GET /api/v1/cajas/{id}/arqueo/` · `/movimientos/` | `caja.operar` | desglose del saldo / historial |
| `GET /api/v1/cajas/` · `GET /api/v1/cajas/{id}/` | `caja.operar` | el vendedor ve solo la suya; con `caja.ver_todas`, todas |

`saldo_esperado = monto_inicial + Σ ventas efectivo + Σ ingresos − Σ egresos`.
Todas las operaciones son transaccionales (`select_for_update` sobre la caja).
`Venta.caja` es FK opcional a nivel de BD pero obligatoria en el flujo del POS.

**Boleta electrónica** (Etapa 10 — DTE 39, SII Chile · integración **MOCK**)

| Método · URL | Permiso | Notas |
|---|---|---|
| `GET /api/v1/boletas/` · `GET /api/v1/boletas/{id}/` | `boleta.ver` | el retrieve incluye la bitácora de `eventos` |
| `GET /api/v1/boletas/{id}/imprimir/` | `boleta.ver` | representación HTML de la boleta |
| `POST /api/v1/boletas/{id}/reintentar/` | `boleta.reintentar` | reprocesa un documento `PENDIENTE` |
| `POST /api/v1/boletas/{id}/anular/` | `boleta.anular` | |

Arquitectura (`apps/boleta/proveedores/`): puerto `ProveedorDTE`
(`emitir` / `anular` / `consultar_estado`) + implementación `ProveedorDTEMock`
(folio incremental, timbre TED ficticio, acepta de inmediato; puede forzar fallos
con `DTE_MOCK_FORZAR_FALLO` / `DTE_MOCK_FALLA_PROB`). El proveedor activo sale de
`ParametroSistema.dte_proveedor`.

Flujo: `confirmar_venta` crea el `DocumentoTributario` **PENDIENTE** dentro de la
transacción de la venta y, **tras el commit**, llama `emitir_seguro` (nunca
propaga errores). Si la emisión falla, el documento queda `PENDIENTE` con
`ultimo_error`/`intentos`, la venta **no** se revierte, y el comando
`manage.py reintentar_dte` (cron cada 15 min) lo reprocesa. Estados:
`PENDIENTE → EMITIDO → ACEPTADO` (`RECHAZADO` / `ANULADO`). Anular la venta anula
su boleta. Toda la traza queda en `EventoDTE` y la respuesta cruda en
`RespuestaProveedorDTE`.

## Puesta en marcha — Opción B: Docker Compose

Desde la **raíz del repo** (no `backend/`):

```powershell
docker compose up --build
```

Levanta `db` (MariaDB 10.11) + `backend` (Django en `:8000`). El `entrypoint.sh`
espera a la base, corre `migrate` y arranca `runserver`. Datos persistentes en el
volumen `pos_db_data`.

```powershell
docker compose exec backend python manage.py createsuperuser
docker compose exec backend python manage.py test
```

## Tests y calidad

```powershell
pytest                      # usa config/settings/test.py (SQLite en memoria)
pytest --cov                 # con cobertura
ruff check .                 # lint
ruff format .                # formateo
pip-audit                    # CVE en dependencias (debe salir limpio)
```

Auditorías: `docs/18-auditoria-testing.md`, `docs/19-auditoria-seguridad.md`.

## Notas

- **Producción** usa `config.settings.prod` y NO usa Docker (cPanel/Passenger).
  El `.env` de producción vive en el *home* del hosting, fuera de `public_html`.
- Los settings nunca contienen secretos: todo sale de variables de entorno.
- `config/settings/base.py` fuerza `sql_mode` estricto y `utf8mb4` en MariaDB.
