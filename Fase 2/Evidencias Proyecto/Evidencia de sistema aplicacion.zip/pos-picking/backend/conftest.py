"""Fixtures compartidas por toda la suite de tests."""

import pytest
from rest_framework.test import APIClient

from apps.usuarios.models import Rol
from apps.usuarios.permisos import sincronizar
from apps.usuarios.tests.factories import UsuarioFactory


@pytest.fixture(autouse=True)
def _cache_limpia():
    """Aísla el estado de throttling/bloqueo (cache) entre tests."""
    from django.core.cache import cache

    cache.clear()
    yield
    cache.clear()


@pytest.fixture
def api():
    return APIClient()


@pytest.fixture
def datos_seguridad(db):
    """Recrea permisos y roles (equivalente a las data migrations de usuarios)."""
    sincronizar()


@pytest.fixture
def rol_admin(datos_seguridad):
    return Rol.objects.get(nombre="administrador")


@pytest.fixture
def rol_bodeguero(datos_seguridad):
    return Rol.objects.get(nombre="bodeguero")


@pytest.fixture
def rol_vendedor(datos_seguridad):
    return Rol.objects.get(nombre="vendedor")


@pytest.fixture
def rol_mayorista(datos_seguridad):
    return Rol.objects.get(nombre="mayorista")


@pytest.fixture
def admin(rol_admin):
    return UsuarioFactory(username="admin", rol=rol_admin, password="clave-admin-123")


@pytest.fixture
def bodeguero(rol_bodeguero):
    return UsuarioFactory(username="bodega", rol=rol_bodeguero, password="clave-bodega-123")


@pytest.fixture
def vendedor(rol_vendedor):
    return UsuarioFactory(username="vende", rol=rol_vendedor, password="clave-vende-123")


@pytest.fixture
def mayorista(rol_mayorista):
    return UsuarioFactory(username="mayor", rol=rol_mayorista, password="clave-mayor-123")


@pytest.fixture
def api_admin(admin):
    cli = APIClient()
    cli.force_authenticate(admin)
    return cli


@pytest.fixture
def api_bodeguero(bodeguero):
    cli = APIClient()
    cli.force_authenticate(bodeguero)
    return cli


@pytest.fixture
def api_vendedor(vendedor):
    cli = APIClient()
    cli.force_authenticate(vendedor)
    return cli


@pytest.fixture
def api_mayorista(mayorista):
    cli = APIClient()
    cli.force_authenticate(mayorista)
    return cli
