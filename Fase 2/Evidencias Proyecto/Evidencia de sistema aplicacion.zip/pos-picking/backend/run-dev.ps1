# Levanta el backend en modo desarrollo (SQLite, sin MariaDB).
# Uso:  .\run-dev.ps1
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Test-Path ".venv")) {
    Write-Host "Creando entorno virtual..." -ForegroundColor Cyan
    python -m venv .venv
    .\.venv\Scripts\python.exe -m pip install --upgrade pip -q
    .\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
}

if (-not (Test-Path ".env")) {
    Write-Host "Falta backend\.env — cópialo desde .env.example" -ForegroundColor Yellow
    exit 1
}

.\.venv\Scripts\python.exe manage.py migrate
.\.venv\Scripts\python.exe manage.py cargar_demo

Write-Host ""
Write-Host "  API .......... http://127.0.0.1:8000/api/v1/health/" -ForegroundColor Green
Write-Host "  Swagger UI ... http://127.0.0.1:8000/api/v1/docs/"   -ForegroundColor Green
Write-Host "  Admin ........ http://127.0.0.1:8000/admin/  (admin / admin12345)" -ForegroundColor Green
Write-Host "  Demo ......... admin_demo / bodega_demo / vende_demo  (demo12345)" -ForegroundColor Green
Write-Host ""

.\.venv\Scripts\python.exe manage.py runserver 127.0.0.1:8000
