"""
Fórmulas de reposición — **algoritmo puro** (sin Django).

Nomenclatura (todo en semanas):

    d    demanda semanal estimada
    σ_d  desviación estándar de la demanda semanal
    L    lead time del proveedor
    R    período de revisión
    Z    factor del nivel de servicio (p. ej. 95 % → 1,65)
    S    stock actual
    T    stock en tránsito (compras emitidas y no recibidas)
    m    múltiplo de compra

Fórmulas::

    SS  = Z · σ_d · sqrt(L + R)                 (stock de seguridad)
    ROP = d · (L + R) + SS                      (punto de pedido)
    Q   = max(0, ROP − (S + T))                 (cantidad a pedir)
    Q   = ceil(Q / m) · m                       (redondeo al múltiplo de compra)

Es **explicable** (cada término se devuelve), **auditable** (se guardan los
inputs) y **reproducible** (misma entrada → misma salida). Versión: ``v1``.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

FORMULA_VERSION = "v1"


@dataclass
class ResultadoReposicion:
    stock_seguridad: float
    punto_pedido: float
    cantidad_bruta: float
    cantidad_recomendada: float
    formula_version: str = FORMULA_VERSION
    inputs: dict = field(default_factory=dict)
    motivo: str = ""


def calcular(
    *,
    demanda_semanal: float,
    desviacion_semanal: float,
    lead_time_semanas: float,
    periodo_revision_semanas: float,
    nivel_servicio_z: float,
    stock_actual: float,
    stock_transito: float,
    multiplo_compra: float = 1.0,
) -> ResultadoReposicion:
    d = max(0.0, float(demanda_semanal))
    sigma = max(0.0, float(desviacion_semanal))
    L = max(0.0, float(lead_time_semanas))
    R = max(0.0, float(periodo_revision_semanas))
    Z = max(0.0, float(nivel_servicio_z))
    S = float(stock_actual)
    T = max(0.0, float(stock_transito))
    m = max(1e-9, float(multiplo_compra))

    ciclo = L + R
    ss = Z * sigma * math.sqrt(ciclo)
    rop = d * ciclo + ss
    q_bruta = max(0.0, rop - (S + T))
    q = math.ceil(q_bruta / m) * m if q_bruta > 0 else 0.0

    ss, rop, q_bruta, q = round(ss, 3), round(rop, 3), round(q_bruta, 3), round(q, 3)

    if q > 0:
        motivo = (
            f"Stock {S:g} + tránsito {T:g} = {S + T:g} bajo el punto de pedido {rop:g} "
            f"(demanda {d:g}/sem × {ciclo:g} sem + stock de seguridad {ss:g}). "
            f"Se sugiere comprar {q:g} unidades."
        )
    else:
        motivo = (
            f"Stock {S:g} + tránsito {T:g} = {S + T:g} cubre el punto de pedido {rop:g}. "
            f"No se requiere reposición."
        )

    return ResultadoReposicion(
        stock_seguridad=ss,
        punto_pedido=rop,
        cantidad_bruta=q_bruta,
        cantidad_recomendada=q,
        inputs={
            "demanda_semanal": d, "desviacion_semanal": sigma,
            "lead_time_semanas": L, "periodo_revision_semanas": R,
            "nivel_servicio_z": Z, "stock_actual": S, "stock_transito": T,
            "multiplo_compra": m, "ciclo_semanas": ciclo,
        },
        motivo=motivo,
    )
