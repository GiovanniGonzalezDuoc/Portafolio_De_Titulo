"""
Calcula las recomendaciones de reposición para todos los productos.

Cron de cPanel (diario)::

    30 3 * * *  cd ~/pos_backend && venv/bin/python manage.py calcular_reposicion
"""

from django.core.management.base import BaseCommand

from apps.reposicion import services


class Command(BaseCommand):
    help = "Genera recomendaciones de reposición (predicción + fórmulas)."

    def handle(self, *args, **options):
        r = services.generar_recomendaciones()
        self.stdout.write(
            self.style.SUCCESS(
                f"Recomendaciones: {r['generadas']} generadas "
                f"({r['con_compra_sugerida']} con compra sugerida), "
                f"{r['sin_datos_suficientes']} sin datos, {r['sin_proveedor']} sin proveedor."
            )
        )
