"""Rutas de reposición."""

from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import ParametroReposicionViewSet, RecomendacionReposicionViewSet

router = DefaultRouter()
router.register("recomendaciones", RecomendacionReposicionViewSet, basename="recomendacion")
router.register("parametros", ParametroReposicionViewSet, basename="parametro-reposicion")

urlpatterns = [path("", include(router.urls))]
