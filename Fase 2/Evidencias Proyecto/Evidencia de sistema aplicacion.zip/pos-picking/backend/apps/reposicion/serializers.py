"""Serializers de reposición."""

from rest_framework import serializers

from .models import ParametroReposicion, RecomendacionReposicion


class ParametroReposicionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ParametroReposicion
        fields = [
            "nivel_servicio_z", "horizonte_semanas",
            "periodo_revision_semanas", "formula_version",
        ]
        read_only_fields = ["formula_version"]


class RecomendacionReposicionSerializer(serializers.ModelSerializer):
    producto = serializers.SlugRelatedField(slug_field="sku", read_only=True)
    producto_nombre = serializers.CharField(source="producto.nombre", read_only=True)
    proveedor = serializers.SlugRelatedField(slug_field="razon_social", read_only=True)
    estado_display = serializers.CharField(source="get_estado_display", read_only=True)

    class Meta:
        model = RecomendacionReposicion
        fields = [
            "id", "producto", "producto_nombre", "proveedor",
            "stock_actual", "stock_transito", "demanda_estimada", "desviacion_demanda",
            "lead_time_semanas", "stock_seguridad", "punto_pedido", "cantidad_recomendada",
            "motivo", "inputs", "formula_version", "estado", "estado_display",
            "orden_compra", "generado_en",
        ]
        read_only_fields = fields


class GenerarOrdenSerializer(serializers.Serializer):
    ids = serializers.ListField(child=serializers.IntegerField(), allow_empty=False)
