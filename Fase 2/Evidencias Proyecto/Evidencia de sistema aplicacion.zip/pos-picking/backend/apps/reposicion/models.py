"""Modelos de recomendación de reposición."""

from __future__ import annotations

from decimal import Decimal

from django.db import models


class ParametroReposicion(models.Model):
    """Configuración global (fila única, ``id=1``)."""

    nivel_servicio_z = models.DecimalField(
        "factor de nivel de servicio (Z)", max_digits=4, decimal_places=2, default=Decimal("1.65")
    )
    horizonte_semanas = models.PositiveSmallIntegerField("horizonte de predicción (semanas)", default=4)
    periodo_revision_semanas = models.DecimalField(
        "período de revisión (semanas)", max_digits=4, decimal_places=2, default=Decimal("1")
    )
    formula_version = models.CharField("versión de fórmula", max_length=10, default="v1")

    class Meta:
        verbose_name = "parámetro de reposición"
        verbose_name_plural = "parámetros de reposición"

    def __str__(self) -> str:
        return "Parámetros de reposición"

    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)

    @classmethod
    def get(cls) -> ParametroReposicion:
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj


class EstadoRecomendacion(models.TextChoices):
    SUGERIDA = "SUGERIDA", "Sugerida"
    APROBADA = "APROBADA", "Aprobada"
    DESCARTADA = "DESCARTADA", "Descartada"
    ORDENADA = "ORDENADA", "Convertida en orden de compra"


class RecomendacionReposicion(models.Model):
    producto = models.ForeignKey(
        "catalogo.Producto", on_delete=models.CASCADE, related_name="recomendaciones_reposicion"
    )
    proveedor = models.ForeignKey(
        "proveedores.Proveedor", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="recomendaciones",
    )
    modelo = models.ForeignKey(
        "prediccion.ModeloPrediccion", on_delete=models.PROTECT, null=True, blank=True,
        related_name="recomendaciones",
    )

    stock_actual = models.DecimalField("stock actual", max_digits=12, decimal_places=3)
    stock_transito = models.DecimalField("stock en tránsito", max_digits=12, decimal_places=3, default=0)
    demanda_estimada = models.DecimalField("demanda estimada (horizonte)", max_digits=12, decimal_places=3)
    desviacion_demanda = models.DecimalField("desviación de la demanda", max_digits=12, decimal_places=3, default=0)
    lead_time_semanas = models.DecimalField("lead time (semanas)", max_digits=5, decimal_places=2)

    stock_seguridad = models.DecimalField("stock de seguridad", max_digits=12, decimal_places=3)
    punto_pedido = models.DecimalField("punto de pedido", max_digits=12, decimal_places=3)
    cantidad_recomendada = models.DecimalField("cantidad recomendada", max_digits=12, decimal_places=3)

    motivo = models.CharField("motivo", max_length=400)
    inputs = models.JSONField("inputs de la fórmula", default=dict)
    formula_version = models.CharField("versión de fórmula", max_length=10)

    estado = models.CharField(
        "estado", max_length=12, choices=EstadoRecomendacion.choices,
        default=EstadoRecomendacion.SUGERIDA,
    )
    orden_compra = models.ForeignKey(
        "compras.OrdenCompra", on_delete=models.SET_NULL, null=True, blank=True, related_name="+"
    )
    generado_en = models.DateTimeField("generado en", auto_now_add=True)

    class Meta:
        verbose_name = "recomendación de reposición"
        verbose_name_plural = "recomendaciones de reposición"
        ordering = ["-generado_en", "-cantidad_recomendada"]
        indexes = [
            models.Index(fields=["producto", "generado_en"]),
            models.Index(fields=["estado", "generado_en"]),
        ]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(cantidad_recomendada__gte=0),
                name="recomendacion_cantidad_no_negativa",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.producto.sku}: comprar {self.cantidad_recomendada} ({self.get_estado_display()})"
