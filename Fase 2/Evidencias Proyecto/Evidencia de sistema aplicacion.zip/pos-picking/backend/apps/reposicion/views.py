"""API de recomendación de reposición."""

from __future__ import annotations

import django_filters as filters
from drf_spectacular.utils import extend_schema
from rest_framework import mixins, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.usuarios.permissions import PermisoPorAccion

from . import services
from .models import ParametroReposicion, RecomendacionReposicion
from .serializers import (
    GenerarOrdenSerializer,
    ParametroReposicionSerializer,
    RecomendacionReposicionSerializer,
)


class RecomendacionFilter(filters.FilterSet):
    # `icontains` (no `iexact`): el campo del panel es un buscador libre de
    # SKU ("ej. BEB-001"), no un selector exacto — exigir el SKU completo
    # hacía que pareciera roto para cualquier búsqueda parcial.
    producto = filters.CharFilter(field_name="producto__sku", lookup_expr="icontains")
    con_compra = filters.BooleanFilter(method="_con_compra")

    class Meta:
        model = RecomendacionReposicion
        fields = ["estado", "producto", "proveedor__rut"]

    def _con_compra(self, qs, name, value):
        return qs.filter(cantidad_recomendada__gt=0) if value else qs


class RecomendacionReposicionViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = RecomendacionReposicion.objects.select_related(
        "producto", "proveedor", "modelo"
    ).all()
    serializer_class = RecomendacionReposicionSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        "list": "reposicion.ver",
        "retrieve": "reposicion.ver",
        "generar": "reposicion.ejecutar",
        "aprobar": "reposicion.ejecutar",
        "descartar": "reposicion.ejecutar",
        "generar_orden": "compras.crear",
    }
    filterset_class = RecomendacionFilter
    ordering_fields = ["generado_en", "cantidad_recomendada"]

    @extend_schema(
        request={
            "application/json": {
                "type": "object",
                "properties": {"minimo_semanas": {"type": "integer"}},
            }
        },
        responses=None,
        description="Ejecuta el cálculo para todos los productos activos. `minimo_semanas` "
        "(opcional) reemplaza el mínimo de RF-K8 solo para esta tanda, para poder demostrar "
        "el mecanismo sin cambiar la configuración general.",
    )
    @action(detail=False, methods=["post"])
    def generar(self, request):
        minimo_semanas = None
        crudo = request.data.get("minimo_semanas") if hasattr(request.data, "get") else None
        if crudo not in (None, ""):
            try:
                minimo_semanas = max(1, min(52, int(crudo)))
            except (TypeError, ValueError):
                minimo_semanas = None
        return Response(services.generar_recomendaciones(minimo_semanas=minimo_semanas))

    @action(detail=True, methods=["post"])
    def aprobar(self, request, pk=None):
        rec = services.aprobar(self.get_object())
        return Response(RecomendacionReposicionSerializer(rec).data)

    @action(detail=True, methods=["post"])
    def descartar(self, request, pk=None):
        rec = services.descartar(self.get_object())
        return Response(RecomendacionReposicionSerializer(rec).data)

    @extend_schema(request=GenerarOrdenSerializer, responses=None)
    @action(detail=False, methods=["post"], url_path="generar-orden")
    def generar_orden(self, request):
        serializer = GenerarOrdenSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        orden = services.generar_orden_compra(serializer.validated_data["ids"], request.user)
        from apps.compras.serializers import OrdenCompraSerializer

        return Response(OrdenCompraSerializer(orden).data, status=status.HTTP_201_CREATED)


class ParametroReposicionViewSet(
    mixins.ListModelMixin, mixins.UpdateModelMixin, viewsets.GenericViewSet
):
    serializer_class = ParametroReposicionSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        "list": "reposicion.ver",
        "update": "reposicion.ejecutar",
        "partial_update": "reposicion.ejecutar",
    }

    def get_queryset(self):
        return ParametroReposicion.objects.filter(pk=1)

    def get_object(self):
        return ParametroReposicion.get()

    def list(self, request, *args, **kwargs):
        return Response(ParametroReposicionSerializer(ParametroReposicion.get()).data)
