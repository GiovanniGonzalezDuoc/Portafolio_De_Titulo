from django.contrib import admin

from .models import ParametroReposicion, RecomendacionReposicion


@admin.register(ParametroReposicion)
class ParametroReposicionAdmin(admin.ModelAdmin):
    list_display = ["__str__", "nivel_servicio_z", "horizonte_semanas", "periodo_revision_semanas"]

    def has_add_permission(self, request):
        return not ParametroReposicion.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(RecomendacionReposicion)
class RecomendacionReposicionAdmin(admin.ModelAdmin):
    list_display = ["producto", "proveedor", "cantidad_recomendada", "estado", "generado_en"]
    list_filter = ["estado", "formula_version"]
    search_fields = ["producto__sku"]
    readonly_fields = [f.name for f in RecomendacionReposicion._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
