"""Tests de la integración Django de reposición."""

from decimal import Decimal

import pytest

from apps.catalogo.tests.factories import ProductoFactory
from apps.compras.models import EstadoOrdenCompra
from apps.inventario import services as inventario
from apps.proveedores.models import ProductoProveedor
from apps.proveedores.tests.factories import ProveedorFactory
from apps.reposicion import services
from apps.reposicion.models import EstadoRecomendacion

pytestmark = pytest.mark.django_db


def _producto_surtido(sku, proveedor, *, stock, admin):
    prod = ProductoFactory(sku=sku, costo_referencial=500)
    ProductoProveedor.objects.create(producto=prod, proveedor=proveedor, es_preferente=True, costo=500)
    if stock:
        inventario.entrada(producto=prod, cantidad=stock, usuario=admin, motivo="init")
    return prod


def test_recomendar_producto_genera_recomendacion(modelo_entrenado, admin):
    prov = ProveedorFactory(lead_time_dias=7)
    prod = _producto_surtido("BEB-001", prov, stock=5, admin=admin)

    rec = services.recomendar_producto(prod)
    assert rec is not None
    assert rec.cantidad_recomendada >= 0
    assert rec.punto_pedido > 0
    assert rec.formula_version == "v1"
    assert rec.inputs["ciclo_semanas"] > 0
    assert "punto de pedido" in rec.motivo or "No se requiere" in rec.motivo


def test_sin_proveedor_lanza_error(modelo_entrenado, admin):
    prod = ProductoFactory(sku="BEB-001")
    with pytest.raises(services.ReposicionError):
        services.recomendar_producto(prod)


def test_sin_datos_suficientes_devuelve_none(modelo_entrenado, admin, settings):
    settings.PREDICCION_PERMITIR_SINTETICO = False
    prov = ProveedorFactory()
    prod = _producto_surtido("SIN-HISTORIA", prov, stock=1, admin=admin)
    assert services.recomendar_producto(prod) is None


def test_generar_recomendaciones_resumen(modelo_entrenado, admin):
    prov = ProveedorFactory()
    _producto_surtido("BEB-001", prov, stock=2, admin=admin)
    _producto_surtido("BEB-002", prov, stock=2, admin=admin)
    ProductoFactory(sku="ABA-001")  # sin proveedor

    r = services.generar_recomendaciones()
    assert r["generadas"] == 2
    assert r["sin_proveedor"] == 1


def test_generar_recomendaciones_pasa_el_minimo_puntual(modelo_entrenado, admin, monkeypatch):
    """
    `minimo_semanas` (el control de prueba del panel) debe llegar intacto
    hasta `prediccion.predecir` — es lo que le permite a Reposición mostrar
    una recomendación con datos reales aunque el producto tenga menos
    semanas que el mínimo configurado, solo para esa tanda.
    """
    prov = ProveedorFactory()
    prod = _producto_surtido("BEB-001", prov, stock=2, admin=admin)

    llamadas = []
    original = services.prediccion.predecir

    def espia(*args, **kwargs):
        llamadas.append(kwargs.get("minimo_semanas"))
        return original(*args, **kwargs)

    monkeypatch.setattr(services.prediccion, "predecir", espia)
    services.recomendar_producto(prod, minimo_semanas=3)
    assert llamadas == [3]


def test_regenerar_no_duplica_sugerencia_pendiente(modelo_entrenado, admin):
    """Regresión: generar recomendaciones más de una vez para el mismo
    producto no debe dejar varias filas SUGERIDA (se veían duplicadas en la
    tabla de Reposición). La anterior se reemplaza por la nueva."""
    prov = ProveedorFactory()
    prod = _producto_surtido("BEB-001", prov, stock=5, admin=admin)

    r1 = services.recomendar_producto(prod)
    r2 = services.recomendar_producto(prod)
    assert r1.id != r2.id
    assert services.RecomendacionReposicion.objects.filter(
        producto=prod, estado=EstadoRecomendacion.SUGERIDA
    ).count() == 1


def test_regenerar_no_toca_recomendaciones_ya_aprobadas(modelo_entrenado, admin):
    prov = ProveedorFactory()
    prod = _producto_surtido("BEB-001", prov, stock=5, admin=admin)

    aprobada = services.aprobar(services.recomendar_producto(prod))
    nueva = services.recomendar_producto(prod)
    aprobada.refresh_from_db()
    assert aprobada.estado == EstadoRecomendacion.APROBADA
    assert nueva.estado == EstadoRecomendacion.SUGERIDA


def test_aprobar_descartar(modelo_entrenado, admin):
    prov = ProveedorFactory()
    prod = _producto_surtido("BEB-001", prov, stock=1, admin=admin)
    rec = services.recomendar_producto(prod)

    services.aprobar(rec)
    rec.refresh_from_db()
    assert rec.estado == EstadoRecomendacion.APROBADA

    otra = _producto_surtido("BEB-002", prov, stock=1, admin=admin)
    r2 = services.recomendar_producto(otra)
    services.descartar(r2)
    r2.refresh_from_db()
    assert r2.estado == EstadoRecomendacion.DESCARTADA


def test_generar_orden_desde_recomendaciones(modelo_entrenado, admin):
    prov = ProveedorFactory()
    p1 = _producto_surtido("BEB-001", prov, stock=1, admin=admin)
    p2 = _producto_surtido("BEB-002", prov, stock=1, admin=admin)
    r1 = services.recomendar_producto(p1)
    r2 = services.recomendar_producto(p2)
    services.aprobar(r1)
    services.aprobar(r2)

    orden = services.generar_orden_compra([r1.id, r2.id], admin)
    assert orden.estado == EstadoOrdenCompra.BORRADOR
    assert orden.lineas.count() == 2
    r1.refresh_from_db()
    assert r1.estado == EstadoRecomendacion.ORDENADA
    assert r1.orden_compra == orden


def test_generar_orden_rechaza_multiples_proveedores(modelo_entrenado, admin):
    prov1, prov2 = ProveedorFactory(), ProveedorFactory()
    p1 = _producto_surtido("BEB-001", prov1, stock=1, admin=admin)
    p2 = _producto_surtido("BEB-002", prov2, stock=1, admin=admin)
    r1 = services.aprobar(services.recomendar_producto(p1))
    r2 = services.aprobar(services.recomendar_producto(p2))
    with pytest.raises(services.ReposicionError):
        services.generar_orden_compra([r1.id, r2.id], admin)


# ─── API ────────────────────────────────────────────────────
def test_api_generar_y_listar(modelo_entrenado, api_bodeguero, admin):
    prov = ProveedorFactory()
    _producto_surtido("BEB-001", prov, stock=2, admin=admin)

    r = api_bodeguero.post("/api/v1/reposicion/recomendaciones/generar/")
    assert r.status_code == 200
    assert r.data["generadas"] >= 1

    r = api_bodeguero.get("/api/v1/reposicion/recomendaciones/")
    assert r.data["conteo"] >= 1


def test_api_vendedor_no_ejecuta(modelo_entrenado, api_vendedor):
    assert api_vendedor.post("/api/v1/reposicion/recomendaciones/generar/").status_code == 403


def test_api_parametros(modelo_entrenado, api_bodeguero):
    r = api_bodeguero.get("/api/v1/reposicion/parametros/")
    assert r.status_code == 200
    assert Decimal(str(r.data["nivel_servicio_z"])) == Decimal("1.65")
