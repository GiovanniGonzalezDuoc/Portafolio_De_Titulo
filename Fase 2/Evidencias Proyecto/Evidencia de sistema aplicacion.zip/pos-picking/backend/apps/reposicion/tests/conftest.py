"""Reusa el fixture de modelo entrenado de la app prediccion."""

from apps.prediccion.tests.conftest import modelo_entrenado  # noqa: F401
