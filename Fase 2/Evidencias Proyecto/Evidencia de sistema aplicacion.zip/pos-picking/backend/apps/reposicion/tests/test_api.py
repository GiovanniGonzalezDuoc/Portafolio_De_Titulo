"""Tests de la API de reposición (acciones de los viewsets)."""

from decimal import Decimal

import pytest

from apps.catalogo.tests.factories import ProductoFactory
from apps.compras.models import OrdenCompra
from apps.proveedores.models import ProductoProveedor
from apps.proveedores.tests.factories import ProveedorFactory
from apps.reposicion.models import (
    EstadoRecomendacion,
    ParametroReposicion,
    RecomendacionReposicion,
)

pytestmark = pytest.mark.django_db


def _recomendacion(sku="REP-1", *, proveedor=None, estado=EstadoRecomendacion.SUGERIDA, cantidad=10):
    prod = ProductoFactory(sku=sku, costo_referencial=500)
    return RecomendacionReposicion.objects.create(
        producto=prod,
        proveedor=proveedor,
        stock_actual=Decimal(2),
        demanda_estimada=Decimal(20),
        lead_time_semanas=Decimal(1),
        stock_seguridad=Decimal(3),
        punto_pedido=Decimal(8),
        cantidad_recomendada=Decimal(cantidad),
        motivo="stock bajo el punto de pedido",
        formula_version="v1",
        estado=estado,
    )


def test_listar_requiere_permiso(api_vendedor):
    assert api_vendedor.get("/api/v1/reposicion/recomendaciones/").status_code == 403


def test_bodeguero_lista_recomendaciones(api_bodeguero):
    _recomendacion()
    r = api_bodeguero.get("/api/v1/reposicion/recomendaciones/")
    assert r.status_code == 200
    assert r.data["conteo"] == 1


def test_filtro_producto_es_busqueda_parcial(api_bodeguero):
    """Regresión: el campo 'SKU del producto' del panel es un buscador libre
    ('ej. BEB-001'), no un selector exacto — con `iexact` una búsqueda
    parcial no devolvía nada y el buscador parecía roto."""
    _recomendacion("BEB-001")
    _recomendacion("ABA-002")
    r = api_bodeguero.get("/api/v1/reposicion/recomendaciones/?producto=beb")
    assert r.status_code == 200
    assert r.data["conteo"] == 1
    assert r.data["resultados"][0]["producto"] == "BEB-001"


def test_filtro_con_compra(api_bodeguero):
    _recomendacion("REP-CON", cantidad=10)
    _recomendacion("REP-SIN", cantidad=0)
    r = api_bodeguero.get("/api/v1/reposicion/recomendaciones/?con_compra=true")
    assert r.status_code == 200
    assert r.data["conteo"] == 1
    assert r.data["resultados"][0]["producto"] == "REP-CON"


def test_generar_recomendaciones(api_bodeguero, modelo_entrenado, admin):
    from apps.inventario import services as inventario

    prov = ProveedorFactory(lead_time_dias=7)
    prod = ProductoFactory(sku="BEB-001", costo_referencial=500)
    ProductoProveedor.objects.create(producto=prod, proveedor=prov, es_preferente=True, costo=500)
    inventario.entrada(producto=prod, cantidad=3, usuario=admin, motivo="init")

    r = api_bodeguero.post("/api/v1/reposicion/recomendaciones/generar/")
    assert r.status_code == 200, r.data
    assert r.data["generadas"] >= 1


def test_generar_recomendaciones_con_minimo_puntual(api_bodeguero, modelo_entrenado, admin):
    """El campo opcional `minimo_semanas` del body no debe romper el endpoint."""
    from apps.inventario import services as inventario

    prov = ProveedorFactory(lead_time_dias=7)
    prod = ProductoFactory(sku="BEB-001", costo_referencial=500)
    ProductoProveedor.objects.create(producto=prod, proveedor=prov, es_preferente=True, costo=500)
    inventario.entrada(producto=prod, cantidad=3, usuario=admin, motivo="init")

    r = api_bodeguero.post(
        "/api/v1/reposicion/recomendaciones/generar/", {"minimo_semanas": 3}, format="json"
    )
    assert r.status_code == 200, r.data
    assert r.data["generadas"] >= 1


def test_aprobar_y_descartar(api_bodeguero):
    rec = _recomendacion()
    r = api_bodeguero.post(f"/api/v1/reposicion/recomendaciones/{rec.id}/aprobar/")
    assert r.status_code == 200
    assert r.data["estado"] == EstadoRecomendacion.APROBADA

    otra = _recomendacion("REP-2")
    r = api_bodeguero.post(f"/api/v1/reposicion/recomendaciones/{otra.id}/descartar/")
    assert r.status_code == 200
    assert r.data["estado"] == EstadoRecomendacion.DESCARTADA


def test_aprobar_dos_veces_devuelve_conflicto(api_bodeguero):
    rec = _recomendacion(estado=EstadoRecomendacion.APROBADA)
    r = api_bodeguero.post(f"/api/v1/reposicion/recomendaciones/{rec.id}/aprobar/")
    assert r.status_code == 409
    assert r.data["error"]["codigo"] == "ya_procesada"


def test_generar_orden_desde_recomendaciones_aprobadas(api_bodeguero):
    prov = ProveedorFactory()
    r1 = _recomendacion("OC-1", proveedor=prov, estado=EstadoRecomendacion.APROBADA)
    r2 = _recomendacion("OC-2", proveedor=prov, estado=EstadoRecomendacion.APROBADA)

    r = api_bodeguero.post(
        "/api/v1/reposicion/recomendaciones/generar-orden/",
        {"ids": [r1.id, r2.id]},
        format="json",
    )
    assert r.status_code == 201, r.data
    assert OrdenCompra.objects.count() == 1
    r1.refresh_from_db()
    assert r1.estado == EstadoRecomendacion.ORDENADA
    assert r1.orden_compra_id is not None


def test_generar_orden_sin_seleccion_valida(api_bodeguero):
    r = api_bodeguero.post(
        "/api/v1/reposicion/recomendaciones/generar-orden/", {"ids": [999]}, format="json"
    )
    assert r.status_code in (400, 409, 422)


def test_parametros_get_y_patch(api_bodeguero):
    r = api_bodeguero.get("/api/v1/reposicion/parametros/")
    assert r.status_code == 200
    assert r.data["formula_version"] == "v1"

    r = api_bodeguero.patch(
        "/api/v1/reposicion/parametros/1/", {"horizonte_semanas": 6}, format="json"
    )
    assert r.status_code == 200
    assert ParametroReposicion.get().horizonte_semanas == 6


def test_parametros_patch_requiere_ejecutar(api_vendedor):
    r = api_vendedor.patch(
        "/api/v1/reposicion/parametros/1/", {"horizonte_semanas": 6}, format="json"
    )
    assert r.status_code == 403
