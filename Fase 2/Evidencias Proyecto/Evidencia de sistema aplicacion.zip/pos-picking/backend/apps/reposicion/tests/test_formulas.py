"""Tests de las fórmulas puras de reposición (sin Django)."""

import math

from apps.reposicion.formulas import FORMULA_VERSION, calcular


def test_formula_basica():
    r = calcular(
        demanda_semanal=10, desviacion_semanal=3,
        lead_time_semanas=2, periodo_revision_semanas=1,
        nivel_servicio_z=1.65, stock_actual=5, stock_transito=0,
        multiplo_compra=1,
    )
    ciclo = 3
    ss = 1.65 * 3 * math.sqrt(ciclo)
    rop = 10 * ciclo + ss
    q = max(0, rop - 5)
    assert r.stock_seguridad == round(ss, 3)
    assert r.punto_pedido == round(rop, 3)
    assert r.cantidad_recomendada == round(math.ceil(q), 3)
    assert r.formula_version == FORMULA_VERSION
    assert "punto de pedido" in r.motivo


def test_no_recomienda_si_hay_stock_suficiente():
    r = calcular(
        demanda_semanal=1, desviacion_semanal=0,
        lead_time_semanas=1, periodo_revision_semanas=1,
        nivel_servicio_z=1.65, stock_actual=500, stock_transito=0,
    )
    assert r.cantidad_recomendada == 0
    assert "No se requiere" in r.motivo


def test_stock_en_transito_reduce_la_compra():
    base = {
        "demanda_semanal": 20, "desviacion_semanal": 5,
        "lead_time_semanas": 2, "periodo_revision_semanas": 1,
        "nivel_servicio_z": 1.65, "stock_actual": 10,
    }
    sin_transito = calcular(**base, stock_transito=0)
    con_transito = calcular(**base, stock_transito=30)
    assert con_transito.cantidad_recomendada < sin_transito.cantidad_recomendada


def test_redondeo_al_multiplo_de_compra():
    r = calcular(
        demanda_semanal=10, desviacion_semanal=2,
        lead_time_semanas=1, periodo_revision_semanas=1,
        nivel_servicio_z=1.65, stock_actual=0, stock_transito=0,
        multiplo_compra=12,
    )
    assert r.cantidad_recomendada % 12 == 0
    assert r.cantidad_recomendada >= r.cantidad_bruta


def test_inputs_quedan_registrados_para_auditoria():
    r = calcular(
        demanda_semanal=7, desviacion_semanal=2,
        lead_time_semanas=1.5, periodo_revision_semanas=1,
        nivel_servicio_z=1.28, stock_actual=3, stock_transito=1,
    )
    assert r.inputs["demanda_semanal"] == 7
    assert r.inputs["ciclo_semanas"] == 2.5
    # reproducible: misma entrada -> misma salida
    r2 = calcular(
        demanda_semanal=7, desviacion_semanal=2,
        lead_time_semanas=1.5, periodo_revision_semanas=1,
        nivel_servicio_z=1.28, stock_actual=3, stock_transito=1,
    )
    assert r.cantidad_recomendada == r2.cantidad_recomendada
