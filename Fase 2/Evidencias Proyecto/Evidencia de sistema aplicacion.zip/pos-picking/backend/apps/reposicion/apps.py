from django.apps import AppConfig


class ReposicionConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.reposicion"
    verbose_name = "Recomendación de reposición"
