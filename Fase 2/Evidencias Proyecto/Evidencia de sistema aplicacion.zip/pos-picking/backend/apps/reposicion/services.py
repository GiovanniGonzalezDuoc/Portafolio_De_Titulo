"""
Integración con Django de la recomendación de reposición.

Une: predicción de demanda (``apps.prediccion``) + stock (``apps.inventario``) +
stock en tránsito (``apps.compras``) + proveedor preferente (``apps.proveedores``)
+ las fórmulas puras (``formulas.py``).
"""

from __future__ import annotations

import logging
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from apps.catalogo.models import Producto
from apps.compras.services import stock_en_transito
from apps.core.exceptions import ConflictoEstado, ErrorDominio
from apps.inventario.models import ParametroInventario, Ubicacion
from apps.inventario.services import stock_de
from apps.prediccion import services as prediccion
from apps.proveedores.models import ProductoProveedor

from . import formulas
from .models import (
    EstadoRecomendacion,
    ParametroReposicion,
    RecomendacionReposicion,
)

logger = logging.getLogger("pos.reposicion")


class ReposicionError(ErrorDominio):
    codigo = "reposicion_error"


def _proveedor_preferente(producto):
    pp = (
        ProductoProveedor.objects.filter(producto=producto, proveedor__activo=True)
        .select_related("proveedor")
        .order_by("-es_preferente", "costo")
        .first()
    )
    return pp.proveedor if pp else None


def _multiplo_compra(producto, ubicacion) -> Decimal:
    param = ParametroInventario.objects.filter(producto=producto, ubicacion=ubicacion).first()
    return param.multiplo_compra if param and param.multiplo_compra else Decimal("1")


@transaction.atomic
def recomendar_producto(
    producto, *, ubicacion: Ubicacion | None = None, minimo_semanas: int | None = None
) -> RecomendacionReposicion | None:
    """
    Genera y persiste una recomendación para un producto. Devuelve ``None`` si
    no hay datos suficientes (no se inventa nada).

    ``minimo_semanas`` reemplaza puntualmente el mínimo de RF-K8 (ver
    ``apps.prediccion.services.historia_producto``) solo para esta tanda —
    para poder demostrar el mecanismo sin cambiar la configuración general.
    """
    ubicacion = ubicacion or Ubicacion.principal()
    params = ParametroReposicion.get()

    proveedor = _proveedor_preferente(producto)
    if proveedor is None:
        raise ReposicionError(
            f"{producto.sku} no tiene proveedor asociado.", codigo="sin_proveedor"
        )

    try:
        pred = prediccion.predecir(
            producto, horizonte_semanas=params.horizonte_semanas, persistir=True,
            minimo_semanas=minimo_semanas,
        )
    except prediccion.DatosInsuficientes:
        return None

    lead_semanas = float(proveedor.lead_time_semanas)
    horizonte = float(params.horizonte_semanas) or 1.0
    demanda_total = float(pred.demanda_estimada)
    desv_total = float(pred.desviacion)
    demanda_semanal = demanda_total / horizonte
    # la desviación guardada es del horizonte -> volver a semanal
    desv_semanal = desv_total / (horizonte ** 0.5)

    stock_actual = stock_de(producto, ubicacion)
    transito = stock_en_transito(producto)

    # Al regenerar, la sugerencia anterior de este producto que siga
    # pendiente (SUGERIDA) queda obsoleta: se elimina para no dejar
    # duplicados en la tabla. Las que ya se aprobaron/descartaron/ordenaron
    # no se tocan (son historial de una decisión ya tomada).
    RecomendacionReposicion.objects.filter(
        producto=producto, estado=EstadoRecomendacion.SUGERIDA
    ).delete()

    resultado = formulas.calcular(
        demanda_semanal=demanda_semanal,
        desviacion_semanal=desv_semanal,
        lead_time_semanas=lead_semanas,
        periodo_revision_semanas=float(params.periodo_revision_semanas),
        nivel_servicio_z=float(params.nivel_servicio_z),
        stock_actual=float(stock_actual),
        stock_transito=float(transito),
        multiplo_compra=float(_multiplo_compra(producto, ubicacion)),
    )

    rec = RecomendacionReposicion.objects.create(
        producto=producto,
        proveedor=proveedor,
        modelo=pred.modelo,
        stock_actual=stock_actual,
        stock_transito=transito,
        demanda_estimada=Decimal(str(demanda_total)),
        desviacion_demanda=Decimal(str(desv_total)),
        lead_time_semanas=Decimal(str(round(lead_semanas, 2))),
        stock_seguridad=Decimal(str(resultado.stock_seguridad)),
        punto_pedido=Decimal(str(resultado.punto_pedido)),
        cantidad_recomendada=Decimal(str(resultado.cantidad_recomendada)),
        motivo=resultado.motivo,
        inputs=resultado.inputs,
        formula_version=resultado.formula_version,
    )
    logger.info("Recomendación %s: comprar %s", producto.sku, rec.cantidad_recomendada)
    return rec


def generar_recomendaciones(*, minimo_semanas: int | None = None) -> dict:
    generadas, sin_datos, sin_proveedor, a_comprar = 0, 0, 0, 0
    for producto in Producto.objects.filter(activo=True).select_related("categoria"):
        try:
            rec = recomendar_producto(producto, minimo_semanas=minimo_semanas)
        except ReposicionError:
            sin_proveedor += 1
            continue
        if rec is None:
            sin_datos += 1
            continue
        generadas += 1
        if rec.cantidad_recomendada > 0:
            a_comprar += 1
    resumen = {
        "generadas": generadas,
        "con_compra_sugerida": a_comprar,
        "sin_datos_suficientes": sin_datos,
        "sin_proveedor": sin_proveedor,
        "fecha": timezone.now().isoformat(),
    }
    logger.info("Reposición: %s", resumen)
    return resumen


# ─── Acciones sobre recomendaciones ────────────────────────
def aprobar(rec: RecomendacionReposicion) -> RecomendacionReposicion:
    if rec.estado != EstadoRecomendacion.SUGERIDA:
        raise ConflictoEstado("La recomendación ya fue procesada.", codigo="ya_procesada")
    rec.estado = EstadoRecomendacion.APROBADA
    rec.save(update_fields=["estado"])
    return rec


def descartar(rec: RecomendacionReposicion) -> RecomendacionReposicion:
    if rec.estado in (EstadoRecomendacion.ORDENADA,):
        raise ConflictoEstado("La recomendación ya generó una orden.", codigo="ya_ordenada")
    rec.estado = EstadoRecomendacion.DESCARTADA
    rec.save(update_fields=["estado"])
    return rec


@transaction.atomic
def generar_orden_compra(recomendacion_ids: list[int], usuario):
    """Crea una OC (borrador) agrupando recomendaciones APROBADAS por proveedor."""
    from apps.compras import services as compras

    recs = list(
        RecomendacionReposicion.objects.select_related("producto", "proveedor")
        .filter(id__in=recomendacion_ids, estado=EstadoRecomendacion.APROBADA)
    )
    if not recs:
        raise ReposicionError("No hay recomendaciones aprobadas en la selección.", codigo="sin_aprobadas")

    proveedores = {r.proveedor_id for r in recs}
    if len(proveedores) != 1:
        raise ReposicionError(
            "Las recomendaciones deben ser del mismo proveedor para una orden.",
            codigo="multiples_proveedores",
        )

    proveedor = recs[0].proveedor
    lineas = []
    for r in recs:
        if r.cantidad_recomendada <= 0:
            continue
        lineas.append({
            "producto": r.producto,
            "cantidad": r.cantidad_recomendada,
            "costo_unitario": r.producto.costo_referencial,
        })
    if not lineas:
        raise ReposicionError("Ninguna recomendación sugiere comprar unidades.", codigo="nada_que_comprar")

    orden = compras.crear_orden(
        proveedor=proveedor, lineas=lineas, usuario=usuario,
        observacion="Generada desde recomendaciones de reposición",
    )
    RecomendacionReposicion.objects.filter(id__in=[r.id for r in recs]).update(
        estado=EstadoRecomendacion.ORDENADA, orden_compra=orden
    )
    return orden
