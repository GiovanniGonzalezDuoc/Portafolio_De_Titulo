"""
Genera alertas de inventario (stock bajo, sin stock, reposición).

Cron de cPanel (cada hora)::

    0 * * * *  cd ~/pos_backend && venv/bin/python manage.py generar_alertas
"""

from django.core.management.base import BaseCommand

from apps.alertas.motor import escanear_inventario


class Command(BaseCommand):
    help = "Escanea el inventario y genera/cierra alertas."

    def handle(self, *args, **options):
        resultado = escanear_inventario()
        creadas = resultado["creadas"]
        self.stdout.write(
            self.style.SUCCESS(
                f"Alertas creadas: stock_bajo={creadas.get('STOCK_BAJO', 0)}, "
                f"sin_stock={creadas.get('SIN_STOCK', 0)}, "
                f"reposicion={creadas.get('REPOSICION', 0)} | "
                f"cerradas={resultado['cerradas']}"
            )
        )
