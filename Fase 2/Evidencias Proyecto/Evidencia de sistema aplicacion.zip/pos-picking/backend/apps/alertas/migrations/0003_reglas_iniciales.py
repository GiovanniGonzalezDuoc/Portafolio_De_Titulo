"""Crea una regla por defecto para cada tipo de alerta."""

from django.db import migrations

REGLAS = [
    ("STOCK_BAJO", "WARNING", 0),
    ("SIN_STOCK", "CRITICAL", 0),
    ("REPOSICION", "WARNING", 0),
    ("DISCREPANCIA", "WARNING", 0),
    ("DTE_FALLIDO", "CRITICAL", 0),
    ("ERROR_SISTEMA", "CRITICAL", 0),
]


def cargar(apps, schema_editor):
    ReglaAlerta = apps.get_model("alertas", "ReglaAlerta")
    for tipo, severidad, holgura in REGLAS:
        ReglaAlerta.objects.update_or_create(
            tipo=tipo,
            defaults={"activa": True, "severidad": severidad, "holgura_pct": holgura},
        )


def revertir(apps, schema_editor):
    apps.get_model("alertas", "ReglaAlerta").objects.all().delete()


class Migration(migrations.Migration):
    dependencies = [("alertas", "0002_reglaalerta")]
    operations = [migrations.RunPython(cargar, revertir)]
