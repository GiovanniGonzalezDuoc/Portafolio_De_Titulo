"""
Modelo de alertas.

En la Etapa 6 se usa para las alertas de stock. La Etapa 11 agrega
``ReglaAlerta`` (umbrales configurables), más tipos y el motor por cron.
"""

from __future__ import annotations

from django.conf import settings
from django.db import models

from apps.core.models import TimeStampedModel


class TipoAlerta(models.TextChoices):
    STOCK_BAJO = "STOCK_BAJO", "Stock bajo"
    SIN_STOCK = "SIN_STOCK", "Sin stock"
    REPOSICION = "REPOSICION", "Necesidad de reposición"
    DISCREPANCIA = "DISCREPANCIA", "Discrepancia de inventario"
    DTE_FALLIDO = "DTE_FALLIDO", "Fallo de emisión de documento"
    ERROR_SISTEMA = "ERROR_SISTEMA", "Error importante del sistema"


class Severidad(models.TextChoices):
    INFO = "INFO", "Informativa"
    WARNING = "WARNING", "Advertencia"
    CRITICAL = "CRITICAL", "Crítica"


class EstadoAlerta(models.TextChoices):
    NUEVA = "NUEVA", "Nueva"
    VISTA = "VISTA", "Vista"
    RESUELTA = "RESUELTA", "Resuelta"


class ReglaAlerta(models.Model):
    """
    Configuración por tipo de alerta: si está activa, su severidad y un
    holgura sobre el umbral base (p. ej. avisar cuando el stock esté un 20 %
    por encima del mínimo). Una fila por tipo.
    """

    tipo = models.CharField(
        "tipo", max_length=20, choices=TipoAlerta.choices, unique=True
    )
    activa = models.BooleanField("activa", default=True)
    severidad = models.CharField(
        "severidad", max_length=10, choices=Severidad.choices, default=Severidad.WARNING
    )
    holgura_pct = models.PositiveSmallIntegerField(
        "holgura sobre el umbral (%)", default=0,
        help_text="Solo para STOCK_BAJO: adelanta el aviso este % sobre el mínimo.",
    )
    parametros = models.JSONField("parámetros extra", null=True, blank=True)

    class Meta:
        verbose_name = "regla de alerta"
        verbose_name_plural = "reglas de alerta"
        ordering = ["tipo"]

    def __str__(self) -> str:
        return f"Regla {self.get_tipo_display()} ({'activa' if self.activa else 'inactiva'})"


class AlertaQuerySet(models.QuerySet):
    def abiertas(self):
        return self.exclude(estado=EstadoAlerta.RESUELTA)


class Alerta(TimeStampedModel):
    tipo = models.CharField("tipo", max_length=20, choices=TipoAlerta.choices)
    severidad = models.CharField(
        "severidad", max_length=10, choices=Severidad.choices, default=Severidad.WARNING
    )
    estado = models.CharField(
        "estado", max_length=10, choices=EstadoAlerta.choices, default=EstadoAlerta.NUEVA
    )
    mensaje = models.CharField("mensaje", max_length=300)

    producto = models.ForeignKey(
        "catalogo.Producto",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="alertas",
        verbose_name="producto",
    )
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="alertas",
        verbose_name="usuario relacionado",
    )
    doc_tipo = models.CharField("tipo de documento", max_length=20, blank=True, default="")
    doc_id = models.BigIntegerField("id de documento", null=True, blank=True)

    # Clave para no duplicar alertas abiertas del mismo evento.
    hash_dedupe = models.CharField("hash de deduplicación", max_length=64, db_index=True)

    vista_por = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
    )
    resuelta_por = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
    )
    resuelta_en = models.DateTimeField("resuelta en", null=True, blank=True)

    objects = AlertaQuerySet.as_manager()

    class Meta:
        verbose_name = "alerta"
        verbose_name_plural = "alertas"
        ordering = ["-creado_en"]
        indexes = [
            models.Index(fields=["estado", "severidad"]),
            models.Index(fields=["tipo", "creado_en"]),
        ]

    def __str__(self) -> str:
        return f"[{self.severidad}] {self.get_tipo_display()} — {self.mensaje}"
