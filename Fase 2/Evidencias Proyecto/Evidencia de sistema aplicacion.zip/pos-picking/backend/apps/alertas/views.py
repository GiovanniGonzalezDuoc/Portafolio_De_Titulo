"""API de alertas y reglas de alerta."""

from __future__ import annotations

import django_filters as filters
from drf_spectacular.utils import extend_schema
from rest_framework import mixins, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.usuarios.permissions import PermisoPorAccion

from . import services
from .models import Alerta, ReglaAlerta
from .serializers import (
    AlertaSerializer,
    ReglaAlertaSerializer,
    ResolverVariasSerializer,
)


class AlertaFilter(filters.FilterSet):
    producto = filters.CharFilter(field_name="producto__sku", lookup_expr="iexact")
    desde = filters.DateTimeFilter(field_name="creado_en", lookup_expr="gte")
    hasta = filters.DateTimeFilter(field_name="creado_en", lookup_expr="lte")
    abiertas = filters.BooleanFilter(method="_abiertas")

    class Meta:
        model = Alerta
        fields = ["tipo", "severidad", "estado", "producto"]

    def _abiertas(self, queryset, name, value):
        return queryset.abiertas() if value else queryset


class AlertaViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = Alerta.objects.select_related("producto", "vista_por", "resuelta_por").all()
    serializer_class = AlertaSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        "list": "alertas.ver",
        "retrieve": "alertas.ver",
        "resumen": "alertas.ver",
        "marcar_vista": "alertas.ver",
        "resolver": "alertas.resolver",
        "resolver_varias": "alertas.resolver",
    }
    filterset_class = AlertaFilter
    ordering_fields = ["creado_en", "severidad"]
    search_fields = ["mensaje"]

    @action(detail=False, methods=["get"])
    def resumen(self, request):
        return Response(services.resumen())

    @action(detail=True, methods=["post"], url_path="marcar-vista")
    def marcar_vista(self, request, pk=None):
        alerta = services.marcar_vista(self.get_object(), request.user)
        return Response(AlertaSerializer(alerta).data)

    @action(detail=True, methods=["post"])
    def resolver(self, request, pk=None):
        alerta = services.resolver(self.get_object(), request.user)
        return Response(AlertaSerializer(alerta).data)

    @extend_schema(request=ResolverVariasSerializer, responses={200: None})
    @action(detail=False, methods=["post"], url_path="resolver-varias")
    def resolver_varias(self, request):
        serializer = ResolverVariasSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        n = services.resolver_varias(serializer.validated_data["ids"], request.user)
        return Response({"resueltas": n})


class ReglaAlertaViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, mixins.UpdateModelMixin,
    viewsets.GenericViewSet,
):
    queryset = ReglaAlerta.objects.all()
    serializer_class = ReglaAlertaSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        "list": "alertas.ver",
        "retrieve": "alertas.ver",
        "update": "alertas.configurar",
        "partial_update": "alertas.configurar",
    }
