"""Serializers de alertas."""

from rest_framework import serializers

from .models import Alerta, ReglaAlerta


class AlertaSerializer(serializers.ModelSerializer):
    producto_sku = serializers.CharField(source="producto.sku", read_only=True, default=None)
    producto_nombre = serializers.CharField(source="producto.nombre", read_only=True, default=None)
    tipo_display = serializers.CharField(source="get_tipo_display", read_only=True)
    vista_por = serializers.CharField(source="vista_por.username", read_only=True, default=None)
    resuelta_por = serializers.CharField(source="resuelta_por.username", read_only=True, default=None)

    class Meta:
        model = Alerta
        fields = [
            "id", "tipo", "tipo_display", "severidad", "estado", "mensaje",
            "producto", "producto_sku", "producto_nombre", "doc_tipo", "doc_id",
            "vista_por", "resuelta_por", "resuelta_en", "creado_en", "actualizado_en",
        ]
        read_only_fields = fields


class ReglaAlertaSerializer(serializers.ModelSerializer):
    tipo_display = serializers.CharField(source="get_tipo_display", read_only=True)

    class Meta:
        model = ReglaAlerta
        fields = ["id", "tipo", "tipo_display", "activa", "severidad", "holgura_pct", "parametros"]
        read_only_fields = ["id", "tipo", "tipo_display"]


class ResolverVariasSerializer(serializers.Serializer):
    ids = serializers.ListField(child=serializers.IntegerField(), allow_empty=False)
