"""Tests de la app alertas."""

import pytest

from apps.alertas import services
from apps.alertas.models import Alerta, EstadoAlerta, Severidad, TipoAlerta

pytestmark = pytest.mark.django_db


def test_crear_alerta_y_deduplicar():
    a1 = services.crear_alerta(
        tipo=TipoAlerta.ERROR_SISTEMA, mensaje="algo falló", clave_dedupe="err-1"
    )
    a2 = services.crear_alerta(
        tipo=TipoAlerta.ERROR_SISTEMA, mensaje="algo falló otra vez", clave_dedupe="err-1"
    )
    assert a1 is not None
    assert a2 is None
    assert Alerta.objects.count() == 1


def test_alerta_se_recrea_si_la_anterior_fue_resuelta(admin):
    a1 = services.crear_alerta(
        tipo=TipoAlerta.ERROR_SISTEMA, mensaje="x", clave_dedupe="err-2"
    )
    services.resolver(a1, admin)
    a2 = services.crear_alerta(
        tipo=TipoAlerta.ERROR_SISTEMA, mensaje="x de nuevo", clave_dedupe="err-2"
    )
    assert a2 is not None
    assert Alerta.objects.count() == 2


def test_marcar_vista_y_resolver(admin):
    a = services.crear_alerta(tipo=TipoAlerta.ERROR_SISTEMA, mensaje="x", clave_dedupe="e3")
    services.marcar_vista(a, admin)
    a.refresh_from_db()
    assert a.estado == EstadoAlerta.VISTA and a.vista_por == admin

    services.resolver(a, admin)
    a.refresh_from_db()
    assert a.estado == EstadoAlerta.RESUELTA and a.resuelta_en is not None


def test_api_listar_alertas_requiere_permiso(api_vendedor):
    # vendedor tiene alertas.ver
    assert api_vendedor.get("/api/v1/alertas/").status_code == 200


def test_api_resolver_requiere_permiso_resolver(api_vendedor):
    a = services.crear_alerta(tipo=TipoAlerta.ERROR_SISTEMA, mensaje="x", clave_dedupe="e4")
    r = api_vendedor.post(f"/api/v1/alertas/{a.id}/resolver/")
    assert r.status_code == 403


def test_api_bodeguero_resuelve_alerta(api_bodeguero):
    a = services.crear_alerta(
        tipo=TipoAlerta.STOCK_BAJO, mensaje="stock bajo", severidad=Severidad.WARNING,
        clave_dedupe="e5",
    )
    r = api_bodeguero.post(f"/api/v1/alertas/{a.id}/resolver/")
    assert r.status_code == 200
    assert r.data["estado"] == "RESUELTA"


def test_api_filtro_abiertas(api_admin, admin):
    a1 = services.crear_alerta(tipo=TipoAlerta.STOCK_BAJO, mensaje="a", clave_dedupe="f1")
    services.crear_alerta(tipo=TipoAlerta.STOCK_BAJO, mensaje="b", clave_dedupe="f2")
    services.resolver(a1, admin)

    r = api_admin.get("/api/v1/alertas/?abiertas=true")
    assert r.data["conteo"] == 1
