"""Tests del motor de alertas, reglas y resolución en bloque (Etapa 11)."""

import pytest

from apps.alertas import services
from apps.alertas.models import Alerta, ReglaAlerta, TipoAlerta
from apps.alertas.motor import escanear_inventario
from apps.catalogo.tests.factories import ProductoFactory
from apps.inventario import services as inventario
from apps.inventario.tests.factories import ParametroInventarioFactory, UbicacionFactory

pytestmark = pytest.mark.django_db


def test_reglas_iniciales_existen():
    assert ReglaAlerta.objects.count() == len(TipoAlerta.choices)


def test_regla_inactiva_no_genera_alerta(admin):
    ReglaAlerta.objects.filter(tipo=TipoAlerta.STOCK_BAJO).update(activa=False)
    a = services.crear_alerta(tipo=TipoAlerta.STOCK_BAJO, mensaje="x", clave_dedupe="k1")
    assert a is None


def test_regla_define_severidad():
    ReglaAlerta.objects.filter(tipo=TipoAlerta.REPOSICION).update(severidad="INFO")
    a = services.crear_alerta(tipo=TipoAlerta.REPOSICION, mensaje="x", clave_dedupe="k2")
    assert a.severidad == "INFO"


def test_holgura_adelanta_la_alerta_de_stock_bajo(admin):
    ReglaAlerta.objects.filter(tipo=TipoAlerta.STOCK_BAJO).update(holgura_pct=50)
    ubic = UbicacionFactory(nombre="B1")
    p = ProductoFactory()
    ParametroInventarioFactory(producto=p, ubicacion=ubic, stock_minimo=10)
    # stock 14 > mínimo 10, pero <= 10 * 1.5 -> con holgura sí alerta
    a = services.notificar_stock(producto=p, ubicacion=ubic, cantidad=14, stock_minimo=10)
    assert a is not None and a.tipo == TipoAlerta.STOCK_BAJO


def test_motor_genera_alertas_de_inventario(admin):
    ubic = inventario.Ubicacion.principal()
    bajo = ProductoFactory(sku="BAJO")
    ok = ProductoFactory(sku="OK")
    ParametroInventarioFactory(producto=bajo, ubicacion=ubic, stock_minimo=10, punto_reposicion=15)
    ParametroInventarioFactory(producto=ok, ubicacion=ubic, stock_minimo=2, punto_reposicion=3)
    inventario.entrada(producto=bajo, cantidad=4, usuario=admin, ubicacion=ubic)
    inventario.entrada(producto=ok, cantidad=50, usuario=admin, ubicacion=ubic)

    Alerta.objects.all().delete()
    resultado = escanear_inventario()
    assert resultado["creadas"]["STOCK_BAJO"] == 1
    assert resultado["creadas"]["REPOSICION"] == 1
    assert Alerta.objects.filter(producto=bajo, tipo="STOCK_BAJO").exists()
    assert not Alerta.objects.filter(producto=ok).exists()


def test_motor_cierra_alertas_cuando_el_stock_se_normaliza(admin):
    ubic = inventario.Ubicacion.principal()
    p = ProductoFactory(sku="RECUP")
    ParametroInventarioFactory(producto=p, ubicacion=ubic, stock_minimo=10)
    inventario.entrada(producto=p, cantidad=3, usuario=admin, ubicacion=ubic)
    escanear_inventario()
    assert Alerta.objects.filter(producto=p, tipo="STOCK_BAJO", estado="NUEVA").exists()

    inventario.entrada(producto=p, cantidad=50, usuario=admin, ubicacion=ubic)  # ahora 53
    escanear_inventario()
    assert not Alerta.objects.abiertas().filter(producto=p, tipo="STOCK_BAJO").exists()


def test_escanear_dos_veces_no_duplica_alerta_abierta(admin):
    """Regresión: la clave de deduplicación no debe incluir la fecha — si el
    motor corre en días distintos sobre el mismo problema sin resolver, no
    debe crear una alerta nueva cada vez (quedaban duplicadas en la lista)."""
    ubic = inventario.Ubicacion.principal()
    p = ProductoFactory(sku="DUP")
    ParametroInventarioFactory(producto=p, ubicacion=ubic, stock_minimo=10)
    inventario.entrada(producto=p, cantidad=3, usuario=admin, ubicacion=ubic)

    Alerta.objects.all().delete()
    escanear_inventario()
    escanear_inventario()  # simula el cron corriendo "otro día" sin resolver
    assert Alerta.objects.filter(producto=p, tipo="STOCK_BAJO").count() == 1


def test_resolver_varias(admin):
    a1 = services.crear_alerta(tipo=TipoAlerta.STOCK_BAJO, mensaje="a", clave_dedupe="r1")
    a2 = services.crear_alerta(tipo=TipoAlerta.STOCK_BAJO, mensaje="b", clave_dedupe="r2")
    n = services.resolver_varias([a1.id, a2.id], admin)
    assert n == 2
    assert Alerta.objects.abiertas().count() == 0


def test_resumen(admin):
    services.crear_alerta(tipo=TipoAlerta.STOCK_BAJO, mensaje="a", severidad="WARNING", clave_dedupe="s1")
    services.crear_alerta(tipo=TipoAlerta.SIN_STOCK, mensaje="b", severidad="CRITICAL", clave_dedupe="s2")
    r = services.resumen()
    assert r["abiertas"] == 2
    assert r["por_severidad"]["CRITICAL"] == 1


# ─── API ────────────────────────────────────────────────────
def test_api_resumen(api_admin):
    services.crear_alerta(tipo=TipoAlerta.STOCK_BAJO, mensaje="x", clave_dedupe="a1")
    r = api_admin.get("/api/v1/alertas/resumen/")
    assert r.status_code == 200 and r.data["abiertas"] == 1


def test_api_resolver_varias(api_admin, admin):
    a1 = services.crear_alerta(tipo=TipoAlerta.STOCK_BAJO, mensaje="x", clave_dedupe="b1")
    a2 = services.crear_alerta(tipo=TipoAlerta.STOCK_BAJO, mensaje="y", clave_dedupe="b2")
    r = api_admin.post("/api/v1/alertas/resolver-varias/", {"ids": [a1.id, a2.id]}, format="json")
    assert r.status_code == 200 and r.data["resueltas"] == 2


def test_api_reglas_vendedor_ve_pero_no_configura(api_vendedor):
    regla = ReglaAlerta.objects.get(tipo=TipoAlerta.STOCK_BAJO)
    assert api_vendedor.get("/api/v1/reglas-alerta/").status_code == 200
    r = api_vendedor.patch(f"/api/v1/reglas-alerta/{regla.id}/", {"activa": False}, format="json")
    assert r.status_code == 403


def test_api_reglas_admin_configura(api_admin):
    regla = ReglaAlerta.objects.get(tipo=TipoAlerta.STOCK_BAJO)
    r = api_admin.patch(f"/api/v1/reglas-alerta/{regla.id}/", {"holgura_pct": 25}, format="json")
    assert r.status_code == 200 and r.data["holgura_pct"] == 25


def test_filtro_por_tipo_y_fecha(api_admin):
    services.crear_alerta(tipo=TipoAlerta.STOCK_BAJO, mensaje="x", clave_dedupe="f1")
    services.crear_alerta(tipo=TipoAlerta.SIN_STOCK, mensaje="y", clave_dedupe="f2")
    r = api_admin.get("/api/v1/alertas/?tipo=SIN_STOCK")
    assert r.data["conteo"] == 1
