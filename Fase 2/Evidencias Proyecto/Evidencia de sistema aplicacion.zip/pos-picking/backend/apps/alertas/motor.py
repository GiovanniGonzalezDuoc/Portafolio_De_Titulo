"""
Motor de alertas por proceso programado (cron).

Recorre el inventario y genera/actualiza alertas de stock bajo, sin stock y
necesidad de reposición. Idempotente gracias a la deduplicación de ``crear_alerta``.
"""

from __future__ import annotations

import logging

from apps.inventario.models import ParametroInventario, Stock

from . import services

logger = logging.getLogger("pos.alertas")


def escanear_inventario() -> dict:
    creadas = {"STOCK_BAJO": 0, "SIN_STOCK": 0, "REPOSICION": 0}
    cerradas = 0

    parametros = {
        (p.producto_id, p.ubicacion_id): p
        for p in ParametroInventario.objects.all()
    }

    stocks = Stock.objects.select_related("producto", "ubicacion").filter(
        producto__activo=True
    )
    for stock in stocks:
        producto, ubicacion = stock.producto, stock.ubicacion
        param = parametros.get((producto.id, ubicacion.id))
        minimo = param.stock_minimo if param else 0
        punto = param.punto_reposicion if param else 0

        if stock.cantidad > 0 and (not minimo or stock.cantidad > minimo):
            # El stock se normalizó: cerramos alertas abiertas de stock.
            cerradas += services.resolver_por_producto(producto, "SIN_STOCK", None)
            cerradas += services.resolver_por_producto(producto, "STOCK_BAJO", None)

        a1 = services.notificar_stock(
            producto=producto, ubicacion=ubicacion,
            cantidad=stock.cantidad, stock_minimo=minimo,
        )
        if a1:
            creadas[a1.tipo] = creadas.get(a1.tipo, 0) + 1

        if punto:
            from apps.compras.services import stock_en_transito

            a2 = services.notificar_reposicion(
                producto=producto, ubicacion=ubicacion, cantidad=stock.cantidad,
                punto_reposicion=punto, en_transito=stock_en_transito(producto),
            )
            if a2:
                creadas["REPOSICION"] += 1

    resultado = {"creadas": creadas, "cerradas": cerradas}
    logger.info("Escaneo de alertas: %s", resultado)
    return resultado
