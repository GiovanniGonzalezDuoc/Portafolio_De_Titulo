"""Servicios de alertas: creación con deduplicación, reglas y resolución."""

from __future__ import annotations

import hashlib
import logging
from decimal import Decimal

from django.db.models import Count
from django.utils import timezone

from .models import (
    Alerta,
    EstadoAlerta,
    ReglaAlerta,
    Severidad,
    TipoAlerta,
)

logger = logging.getLogger("pos.alertas")


def _hash(*partes) -> str:
    crudo = "|".join(str(p) for p in partes)
    return hashlib.sha256(crudo.encode()).hexdigest()


def regla(tipo: str) -> ReglaAlerta | None:
    return ReglaAlerta.objects.filter(tipo=tipo).first()


def crear_alerta(
    *,
    tipo: str,
    mensaje: str,
    severidad: str | None = None,
    producto=None,
    usuario=None,
    doc_tipo: str | None = None,
    doc_id: int | None = None,
    clave_dedupe: str | None = None,
) -> Alerta | None:
    """
    Crea una alerta si no existe otra **abierta** con la misma clave de
    deduplicación y si la regla del tipo está activa. Devuelve la alerta creada
    o ``None``.
    """
    r = regla(tipo)
    if r is not None and not r.activa:
        return None
    severidad = severidad or (r.severidad if r else Severidad.WARNING)

    hash_dedupe = _hash(
        clave_dedupe or tipo,
        getattr(producto, "id", ""),
        doc_tipo or "",
        doc_id or "",
    )
    if Alerta.objects.abiertas().filter(hash_dedupe=hash_dedupe).exists():
        return None

    alerta = Alerta.objects.create(
        tipo=tipo,
        mensaje=mensaje,
        severidad=severidad,
        producto=producto,
        usuario=usuario,
        doc_tipo=doc_tipo or "",
        doc_id=doc_id,
        hash_dedupe=hash_dedupe,
    )
    logger.info("Alerta creada: %s — %s", tipo, mensaje)
    return alerta


def notificar_stock(*, producto, ubicacion, cantidad, stock_minimo) -> Alerta | None:
    """Genera SIN_STOCK o STOCK_BAJO según la cantidad tras un movimiento."""
    cantidad = Decimal(str(cantidad))
    minimo = Decimal(str(stock_minimo or 0))

    if cantidad <= 0:
        return crear_alerta(
            tipo=TipoAlerta.SIN_STOCK,
            severidad=Severidad.CRITICAL,
            mensaje=f"Producto sin stock: {producto.nombre} ({producto.sku}) en {ubicacion.nombre}.",
            producto=producto,
            # Sin fecha en la clave: mientras la alerta siga abierta representa
            # el mismo evento, así el motor (que corre por cron) no crea una
            # copia nueva cada día que escanea el mismo problema sin resolver.
            clave_dedupe=f"sin_stock:{producto.id}:{ubicacion.id}",
        )

    r = regla(TipoAlerta.STOCK_BAJO)
    holgura = Decimal(1) + Decimal(r.holgura_pct if r else 0) / Decimal(100)
    if minimo and cantidad <= minimo * holgura:
        return crear_alerta(
            tipo=TipoAlerta.STOCK_BAJO,
            mensaje=(
                f"Stock bajo: {producto.nombre} ({producto.sku}) en {cantidad} "
                f"(mínimo {minimo}) en {ubicacion.nombre}."
            ),
            producto=producto,
            clave_dedupe=f"stock_bajo:{producto.id}:{ubicacion.id}",
        )
    return None


def notificar_reposicion(*, producto, ubicacion, cantidad, punto_reposicion, en_transito) -> Alerta | None:
    if punto_reposicion and Decimal(str(cantidad)) + Decimal(str(en_transito)) <= Decimal(str(punto_reposicion)):
        return crear_alerta(
            tipo=TipoAlerta.REPOSICION,
            mensaje=(
                f"Reposición sugerida: {producto.nombre} ({producto.sku}) — stock {cantidad} "
                f"+ en tránsito {en_transito} ≤ punto de pedido {punto_reposicion}."
            ),
            producto=producto,
            clave_dedupe=f"reposicion:{producto.id}:{ubicacion.id}",
        )
    return None


def notificar_dte_fallido(documento) -> Alerta | None:
    return crear_alerta(
        tipo=TipoAlerta.DTE_FALLIDO,
        severidad=Severidad.CRITICAL,
        mensaje=(
            f"La boleta de la venta {documento.venta.folio} no se pudo emitir tras "
            f"{documento.intentos} intentos: {documento.ultimo_error}"
        ),
        doc_tipo="documento_tributario",
        doc_id=documento.id,
        clave_dedupe=f"dte_fallido:{documento.id}",
    )


# ─── Resolución ─────────────────────────────────────────────
def marcar_vista(alerta: Alerta, usuario) -> Alerta:
    if alerta.estado == EstadoAlerta.NUEVA:
        alerta.estado = EstadoAlerta.VISTA
        alerta.vista_por = usuario
        alerta.save(update_fields=["estado", "vista_por", "actualizado_en"])
    return alerta


def resolver(alerta: Alerta, usuario) -> Alerta:
    alerta.estado = EstadoAlerta.RESUELTA
    alerta.resuelta_por = usuario
    alerta.resuelta_en = timezone.now()
    alerta.save(update_fields=["estado", "resuelta_por", "resuelta_en", "actualizado_en"])
    return alerta


def resolver_varias(ids: list[int], usuario) -> int:
    """Resuelve en bloque. Devuelve cuántas se resolvieron."""
    qs = Alerta.objects.abiertas().filter(id__in=ids)
    n = qs.update(
        estado=EstadoAlerta.RESUELTA, resuelta_por=usuario, resuelta_en=timezone.now()
    )
    return n


def resolver_por_producto(producto, tipo: str, usuario) -> int:
    """Cierra alertas abiertas de un tipo para un producto (p. ej. al reponer stock)."""
    qs = Alerta.objects.abiertas().filter(producto=producto, tipo=tipo)
    return qs.update(
        estado=EstadoAlerta.RESUELTA, resuelta_por=usuario, resuelta_en=timezone.now()
    )


def resumen() -> dict:
    abiertas = Alerta.objects.abiertas()
    por_sev = {row["severidad"]: row["n"] for row in abiertas.values("severidad").annotate(n=Count("id"))}
    por_tipo = {row["tipo"]: row["n"] for row in abiertas.values("tipo").annotate(n=Count("id"))}
    return {
        "abiertas": abiertas.count(),
        "nuevas": abiertas.filter(estado=EstadoAlerta.NUEVA).count(),
        "por_severidad": por_sev,
        "por_tipo": por_tipo,
    }
