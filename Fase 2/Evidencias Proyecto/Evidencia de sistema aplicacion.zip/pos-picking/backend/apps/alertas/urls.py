"""Rutas de alertas."""

from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import AlertaViewSet, ReglaAlertaViewSet

router = DefaultRouter()
router.register("alertas", AlertaViewSet, basename="alerta")
router.register("reglas-alerta", ReglaAlertaViewSet, basename="regla-alerta")

urlpatterns = [path("", include(router.urls))]
