from django.contrib import admin

from .models import Alerta, ReglaAlerta


@admin.register(Alerta)
class AlertaAdmin(admin.ModelAdmin):
    list_display = ["tipo", "severidad", "estado", "mensaje", "producto", "creado_en"]
    list_filter = ["tipo", "severidad", "estado"]
    search_fields = ["mensaje"]
    readonly_fields = ["hash_dedupe", "creado_en", "actualizado_en"]


@admin.register(ReglaAlerta)
class ReglaAlertaAdmin(admin.ModelAdmin):
    list_display = ["tipo", "activa", "severidad", "holgura_pct"]
    list_filter = ["activa", "severidad"]
