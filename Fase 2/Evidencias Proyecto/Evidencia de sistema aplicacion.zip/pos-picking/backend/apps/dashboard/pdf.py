"""
Reporte ejecutivo en PDF del Dashboard — mismo criterio que
``apps.compras.pdf``: ``reportlab`` puro (sin dependencias que compilar,
pensado para el hosting compartido). No hay lógica de negocio nueva acá:
solo formatea lo que ``selectors.py`` ya calcula para las 4 secciones.

Si el usuario no tiene ``dashboard.ver_completo`` el reporte queda acotado
a Ventas (mismo alcance que ve en la pantalla).
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from io import BytesIO
from pathlib import Path

from django.http import HttpResponse
from django.utils import timezone
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from . import selectors

EMPRESA_NOMBRE = "Liquidadora Los Europeos"
_VERDE = colors.HexColor("#00794a")
_GRIS = colors.HexColor("#666666")
_ROJO = colors.HexColor("#c0362f")
_LOGO = Path(__file__).resolve().parent / "assets" / "logo.png"
_LOGO_ANCHO_ORIGINAL, _LOGO_ALTO_ORIGINAL = 480, 376
_ANCHO_UTIL = 17 * cm


def _clp(valor) -> str:
    return f"${int(valor):,}".replace(",", ".")


def _cantidad(valor) -> str:
    """Cantidad en formato chileno, sin ceros de más — mismo criterio que
    ``apps.compras.pdf._cantidad`` (un ``Decimal`` como "16.000" se lee
    "16", no "dieciséis mil")."""
    texto = format(Decimal(valor), "f")
    if "." in texto:
        texto = texto.rstrip("0").rstrip(".")
    entero, _, decimales = texto.partition(".")
    entero_fmt = f"{int(entero):,}".replace(",", ".")
    return f"{entero_fmt},{decimales}" if decimales else entero_fmt


def _logo() -> Image | None:
    if not _LOGO.exists():
        return None
    ancho = 2.6 * cm
    alto = ancho * (_LOGO_ALTO_ORIGINAL / _LOGO_ANCHO_ORIGINAL)
    return Image(str(_LOGO), width=ancho, height=alto)


def _tabla(filas: list[list[str]], anchos: list[float], alinear_num_desde: int = 1) -> Table:
    tabla = Table(filas, colWidths=anchos)
    estilo = [
        ("BACKGROUND", (0, 0), (-1, 0), _VERDE),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dddddd")),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("ALIGN", (alinear_num_desde, 0), (-1, -1), "RIGHT"),
    ]
    tabla.setStyle(TableStyle(estilo))
    return tabla


def reporte_pdf_bytes(*, desde: str | None, hasta: str | None, completo: bool, vendedor=None) -> bytes:
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=letter,
        topMargin=1.8 * cm, bottomMargin=1.8 * cm, leftMargin=1.8 * cm, rightMargin=1.8 * cm,
    )
    estilos = getSampleStyleSheet()
    titulo = ParagraphStyle("titulo", parent=estilos["Heading1"], textColor=_VERDE, spaceAfter=2)
    subtitulo = ParagraphStyle("subtitulo", parent=estilos["Normal"], textColor=_GRIS, spaceAfter=4)
    h2 = ParagraphStyle("h2", parent=estilos["Heading2"], textColor=_VERDE, spaceBefore=16, spaceAfter=8, fontSize=13)
    nota = ParagraphStyle("nota", parent=estilos["Normal"], textColor=_GRIS, fontSize=8.5)

    hoy = date.today().isoformat()
    rango_txt = f"{desde or hoy} al {hasta or hoy}"

    bloque_titulo = [
        Paragraph(EMPRESA_NOMBRE, titulo),
        Paragraph(
            f"Reporte del dashboard — período {rango_txt} · "
            f"generado el {timezone.localtime().strftime('%d/%m/%Y %H:%M')}",
            subtitulo,
        ),
    ]
    logo = _logo()
    encabezado = Table(
        [[bloque_titulo, logo] if logo else [bloque_titulo]],
        colWidths=[13.5 * cm, 3.5 * cm] if logo else [_ANCHO_UTIL],
    )
    encabezado.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ALIGN", (-1, 0), (-1, 0), "RIGHT"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))
    elementos: list = [encabezado]

    # ─── Ventas ──────────────────────────────────────────────
    kpis = selectors.kpis_ventas(desde=desde, hasta=hasta, vendedor=vendedor)
    elementos.append(Paragraph("Ventas", h2))
    variacion = f"{kpis['variacion_pct']:+d}%" if kpis["variacion_pct"] is not None else "—"
    elementos.append(_tabla(
        [
            ["Ventas del período", "Ticket promedio", "N° ventas", "Unidades", "Variación"],
            [_clp(kpis["monto"]), _clp(kpis["ticket_promedio"]), str(kpis["n_ventas"]), _cantidad(kpis["unidades"]), variacion],
        ],
        [3.6 * cm, 3.4 * cm, 3.2 * cm, 3.2 * cm, 3.6 * cm],
        alinear_num_desde=0,
    ))
    elementos.append(Spacer(1, 10))

    top_productos = selectors.productos_mas_vendidos(desde=desde, hasta=hasta, vendedor=vendedor, limite=8)
    if top_productos:
        filas = [["Producto", "SKU", "Unidades", "Monto"]]
        filas += [[p["nombre"], p["sku"], _cantidad(p["unidades"]), _clp(p["monto"])] for p in top_productos]
        elementos.append(Paragraph("Top productos más vendidos", nota))
        elementos.append(_tabla(filas, [7 * cm, 3.5 * cm, 3 * cm, 3.5 * cm], alinear_num_desde=2))

    if completo:
        # ─── Rentabilidad ────────────────────────────────────
        rent = selectors.top_rentabilidad(desde=desde, hasta=hasta, metrica="recuperacion")
        elementos.append(Paragraph("Rentabilidad y recuperación de productos", h2))
        if rent["mejores"] or rent["peores"]:
            filas = [["Producto", "SKU", "Ingresos", "Margen", "Recuperación"]]
            for f in rent["mejores"]:
                pct = f"{f['recuperacion_pct']}%" if f["recuperacion_pct"] is not None else "—"
                filas.append([f["nombre"], f["sku"], _clp(f["ingresos"]), _clp(f["margen"]), pct])
            elementos.append(_tabla(filas, [6 * cm, 2.7 * cm, 2.7 * cm, 2.7 * cm, 2.9 * cm], alinear_num_desde=2))
        else:
            elementos.append(Paragraph("Sin datos suficientes en este rango.", nota))
        elementos.append(Spacer(1, 10))

        # ─── Operación e inventario ────────────────────────────
        inv = selectors.kpis_inventario()
        ciclo = selectors.kpis_ciclo_compras()
        elementos.append(Paragraph("Operación e inventario", h2))
        elementos.append(_tabla(
            [
                ["Stock normal", "Bajo mínimo", "Sin stock", "Valorizado", "En tránsito"],
                [str(inv["productos_normal"]), str(inv["productos_stock_bajo"]), str(inv["productos_sin_stock"]),
                 _clp(inv["valorizado"]), _cantidad(ciclo["unidades_en_transito"])],
            ],
            [3.4 * cm, 3.4 * cm, 3.4 * cm, 3.4 * cm, 3.4 * cm],
            alinear_num_desde=0,
        ))
        elementos.append(Spacer(1, 10))

        # ─── Caja y riesgos ────────────────────────────────────
        alertas = selectors.kpis_alertas()
        riesgos = selectors.kpis_riesgos_operativos()
        elementos.append(Paragraph("Caja y riesgos operativos", h2))
        elementos.append(_tabla(
            [
                ["Alertas abiertas", "Críticas", "Boletas rechazadas", "Discrepancias abiertas"],
                [str(alertas["abiertas"]), str(alertas["criticas"]), str(riesgos["dte_rechazados"]),
                 str(riesgos["discrepancias_abiertas"])],
            ],
            [4.25 * cm] * 4,
            alinear_num_desde=0,
        ))

    doc.build(elementos)
    return buffer.getvalue()


def reporte_pdf_response(*, desde: str | None, hasta: str | None, completo: bool, vendedor=None) -> HttpResponse:
    contenido = reporte_pdf_bytes(desde=desde, hasta=hasta, completo=completo, vendedor=vendedor)
    resp = HttpResponse(contenido, content_type="application/pdf")
    nombre = f"dashboard_{desde or 'hoy'}_a_{hasta or 'hoy'}.pdf"
    resp["Content-Disposition"] = f'attachment; filename="{nombre}"'
    return resp
