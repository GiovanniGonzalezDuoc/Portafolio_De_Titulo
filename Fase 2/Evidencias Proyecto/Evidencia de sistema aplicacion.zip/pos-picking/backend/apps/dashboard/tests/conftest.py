from apps.prediccion.tests.conftest import modelo_entrenado  # noqa: F401
