"""Tests del Dashboard analítico (Ventas + Rentabilidad y recuperación)."""

from datetime import timedelta
from decimal import Decimal

import pytest
from django.utils import timezone

from apps.caja.services import abrir_caja
from apps.compras import services as compras_services
from apps.compras.tests.factories import crear_orden_simple
from apps.ventas import services as ventas_services
from apps.ventas.tests.factories import item, producto_con_stock

pytestmark = pytest.mark.django_db


def _vender(vendedor, producto, cantidad, monto, medio="DEBITO"):
    return ventas_services.confirmar_venta(
        items=[item(producto, cantidad)],
        pagos=[{"medio": medio, "monto": monto}],
        vendedor=vendedor,
    )


def _backdatar(venta, dias: int):
    from apps.ventas.models import Venta

    Venta.objects.filter(id=venta.id).update(creado_en=timezone.now() - timedelta(days=dias))


# ─── Permisos ───────────────────────────────────────────────
def test_ventas_analitica_requiere_login(api):
    assert api.get("/api/v1/dashboard/ventas-analitica/").status_code == 401


def test_rentabilidad_analitica_requiere_ver_completo(api_vendedor):
    assert api_vendedor.get("/api/v1/dashboard/rentabilidad-analitica/").status_code == 403


def test_vendedor_ve_solo_sus_ventas(api_vendedor, vendedor, admin):
    abrir_caja(usuario=vendedor, monto_inicial=1000)
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=50, precio_venta=1000)
    _vender(vendedor, p, 1, 1000)
    _vender(admin, p, 5, 5000)

    r = api_vendedor.get("/api/v1/dashboard/ventas-analitica/")
    assert r.status_code == 200
    assert r.data["kpis"]["monto"] == 1000  # no ve la venta del admin


# ─── Sección 1: Ventas ──────────────────────────────────────
def test_kpis_ventas_con_variacion_vs_periodo_anterior(api_admin, admin):
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=50, precio_venta=1000)
    _vender(admin, p, 2, 2000)  # hoy
    v_ayer = _vender(admin, p, 1, 1000)  # se backdata
    _backdatar(v_ayer, 1)

    hoy = timezone.localdate().isoformat()
    r = api_admin.get(f"/api/v1/dashboard/ventas-analitica/?desde={hoy}&hasta={hoy}")
    kpis = r.data["kpis"]
    assert kpis["monto"] == 2000
    assert kpis["n_ventas"] == 1
    assert kpis["ticket_promedio"] == 2000
    assert kpis["variacion_pct"] == 100  # 2000 vs 1000 el "período anterior" (ayer) = +100%


def test_tendencia_agrupa_por_dia(api_admin, admin):
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=50, precio_venta=1000)
    _vender(admin, p, 1, 1000)
    v_ayer = _vender(admin, p, 1, 1000)
    _backdatar(v_ayer, 1)

    ayer = (timezone.localdate() - timedelta(days=1)).isoformat()
    hoy = timezone.localdate().isoformat()
    r = api_admin.get(f"/api/v1/dashboard/ventas-analitica/?desde={ayer}&hasta={hoy}")
    tendencia = {p["periodo"]: p["monto"] for p in r.data["tendencia"]}
    assert tendencia[ayer] == 1000
    assert tendencia[hoy] == 1000


def test_tendencia_incluye_dias_sin_ventas_con_monto_cero(api_admin, admin):
    """Un día sin ventas dentro del rango no debe omitirse: debe aparecer con
    monto 0 para que `tendencia` tenga el MISMO largo que `tendencia_anterior`
    (position-aligned) — si se omite, el frontend desalinea las dos series y
    la línea se dibuja fuera del gráfico."""
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=50, precio_venta=1000)
    v_hace_2 = _vender(admin, p, 1, 1000)
    _backdatar(v_hace_2, 2)
    # "ayer" (hace 1 día) queda sin ventas — es el día que antes se omitía.
    _vender(admin, p, 1, 1000)

    hace_2 = (timezone.localdate() - timedelta(days=2)).isoformat()
    ayer = (timezone.localdate() - timedelta(days=1)).isoformat()
    hoy = timezone.localdate().isoformat()
    r = api_admin.get(f"/api/v1/dashboard/ventas-analitica/?desde={hace_2}&hasta={hoy}")
    tendencia = r.data["tendencia"]
    assert [p["periodo"] for p in tendencia] == [hace_2, ayer, hoy]
    assert [p["monto"] for p in tendencia] == [1000, 0, 1000]
    assert len(tendencia) == len(r.data["tendencia_anterior"])


def test_tendencia_rango_hoy_antepone_ayer(api_admin, admin):
    """Un rango de un solo día ("Hoy") no forma línea por sí solo, así que
    `serie_ventas` antepone el día anterior como punto de comparación."""
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=50, precio_venta=1000)
    _vender(admin, p, 2, 2000)  # hoy
    v_ayer = _vender(admin, p, 1, 1000)
    _backdatar(v_ayer, 1)

    ayer = (timezone.localdate() - timedelta(days=1)).isoformat()
    hoy = timezone.localdate().isoformat()
    r = api_admin.get(f"/api/v1/dashboard/ventas-analitica/?desde={hoy}&hasta={hoy}")
    tendencia = r.data["tendencia"]
    assert [p["periodo"] for p in tendencia] == [ayer, hoy]
    assert tendencia[0]["monto"] == 1000
    assert tendencia[1]["monto"] == 2000


def test_top_productos_ordena_por_unidades(api_admin, admin):
    abrir_caja(usuario=admin, monto_inicial=1000)
    p1 = producto_con_stock(admin, cantidad=50, precio_venta=1000, sku="TOP-1")
    p2 = producto_con_stock(admin, cantidad=50, precio_venta=1000, sku="TOP-2")
    _vender(admin, p1, 10, 10000)
    _vender(admin, p2, 3, 3000)

    r = api_admin.get("/api/v1/dashboard/ventas-analitica/")
    top = r.data["top_productos"]
    assert top[0]["sku"] == "TOP-1"
    assert Decimal(str(top[0]["unidades"])) == 10


def test_desglose_por_medio_de_pago(api_admin, admin):
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=50, precio_venta=1000)
    _vender(admin, p, 2, 2000, medio="EFECTIVO")
    _vender(admin, p, 1, 1000, medio="DEBITO")

    r = api_admin.get("/api/v1/dashboard/ventas-analitica/")
    por_medio = {m["medio"]: m["monto"] for m in r.data["por_medio_pago"]}
    assert por_medio["EFECTIVO"] == 2000
    assert por_medio["DEBITO"] == 1000


def test_desglose_por_categoria(api_admin, admin):
    from apps.catalogo.tests.factories import CategoriaFactory

    abrir_caja(usuario=admin, monto_inicial=1000)
    cat_a = CategoriaFactory(nombre="Bebidas")
    cat_b = CategoriaFactory(nombre="Abarrotes")
    p1 = producto_con_stock(admin, cantidad=50, precio_venta=1000, categoria=cat_a)
    p2 = producto_con_stock(admin, cantidad=50, precio_venta=1000, categoria=cat_b)
    _vender(admin, p1, 2, 2000)
    _vender(admin, p2, 1, 1000)

    r = api_admin.get("/api/v1/dashboard/ventas-analitica/")
    por_cat = {c["categoria"]: c["monto"] for c in r.data["por_categoria"]}
    assert por_cat["Bebidas"] == 2000
    assert por_cat["Abarrotes"] == 1000


def test_ventas_analitica_sin_n_mas_uno(api_admin, admin, django_assert_max_num_queries):
    """RF-J10: la cantidad de consultas no debe crecer con el número de
    productos/ventas — todo se resuelve con aggregate()/annotate()."""
    abrir_caja(usuario=admin, monto_inicial=1000)
    for i in range(15):
        p = producto_con_stock(admin, cantidad=50, precio_venta=1000, sku=f"NQ1-{i}")
        _vender(admin, p, 1, 1000)

    # 15 + un puñado fijo de consultas agregadas más (margen, anulaciones,
    # descuentos, mix mayorista/retail, rotación de inventario, tendencia
    # anterior, ventas por día de semana, top rendimiento, precisión de
    # recepción) — todas aggregate()/values().annotate(), ninguna crece con N.
    with django_assert_max_num_queries(34):
        api_admin.get("/api/v1/dashboard/ventas-analitica/")


def test_margen_global_solo_visible_con_ver_completo(api_admin, api_vendedor, admin):
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=10, precio_venta=1000, costo_referencial=600)
    _vender(admin, p, 2, 2000)  # ingresos 2000, margen 2000 - 2*600 = 800

    completo = api_admin.get("/api/v1/dashboard/ventas-analitica/")
    assert completo.data["margen"]["margen"] == 800
    assert completo.data["margen"]["margen_pct"] == pytest.approx(40.0, rel=0.01)
    assert completo.data["rotacion_inventario"]["costo_venta"] == 1200

    acotado = api_vendedor.get("/api/v1/dashboard/ventas-analitica/")
    assert "margen" not in acotado.data
    assert "rotacion_inventario" not in acotado.data


def test_tasa_anulacion_cuenta_ventas_anuladas(api_admin, admin):
    from apps.ventas import services as ventas_services

    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=10, precio_venta=1000)
    _vender(admin, p, 1, 1000)
    anulada = _vender(admin, p, 1, 1000)
    ventas_services.anular_venta(anulada, usuario=admin, motivo="prueba")

    r = api_admin.get("/api/v1/dashboard/ventas-analitica/")
    anulaciones = r.data["anulaciones"]
    assert anulaciones["anuladas_n"] == 1
    assert anulaciones["anuladas_pct"] == pytest.approx(50.0, rel=0.01)
    assert anulaciones["monto_anulado"] == 1000


def test_mix_tipo_cliente_separa_mayorista_y_retail(api_admin, admin):
    from apps.ventas import services as ventas_services

    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=10, precio_venta=1000)
    _vender(admin, p, 1, 1000)
    ventas_services.confirmar_venta(
        items=[item(p, 1)], pagos=[{"medio": "DEBITO", "monto": 1000}],
        vendedor=admin, es_mayorista=True,
    )

    r = api_admin.get("/api/v1/dashboard/ventas-analitica/")
    mix = {f["tipo"]: f for f in r.data["mix_cliente"]}
    assert mix["Retail"]["monto"] == 1000
    assert mix["Mayorista"]["monto"] == 1000


def test_kpis_descuentos_suma_lo_otorgado(api_admin, admin):
    from apps.ventas import services as ventas_services

    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=10, precio_venta=1000)
    ventas_services.confirmar_venta(
        items=[item(p, 1, descuento=40)],  # bruto 1000, descuento 40 (4 %, bajo el tope de 5 %)
        pagos=[{"medio": "DEBITO", "monto": 960}],
        vendedor=admin,
    )

    r = api_admin.get("/api/v1/dashboard/ventas-analitica/")
    descuentos = r.data["descuentos"]
    assert descuentos["descuento_total"] == 40
    assert descuentos["descuento_pct"] == pytest.approx(4.0, rel=0.01)
    assert descuentos["tope_pct"] == pytest.approx(5.0, rel=0.01)


def test_unidades_por_semana_agrupa_iso(api_admin, admin):
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=10, precio_venta=1000)
    _vender(admin, p, 3, 3000)

    r = api_admin.get("/api/v1/dashboard/ventas-analitica/")
    semanas = r.data["unidades_semana"]
    assert len(semanas) == 1
    assert semanas[0]["unidades"] == 3


def test_mapa_presion_solo_visible_con_ver_completo(api_admin, api_vendedor, admin):
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=10, precio_venta=1000)
    _vender(admin, p, 1, 1000)

    completo = api_admin.get("/api/v1/dashboard/ventas-analitica/")
    matriz = completo.data["mapa_presion"]
    assert len(matriz) == 5
    assert all(len(fila) == 7 for fila in matriz)
    assert sum(sum(fila) for fila in matriz) == 1

    acotado = api_vendedor.get("/api/v1/dashboard/ventas-analitica/")
    assert "mapa_presion" not in acotado.data


def test_tendencia_anterior_alinea_por_posicion(api_admin, admin):
    """El período anterior a "hoy" es "ayer" — la venta de ayer debe
    aparecer en la posición 0 de `tendencia_anterior`, sin importar la
    fecha real."""
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=10, precio_venta=1000)
    de_ayer = _vender(admin, p, 1, 1000)
    _backdatar(de_ayer, dias=1)

    r = api_admin.get("/api/v1/dashboard/ventas-analitica/")
    assert r.data["tendencia_anterior"] == [1000]


def test_ventas_por_dia_semana_cuenta_en_el_dia_correcto(api_admin, admin):
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=10, precio_venta=1000)
    _vender(admin, p, 1, 1000)
    _vender(admin, p, 1, 1000)

    r = api_admin.get("/api/v1/dashboard/ventas-analitica/")
    conteo = r.data["ventas_por_dia_semana"]
    assert len(conteo) == 7
    hoy_idx = timezone.localdate().weekday()
    assert conteo[hoy_idx] == 2
    assert sum(conteo) == 2


def test_top_rendimiento_incluye_ventas_margen_y_stock(api_admin, admin):
    p = producto_con_stock(admin, cantidad=30, precio_venta=2000, costo_referencial=1200, sku="TOP-1")
    abrir_caja(usuario=admin, monto_inicial=1000)
    _vender(admin, p, 5, 10000)  # ingresos 10000, margen 10000 - 5*1200 = 4000

    r = api_admin.get("/api/v1/dashboard/ventas-analitica/")
    fila = next(f for f in r.data["top_rendimiento"] if f["sku"] == "TOP-1")
    assert Decimal(str(fila["unidades"])) == 5
    assert fila["ventas"] == 10000
    assert fila["margen_pct"] == pytest.approx(40.0, rel=0.01)
    assert Decimal(str(fila["stock"])) == 25  # 30 iniciales - 5 vendidas
    assert fila["categoria"]


def test_precision_recepcion_calcula_porcentaje_de_lineas_completas(api_admin, admin):
    from apps.proveedores.tests.factories import ProveedorFactory

    proveedor = ProveedorFactory()
    p1 = producto_con_stock(admin, cantidad=10, precio_venta=1000, sku="PREC-1")
    p2 = producto_con_stock(admin, cantidad=10, precio_venta=1000, sku="PREC-2")
    orden = crear_orden_simple(
        admin, proveedor=proveedor, productos=[(p1, Decimal("10"), 500), (p2, Decimal("10"), 500)], emitir=True,
    )
    linea1, linea2 = orden.lineas.all()
    compras_services.recibir(orden=orden, lineas=[{"linea_orden": linea1, "cantidad": Decimal("10")}], usuario=admin)
    compras_services.recibir(orden=orden, lineas=[{"linea_orden": linea2, "cantidad": Decimal("4")}], usuario=admin)

    r = api_admin.get("/api/v1/dashboard/ventas-analitica/")
    precision = r.data["precision_recepcion"]
    assert precision["lineas_recibidas"] == 2
    assert precision["lineas_completas"] == 1
    assert precision["lineas_incompletas"] == 1
    assert precision["precision_pct"] == pytest.approx(50.0, rel=0.01)


# ─── Sección 2: Rentabilidad y recuperación de productos ────
def test_recuperacion_pct_y_margen(api_admin, admin):
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=20, precio_venta=2000, costo_referencial=500, sku="REC-1")

    from apps.proveedores.tests.factories import ProveedorFactory

    proveedor = ProveedorFactory()
    orden = crear_orden_simple(admin, proveedor=proveedor, productos=[(p, Decimal("10"), 400)], emitir=True)
    linea = orden.lineas.first()
    compras_services.recibir(orden=orden, lineas=[{"linea_orden": linea, "cantidad": Decimal("10")}], usuario=admin)

    # recibir() actualiza costo_referencial al costo real recibido (400, el
    # cotizado en la orden, ya que no se manda un costo_unitario puntual) —
    # ese es el costo vigente al momento de la venta, no el 500 original.
    _vender(admin, p, 5, 10000)  # ingresos 10000, margen = 10000 - 5*400 = 8000

    r = api_admin.get("/api/v1/dashboard/rentabilidad-analitica/")
    fila = next(f for f in r.data["mejores"] if f["sku"] == "REC-1")
    assert fila["ingresos"] == 10000
    assert fila["margen"] == 8000
    assert fila["costo_compra"] == 10 * 400
    assert fila["recuperacion_pct"] == pytest.approx(10000 / 4000 * 100, rel=0.01)


def test_top_rentabilidad_metrica_margen_ordena_por_margen(api_admin, admin):
    abrir_caja(usuario=admin, monto_inicial=1000)
    alto = producto_con_stock(admin, cantidad=20, precio_venta=5000, costo_referencial=500, sku="ALTO-M")
    bajo = producto_con_stock(admin, cantidad=20, precio_venta=1000, costo_referencial=900, sku="BAJO-M")
    _vender(admin, alto, 1, 5000)  # margen 4500
    _vender(admin, bajo, 1, 1000)  # margen 100

    r = api_admin.get("/api/v1/dashboard/rentabilidad-analitica/?metrica=margen")
    assert r.data["metrica"] == "margen"
    assert r.data["mejores"][0]["sku"] == "ALTO-M"


def test_top_rentabilidad_incluye_listado_completo_ordenado(api_admin, admin):
    """`todas` alimenta la tabla de detalle: TODOS los productos con ventas
    en el período, no solo el top/bottom 5 — mismo orden que `mejores`."""
    abrir_caja(usuario=admin, monto_inicial=1000)
    alto = producto_con_stock(admin, cantidad=20, precio_venta=5000, costo_referencial=500, sku="ALTO-M")
    bajo = producto_con_stock(admin, cantidad=20, precio_venta=1000, costo_referencial=900, sku="BAJO-M")
    _vender(admin, alto, 1, 5000)  # margen 4500
    _vender(admin, bajo, 1, 1000)  # margen 100

    r = api_admin.get("/api/v1/dashboard/rentabilidad-analitica/?metrica=margen")
    todas = r.data["todas"]
    assert [f["sku"] for f in todas] == ["ALTO-M", "BAJO-M"]


def test_producto_sin_compras_en_el_periodo_no_tiene_recuperacion_pct(api_admin, admin):
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=20, precio_venta=1000, sku="SIN-COMPRA")
    _vender(admin, p, 1, 1000)

    r = api_admin.get("/api/v1/dashboard/rentabilidad-analitica/")
    todas = r.data["mejores"] + r.data["peores"]
    fila = next((f for f in todas if f["sku"] == "SIN-COMPRA"), None)
    # sin costo de compra en el período, no puede calcularse el % -> no debe
    # aparecer en el ranking por recuperación (si aparece, con pct None)
    assert fila is None or fila["recuperacion_pct"] is None


def test_serie_producto_evolucion_y_rotacion(api_admin, admin):
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=100, precio_venta=1000, costo_referencial=600, sku="DET-1")

    from apps.proveedores.tests.factories import ProveedorFactory

    proveedor = ProveedorFactory()
    orden = crear_orden_simple(admin, proveedor=proveedor, productos=[(p, Decimal("10"), 500)], emitir=True)
    linea = orden.lineas.first()
    compras_services.recibir(orden=orden, lineas=[{"linea_orden": linea, "cantidad": Decimal("10")}], usuario=admin)

    # recibir() deja costo_referencial en 500 (el cotizado, sin override) —
    # ese es el vigente al vender, no el 600 original de la factory.
    _vender(admin, p, 4, 4000)  # ingresos 4000, margen 4000 - 4*500 = 2000

    r = api_admin.get("/api/v1/dashboard/rentabilidad-analitica/DET-1/")
    assert r.status_code == 200
    ultimo = r.data["serie_recuperacion"][-1]
    assert ultimo["margen"] == 2000
    assert ultimo["recuperacion_pct"] == pytest.approx(4000 / 5000 * 100, rel=0.01)
    rotacion_hoy = r.data["serie_rotacion"][-1]
    # stock actual: 100 iniciales + 10 recibidas - 4 vendidas = 106
    assert rotacion_hoy["rotacion"] == pytest.approx(4 / 106, rel=0.01)


def test_producto_inexistente_404(api_admin):
    r = api_admin.get("/api/v1/dashboard/rentabilidad-analitica/NO-EXISTE/")
    assert r.status_code == 404


# ─── Sección 3: Operación e inventario ──────────────────────
def test_operacion_inventario_requiere_ver_completo(api_vendedor):
    assert api_vendedor.get("/api/v1/dashboard/operacion-inventario/").status_code == 403


def test_salud_inventario_desglosa_normal_bajo_sin_stock(api_admin, admin):
    """Regresión: el desglose necesita las 3 categorías sumadas al total de
    productos activos, no solo los dos conteos de excepción."""
    from apps.catalogo.tests.factories import ProductoFactory
    from apps.inventario import services as inventario
    from apps.inventario.tests.factories import ParametroInventarioFactory

    normal = ProductoFactory(sku="SALUD-1")
    inventario.entrada(producto=normal, cantidad=50, usuario=admin, motivo="init")
    bajo = ProductoFactory(sku="SALUD-2")
    inventario.entrada(producto=bajo, cantidad=2, usuario=admin, motivo="init")
    ParametroInventarioFactory(producto=bajo, ubicacion=inventario.Ubicacion.principal(), stock_minimo=10)
    sin_stock = ProductoFactory(sku="SALUD-3")
    inventario.entrada(producto=sin_stock, cantidad=5, usuario=admin, motivo="init")
    inventario.salida(producto=sin_stock, cantidad=5, usuario=admin, motivo="venta simulada")

    r = api_admin.get("/api/v1/dashboard/operacion-inventario/")
    salud = r.data["salud_inventario"]
    assert salud["productos_sin_stock"] == 1
    assert salud["productos_stock_bajo"] == 1
    assert salud["productos_normal"] == salud["productos_activos"] - 2


def test_ciclo_compras_cuenta_ordenes_pendientes_y_transito(api_admin, admin):
    crear_orden_simple(admin, emitir=True)  # OC EMITIDA -> pendiente de recepción
    r = api_admin.get("/api/v1/dashboard/operacion-inventario/")
    ciclo = r.data["ciclo_compras"]
    assert ciclo["ordenes_pendientes_recepcion"] == 1
    assert Decimal(str(ciclo["unidades_en_transito"])) == 10


def test_prediccion_cuenta_la_ultima_por_producto(api_admin, admin, modelo_entrenado):
    """Si un producto se recalcula varias veces, cuenta su ÚLTIMO nivel de
    confianza, no una fila por cada recálculo."""
    from apps.catalogo.tests.factories import ProductoFactory
    from apps.prediccion import services as prediccion

    p1 = ProductoFactory(sku="BEB-001")
    p2 = ProductoFactory(sku="BEB-002")
    prediccion.predecir(p1, horizonte_semanas=4)
    prediccion.predecir(p1, horizonte_semanas=4)  # recalculado: no debe duplicar
    prediccion.predecir(p2, horizonte_semanas=4)

    r = api_admin.get("/api/v1/dashboard/operacion-inventario/")
    ia = r.data["prediccion"]
    assert ia["con_prediccion"] == 2
    assert ia["sin_prediccion"] == ia["productos_activos"] - 2


def test_quiebre_inminente_detecta_riesgo_de_stockout(api_admin, admin, modelo_entrenado):
    from apps.catalogo.tests.factories import ProductoFactory
    from apps.inventario import services as inventario
    from apps.prediccion.models import PrediccionDemanda

    urgente = ProductoFactory(sku="URG-1")
    inventario.entrada(producto=urgente, cantidad=4, usuario=admin, motivo="init")
    PrediccionDemanda.objects.create(
        producto=urgente, modelo=modelo_entrenado, horizonte_semanas=4,
        demanda_estimada=Decimal("28"),  # 7 unidades/semana -> stock de 4 dura 4 días
    )
    tranquilo = ProductoFactory(sku="OK-1")
    inventario.entrada(producto=tranquilo, cantidad=1000, usuario=admin, motivo="init")
    PrediccionDemanda.objects.create(
        producto=tranquilo, modelo=modelo_entrenado, horizonte_semanas=4,
        demanda_estimada=Decimal("28"),
    )

    r = api_admin.get("/api/v1/dashboard/operacion-inventario/")
    riesgos = {q["sku"]: q for q in r.data["quiebre_inminente"]}
    assert "URG-1" in riesgos
    assert riesgos["URG-1"]["dias_restantes"] == pytest.approx(4.0, rel=0.01)
    assert "OK-1" not in riesgos


def test_baja_rotacion_prioriza_stock_alto_con_pocas_ventas(api_admin, admin):
    quieto = producto_con_stock(admin, cantidad=200, precio_venta=1000, sku="QUIETO-1")
    activo = producto_con_stock(admin, cantidad=5, precio_venta=1000, sku="ACTIVO-1")
    abrir_caja(usuario=admin, monto_inicial=1000)
    _vender(admin, activo, 5, 5000)  # se vendió todo -> no es candidato

    r = api_admin.get("/api/v1/dashboard/operacion-inventario/")
    baja = {f["sku"]: f for f in r.data["baja_rotacion"]}
    assert baja["QUIETO-1"]["unidades_vendidas"] == 0
    assert baja["QUIETO-1"]["stock_actual"] == 200
    assert "ACTIVO-1" not in baja


def test_desempeno_proveedores_calcula_dias_promedio(api_admin, admin):
    from apps.proveedores.tests.factories import ProveedorFactory

    proveedor = ProveedorFactory(razon_social="Proveedor Lento SPA")
    p = producto_con_stock(admin, cantidad=10, precio_venta=1000, sku="LEAD-1")
    orden = crear_orden_simple(admin, proveedor=proveedor, productos=[(p, Decimal("10"), 400)], emitir=True)
    orden.fecha_emision = timezone.now() - timedelta(days=3)
    orden.save(update_fields=["fecha_emision"])
    linea = orden.lineas.first()
    compras_services.recibir(orden=orden, lineas=[{"linea_orden": linea, "cantidad": Decimal("10")}], usuario=admin)

    r = api_admin.get("/api/v1/dashboard/operacion-inventario/")
    fila = next(f for f in r.data["proveedores"] if f["proveedor"] == "Proveedor Lento SPA")
    assert fila["dias_promedio"] == pytest.approx(3.0, abs=0.1)
    assert fila["n_recepciones"] == 1


def test_valorizacion_por_ubicacion_agrupa_por_bodega(api_admin, admin):
    from apps.inventario import services as inventario
    from apps.inventario.models import Ubicacion

    otra = Ubicacion.objects.create(nombre="Bodega Secundaria")
    p = producto_con_stock(admin, cantidad=10, precio_venta=1000, costo_referencial=500, sku="UB-1")
    inventario.entrada(producto=p, cantidad=5, usuario=admin, ubicacion=otra, motivo="init secundaria")

    r = api_admin.get("/api/v1/dashboard/operacion-inventario/")
    por_ubicacion = {f["ubicacion"]: f for f in r.data["por_ubicacion"]}
    assert por_ubicacion["Bodega Secundaria"]["valorizado"] == 5 * 500
    assert por_ubicacion["Bodega Principal"]["valorizado"] == 10 * 500


# ─── Sección 4: Caja y riesgos operativos ───────────────────
def test_caja_riesgos_requiere_ver_completo(api_vendedor):
    assert api_vendedor.get("/api/v1/dashboard/caja-riesgos/").status_code == 403


def test_ventas_por_cajero_hoy_vs_ayer(api_admin, admin, vendedor):
    from apps.ventas.models import Venta

    abrir_caja(usuario=admin, monto_inicial=1000)
    abrir_caja(usuario=vendedor, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=50, precio_venta=1000)

    _vender(admin, p, 1, 1000)  # admin: hoy 1000
    v_ayer = _vender(vendedor, p, 2, 2000)
    Venta.objects.filter(id=v_ayer.id).update(creado_en=timezone.now() - timedelta(days=1))

    r = api_admin.get("/api/v1/dashboard/caja-riesgos/")
    cajeros = {c["usuario"]: c for c in r.data["caja"]["cajeros"]}
    assert cajeros[admin.username]["hoy"] == 1000
    assert cajeros[admin.username]["ayer"] == 0
    assert cajeros[vendedor.username]["hoy"] == 0
    assert cajeros[vendedor.username]["ayer"] == 2000
    assert r.data["caja"]["cajas_abiertas"] == 2


def test_tendencia_margen_incluye_hoy(api_admin, admin):
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=10, precio_venta=1000, costo_referencial=600)
    _vender(admin, p, 2, 2000)  # ingresos 2000, margen 2000 - 2*600 = 800

    r = api_admin.get("/api/v1/dashboard/caja-riesgos/")
    serie = r.data["tendencia_margen"]
    assert len(serie) >= 1
    hoy = serie[-1]
    assert hoy["ingresos"] == 2000
    assert hoy["margen"] == 800


def test_riesgos_operativos(api_admin, admin):
    from apps.alertas import services as alertas_services
    from apps.alertas.models import TipoAlerta
    from apps.boleta.models import DocumentoTributario, EstadoDTE

    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=10, precio_venta=1000)
    venta = _vender(admin, p, 1, 1000)
    DocumentoTributario.objects.filter(venta=venta).update(estado=EstadoDTE.RECHAZADO)
    alertas_services.crear_alerta(tipo=TipoAlerta.DISCREPANCIA, mensaje="conteo distinto", clave_dedupe="disc-test")

    r = api_admin.get("/api/v1/dashboard/caja-riesgos/")
    riesgos = r.data["riesgos_operativos"]
    assert riesgos["dte_rechazados"] == 1
    assert riesgos["discrepancias_abiertas"] == 1


def test_discrepancias_caja_suma_diferencia_absoluta(api_admin, admin):
    from apps.caja.services import cerrar_caja

    caja = abrir_caja(usuario=admin, monto_inicial=1000)
    cerrar_caja(caja=caja, monto_contado=1300, usuario=admin)  # esperado 1000 -> diferencia +300

    r = api_admin.get("/api/v1/dashboard/caja-riesgos/")
    disc = r.data["discrepancias_caja"]
    assert disc["cierres"] == 1
    assert disc["con_diferencia"] == 1
    assert disc["monto_absoluto"] == 300


# ─── Exportar reporte PDF ────────────────────────────────────
def test_exportar_requiere_login(api):
    assert api.get("/api/v1/dashboard/exportar/").status_code == 401


def test_exportar_devuelve_pdf(api_admin, admin):
    abrir_caja(usuario=admin, monto_inicial=1000)
    p = producto_con_stock(admin, cantidad=50, precio_venta=1000, sku="EXP-1")
    _vender(admin, p, 2, 2000)

    r = api_admin.get("/api/v1/dashboard/exportar/")
    assert r.status_code == 200
    assert r["Content-Type"] == "application/pdf"
    assert r.content.startswith(b"%PDF")
    assert len(r.content) > 500


def test_exportar_vendedor_no_incluye_secciones_completas(api_vendedor, vendedor):
    """Un vendedor sin dashboard.ver_completo igual puede exportar, pero el
    PDF queda acotado a Ventas (mismo alcance que ve en pantalla) — se
    verifica indirectamente: no debe fallar con 403 ni 500."""
    abrir_caja(usuario=vendedor, monto_inicial=1000)
    r = api_vendedor.get("/api/v1/dashboard/exportar/")
    assert r.status_code == 200
    assert r.content.startswith(b"%PDF")
