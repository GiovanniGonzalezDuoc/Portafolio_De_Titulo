"""
Consultas agregadas del Dashboard analítico (Ventas + Rentabilidad y
recuperación de productos — RF-J10: todo usa ``aggregate()``/``annotate()``
del ORM, nunca un bucle en Python haciendo una consulta por fila, para no
incurrir en N+1 y mantener la carga bajo 1,5 s (RNF-2).

Excepción documentada: las series "por día" agrupan en Python (no con
``TruncDate``) porque el MariaDB del hosting no tiene cargadas las tablas de
huso horario y esa truncación devuelve ``NULL`` con ``USE_TZ`` — ver el
comentario de ``_agrupar_por_dia()``. Sigue siendo una sola consulta
(``values_list`` trae todas las filas de una vez); lo que se evita es N+1,
no la agregación en sí.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta
from decimal import Decimal

from django.db.models import (
    Avg,
    Count,
    DecimalField,
    DurationField,
    ExpressionWrapper,
    F,
    OuterRef,
    Q,
    Subquery,
    Sum,
)
from django.db.models.functions import Abs, Coalesce
from django.utils import timezone

from apps.alertas.models import Alerta, EstadoAlerta, TipoAlerta
from apps.catalogo.models import Producto
from apps.compras.models import (
    ESTADOS_RECIBIBLES,
    LineaOrdenCompra,
    LineaRecepcion,
    OrdenCompra,
    RecepcionCompra,
)
from apps.core.exceptions import ErrorDominio, RecursoNoEncontrado
from apps.inventario.models import ParametroInventario, Stock
from apps.ventas.models import EstadoVenta, LineaVenta, MedioPago, PagoVenta, Venta

_ENTERO = DecimalField(max_digits=18, decimal_places=2)

# Costo de venta aproximado con el costo_referencial ACTUAL del producto (no
# hay histórico de costo por línea de venta) — mismo criterio ya usado en
# "recuperación de productos" desde la Etapa 9.
_COSTO_VENTA_LINEA = ExpressionWrapper(
    F("cantidad") * F("producto__costo_referencial"), output_field=_ENTERO
)
_MARGEN_LINEA = ExpressionWrapper(F("total_linea") - _COSTO_VENTA_LINEA, output_field=_ENTERO)
_COSTO_RECEPCION_LINEA = ExpressionWrapper(
    F("cantidad") * F("costo_unitario"), output_field=_ENTERO
)


# ─── Rango de fechas (control global) ───────────────────────
def _fecha(valor: str, campo: str) -> date:
    try:
        return date.fromisoformat(valor)
    except (TypeError, ValueError) as exc:
        raise ErrorDominio(
            f"El parámetro «{campo}» debe tener formato YYYY-MM-DD.",
            codigo="fecha_invalida",
        ) from exc


def _rango(desde: str | None, hasta: str | None) -> tuple[datetime, datetime]:
    """Por defecto, hoy (coincide con el preset "Hoy" del selector)."""
    hoy = timezone.localdate()
    d = _fecha(desde, "desde") if desde else hoy
    h = _fecha(hasta, "hasta") if hasta else hoy
    tz = timezone.get_current_timezone()
    return (
        timezone.make_aware(datetime.combine(d, datetime.min.time()), tz),
        timezone.make_aware(datetime.combine(h, datetime.max.time()), tz),
    )


def _rango_anterior(ini: datetime, fin: datetime) -> tuple[datetime, datetime]:
    """
    El mismo largo de días, inmediatamente antes — para el "% vs. período
    anterior" del selector de rango (Hoy -> ayer; Esta semana -> la semana
    anterior; un rango personalizado -> el tramo igual de largo justo antes).
    """
    dias = (fin.date() - ini.date()).days + 1
    tz = timezone.get_current_timezone()
    fin_ant = ini.date() - timedelta(days=1)
    ini_ant = fin_ant - timedelta(days=dias - 1)
    return (
        timezone.make_aware(datetime.combine(ini_ant, datetime.min.time()), tz),
        timezone.make_aware(datetime.combine(fin_ant, datetime.max.time()), tz),
    )


def _agrupar_por_dia(filas, tz) -> dict:
    """
    Recibe pares ``(creado_en, ...)`` ya traídos en UNA sola consulta
    (``values_list``) y los agrupa por día LOCAL en Python. No se usa
    ``TruncDate`` de Django: con ``USE_TZ=True`` esa truncación pide
    ``CONVERT_TZ()`` a nivel de SQL, y el MariaDB del hosting no tiene
    cargadas las tablas ``mysql.time_zone`` — la agrupación queda vacía en
    producción aunque sí haya datos (bug real ya encontrado y corregido).
    """
    acumulado: dict[date, list] = {}
    for fila in filas:
        creado_en = fila[0]
        local = timezone.localtime(creado_en, tz) if timezone.is_aware(creado_en) else creado_en
        acumulado.setdefault(local.date(), []).append(fila[1:])
    return acumulado


def _ventas_pagadas(ini: datetime, fin: datetime, vendedor=None):
    qs = Venta.objects.filter(estado=EstadoVenta.PAGADA, creado_en__gte=ini, creado_en__lte=fin)
    if vendedor is not None:
        qs = qs.filter(vendedor=vendedor)
    return qs


# ─── Sección 1: Ventas ──────────────────────────────────────
def kpis_ventas(*, desde=None, hasta=None, vendedor=None) -> dict:
    ini, fin = _rango(desde, hasta)
    ini_ant, fin_ant = _rango_anterior(ini, fin)

    actual = _ventas_pagadas(ini, fin, vendedor).aggregate(monto=Coalesce(Sum("total"), 0), n=Count("id"))
    monto_anterior = _ventas_pagadas(ini_ant, fin_ant, vendedor).aggregate(
        monto=Coalesce(Sum("total"), 0)
    )["monto"]
    unidades = LineaVenta.objects.filter(
        venta__in=_ventas_pagadas(ini, fin, vendedor)
    ).aggregate(u=Coalesce(Sum("cantidad"), Decimal(0)))["u"]

    monto = actual["monto"] or 0
    n = actual["n"] or 0
    if monto_anterior:
        variacion_pct = round((monto - monto_anterior) / monto_anterior * 100)
    else:
        variacion_pct = 100 if monto > 0 else None

    return {
        "monto": monto,
        "variacion_pct": variacion_pct,
        "n_ventas": n,
        "unidades": unidades,
        "ticket_promedio": round(monto / n) if n else 0,
    }


def serie_ventas(*, desde=None, hasta=None, vendedor=None) -> list[dict]:
    """Tendencia de ventas por día dentro del rango elegido — un punto por
    CADA día del rango (con monto 0 si no hubo ventas ese día, no se omite):
    el frontend superpone esta serie con `serie_ventas_periodo_anterior`
    alineadas por posición, así que ambas deben tener siempre el mismo largo
    (un desface acá hace que la línea se salga del gráfico). Un rango de un
    solo día ("Hoy") no alcanza a formar una línea por sí solo, así que se
    antepone el día anterior para tener de inmediato un punto de comparación
    visible (hoy vs. ayer)."""
    ini, fin = _rango(desde, hasta)
    tz = timezone.get_current_timezone()
    filas = _ventas_pagadas(ini, fin, vendedor).values_list("creado_en", "total")

    por_dia = _agrupar_por_dia(filas, tz)
    montos_por_fecha = {
        dia: sum(int(t or 0) for (t,) in valores) for dia, valores in por_dia.items()
    }

    if fin.date() == ini.date():
        ini_ayer, fin_ayer = _rango_anterior(ini, fin)
        montos_ayer = _ventas_pagadas(ini_ayer, fin_ayer, vendedor).values_list("total", flat=True)
        monto_ayer = sum(int(t or 0) for t in montos_ayer)
        return [
            {"periodo": ini_ayer.date().isoformat(), "monto": monto_ayer},
            {"periodo": ini.date().isoformat(), "monto": montos_por_fecha.get(ini.date(), 0)},
        ]

    dias_total = (fin.date() - ini.date()).days + 1
    dias = [ini.date() + timedelta(days=i) for i in range(dias_total)]
    return [
        {"periodo": dia.isoformat(), "monto": montos_por_fecha.get(dia, 0)}
        for dia in dias
    ]


def serie_ventas_periodo_anterior(*, desde=None, hasta=None, vendedor=None) -> list[int]:
    """Montos de venta por día del período INMEDIATAMENTE ANTERIOR, de igual
    duración — alineados por POSICIÓN (día 1 vs. día 1, día 2 vs. día 2...),
    no por fecha real (que difiere), para superponer como línea de
    comparación sobre `serie_ventas` en el mismo gráfico."""
    ini, fin = _rango(desde, hasta)
    ini_ant, fin_ant = _rango_anterior(ini, fin)
    tz = timezone.get_current_timezone()
    dias_total = (fin.date() - ini.date()).days + 1

    filas = _ventas_pagadas(ini_ant, fin_ant, vendedor).values_list("creado_en", "total")
    por_dia = _agrupar_por_dia(filas, tz)
    montos_por_fecha = {
        dia: sum(int(t or 0) for (t,) in valores) for dia, valores in por_dia.items()
    }
    fechas_ordenadas = sorted(montos_por_fecha)
    montos = [montos_por_fecha[d] for d in fechas_ordenadas]
    # Completa con ceros o recorta para que calce en cantidad de posiciones
    # con `serie_ventas` del período actual, aunque el anterior tenga menos
    # días con ventas registradas.
    return (montos + [0] * dias_total)[:dias_total]


def ventas_por_dia_semana(*, desde=None, hasta=None, vendedor=None) -> list[int]:
    """Cantidad de ventas por día de la semana (0=lunes) dentro del rango
    elegido — carga operacional por día, no depende del monto."""
    ini, fin = _rango(desde, hasta)
    tz = timezone.get_current_timezone()
    filas = _ventas_pagadas(ini, fin, vendedor).values_list("creado_en", flat=True)
    conteo = [0] * 7
    for creado_en in filas:
        local = timezone.localtime(creado_en, tz) if timezone.is_aware(creado_en) else creado_en
        conteo[local.weekday()] += 1
    return conteo


def top_rendimiento(*, desde=None, hasta=None, vendedor=None, limite=5) -> list[dict]:
    """Productos con mejor rendimiento del período: unidades, ventas, margen
    y stock actual — para la tabla de "mejor rendimiento" del panorama."""
    ini, fin = _rango(desde, hasta)
    filas = (
        LineaVenta.objects.filter(venta__in=_ventas_pagadas(ini, fin, vendedor))
        .values("producto_id", "producto__sku", "producto__nombre", "producto__categoria__nombre")
        .annotate(
            unidades=Sum("cantidad"),
            ventas=Coalesce(Sum("total_linea"), 0),
            margen=Coalesce(Sum(_MARGEN_LINEA), 0, output_field=_ENTERO),
        )
        .order_by("-ventas")[:limite]
    )
    filas = list(filas)
    ids = [f["producto_id"] for f in filas]
    stocks = {
        s["producto_id"]: s["total"]
        for s in Stock.objects.filter(producto_id__in=ids)
        .values("producto_id")
        .annotate(total=Sum("cantidad"))
    }
    resultado = []
    for f in filas:
        ventas = int(f["ventas"] or 0)
        margen = int(f["margen"] or 0)
        resultado.append(
            {
                "sku": f["producto__sku"],
                "nombre": f["producto__nombre"],
                "categoria": f["producto__categoria__nombre"] or "Sin categoría",
                "unidades": f["unidades"],
                "ventas": ventas,
                "margen_pct": round(margen / ventas * 100, 1) if ventas else 0,
                "stock": stocks.get(f["producto_id"], 0),
            }
        )
    return resultado


def precision_recepcion(*, desde=None, hasta=None) -> dict:
    """Precisión de recepción de compras: de las líneas de orden que
    recibieron alguna entrega en el período, qué % llegó COMPLETA (cantidad
    recibida acumulada >= cantidad pedida) — el equivalente en compras de
    una métrica de exactitud de cumplimiento (no hay picking/despacho de
    pedidos en este negocio, es venta de mostrador; esta es la operación
    real más parecida: qué tan bien cumplen los proveedores lo pedido)."""
    ini, fin = _rango(desde, hasta)
    lineas_ids = (
        LineaRecepcion.objects.filter(recepcion__creado_en__gte=ini, recepcion__creado_en__lte=fin)
        .values_list("linea_orden_id", flat=True)
        .distinct()
    )
    lineas = LineaOrdenCompra.objects.filter(id__in=lineas_ids)
    total = lineas.count()
    completas = lineas.filter(cantidad_recibida__gte=F("cantidad")).count()
    return {
        "precision_pct": round(completas / total * 100, 1) if total else 100.0,
        "lineas_recibidas": total,
        "lineas_completas": completas,
        "lineas_incompletas": total - completas,
    }


def productos_mas_vendidos(*, desde=None, hasta=None, limite=8, vendedor=None) -> list[dict]:
    ini, fin = _rango(desde, hasta)
    qs = (
        LineaVenta.objects.filter(venta__in=_ventas_pagadas(ini, fin, vendedor))
        .values("producto__sku", "producto__nombre")
        .annotate(unidades=Sum("cantidad"), monto=Coalesce(Sum("total_linea"), 0))
        .order_by("-unidades")[:limite]
    )
    return [
        {
            "sku": row["producto__sku"], "nombre": row["producto__nombre"],
            "unidades": row["unidades"], "monto": row["monto"],
        }
        for row in qs
    ]


def ventas_por_medio_pago(*, desde=None, hasta=None, vendedor=None) -> list[dict]:
    ini, fin = _rango(desde, hasta)
    qs = (
        PagoVenta.objects.filter(venta__in=_ventas_pagadas(ini, fin, vendedor))
        .values("medio")
        .annotate(monto=Coalesce(Sum("monto"), 0))
        .order_by("-monto")
    )
    return [
        {"medio": row["medio"], "medio_display": MedioPago(row["medio"]).label, "monto": row["monto"]}
        for row in qs
    ]


def ventas_por_categoria(*, desde=None, hasta=None, vendedor=None) -> list[dict]:
    ini, fin = _rango(desde, hasta)
    qs = (
        LineaVenta.objects.filter(venta__in=_ventas_pagadas(ini, fin, vendedor))
        .values("producto__categoria__nombre")
        .annotate(monto=Coalesce(Sum("total_linea"), 0))
        .order_by("-monto")
    )
    return [
        {"categoria": row["producto__categoria__nombre"] or "Sin categoría", "monto": row["monto"]}
        for row in qs
    ]


def unidades_por_semana(*, desde=None, hasta=None, vendedor=None) -> list[dict]:
    """Unidades vendidas por semana ISO dentro del rango — velocidad de salida."""
    ini, fin = _rango(desde, hasta)
    tz = timezone.get_current_timezone()
    filas = LineaVenta.objects.filter(venta__in=_ventas_pagadas(ini, fin, vendedor)).values_list(
        "venta__creado_en", "cantidad"
    )
    acumulado: dict[tuple[int, int], float] = {}
    for creado_en, cantidad in filas:
        local = timezone.localtime(creado_en, tz) if timezone.is_aware(creado_en) else creado_en
        anio, semana, _ = local.isocalendar()
        clave = (anio, semana)
        acumulado[clave] = acumulado.get(clave, 0) + float(cantidad)
    return [
        {"semana": f"{anio}-W{semana:02d}", "unidades": round(unidades)}
        for (anio, semana), unidades in sorted(acumulado.items())
    ]


def mapa_presion(*, dias=30) -> list[list[int]]:
    """Matriz franja horaria (5 bloques de ~5 h) x día de semana (0=lunes) con la
    cantidad de ventas de los últimos `dias` días — intensidad de demanda reciente."""
    hoy = timezone.localdate()
    ini, fin = _rango((hoy - timedelta(days=dias - 1)).isoformat(), hoy.isoformat())
    tz = timezone.get_current_timezone()
    filas = _ventas_pagadas(ini, fin, None).values_list("creado_en", flat=True)
    matriz = [[0] * 7 for _ in range(5)]
    for creado_en in filas:
        local = timezone.localtime(creado_en, tz) if timezone.is_aware(creado_en) else creado_en
        franja = min(local.hour // 5, 4)
        matriz[franja][local.weekday()] += 1
    return matriz


def margen_global(*, desde=None, hasta=None, vendedor=None) -> dict:
    """Margen bruto del período completo (no por producto) — % sobre ingresos."""
    ini, fin = _rango(desde, hasta)
    agg = LineaVenta.objects.filter(venta__in=_ventas_pagadas(ini, fin, vendedor)).aggregate(
        ingresos=Coalesce(Sum("total_linea"), 0),
        margen=Coalesce(Sum(_MARGEN_LINEA), 0, output_field=_ENTERO),
    )
    ingresos = int(agg["ingresos"] or 0)
    margen = int(agg["margen"] or 0)
    return {"margen": margen, "margen_pct": round(margen / ingresos * 100, 1) if ingresos else 0}


def tasa_anulacion(*, desde=None, hasta=None, vendedor=None) -> dict:
    """% de ventas anuladas del período (sobre el total de ventas emitidas, pagadas o no)."""
    ini, fin = _rango(desde, hasta)
    qs = Venta.objects.filter(creado_en__gte=ini, creado_en__lte=fin)
    if vendedor is not None:
        qs = qs.filter(vendedor=vendedor)
    agg = qs.aggregate(
        n_total=Count("id"),
        anuladas=Count("id", filter=Q(estado=EstadoVenta.ANULADA)),
        monto_anulado=Coalesce(Sum("total", filter=Q(estado=EstadoVenta.ANULADA)), 0),
    )
    total = agg["n_total"] or 0
    anuladas = agg["anuladas"] or 0
    return {
        "anuladas_n": anuladas,
        "anuladas_pct": round(anuladas / total * 100, 1) if total else 0,
        "monto_anulado": int(agg["monto_anulado"] or 0),
    }


def kpis_descuentos(*, desde=None, hasta=None, vendedor=None) -> dict:
    """Descuentos otorgados en el período y su peso sobre las ventas brutas (antes de
    descuento), contra el tope de descuento del vendedor configurado en el sistema."""
    from apps.core.models import ParametroSistema

    ini, fin = _rango(desde, hasta)
    agg = _ventas_pagadas(ini, fin, vendedor).aggregate(
        descuento=Coalesce(Sum("descuento_total"), 0),
        bruto=Coalesce(Sum(F("total") + F("descuento_total")), 0, output_field=_ENTERO),
    )
    descuento = int(agg["descuento"] or 0)
    bruto = int(agg["bruto"] or 0)
    return {
        "descuento_total": descuento,
        "descuento_pct": round(descuento / bruto * 100, 1) if bruto else 0,
        "tope_pct": float(ParametroSistema.get().tope_descuento_vendedor_pct),
    }


def mix_tipo_cliente(*, desde=None, hasta=None, vendedor=None) -> list[dict]:
    """Monto vendido a mayoristas vs. retail en el período."""
    ini, fin = _rango(desde, hasta)
    filas = (
        _ventas_pagadas(ini, fin, vendedor)
        .values("es_mayorista")
        .annotate(monto=Coalesce(Sum("total"), 0), n=Count("id"))
    )
    por_tipo = {f["es_mayorista"]: f for f in filas}
    return [
        {
            "tipo": "Mayorista",
            "monto": int((por_tipo.get(True) or {}).get("monto", 0) or 0),
            "n": (por_tipo.get(True) or {}).get("n", 0),
        },
        {
            "tipo": "Retail",
            "monto": int((por_tipo.get(False) or {}).get("monto", 0) or 0),
            "n": (por_tipo.get(False) or {}).get("n", 0),
        },
    ]


def rotacion_inventario(*, desde=None, hasta=None) -> dict:
    """Rotación = costo de venta del período / valor de inventario ACTUAL (aproximación: no
    hay histórico de stock diario para promediarlo dentro del período — mismo criterio que la
    rotación por producto de la Sección 2)."""
    ini, fin = _rango(desde, hasta)
    costo_venta = LineaVenta.objects.filter(venta__in=_ventas_pagadas(ini, fin, None)).aggregate(
        c=Coalesce(Sum(_COSTO_VENTA_LINEA), 0, output_field=_ENTERO)
    )["c"]
    valor_expr = ExpressionWrapper(F("cantidad") * F("producto__costo_referencial"), output_field=_ENTERO)
    valorizado = Stock.objects.aggregate(v=Coalesce(Sum(valor_expr), Decimal(0)))["v"]
    return {
        "rotacion": round(float(costo_venta) / float(valorizado), 3) if valorizado else 0.0,
        "costo_venta": int(costo_venta or 0),
        "valorizado": int(valorizado or 0),
    }


# ─── Sección 2: Rentabilidad y recuperación de productos ────
#
# "Recuperación" (definición del cliente): (ingresos por ventas del producto
# en el período / costo total de compra del producto en el MISMO período) ×
# 100. Sobre 100 % significa que ya generó más ingreso del que costó
# comprarlo en ese tramo — es una métrica de PERÍODO, no acumulada contra
# toda la historia (esa era la versión anterior de "recuperación de
# inversión"; esta reemplaza a esa).
# "Margen bruto" = ingresos − costo de venta (mismo criterio que Sección 1).
def _rentabilidad_por_producto(*, ini: datetime, fin: datetime) -> list[dict]:
    ventas = (
        LineaVenta.objects.filter(venta__estado=EstadoVenta.PAGADA, venta__creado_en__gte=ini, venta__creado_en__lte=fin)
        .values("producto_id", "producto__sku", "producto__nombre")
        .annotate(
            ingresos=Coalesce(Sum("total_linea"), 0),
            margen=Coalesce(Sum(_MARGEN_LINEA), 0, output_field=_ENTERO),
        )
    )
    costos = (
        LineaRecepcion.objects.filter(recepcion__creado_en__gte=ini, recepcion__creado_en__lte=fin)
        .values("linea_orden__producto_id")
        .annotate(costo_compra=Coalesce(Sum(_COSTO_RECEPCION_LINEA), 0, output_field=_ENTERO))
    )
    costo_por_producto = {
        c["linea_orden__producto_id"]: int(c["costo_compra"] or 0) for c in costos
    }

    resultado = []
    for v in ventas:
        costo_compra = costo_por_producto.get(v["producto_id"], 0)
        ingresos = int(v["ingresos"] or 0)
        resultado.append({
            "sku": v["producto__sku"],
            "nombre": v["producto__nombre"],
            "ingresos": ingresos,
            "margen": int(v["margen"] or 0),
            "costo_compra": costo_compra,
            "recuperacion_pct": round(ingresos / costo_compra * 100, 1) if costo_compra > 0 else None,
        })
    return resultado


def top_rentabilidad(*, desde=None, hasta=None, metrica="recuperacion", limite=5) -> dict:
    """``metrica``: "recuperacion" (%) o "margen" ($) — cuál ordena mejores/peores."""
    ini, fin = _rango(desde, hasta)
    filas = _rentabilidad_por_producto(ini=ini, fin=fin)

    if metrica == "margen":
        ordenados = sorted(filas, key=lambda f: f["margen"], reverse=True)
    else:
        metrica = "recuperacion"
        ordenados = sorted(
            (f for f in filas if f["recuperacion_pct"] is not None),
            key=lambda f: f["recuperacion_pct"],
            reverse=True,
        )

    mejores = ordenados[:limite]
    restantes = ordenados[limite:]
    peores = list(reversed(restantes[-limite:])) if restantes else []
    # "todas": el listado completo (no solo el top/bottom N) para la tabla
    # de detalle — se agrega sin tocar `mejores`/`peores` para no romper a
    # quien ya consume esa forma de la respuesta.
    return {"metrica": metrica, "mejores": mejores, "peores": peores, "todas": ordenados}


def serie_producto(*, sku: str, desde=None, hasta=None) -> dict:
    """
    Para el buscador de la Sección 2: evolución de la recuperación/margen de
    UN producto dentro del rango, día a día (acumulado, para una curva
    legible en vez de una serie a saltos con la mayoría de los días en
    cero), + su rotación de inventario (unidades vendidas del día / stock
    actual — se usa el stock de HOY como referencia estable; el sistema no
    guarda un histórico de stock por día para calcular un "promedio del
    período" exacto, así que esto es una aproximación, igual criterio que
    el resto de las métricas de esta pantalla).
    """
    producto = Producto.objects.filter(sku=sku).first()
    if producto is None:
        raise RecursoNoEncontrado("No existe un producto con ese SKU.", codigo="producto_no_encontrado")

    ini, fin = _rango(desde, hasta)
    tz = timezone.get_current_timezone()

    ventas_filas = LineaVenta.objects.filter(
        producto=producto, venta__estado=EstadoVenta.PAGADA, venta__creado_en__gte=ini, venta__creado_en__lte=fin
    ).values_list("venta__creado_en", "total_linea", "cantidad")
    ventas_por_dia = _agrupar_por_dia(ventas_filas, tz)

    compras_filas = LineaRecepcion.objects.filter(
        linea_orden__producto=producto, recepcion__creado_en__gte=ini, recepcion__creado_en__lte=fin
    ).values_list("recepcion__creado_en", "cantidad", "costo_unitario")
    compras_por_dia = _agrupar_por_dia(compras_filas, tz)

    costo_ref = producto.costo_referencial or 0
    stock_actual = Stock.objects.filter(producto=producto).aggregate(
        t=Coalesce(Sum("cantidad"), Decimal(0))
    )["t"]

    dias = sorted(set(ventas_por_dia) | set(compras_por_dia))
    serie_recuperacion: list[dict] = []
    serie_rotacion: list[dict] = []
    ingresos_acum = 0
    costo_compra_acum = 0
    for dia in dias:
        ingresos_dia = sum(int(total or 0) for total, _cant in ventas_por_dia.get(dia, []))
        unidades_dia = sum(cant for _total, cant in ventas_por_dia.get(dia, []))
        costo_compra_dia = sum(int(cant * costo) for cant, costo in compras_por_dia.get(dia, []))

        ingresos_acum += ingresos_dia
        costo_compra_acum += costo_compra_dia
        margen_dia = ingresos_dia - int(unidades_dia * costo_ref)

        serie_recuperacion.append({
            "periodo": dia.isoformat(),
            "recuperacion_pct": round(ingresos_acum / costo_compra_acum * 100, 1) if costo_compra_acum > 0 else None,
            "margen": margen_dia,
        })
        serie_rotacion.append({
            "periodo": dia.isoformat(),
            "rotacion": round(float(unidades_dia) / float(stock_actual), 3) if stock_actual else 0.0,
        })

    return {
        "sku": producto.sku,
        "nombre": producto.nombre,
        "serie_recuperacion": serie_recuperacion,
        "serie_rotacion": serie_rotacion,
    }


# ─── Sección 3: Operación e inventario (estado ACTUAL, no depende del
# rango de fechas global — son snapshots de "ahora mismo", no series de un
# período: salud de stock, pipeline de compras y cobertura del modelo de
# IA no tienen una lectura sensata como "entre el 3 y el 10 de marzo") ────
def kpis_inventario() -> dict:
    valor_expr = ExpressionWrapper(F("cantidad") * F("producto__costo_referencial"), output_field=_ENTERO)
    agg = Stock.objects.aggregate(
        valorizado=Coalesce(Sum(valor_expr), Decimal(0)),
        unidades=Coalesce(Sum("cantidad"), Decimal(0)),
    )
    sin_stock = Stock.objects.filter(cantidad__lte=0, producto__activo=True).count()

    minimos = {(p.producto_id, p.ubicacion_id): p.stock_minimo for p in ParametroInventario.objects.all()}
    bajo = 0
    for s in Stock.objects.filter(producto__activo=True).values("producto_id", "ubicacion_id", "cantidad"):
        m = minimos.get((s["producto_id"], s["ubicacion_id"]), 0)
        if m and 0 < s["cantidad"] <= m:
            bajo += 1

    activos = Producto.objects.filter(activo=True).count()
    return {
        "valorizado": int(agg["valorizado"]),
        "productos_activos": activos,
        "productos_sin_stock": sin_stock,
        "productos_stock_bajo": bajo,
        "productos_normal": max(activos - sin_stock - bajo, 0),
    }


def valorizacion_por_ubicacion(*, limite=8) -> list[dict]:
    """Valor de inventario y cantidad de productos por ubicación/bodega — snapshot actual."""
    valor_expr = ExpressionWrapper(F("cantidad") * F("producto__costo_referencial"), output_field=_ENTERO)
    qs = (
        Stock.objects.filter(producto__activo=True)
        .values("ubicacion__nombre")
        .annotate(
            valorizado=Coalesce(Sum(valor_expr), Decimal(0), output_field=_ENTERO),
            productos=Count("producto_id", distinct=True),
        )
        .order_by("-valorizado")[:limite]
    )
    return [
        {
            "ubicacion": row["ubicacion__nombre"] or "Sin ubicación",
            "valorizado": int(row["valorizado"] or 0),
            "productos": row["productos"],
        }
        for row in qs
    ]


def kpis_ciclo_compras() -> dict:
    """Pipeline de abastecimiento: qué necesita reponerse -> qué ya se pidió -> qué viene en camino."""
    params = {
        (p.producto_id, p.ubicacion_id): p.punto_reposicion
        for p in ParametroInventario.objects.all()
        if p.punto_reposicion
    }
    bajo_punto = 0
    for s in Stock.objects.filter(producto__activo=True).values("producto_id", "ubicacion_id", "cantidad"):
        punto = params.get((s["producto_id"], s["ubicacion_id"]))
        if punto and s["cantidad"] <= punto:
            bajo_punto += 1

    pendientes = OrdenCompra.objects.filter(estado__in=ESTADOS_RECIBIBLES)
    en_transito = Decimal(0)
    for linea in LineaOrdenCompra.objects.filter(orden__in=pendientes):
        en_transito += linea.pendiente
    return {
        "productos_bajo_punto_pedido": bajo_punto,
        "ordenes_pendientes_recepcion": pendientes.count(),
        "unidades_en_transito": en_transito,
    }


def kpis_prediccion() -> dict:
    """Cobertura del modelo de IA: cuántos productos tienen predicción vigente y con qué confianza
    (según la ÚLTIMA predicción de cada producto, no todas)."""
    from apps.prediccion.models import PrediccionDemanda

    ultima_por_producto = PrediccionDemanda.objects.filter(producto=OuterRef("producto")).order_by("-generado_en")
    ultimas = PrediccionDemanda.objects.filter(id=Subquery(ultima_por_producto.values("id")[:1]))
    por_confianza = {row["nivel_confianza"]: row["n"] for row in ultimas.values("nivel_confianza").annotate(n=Count("id"))}
    total_activos = Producto.objects.filter(activo=True).count()
    con_prediccion = ultimas.count()
    return {
        "productos_activos": total_activos,
        "con_prediccion": con_prediccion,
        "sin_prediccion": max(total_activos - con_prediccion, 0),
        "no_estable": por_confianza.get("NO_ESTABLE", 0),
        "estable": por_confianza.get("ESTABLE", 0),
        "confiable": por_confianza.get("CONFIABLE", 0),
    }


def quiebre_inminente(*, dias=7, limite=10) -> list[dict]:
    """Productos que, al ritmo de demanda semanal de su ÚLTIMA predicción, se quedarían sin
    stock en `dias` días o menos."""
    from apps.prediccion.models import PrediccionDemanda

    ultima_por_producto = PrediccionDemanda.objects.filter(producto=OuterRef("producto")).order_by("-generado_en")
    ultimas = PrediccionDemanda.objects.filter(id=Subquery(ultima_por_producto.values("id")[:1])).select_related("producto")
    stocks = {
        s["producto_id"]: s["total"]
        for s in Stock.objects.filter(producto__activo=True).values("producto_id").annotate(total=Sum("cantidad"))
    }

    resultado = []
    for pred in ultimas:
        stock_actual = stocks.get(pred.producto_id)
        if not stock_actual or stock_actual <= 0 or not pred.horizonte_semanas:
            continue
        demanda_semanal = float(pred.demanda_estimada) / pred.horizonte_semanas
        if demanda_semanal <= 0:
            continue
        dias_restantes = float(stock_actual) / demanda_semanal * 7
        if dias_restantes <= dias:
            resultado.append({
                "sku": pred.producto.sku,
                "nombre": pred.producto.nombre,
                "stock_actual": stock_actual,
                "dias_restantes": round(dias_restantes, 1),
            })
    resultado.sort(key=lambda r: r["dias_restantes"])
    return resultado[:limite]


def productos_baja_rotacion(*, dias=30, limite=10) -> list[dict]:
    """Candidatos a oferta: stock alto y ventas nulas o muy bajas en los últimos `dias`
    días — lo inverso de `quiebre_inminente`."""
    hoy = timezone.localdate()
    ini, fin = _rango((hoy - timedelta(days=dias - 1)).isoformat(), hoy.isoformat())
    vendidos = {
        row["producto_id"]: row["u"]
        for row in LineaVenta.objects.filter(venta__in=_ventas_pagadas(ini, fin, None))
        .values("producto_id")
        .annotate(u=Sum("cantidad"))
    }
    stocks = (
        Stock.objects.filter(producto__activo=True)
        .values("producto_id", "producto__sku", "producto__nombre")
        .annotate(total=Sum("cantidad"))
        .filter(total__gt=0)
    )
    resultado = [
        {
            "sku": s["producto__sku"],
            "nombre": s["producto__nombre"],
            "stock_actual": s["total"],
            "unidades_vendidas": float(vendidos.get(s["producto_id"], 0) or 0),
        }
        for s in stocks
    ]
    resultado.sort(key=lambda r: (r["unidades_vendidas"], -float(r["stock_actual"])))
    return resultado[:limite]


def desempeno_proveedores(*, limite=8) -> list[dict]:
    """Tiempo promedio de entrega (recepción − emisión de la orden), por proveedor."""
    diff = ExpressionWrapper(
        F("creado_en") - F("orden__fecha_emision"), output_field=DurationField()
    )
    qs = (
        RecepcionCompra.objects.filter(orden__fecha_emision__isnull=False)
        .annotate(lead=diff)
        .values("orden__proveedor__razon_social")
        .annotate(promedio=Avg("lead"), n=Count("id"))
        .order_by("-promedio")[:limite]
    )
    return [
        {
            "proveedor": row["orden__proveedor__razon_social"],
            "dias_promedio": round(row["promedio"].total_seconds() / 86400, 1) if row["promedio"] else 0,
            "n_recepciones": row["n"],
        }
        for row in qs
    ]


# ─── Sección 4: Caja y riesgos operativos (estado ACTUAL / hoy vs. ayer,
# tampoco depende del rango global — ver nota de la Sección 3) ──────────
def ventas_por_cajero_hoy_ayer() -> dict:
    """Monto vendido por cada cajero, hoy vs. ayer, + cajas abiertas ahora."""
    from apps.caja.models import Caja, EstadoCaja

    hoy = timezone.localdate().isoformat()
    ayer = (timezone.localdate() - timedelta(days=1)).isoformat()

    def _por_usuario(dia: str) -> dict[str, dict]:
        ini, fin = _rango(dia, dia)
        filas = (
            Venta.objects.filter(estado=EstadoVenta.PAGADA, creado_en__gte=ini, creado_en__lte=fin)
            .values("vendedor__username", "vendedor__nombres", "vendedor__apellidos")
            .annotate(monto=Coalesce(Sum("total"), 0))
        )
        return {
            f["vendedor__username"]: {
                "nombre": f"{f['vendedor__nombres']} {f['vendedor__apellidos']}".strip(),
                "monto": f["monto"] or 0,
            }
            for f in filas
        }

    de_hoy = _por_usuario(hoy)
    de_ayer = _por_usuario(ayer)
    usuarios = sorted(set(de_hoy) | set(de_ayer))
    cajeros = [
        {
            "usuario": u,
            "nombre": (de_hoy.get(u) or de_ayer[u])["nombre"],
            "hoy": de_hoy.get(u, {"monto": 0})["monto"],
            "ayer": de_ayer.get(u, {"monto": 0})["monto"],
        }
        for u in usuarios
    ]
    return {"cajas_abiertas": Caja.objects.filter(estado=EstadoCaja.ABIERTA).count(), "cajeros": cajeros}


def kpis_alertas() -> dict:
    abiertas = Alerta.objects.exclude(estado=EstadoAlerta.RESUELTA)
    por_sev = {r["severidad"]: r["n"] for r in abiertas.values("severidad").annotate(n=Count("id"))}
    return {"abiertas": abiertas.count(), "criticas": por_sev.get("CRITICAL", 0), "por_severidad": por_sev}


def kpis_riesgos_operativos() -> dict:
    """Salud del simulador de boleta electrónica (DTE) y discrepancias de inventario abiertas."""
    from apps.boleta.models import DocumentoTributario, EstadoDTE

    return {
        "dte_rechazados": DocumentoTributario.objects.filter(estado=EstadoDTE.RECHAZADO).count(),
        "dte_pendientes": DocumentoTributario.objects.filter(estado=EstadoDTE.PENDIENTE).count(),
        "dte_fallidos_abiertos": Alerta.objects.abiertas().filter(tipo=TipoAlerta.DTE_FALLIDO).count(),
        "discrepancias_abiertas": Alerta.objects.abiertas().filter(tipo=TipoAlerta.DISCREPANCIA).count(),
    }


def serie_ventas_y_margen(*, dias=14) -> list[dict]:
    """Ingresos vs. margen bruto de los últimos `dias` días (ventana fija, no ligada al
    rango global — es una tendencia de contexto reciente, no un reporte de un período elegido)."""
    hoy = timezone.localdate()
    ini, fin = _rango((hoy - timedelta(days=dias - 1)).isoformat(), hoy.isoformat())
    tz = timezone.get_current_timezone()
    filas = LineaVenta.objects.filter(
        venta__estado=EstadoVenta.PAGADA, venta__creado_en__gte=ini, venta__creado_en__lte=fin
    ).values_list("venta__creado_en", "total_linea", "cantidad", "producto__costo_referencial")

    acumulado: dict[date, dict] = {}
    for creado_en, total_linea, cantidad, costo in filas:
        local = timezone.localtime(creado_en, tz) if timezone.is_aware(creado_en) else creado_en
        dia = local.date()
        bucket = acumulado.setdefault(dia, {"ingresos": 0, "margen": 0})
        ingreso = int(total_linea or 0)
        bucket["ingresos"] += ingreso
        bucket["margen"] += ingreso - int(cantidad) * int(costo or 0)

    return [
        {"periodo": dia.isoformat(), "ingresos": v["ingresos"], "margen": v["margen"]}
        for dia, v in sorted(acumulado.items())
    ]


def discrepancias_caja(*, dias=30) -> dict:
    """Diferencia ($) entre lo esperado y lo contado al cierre de caja, ventana fija de
    contexto reciente (mismo criterio que `serie_ventas_y_margen`)."""
    from apps.caja.models import Caja, EstadoCaja

    hoy = timezone.localdate()
    ini, fin = _rango((hoy - timedelta(days=dias - 1)).isoformat(), hoy.isoformat())
    qs = Caja.objects.filter(estado=EstadoCaja.CERRADA, cerrada_en__gte=ini, cerrada_en__lte=fin)
    agg = qs.aggregate(
        n=Count("id"),
        con_diferencia=Count("id", filter=Q(diferencia__isnull=False) & ~Q(diferencia=0)),
        monto_absoluto=Coalesce(Sum(Abs(F("diferencia"))), 0),
    )
    return {
        "cierres": agg["n"] or 0,
        "con_diferencia": agg["con_diferencia"] or 0,
        "monto_absoluto": int(agg["monto_absoluto"] or 0),
    }
