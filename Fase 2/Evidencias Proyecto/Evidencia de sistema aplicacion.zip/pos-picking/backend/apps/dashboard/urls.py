"""Rutas del dashboard."""

from django.urls import path

from .views import (
    CajaRiesgosView,
    ExportarReporteView,
    OperacionInventarioView,
    ProductoDetalleAnaliticoView,
    RentabilidadAnaliticaView,
    VentasAnaliticaView,
)

urlpatterns = [
    path("ventas-analitica/", VentasAnaliticaView.as_view(), name="ventas-analitica"),
    path("rentabilidad-analitica/", RentabilidadAnaliticaView.as_view(), name="rentabilidad-analitica"),
    path(
        "rentabilidad-analitica/<str:sku>/",
        ProductoDetalleAnaliticoView.as_view(),
        name="rentabilidad-analitica-producto",
    ),
    path("operacion-inventario/", OperacionInventarioView.as_view(), name="operacion-inventario"),
    path("caja-riesgos/", CajaRiesgosView.as_view(), name="caja-riesgos"),
    path("exportar/", ExportarReporteView.as_view(), name="exportar-reporte"),
]
