"""
Endpoints del Dashboard analítico (solo lectura, agregados).

Dos secciones, controladas por un único rango de fechas (``desde``/``hasta``,
YYYY-MM-DD; por defecto "hoy"):
- Ventas: KPIs + tendencia + top productos + desglose por medio de pago y
  categoría.
- Rentabilidad y recuperación de productos: ranking top 5 mejores/peores
  (según % de recuperación o margen bruto) + detalle de un producto.

Permisos:
- ``dashboard.ver``: Ventas (un vendedor sin ``ver_completo`` ve solo lo suyo).
- ``dashboard.ver_completo``: Rentabilidad y recuperación (información de
  costos/márgenes, no para cualquier rol).
"""

from __future__ import annotations

from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import OpenApiParameter, extend_schema
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.usuarios.permissions import TienePermiso

from . import selectors
from .pdf import reporte_pdf_response

_OBJ = {200: OpenApiTypes.OBJECT}

_RANGO_PARAMS = [
    OpenApiParameter("desde", str, description="YYYY-MM-DD (default: hoy)"),
    OpenApiParameter("hasta", str, description="YYYY-MM-DD (default: hoy)"),
]


class _DashboardView(APIView):
    permission_classes = [IsAuthenticated, TienePermiso.para("dashboard.ver")]

    def _completo(self, request) -> bool:
        u = request.user
        return u.is_superuser or u.tiene_permiso("dashboard.ver_completo")

    def _vendedor_scope(self, request):
        """Devuelve el usuario para filtrar ventas, o None si ve todo."""
        return None if self._completo(request) else request.user


class VentasAnaliticaView(_DashboardView):
    @extend_schema(responses=_OBJ, parameters=_RANGO_PARAMS, description="Sección 1 del dashboard: Ventas.")
    def get(self, request):
        p = request.query_params
        desde, hasta = p.get("desde"), p.get("hasta")
        vendedor = self._vendedor_scope(request)
        data = {
            "kpis": selectors.kpis_ventas(desde=desde, hasta=hasta, vendedor=vendedor),
            "tendencia": selectors.serie_ventas(desde=desde, hasta=hasta, vendedor=vendedor),
            "top_productos": selectors.productos_mas_vendidos(desde=desde, hasta=hasta, vendedor=vendedor),
            "por_medio_pago": selectors.ventas_por_medio_pago(desde=desde, hasta=hasta, vendedor=vendedor),
            "por_categoria": selectors.ventas_por_categoria(desde=desde, hasta=hasta, vendedor=vendedor),
            "anulaciones": selectors.tasa_anulacion(desde=desde, hasta=hasta, vendedor=vendedor),
            "descuentos": selectors.kpis_descuentos(desde=desde, hasta=hasta, vendedor=vendedor),
            "mix_cliente": selectors.mix_tipo_cliente(desde=desde, hasta=hasta, vendedor=vendedor),
            "unidades_semana": selectors.unidades_por_semana(desde=desde, hasta=hasta, vendedor=vendedor),
            "tendencia_anterior": selectors.serie_ventas_periodo_anterior(desde=desde, hasta=hasta, vendedor=vendedor),
            "ventas_por_dia_semana": selectors.ventas_por_dia_semana(desde=desde, hasta=hasta, vendedor=vendedor),
        }
        if self._completo(request):
            data["margen"] = selectors.margen_global(desde=desde, hasta=hasta, vendedor=vendedor)
            data["rotacion_inventario"] = selectors.rotacion_inventario(desde=desde, hasta=hasta)
            data["mapa_presion"] = selectors.mapa_presion()
            data["top_rendimiento"] = selectors.top_rendimiento(desde=desde, hasta=hasta, vendedor=vendedor)
            data["precision_recepcion"] = selectors.precision_recepcion(desde=desde, hasta=hasta)
        return Response(data)


class RentabilidadAnaliticaView(_DashboardView):
    permission_classes = [IsAuthenticated, TienePermiso.para("dashboard.ver_completo")]

    @extend_schema(
        responses=_OBJ,
        parameters=[*_RANGO_PARAMS, OpenApiParameter("metrica", str, enum=["recuperacion", "margen"])],
        description="Sección 2 del dashboard: top 5 mejores/peores por recuperación o margen.",
    )
    def get(self, request):
        p = request.query_params
        return Response(
            selectors.top_rentabilidad(
                desde=p.get("desde"), hasta=p.get("hasta"), metrica=p.get("metrica", "recuperacion"),
            )
        )


class ProductoDetalleAnaliticoView(_DashboardView):
    permission_classes = [IsAuthenticated, TienePermiso.para("dashboard.ver_completo")]

    @extend_schema(
        responses=_OBJ,
        parameters=[*_RANGO_PARAMS, OpenApiParameter("sku", str, OpenApiParameter.PATH)],
        description="Evolución de recuperación/margen y rotación de UN producto, para el buscador de la Sección 2.",
    )
    def get(self, request, sku):
        p = request.query_params
        return Response(selectors.serie_producto(sku=sku, desde=p.get("desde"), hasta=p.get("hasta")))


class OperacionInventarioView(_DashboardView):
    """Sección 3: estado ACTUAL de inventario/compras/IA (no depende del rango de fechas)."""

    permission_classes = [IsAuthenticated, TienePermiso.para("dashboard.ver_completo")]

    @extend_schema(responses=_OBJ, description="Sección 3 del dashboard: Operación e inventario.")
    def get(self, request):
        return Response({
            "salud_inventario": selectors.kpis_inventario(),
            "ciclo_compras": selectors.kpis_ciclo_compras(),
            "prediccion": selectors.kpis_prediccion(),
            "quiebre_inminente": selectors.quiebre_inminente(),
            "baja_rotacion": selectors.productos_baja_rotacion(),
            "proveedores": selectors.desempeno_proveedores(),
            "por_ubicacion": selectors.valorizacion_por_ubicacion(),
        })


class CajaRiesgosView(_DashboardView):
    """Sección 4: caja hoy vs. ayer + riesgos operativos (no depende del rango de fechas)."""

    permission_classes = [IsAuthenticated, TienePermiso.para("dashboard.ver_completo")]

    @extend_schema(responses=_OBJ, description="Sección 4 del dashboard: Caja y riesgos operativos.")
    def get(self, request):
        return Response({
            "caja": selectors.ventas_por_cajero_hoy_ayer(),
            "alertas": selectors.kpis_alertas(),
            "riesgos_operativos": selectors.kpis_riesgos_operativos(),
            "tendencia_margen": selectors.serie_ventas_y_margen(),
            "discrepancias_caja": selectors.discrepancias_caja(),
        })


class ExportarReporteView(_DashboardView):
    """Reporte ejecutivo en PDF del dashboard para el rango elegido — ver
    ``apps.dashboard.pdf``. Acotado a Ventas si el usuario no tiene
    ``dashboard.ver_completo`` (mismo alcance que ve en pantalla)."""

    @extend_schema(
        responses={200: OpenApiTypes.BINARY},
        parameters=_RANGO_PARAMS,
        description="Descarga un PDF con el resumen del dashboard para el rango elegido.",
    )
    def get(self, request):
        p = request.query_params
        return reporte_pdf_response(
            desde=p.get("desde"),
            hasta=p.get("hasta"),
            completo=self._completo(request),
            vendedor=self._vendedor_scope(request),
        )
