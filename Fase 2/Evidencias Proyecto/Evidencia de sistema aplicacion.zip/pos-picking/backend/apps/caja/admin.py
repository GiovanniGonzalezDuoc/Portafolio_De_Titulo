from django.contrib import admin

from .models import Caja, MovimientoCaja


class MovimientoCajaInline(admin.TabularInline):
    model = MovimientoCaja
    extra = 0
    readonly_fields = ["tipo", "monto", "motivo", "venta", "usuario", "creado_en"]
    can_delete = False


@admin.register(Caja)
class CajaAdmin(admin.ModelAdmin):
    list_display = ["codigo", "usuario", "estado", "monto_inicial", "monto_esperado", "diferencia", "abierta_en"]
    list_filter = ["estado"]
    search_fields = ["codigo", "usuario__username"]
    inlines = [MovimientoCajaInline]
    readonly_fields = [f.name for f in Caja._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.register(MovimientoCaja)
class MovimientoCajaAdmin(admin.ModelAdmin):
    list_display = ["creado_en", "caja", "tipo", "monto", "motivo", "usuario"]
    list_filter = ["tipo"]
    search_fields = ["caja__codigo", "motivo"]
    readonly_fields = [f.name for f in MovimientoCaja._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
