"""Lógica de negocio de caja."""

from __future__ import annotations

import logging

from django.db import transaction
from django.db.models import Sum
from django.utils import timezone

from apps.core.exceptions import ConflictoEstado, ErrorDominio
from apps.core.models import Secuencia

from .models import Caja, EstadoCaja, MovimientoCaja, TipoMovimientoCaja

logger = logging.getLogger("pos.caja")


class CajaError(ErrorDominio):
    codigo = "caja_error"


class CajaNoAbierta(ErrorDominio):
    codigo = "caja_no_abierta"
    mensaje = "No tienes una caja abierta. Debes abrir la caja antes de operar."
    http_status = 409


def caja_abierta_de(usuario) -> Caja | None:
    return Caja.objects.filter(usuario=usuario, estado=EstadoCaja.ABIERTA).first()


@transaction.atomic
def abrir_caja(*, usuario, monto_inicial: int) -> Caja:
    if int(monto_inicial) < 0:
        raise CajaError("El monto inicial no puede ser negativo.", codigo="monto_invalido")
    # Bloquea las cajas del usuario para evitar dos aperturas simultáneas.
    existentes = list(
        Caja.objects.select_for_update().filter(usuario=usuario, estado=EstadoCaja.ABIERTA)
    )
    if existentes:
        raise ConflictoEstado(
            f"Ya tienes una caja abierta ({existentes[0].codigo}).",
            codigo="caja_ya_abierta",
        )
    caja = Caja.objects.create(
        codigo=Secuencia.folio("caja", "CAJA"),
        usuario=usuario,
        monto_inicial=int(monto_inicial),
        estado=EstadoCaja.ABIERTA,
    )
    logger.info("Caja %s abierta por %s con $%s", caja.codigo, usuario.username, monto_inicial)
    return caja


def _sumar(caja: Caja, tipo: str) -> int:
    return caja.movimientos.filter(tipo=tipo).aggregate(t=Sum("monto"))["t"] or 0


def resumen_ventas(caja: Caja) -> dict:
    """
    Ventas del turno: cantidad, total cobrado y desglose por medio de pago.
    El ``total`` es la suma de todos los pagos (efectivo, débito, transferencia…),
    no solo el efectivo.
    """
    from django.db.models import Count

    from apps.ventas.models import EstadoVenta, PagoVenta, Venta

    pagos = PagoVenta.objects.filter(
        venta__caja=caja, venta__estado=EstadoVenta.PAGADA
    )
    por_medio = list(
        pagos.values("medio")
        .annotate(total=Sum("monto"), cantidad=Count("id"))
        .order_by("medio")
    )
    total = pagos.aggregate(t=Sum("monto"))["t"] or 0
    n_ventas = Venta.objects.filter(caja=caja, estado=EstadoVenta.PAGADA).count()
    anuladas = Venta.objects.filter(caja=caja, estado=EstadoVenta.ANULADA).count()
    return {
        "cantidad": n_ventas,
        "total": total,
        "anuladas": anuladas,
        "por_medio": [
            {"medio": f["medio"], "total": f["total"], "cantidad": f["cantidad"]}
            for f in por_medio
        ],
    }


def saldo_esperado(caja: Caja) -> int:
    """
    Valor que debería tener la caja al cierre: apertura + TODO lo vendido en el
    turno (cualquier medio de pago, se toma de los pagos de las ventas) +
    ingresos manuales − egresos manuales.
    """
    return (
        caja.monto_inicial
        + resumen_ventas(caja)["total"]
        + _sumar(caja, TipoMovimientoCaja.INGRESO)
        - _sumar(caja, TipoMovimientoCaja.EGRESO)
    )


def arqueo(caja: Caja) -> dict:
    resumen = resumen_ventas(caja)
    ventas_total = resumen["total"]
    ingresos = _sumar(caja, TipoMovimientoCaja.INGRESO)
    egresos = _sumar(caja, TipoMovimientoCaja.EGRESO)
    saldo = caja.monto_inicial + ventas_total + ingresos - egresos
    return {
        "codigo": caja.codigo,
        "estado": caja.estado,
        "usuario": caja.usuario.username,
        "abierta_en": caja.abierta_en.isoformat() if caja.abierta_en else None,
        "cerrada_en": caja.cerrada_en.isoformat() if caja.cerrada_en else None,
        "monto_inicial": caja.monto_inicial,
        "ventas_total": ventas_total,
        "ingresos": ingresos,
        "egresos": egresos,
        "saldo_esperado": saldo,
        "monto_contado": caja.monto_contado,
        "diferencia": caja.diferencia,
        "observacion_cierre": caja.observacion_cierre,
        "ventas": resumen,
    }


@transaction.atomic
def registrar_movimiento(
    *, caja: Caja, tipo: str, monto: int, usuario, motivo: str = "", venta=None
) -> MovimientoCaja:
    caja = Caja.objects.select_for_update().get(pk=caja.pk)
    if not caja.esta_abierta:
        raise ConflictoEstado("La caja está cerrada.", codigo="caja_cerrada")
    if int(monto) <= 0:
        raise CajaError("El monto debe ser mayor que cero.", codigo="monto_invalido")
    if tipo in (TipoMovimientoCaja.INGRESO, TipoMovimientoCaja.EGRESO) and not motivo.strip():
        raise CajaError("Los ingresos y egresos requieren un motivo.", codigo="motivo_requerido")
    if tipo == TipoMovimientoCaja.EGRESO and int(monto) > saldo_esperado(caja):
        raise ConflictoEstado(
            "El egreso supera el saldo disponible en caja.", codigo="egreso_excede_saldo"
        )

    mov = MovimientoCaja.objects.create(
        caja=caja, tipo=tipo, monto=int(monto), motivo=motivo, venta=venta, usuario=usuario
    )
    logger.info("Movimiento caja %s: %s $%s (%s)", caja.codigo, tipo, monto, motivo)
    return mov


def ingreso(*, caja, monto, usuario, motivo):
    return registrar_movimiento(
        caja=caja, tipo=TipoMovimientoCaja.INGRESO, monto=monto, usuario=usuario, motivo=motivo
    )


def egreso(*, caja, monto, usuario, motivo):
    return registrar_movimiento(
        caja=caja, tipo=TipoMovimientoCaja.EGRESO, monto=monto, usuario=usuario, motivo=motivo
    )


def registrar_venta(*, caja, venta, monto, usuario, medios: str = "") -> MovimientoCaja:
    """
    Lo llama ``ventas.confirmar_venta`` con el total de la venta. Se registra un
    movimiento por venta (no por pago), indicando en el motivo los medios
    usados: "Venta V-000012 · Efectivo/Débito".
    """
    detalle = f" · {medios}" if medios else ""
    return MovimientoCaja.objects.create(
        caja=caja, tipo=TipoMovimientoCaja.VENTA, monto=int(monto),
        motivo=f"Venta {venta.folio}{detalle}"[:200], venta=venta, usuario=usuario,
    )


@transaction.atomic
def cerrar_caja(*, caja: Caja, monto_contado: int, usuario, observacion: str = "") -> Caja:
    caja = Caja.objects.select_for_update().get(pk=caja.pk)
    if not caja.esta_abierta:
        raise ConflictoEstado("La caja ya está cerrada.", codigo="caja_ya_cerrada")
    if int(monto_contado) < 0:
        raise CajaError("El monto contado no puede ser negativo.", codigo="monto_invalido")

    esperado = saldo_esperado(caja)
    caja.monto_esperado = esperado
    caja.monto_contado = int(monto_contado)
    caja.diferencia = int(monto_contado) - esperado
    caja.observacion_cierre = observacion
    caja.estado = EstadoCaja.CERRADA
    caja.cerrada_en = timezone.now()
    caja.save(
        update_fields=[
            "monto_esperado", "monto_contado", "diferencia",
            "observacion_cierre", "estado", "cerrada_en",
        ]
    )
    logger.info(
        "Caja %s cerrada por %s: esperado $%s, contado $%s, diferencia $%s",
        caja.codigo, usuario.username, esperado, monto_contado, caja.diferencia,
    )
    return caja
