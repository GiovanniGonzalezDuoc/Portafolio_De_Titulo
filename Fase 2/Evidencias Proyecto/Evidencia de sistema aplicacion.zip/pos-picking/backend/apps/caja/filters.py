"""Filtros de caja."""

from datetime import datetime, time, timedelta

import django_filters as filters
from django.utils import timezone

from .models import Caja


class CajaFilter(filters.FilterSet):
    usuario = filters.CharFilter(field_name="usuario__username", lookup_expr="iexact")
    # Rango sobre la fecha de cierre (día completo, hora local).
    desde = filters.DateFilter(method="_desde", label="Cerrada desde (YYYY-MM-DD)")
    hasta = filters.DateFilter(method="_hasta", label="Cerrada hasta (YYYY-MM-DD)")

    class Meta:
        model = Caja
        fields = ["estado", "usuario"]

    def _desde(self, queryset, name, value):
        ini = timezone.make_aware(datetime.combine(value, time.min))
        return queryset.filter(cerrada_en__gte=ini)

    def _hasta(self, queryset, name, value):
        fin = timezone.make_aware(datetime.combine(value + timedelta(days=1), time.min))
        return queryset.filter(cerrada_en__lt=fin)
