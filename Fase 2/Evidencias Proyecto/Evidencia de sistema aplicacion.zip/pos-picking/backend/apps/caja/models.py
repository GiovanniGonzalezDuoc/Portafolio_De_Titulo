"""
Modelos de caja.

- ``Caja``: una sesión de caja (apertura → cierre) de un usuario.
- ``MovimientoCaja``: cada ingreso/egreso/venta en efectivo. Append-only.

Regla: **una sola caja ABIERTA por usuario** a la vez. MariaDB no soporta
índices únicos condicionales, por lo que se garantiza en la capa de servicios
(``select_for_update`` + validación).
"""

from __future__ import annotations

from django.conf import settings
from django.db import models


class EstadoCaja(models.TextChoices):
    ABIERTA = "ABIERTA", "Abierta"
    CERRADA = "CERRADA", "Cerrada"


class TipoMovimientoCaja(models.TextChoices):
    VENTA = "VENTA", "Venta"
    INGRESO = "INGRESO", "Ingreso"
    EGRESO = "EGRESO", "Egreso"


class Caja(models.Model):
    codigo = models.CharField("código", max_length=20, unique=True)
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="cajas"
    )
    estado = models.CharField(
        "estado", max_length=10, choices=EstadoCaja.choices, default=EstadoCaja.ABIERTA
    )
    monto_inicial = models.PositiveIntegerField("monto inicial (CLP)", default=0)
    monto_esperado = models.IntegerField("monto esperado (CLP)", null=True, blank=True)
    monto_contado = models.PositiveIntegerField("monto contado (CLP)", null=True, blank=True)
    diferencia = models.IntegerField("diferencia (CLP)", null=True, blank=True)
    observacion_cierre = models.CharField("observación de cierre", max_length=300, blank=True)

    abierta_en = models.DateTimeField("abierta en", auto_now_add=True)
    cerrada_en = models.DateTimeField("cerrada en", null=True, blank=True)

    class Meta:
        verbose_name = "caja"
        verbose_name_plural = "cajas"
        ordering = ["-abierta_en"]
        indexes = [models.Index(fields=["usuario", "estado"])]

    def __str__(self) -> str:
        return f"{self.codigo} ({self.get_estado_display()})"

    @property
    def esta_abierta(self) -> bool:
        return self.estado == EstadoCaja.ABIERTA


class MovimientoCaja(models.Model):
    caja = models.ForeignKey(Caja, on_delete=models.PROTECT, related_name="movimientos")
    tipo = models.CharField("tipo", max_length=10, choices=TipoMovimientoCaja.choices)
    monto = models.PositiveIntegerField("monto (CLP)")
    motivo = models.CharField("motivo", max_length=200, blank=True)
    venta = models.ForeignKey(
        "ventas.Venta", on_delete=models.SET_NULL, null=True, blank=True, related_name="+"
    )
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="movimientos_caja"
    )
    creado_en = models.DateTimeField("creado en", auto_now_add=True)

    class Meta:
        verbose_name = "movimiento de caja"
        verbose_name_plural = "movimientos de caja"
        ordering = ["-creado_en", "-id"]
        indexes = [
            models.Index(fields=["caja", "creado_en"]),
            models.Index(fields=["tipo"]),
        ]
        constraints = [
            models.CheckConstraint(condition=models.Q(monto__gt=0), name="movimiento_caja_monto_positivo"),
        ]

    def __str__(self) -> str:
        return f"{self.get_tipo_display()}: ${self.monto}"
