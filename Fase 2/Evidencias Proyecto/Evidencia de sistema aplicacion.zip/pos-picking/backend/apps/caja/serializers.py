"""Serializers de caja."""

from rest_framework import serializers

from .models import Caja, MovimientoCaja


class MovimientoCajaSerializer(serializers.ModelSerializer):
    tipo_display = serializers.CharField(source="get_tipo_display", read_only=True)
    usuario = serializers.CharField(source="usuario.username", read_only=True)
    venta_folio = serializers.CharField(source="venta.folio", read_only=True, default=None)

    class Meta:
        model = MovimientoCaja
        fields = [
            "id", "tipo", "tipo_display", "monto", "motivo",
            "venta_folio", "usuario", "creado_en",
        ]
        read_only_fields = fields


class CajaSerializer(serializers.ModelSerializer):
    usuario = serializers.CharField(source="usuario.username", read_only=True)
    estado_display = serializers.CharField(source="get_estado_display", read_only=True)

    class Meta:
        model = Caja
        fields = [
            "id", "codigo", "usuario", "estado", "estado_display",
            "monto_inicial", "monto_esperado", "monto_contado", "diferencia",
            "observacion_cierre", "abierta_en", "cerrada_en",
        ]
        read_only_fields = fields


class AbrirCajaSerializer(serializers.Serializer):
    monto_inicial = serializers.IntegerField(min_value=0)


class CerrarCajaSerializer(serializers.Serializer):
    monto_contado = serializers.IntegerField(min_value=0)
    observacion = serializers.CharField(max_length=300, required=False, allow_blank=True, default="")


class MovimientoCajaManualSerializer(serializers.Serializer):
    monto = serializers.IntegerField(min_value=1)
    motivo = serializers.CharField(max_length=200)
