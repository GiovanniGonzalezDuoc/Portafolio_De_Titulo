"""Tests de la API de caja."""

import pytest

from apps.caja.services import abrir_caja

pytestmark = pytest.mark.django_db


def test_abrir_caja_por_api(api_vendedor, vendedor):
    r = api_vendedor.post("/api/v1/cajas/abrir/", {"monto_inicial": 20000}, format="json")
    assert r.status_code == 201, r.data
    assert r.data["estado"] == "ABIERTA"


def test_abrir_dos_veces_da_409(api_vendedor, vendedor):
    api_vendedor.post("/api/v1/cajas/abrir/", {"monto_inicial": 10000}, format="json")
    r = api_vendedor.post("/api/v1/cajas/abrir/", {"monto_inicial": 5000}, format="json")
    assert r.status_code == 409
    assert r.data["error"]["codigo"] == "caja_ya_abierta"


def test_mi_caja(api_vendedor, vendedor):
    assert api_vendedor.get("/api/v1/cajas/mi-caja/").status_code == 404
    abrir_caja(usuario=vendedor, monto_inicial=10000)
    r = api_vendedor.get("/api/v1/cajas/mi-caja/")
    assert r.status_code == 200 and r.data["estado"] == "ABIERTA"


def test_ingreso_egreso_y_arqueo(api_vendedor, vendedor):
    caja = abrir_caja(usuario=vendedor, monto_inicial=10000)
    api_vendedor.post(f"/api/v1/cajas/{caja.id}/ingreso/", {"monto": 3000, "motivo": "fondo"}, format="json")
    api_vendedor.post(f"/api/v1/cajas/{caja.id}/egreso/", {"monto": 1000, "motivo": "insumos"}, format="json")
    r = api_vendedor.get(f"/api/v1/cajas/{caja.id}/arqueo/")
    assert r.data["saldo_esperado"] == 12000
    assert r.data["ingresos"] == 3000 and r.data["egresos"] == 1000


def test_arqueo_incluye_resumen_de_ventas(api_vendedor, vendedor):
    caja = abrir_caja(usuario=vendedor, monto_inicial=10000)
    r = api_vendedor.get(f"/api/v1/cajas/{caja.id}/arqueo/")
    assert r.status_code == 200
    assert r.data["usuario"] == vendedor.username
    assert r.data["ventas"] == {
        "cantidad": 0,
        "total": 0,
        "anuladas": 0,
        "por_medio": [],
    }


def test_egreso_requiere_motivo(api_vendedor, vendedor):
    caja = abrir_caja(usuario=vendedor, monto_inicial=10000)
    r = api_vendedor.post(f"/api/v1/cajas/{caja.id}/egreso/", {"monto": 1000}, format="json")
    assert r.status_code == 400


def test_cerrar_caja_por_api(api_vendedor, vendedor):
    caja = abrir_caja(usuario=vendedor, monto_inicial=10000)
    r = api_vendedor.post(
        f"/api/v1/cajas/{caja.id}/cerrar/",
        {"monto_contado": 9800, "observacion": "faltó vuelto"},
        format="json",
    )
    assert r.status_code == 200
    assert r.data["estado"] == "CERRADA"
    assert r.data["diferencia"] == -200


def test_vendedor_no_ve_caja_de_otro(api, vendedor, rol_vendedor):
    from apps.usuarios.tests.factories import UsuarioFactory
    otro = UsuarioFactory(rol=rol_vendedor, username="cajero2")
    caja_otro = abrir_caja(usuario=otro, monto_inicial=5000)

    api.force_authenticate(vendedor)
    assert api.get(f"/api/v1/cajas/{caja_otro.id}/").status_code == 404
    r = api.get("/api/v1/cajas/")
    assert r.data["conteo"] == 0


def test_admin_ve_todas_las_cajas(api_admin, vendedor):
    abrir_caja(usuario=vendedor, monto_inicial=5000)
    r = api_admin.get("/api/v1/cajas/")
    assert r.data["conteo"] == 1


def test_cierres_filtrados_por_fecha(api_admin, admin):
    from apps.caja import services
    from django.utils import timezone

    caja = services.abrir_caja(usuario=admin, monto_inicial=1000)
    services.cerrar_caja(caja=caja, monto_contado=1000, usuario=admin)
    hoy = timezone.localdate().isoformat()

    assert api_admin.get(f"/api/v1/cajas/?estado=CERRADA&desde={hoy}&hasta={hoy}").data["conteo"] == 1
    assert api_admin.get("/api/v1/cajas/?estado=CERRADA&hasta=2000-01-01").data["conteo"] == 0


def test_venta_sin_caja_abierta_da_409(api_vendedor, vendedor):
    from apps.ventas.tests.factories import producto_con_stock
    # cerramos la caja que abre el autouse fixture de ventas... no aplica aquí:
    # en los tests de caja NO hay caja auto-abierta.
    p = producto_con_stock(vendedor, cantidad=10, precio_venta=1000)
    r = api_vendedor.post(
        "/api/v1/ventas/",
        {"items": [{"producto": p.sku, "cantidad": "1"}],
         "pagos": [{"medio": "DEBITO", "monto": 1000}]},
        format="json",
    )
    assert r.status_code == 409
    assert r.data["error"]["codigo"] == "caja_no_abierta"
