"""Tests del servicio de caja."""

import pytest

from apps.caja import services
from apps.caja.models import EstadoCaja, MovimientoCaja, TipoMovimientoCaja
from apps.core.exceptions import ConflictoEstado

pytestmark = pytest.mark.django_db


def test_abrir_caja(vendedor):
    caja = services.abrir_caja(usuario=vendedor, monto_inicial=15000)
    assert caja.estado == EstadoCaja.ABIERTA
    assert caja.codigo.startswith("CAJA-")
    assert services.caja_abierta_de(vendedor) == caja


def test_no_se_pueden_abrir_dos_cajas(vendedor):
    services.abrir_caja(usuario=vendedor, monto_inicial=10000)
    with pytest.raises(ConflictoEstado) as exc:
        services.abrir_caja(usuario=vendedor, monto_inicial=5000)
    assert exc.value.codigo == "caja_ya_abierta"


def test_ingreso_y_egreso(vendedor):
    caja = services.abrir_caja(usuario=vendedor, monto_inicial=10000)
    services.ingreso(caja=caja, monto=3000, usuario=vendedor, motivo="fondo extra")
    services.egreso(caja=caja, monto=2000, usuario=vendedor, motivo="compra insumos")
    assert services.saldo_esperado(caja) == 11000
    assert MovimientoCaja.objects.filter(caja=caja).count() == 2


def test_ingreso_sin_motivo_falla(vendedor):
    caja = services.abrir_caja(usuario=vendedor, monto_inicial=10000)
    with pytest.raises(services.CajaError):
        services.ingreso(caja=caja, monto=1000, usuario=vendedor, motivo="  ")


def test_egreso_mayor_al_saldo_falla(vendedor):
    caja = services.abrir_caja(usuario=vendedor, monto_inicial=1000)
    with pytest.raises(ConflictoEstado):
        services.egreso(caja=caja, monto=5000, usuario=vendedor, motivo="x")


def test_venta_en_efectivo_suma_a_la_caja(vendedor):
    from apps.ventas import services as ventas_services
    from apps.ventas.tests.factories import item, producto_con_stock

    caja = services.abrir_caja(usuario=vendedor, monto_inicial=10000)
    prod = producto_con_stock(vendedor, cantidad=20, precio_venta=1000)
    ventas_services.confirmar_venta(
        items=[item(prod, 3)],
        pagos=[{"medio": "EFECTIVO", "monto": 3000}],
        vendedor=vendedor,
    )
    caja.refresh_from_db()
    assert services._sumar(caja, TipoMovimientoCaja.VENTA) == 3000
    assert services.saldo_esperado(caja) == 13000


def test_venta_con_tarjeta_tambien_suma_a_la_caja(vendedor):
    """El saldo del turno cuenta TODO lo vendido, no solo el efectivo."""
    from apps.ventas import services as ventas_services
    from apps.ventas.tests.factories import item, producto_con_stock

    caja = services.abrir_caja(usuario=vendedor, monto_inicial=10000)
    prod = producto_con_stock(vendedor, cantidad=20, precio_venta=1000)
    ventas_services.confirmar_venta(
        items=[item(prod, 2)],
        pagos=[{"medio": "DEBITO", "monto": 2000}],
        vendedor=vendedor,
    )
    assert services._sumar(caja, TipoMovimientoCaja.VENTA) == 2000
    assert services.saldo_esperado(caja) == 12000


def test_venta_pago_mixto_deja_un_movimiento_con_ambos_medios(vendedor):
    from apps.caja.models import MovimientoCaja
    from apps.ventas import services as ventas_services
    from apps.ventas.tests.factories import item, producto_con_stock

    caja = services.abrir_caja(usuario=vendedor, monto_inicial=0)
    prod = producto_con_stock(vendedor, cantidad=20, precio_venta=1000)
    ventas_services.confirmar_venta(
        items=[item(prod, 4)],
        pagos=[
            {"medio": "EFECTIVO", "monto": 2000},
            {"medio": "DEBITO", "monto": 2000},
        ],
        vendedor=vendedor,
    )
    movs = MovimientoCaja.objects.filter(caja=caja, tipo=TipoMovimientoCaja.VENTA)
    assert movs.count() == 1
    assert movs.first().monto == 4000
    assert "Efectivo" in movs.first().motivo and "Débito" in movs.first().motivo


def test_resumen_ventas_incluye_todos_los_medios(vendedor):
    """El resumen del turno muestra todas las ventas con su desglose por medio."""
    from apps.ventas import services as ventas_services
    from apps.ventas.tests.factories import item, producto_con_stock

    caja = services.abrir_caja(usuario=vendedor, monto_inicial=10000)
    prod = producto_con_stock(vendedor, cantidad=50, precio_venta=1000)
    ventas_services.confirmar_venta(
        items=[item(prod, 2)], pagos=[{"medio": "EFECTIVO", "monto": 2000}], vendedor=vendedor
    )
    ventas_services.confirmar_venta(
        items=[item(prod, 3)], pagos=[{"medio": "DEBITO", "monto": 3000}], vendedor=vendedor
    )

    resumen = services.resumen_ventas(caja)
    assert resumen["cantidad"] == 2
    assert resumen["total"] == 5000
    medios = {f["medio"]: f["total"] for f in resumen["por_medio"]}
    assert medios == {"EFECTIVO": 2000, "DEBITO": 3000}
    # el saldo esperado cuenta el total vendido (efectivo + débito)
    assert services.saldo_esperado(caja) == 15000


def test_cerrar_caja_calcula_diferencia(vendedor):
    caja = services.abrir_caja(usuario=vendedor, monto_inicial=10000)
    services.ingreso(caja=caja, monto=5000, usuario=vendedor, motivo="x")
    # esperado = 15000; el cajero cuenta 14500 -> falta 500
    cerrada = services.cerrar_caja(caja=caja, monto_contado=14500, usuario=vendedor)
    assert cerrada.estado == EstadoCaja.CERRADA
    assert cerrada.monto_esperado == 15000
    assert cerrada.diferencia == -500
    assert cerrada.cerrada_en is not None


def test_no_se_cierra_caja_dos_veces(vendedor):
    caja = services.abrir_caja(usuario=vendedor, monto_inicial=10000)
    services.cerrar_caja(caja=caja, monto_contado=10000, usuario=vendedor)
    with pytest.raises(ConflictoEstado):
        services.cerrar_caja(caja=caja, monto_contado=10000, usuario=vendedor)


def test_no_se_opera_caja_cerrada(vendedor):
    caja = services.abrir_caja(usuario=vendedor, monto_inicial=10000)
    services.cerrar_caja(caja=caja, monto_contado=10000, usuario=vendedor)
    with pytest.raises(ConflictoEstado):
        services.ingreso(caja=caja, monto=1000, usuario=vendedor, motivo="x")


def test_tras_cerrar_se_puede_abrir_otra(vendedor):
    c1 = services.abrir_caja(usuario=vendedor, monto_inicial=10000)
    services.cerrar_caja(caja=c1, monto_contado=10000, usuario=vendedor)
    c2 = services.abrir_caja(usuario=vendedor, monto_inicial=8000)
    assert c2.id != c1.id and c2.estado == EstadoCaja.ABIERTA
