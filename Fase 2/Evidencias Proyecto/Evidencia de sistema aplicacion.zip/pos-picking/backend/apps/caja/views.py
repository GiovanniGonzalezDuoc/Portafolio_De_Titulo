"""ViewSets de caja."""

from __future__ import annotations

from drf_spectacular.utils import extend_schema
from rest_framework import mixins, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.core.exceptions import RecursoNoEncontrado
from apps.usuarios.permissions import PermisoPorAccion

from . import services
from .filters import CajaFilter
from .models import Caja, TipoMovimientoCaja
from .serializers import (
    AbrirCajaSerializer,
    CajaSerializer,
    CerrarCajaSerializer,
    MovimientoCajaManualSerializer,
    MovimientoCajaSerializer,
)


class CajaViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = Caja.objects.select_related("usuario").all()
    serializer_class = CajaSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        "list": "caja.operar",
        "retrieve": "caja.operar",
        "abrir": "caja.operar",
        "cerrar": "caja.operar",
        "ingreso": "caja.operar",
        "egreso": "caja.operar",
        "movimientos": "caja.operar",
        "arqueo": "caja.operar",
        "mi_caja": "caja.operar",
    }
    filterset_class = CajaFilter
    ordering_fields = ["abierta_en", "cerrada_en"]

    def get_queryset(self):
        qs = super().get_queryset()
        u = self.request.user
        if u.is_authenticated and not u.is_superuser and not u.tiene_permiso("caja.ver_todas"):
            qs = qs.filter(usuario=u)
        return qs

    @extend_schema(responses=CajaSerializer)
    @action(detail=False, methods=["get"], url_path="mi-caja")
    def mi_caja(self, request):
        caja = services.caja_abierta_de(request.user)
        if caja is None:
            raise RecursoNoEncontrado(
                "No tienes una caja abierta.", codigo="sin_caja_abierta"
            )
        return Response(CajaSerializer(caja).data)

    @extend_schema(request=AbrirCajaSerializer, responses=CajaSerializer)
    @action(detail=False, methods=["post"])
    def abrir(self, request):
        serializer = AbrirCajaSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        caja = services.abrir_caja(
            usuario=request.user, monto_inicial=serializer.validated_data["monto_inicial"]
        )
        return Response(CajaSerializer(caja).data, status=status.HTTP_201_CREATED)

    @extend_schema(request=CerrarCajaSerializer, responses=CajaSerializer)
    @action(detail=True, methods=["post"])
    def cerrar(self, request, pk=None):
        caja = self.get_object()
        serializer = CerrarCajaSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        caja = services.cerrar_caja(
            caja=caja,
            monto_contado=serializer.validated_data["monto_contado"],
            usuario=request.user,
            observacion=serializer.validated_data["observacion"],
        )
        return Response(CajaSerializer(caja).data)

    @extend_schema(request=MovimientoCajaManualSerializer, responses=MovimientoCajaSerializer)
    @action(detail=True, methods=["post"])
    def ingreso(self, request, pk=None):
        return self._movimiento(request, TipoMovimientoCaja.INGRESO)

    @extend_schema(request=MovimientoCajaManualSerializer, responses=MovimientoCajaSerializer)
    @action(detail=True, methods=["post"])
    def egreso(self, request, pk=None):
        return self._movimiento(request, TipoMovimientoCaja.EGRESO)

    def _movimiento(self, request, tipo):
        caja = self.get_object()
        serializer = MovimientoCajaManualSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        mov = services.registrar_movimiento(
            caja=caja, tipo=tipo, monto=serializer.validated_data["monto"],
            usuario=request.user, motivo=serializer.validated_data["motivo"],
        )
        return Response(MovimientoCajaSerializer(mov).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["get"])
    def movimientos(self, request, pk=None):
        caja = self.get_object()
        qs = caja.movimientos.select_related("usuario", "venta").all()
        return Response(MovimientoCajaSerializer(qs, many=True).data)

    @action(detail=True, methods=["get"])
    def arqueo(self, request, pk=None):
        return Response(services.arqueo(self.get_object()))
