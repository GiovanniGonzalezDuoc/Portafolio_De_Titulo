"""Lógica de negocio de usuarios y seguridad de login."""

from __future__ import annotations

import logging
from datetime import timedelta

from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import transaction
from django.utils import timezone

from apps.core.exceptions import ConflictoEstado, ErrorDominio

from .models import IntentoLogin, Rol
from .permisos import ROLES as ROLES_BASE

logger = logging.getLogger("pos.usuarios")
Usuario = get_user_model()


class CuentaBloqueada(ErrorDominio):
    codigo = "cuenta_bloqueada"
    mensaje = "Cuenta bloqueada temporalmente por intentos fallidos. Intenta más tarde."
    http_status = 429


# ─────────────────────────────────────────────────────────────
# Seguridad de login
# ─────────────────────────────────────────────────────────────
def registrar_intento(username: str, ip: str, exito: bool) -> None:
    IntentoLogin.objects.create(username=username or "", ip=ip or "", exito=exito)


def esta_bloqueado(username: str) -> bool:
    """True si hay >= LOGIN_MAX_INTENTOS fallidos en la ventana de bloqueo."""
    ventana = timezone.now() - timedelta(minutes=settings.LOGIN_BLOQUEO_MINUTOS)
    fallidos = IntentoLogin.objects.filter(
        username=username, exito=False, fecha__gte=ventana
    ).count()
    return fallidos >= settings.LOGIN_MAX_INTENTOS


def limpiar_intentos(username: str) -> None:
    """Tras un login exitoso, marca resueltos los fallidos recientes."""
    ventana = timezone.now() - timedelta(minutes=settings.LOGIN_BLOQUEO_MINUTOS)
    IntentoLogin.objects.filter(
        username=username, exito=False, fecha__gte=ventana
    ).delete()


# ─────────────────────────────────────────────────────────────
# Gestión de usuarios
# ─────────────────────────────────────────────────────────────
@transaction.atomic
def crear_usuario(*, datos: dict, password: str) -> Usuario:
    rol = datos.get("rol")
    if rol is None:
        raise ErrorDominio("Debes indicar un rol.", codigo="rol_requerido")
    usuario = Usuario.objects.create_user(password=password, **datos)
    logger.info("Usuario creado: %s (rol=%s)", usuario.username, usuario.rol.nombre)
    return usuario


@transaction.atomic
def actualizar_usuario(usuario: Usuario, *, datos: dict) -> Usuario:
    for campo, valor in datos.items():
        setattr(usuario, campo, valor)
    usuario.full_clean(exclude=["password"], validate_unique=True)
    usuario.save()
    return usuario


def _revocar_sesiones(usuario: Usuario) -> int:
    """Pone en la blacklist todos los refresh vigentes del usuario."""
    from rest_framework_simplejwt.token_blacklist.models import (
        BlacklistedToken,
        OutstandingToken,
    )

    revocados = 0
    for token in OutstandingToken.objects.filter(user=usuario):
        _, creado = BlacklistedToken.objects.get_or_create(token=token)
        revocados += int(creado)
    return revocados


def cambiar_password(usuario: Usuario, *, password_actual: str, password_nuevo: str) -> None:
    if not usuario.check_password(password_actual):
        raise ErrorDominio(
            "La contraseña actual no es correcta.", codigo="password_incorrecta"
        )
    usuario.set_password(password_nuevo)
    usuario.save(update_fields=["password"])
    revocados = _revocar_sesiones(usuario)
    logger.info("Contraseña cambiada: %s (%d sesiones revocadas)", usuario.username, revocados)


def resetear_password(usuario: Usuario, *, password_nuevo: str, por: Usuario) -> None:
    usuario.set_password(password_nuevo)
    usuario.save(update_fields=["password"])
    revocados = _revocar_sesiones(usuario)
    logger.info(
        "Contraseña reseteada para %s por %s (%d sesiones revocadas)",
        usuario.username, por.username, revocados,
    )


def set_estado(usuario: Usuario, *, activo: bool) -> Usuario:
    usuario.is_active = activo
    usuario.save(update_fields=["is_active", "actualizado_en"])
    return usuario


@transaction.atomic
def crear_rol(
    *, nombre: str, descripcion: str = "", activo: bool = True, codigos_permisos: list[str] | None = None
) -> Rol:
    rol = Rol.objects.create(nombre=nombre, descripcion=descripcion, activo=activo)
    if codigos_permisos:
        sincronizar_permisos_rol(rol, codigos_permisos)
    logger.info("Rol creado: %s", rol.nombre)
    return rol


@transaction.atomic
def actualizar_rol(rol: Rol, *, datos: dict) -> Rol:
    nombre_nuevo = datos.get("nombre", rol.nombre)
    if rol.nombre in ROLES_BASE and nombre_nuevo != rol.nombre:
        raise ErrorDominio(
            "Los roles base del sistema no se pueden renombrar.", codigo="rol_base"
        )
    for campo, valor in datos.items():
        setattr(rol, campo, valor)
    rol.save()
    return rol


def eliminar_rol(rol: Rol) -> None:
    if rol.nombre in ROLES_BASE:
        raise ConflictoEstado(
            "Los roles base del sistema no se pueden eliminar.", codigo="rol_base"
        )
    en_uso = rol.usuarios.count()
    if en_uso:
        raise ConflictoEstado(
            f"El rol tiene {en_uso} usuario(s) asignado(s). Reasígnalos a otro rol "
            "antes de eliminarlo.",
            codigo="rol_con_usuarios",
        )
    logger.info("Rol eliminado: %s", rol.nombre)
    rol.delete()


def sincronizar_permisos_rol(rol: Rol, codigos: list[str]) -> Rol:
    """Reemplaza el set de permisos de un rol por los ``codigos`` indicados."""
    from .models import Permiso

    permisos = list(Permiso.objects.filter(codigo__in=codigos))
    encontrados = {p.codigo for p in permisos}
    faltantes = set(codigos) - encontrados
    if faltantes:
        raise ErrorDominio(
            f"Permisos inexistentes: {', '.join(sorted(faltantes))}",
            codigo="permiso_inexistente",
        )
    rol.permisos.set(permisos)
    return rol
