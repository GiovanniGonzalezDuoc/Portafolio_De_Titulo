"""Re-sincroniza permisos tras agregar ventas.autorizar_descuento (Etapa 8)."""

from django.db import migrations

from apps.usuarios.permisos import sincronizar


class Migration(migrations.Migration):
    dependencies = [("usuarios", "0003_resync_permisos")]
    operations = [migrations.RunPython(lambda apps, se: sincronizar(apps), migrations.RunPython.noop)]
