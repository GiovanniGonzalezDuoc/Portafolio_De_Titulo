"""Carga permisos, roles y la matriz rol → permisos."""

from django.db import migrations

from apps.usuarios.permisos import MATRIZ_ROL_PERMISOS, PERMISOS, ROLES


def cargar(apps, schema_editor):
    Permiso = apps.get_model("usuarios", "Permiso")
    Rol = apps.get_model("usuarios", "Rol")

    for codigo, (modulo, descripcion) in PERMISOS.items():
        Permiso.objects.update_or_create(
            codigo=codigo,
            defaults={"modulo": modulo, "descripcion": descripcion},
        )

    for nombre, descripcion in ROLES.items():
        rol, _ = Rol.objects.update_or_create(
            nombre=nombre, defaults={"descripcion": descripcion, "activo": True}
        )
        codigos = MATRIZ_ROL_PERMISOS.get(nombre, set())
        rol.permisos.set(Permiso.objects.filter(codigo__in=codigos))


def revertir(apps, schema_editor):
    Permiso = apps.get_model("usuarios", "Permiso")
    Rol = apps.get_model("usuarios", "Rol")
    Rol.objects.filter(nombre__in=ROLES).delete()
    Permiso.objects.filter(codigo__in=PERMISOS).delete()


class Migration(migrations.Migration):
    dependencies = [("usuarios", "0001_initial")]
    operations = [migrations.RunPython(cargar, revertir)]
