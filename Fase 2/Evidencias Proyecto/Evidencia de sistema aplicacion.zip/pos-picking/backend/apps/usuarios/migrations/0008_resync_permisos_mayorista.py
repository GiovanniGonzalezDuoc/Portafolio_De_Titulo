"""Re-sincroniza la matriz rol → permisos tras acotar el rol mayorista.

El mayorista pasa a tener solo ``ofertas.ver`` (antes también ``catalogo.ver``):
solo ve el catálogo de ofertas vigentes con precio mayorista.
"""

from django.db import migrations

from apps.usuarios.permisos import MATRIZ_ROL_PERMISOS, PERMISOS, ROLES


def resync(apps, schema_editor):
    Permiso = apps.get_model("usuarios", "Permiso")
    Rol = apps.get_model("usuarios", "Rol")

    for codigo, (modulo, descripcion) in PERMISOS.items():
        Permiso.objects.update_or_create(
            codigo=codigo, defaults={"modulo": modulo, "descripcion": descripcion}
        )
    for nombre, descripcion in ROLES.items():
        rol, _ = Rol.objects.update_or_create(
            nombre=nombre, defaults={"descripcion": descripcion}
        )
        rol.permisos.set(
            Permiso.objects.filter(codigo__in=MATRIZ_ROL_PERMISOS.get(nombre, set()))
        )


class Migration(migrations.Migration):
    dependencies = [("usuarios", "0007_resync_permisos_ofertas")]
    operations = [migrations.RunPython(resync, migrations.RunPython.noop)]
