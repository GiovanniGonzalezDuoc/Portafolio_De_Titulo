"""Re-sincroniza permisos tras agregar alertas.configurar (Etapa 11)."""

from django.db import migrations

from apps.usuarios.permisos import sincronizar


class Migration(migrations.Migration):
    dependencies = [("usuarios", "0004_resync_permisos_ventas")]
    operations = [migrations.RunPython(lambda apps, se: sincronizar(apps), migrations.RunPython.noop)]
