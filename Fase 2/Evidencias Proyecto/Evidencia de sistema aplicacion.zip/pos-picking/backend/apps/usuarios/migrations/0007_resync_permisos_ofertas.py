"""Re-sincroniza permisos tras agregar el módulo de ofertas."""

from django.db import migrations

from apps.usuarios.permisos import sincronizar


class Migration(migrations.Migration):
    dependencies = [("usuarios", "0006_alter_usuario_username")]
    operations = [migrations.RunPython(lambda apps, se: sincronizar(apps), migrations.RunPython.noop)]
