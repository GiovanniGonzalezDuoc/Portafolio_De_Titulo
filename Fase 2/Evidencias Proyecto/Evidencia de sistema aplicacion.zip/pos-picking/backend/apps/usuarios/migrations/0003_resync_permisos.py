"""Re-sincroniza permisos y la matriz rol → permisos (idempotente).

Se ejecuta cada vez que cambia ``apps/usuarios/permisos.py``. Para forzar una
re-sincronización futura, crear otra migración que llame a ``resync``.
"""

from django.db import migrations

from apps.usuarios.permisos import MATRIZ_ROL_PERMISOS, PERMISOS, ROLES


def resync(apps, schema_editor):
    Permiso = apps.get_model("usuarios", "Permiso")
    Rol = apps.get_model("usuarios", "Rol")

    for codigo, (modulo, descripcion) in PERMISOS.items():
        Permiso.objects.update_or_create(
            codigo=codigo, defaults={"modulo": modulo, "descripcion": descripcion}
        )
    for nombre, descripcion in ROLES.items():
        rol, _ = Rol.objects.update_or_create(
            nombre=nombre, defaults={"descripcion": descripcion}
        )
        rol.permisos.set(
            Permiso.objects.filter(codigo__in=MATRIZ_ROL_PERMISOS.get(nombre, set()))
        )


class Migration(migrations.Migration):
    dependencies = [("usuarios", "0002_datos_iniciales")]
    operations = [migrations.RunPython(resync, migrations.RunPython.noop)]
