"""Tests del modelo de roles/permisos y sus endpoints."""

import pytest

from apps.usuarios.models import Rol
from apps.usuarios.permisos import PERMISOS

from .factories import UsuarioFactory

pytestmark = pytest.mark.django_db


def test_tiene_permiso_segun_rol(rol_vendedor):
    u = UsuarioFactory(rol=rol_vendedor)
    assert u.tiene_permiso("ventas.crear")
    assert not u.tiene_permiso("usuarios.administrar")


def test_superusuario_tiene_todos_los_permisos(datos_seguridad):
    rol = Rol.objects.get(nombre="vendedor")
    u = UsuarioFactory(rol=rol, is_superuser=True)
    assert u.tiene_permiso("auditoria.ver")
    assert len(u.permisos_efectivos()) == len(PERMISOS)


def test_usuario_con_rol_inactivo_no_tiene_permisos(rol_vendedor):
    u = UsuarioFactory(rol=rol_vendedor)
    rol_vendedor.activo = False
    rol_vendedor.save()
    assert not u.tiene_permiso("ventas.crear")
    assert u.permisos_efectivos() == []


def test_admin_lista_permisos_sin_paginar(api_admin):
    r = api_admin.get("/api/v1/permisos/")
    assert r.status_code == 200
    assert len(r.data) == len(PERMISOS)


def test_vendedor_no_ve_catalogo_de_permisos(api_vendedor):
    assert api_vendedor.get("/api/v1/permisos/").status_code == 403


def test_admin_edita_permisos_de_un_rol(api_admin):
    rol = Rol.objects.get(nombre="vendedor")
    r = api_admin.put(
        f"/api/v1/roles/{rol.id}/permisos/",
        {"permisos": ["ventas.crear", "ventas.ver"]},
        format="json",
    )
    assert r.status_code == 200
    assert set(r.data["permisos"]) == {"ventas.crear", "ventas.ver"}


def test_no_se_pueden_asignar_permisos_inexistentes(api_admin):
    rol = Rol.objects.get(nombre="vendedor")
    r = api_admin.put(
        f"/api/v1/roles/{rol.id}/permisos/",
        {"permisos": ["ventas.crear", "no.existe"]},
        format="json",
    )
    assert r.status_code == 400
    assert r.data["error"]["codigo"] == "permiso_inexistente"


# ─── Alta / edición / borrado de roles ─────────────────────────
def test_admin_crea_rol_con_permisos(api_admin):
    r = api_admin.post(
        "/api/v1/roles/",
        {
            "nombre": "cajero",
            "descripcion": "Solo caja",
            "permisos": ["caja.operar", "ventas.ver"],
        },
        format="json",
    )
    assert r.status_code == 201, r.data
    assert r.data["nombre"] == "cajero"
    assert set(r.data["permisos"]) == {"caja.operar", "ventas.ver"}


def test_admin_edita_nombre_y_descripcion_de_rol(api_admin):
    rol = Rol.objects.create(nombre="temporal", descripcion="x")
    r = api_admin.patch(
        f"/api/v1/roles/{rol.id}/",
        {"nombre": "supervisor", "activo": False},
        format="json",
    )
    assert r.status_code == 200, r.data
    rol.refresh_from_db()
    assert rol.nombre == "supervisor"
    assert rol.activo is False


def test_no_se_puede_renombrar_rol_base(api_admin):
    rol = Rol.objects.get(nombre="vendedor")
    r = api_admin.patch(
        f"/api/v1/roles/{rol.id}/", {"nombre": "otra-cosa"}, format="json"
    )
    assert r.status_code == 400
    assert r.data["error"]["codigo"] == "rol_base"


def test_elimina_rol_sin_usuarios(api_admin):
    rol = Rol.objects.create(nombre="descartable")
    r = api_admin.delete(f"/api/v1/roles/{rol.id}/")
    assert r.status_code == 204
    assert not Rol.objects.filter(id=rol.id).exists()


def test_no_elimina_rol_con_usuarios(api_admin):
    rol = Rol.objects.create(nombre="con-gente")
    UsuarioFactory(rol=rol)
    r = api_admin.delete(f"/api/v1/roles/{rol.id}/")
    assert r.status_code == 409
    assert r.data["error"]["codigo"] == "rol_con_usuarios"


def test_no_elimina_rol_base(api_admin):
    rol = Rol.objects.get(nombre="bodeguero")
    r = api_admin.delete(f"/api/v1/roles/{rol.id}/")
    assert r.status_code == 409
    assert r.data["error"]["codigo"] == "rol_base"


def test_vendedor_no_puede_crear_roles(api_vendedor):
    assert api_vendedor.post("/api/v1/roles/", {"nombre": "x"}, format="json").status_code == 403


# ─── Rol mayorista: solo ofertas ──────────────────────────────
def test_mayorista_solo_tiene_ofertas_ver(rol_mayorista):
    assert rol_mayorista.codigos_permisos == {"ofertas.ver"}


def test_mayorista_ve_ofertas_pero_no_el_catalogo(api_mayorista):
    assert api_mayorista.get("/api/v1/ofertas/?vigente=true").status_code == 200
    assert api_mayorista.get("/api/v1/catalogo/productos/").status_code == 403
    assert api_mayorista.get("/api/v1/catalogo/categorias/").status_code == 403
