"""Tests del CRUD de usuarios y de la autorización por rol."""

import pytest

from apps.usuarios.models import Usuario

pytestmark = pytest.mark.django_db


def test_vendedor_no_puede_listar_usuarios(api_vendedor):
    assert api_vendedor.get("/api/v1/usuarios/").status_code == 403


def test_admin_lista_usuarios(api_admin):
    r = api_admin.get("/api/v1/usuarios/")
    assert r.status_code == 200
    assert "resultados" in r.data


def test_admin_crea_usuario(api_admin, datos_seguridad):
    payload = {
        "username": "bodega1",
        "nombres": "Ana",
        "apellidos": "Soto",
        "email": "ana@example.cl",
        "rut": "11.111.111-1",
        "rol": "bodeguero",
        "password": "clave-nueva-larga-1",
    }
    r = api_admin.post("/api/v1/usuarios/", payload, format="json")
    assert r.status_code == 201, r.data
    u = Usuario.objects.get(username="bodega1")
    assert u.rol.nombre == "bodeguero"
    assert u.rut == "11111111-1"
    assert u.check_password("clave-nueva-larga-1")


def test_no_se_puede_crear_usuario_con_password_debil(api_admin, datos_seguridad):
    payload = {
        "username": "x", "nombres": "X", "apellidos": "Y",
        "rol": "vendedor", "password": "123",
    }
    r = api_admin.post("/api/v1/usuarios/", payload, format="json")
    assert r.status_code == 400


def test_rut_invalido_es_rechazado(api_admin, datos_seguridad):
    payload = {
        "username": "x", "nombres": "X", "apellidos": "Y", "rol": "vendedor",
        "rut": "11.111.111-2", "password": "clave-larga-valida-1",
    }
    r = api_admin.post("/api/v1/usuarios/", payload, format="json")
    assert r.status_code == 400
    assert r.data["error"]["campo"] == "rut"


def test_destroy_desactiva_no_borra(api_admin, vendedor):
    r = api_admin.delete(f"/api/v1/usuarios/{vendedor.id}/")
    assert r.status_code == 204
    vendedor.refresh_from_db()
    assert vendedor.is_active is False
    assert Usuario.objects.filter(id=vendedor.id).exists()


def test_activar_y_desactivar(api_admin, vendedor):
    api_admin.post(f"/api/v1/usuarios/{vendedor.id}/desactivar/")
    vendedor.refresh_from_db()
    assert not vendedor.is_active
    api_admin.post(f"/api/v1/usuarios/{vendedor.id}/activar/")
    vendedor.refresh_from_db()
    assert vendedor.is_active


def test_admin_resetea_password(api_admin, vendedor):
    r = api_admin.post(
        f"/api/v1/usuarios/{vendedor.id}/resetear-password/",
        {"password_nuevo": "clave-reseteada-larga-1"},
    )
    assert r.status_code == 204
    vendedor.refresh_from_db()
    assert vendedor.check_password("clave-reseteada-larga-1")


def test_cambio_de_rol_via_update(api_admin, vendedor, datos_seguridad):
    r = api_admin.patch(
        f"/api/v1/usuarios/{vendedor.id}/",
        {"nombres": vendedor.nombres, "apellidos": vendedor.apellidos, "rol": "bodeguero"},
        format="json",
    )
    assert r.status_code == 200, r.data
    vendedor.refresh_from_db()
    assert vendedor.rol.nombre == "bodeguero"
