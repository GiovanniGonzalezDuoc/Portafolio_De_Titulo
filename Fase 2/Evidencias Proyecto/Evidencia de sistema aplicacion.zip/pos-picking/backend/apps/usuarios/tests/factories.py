"""Factories para tests de usuarios."""

import factory
from django.contrib.auth import get_user_model

from apps.usuarios.models import Rol

Usuario = get_user_model()


class RolFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Rol
        django_get_or_create = ("nombre",)

    nombre = "vendedor"
    descripcion = "Rol de prueba"
    activo = True


class UsuarioFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Usuario
        skip_postgeneration_save = True

    username = factory.Sequence(lambda n: f"usuario{n}")
    nombres = "Juan"
    apellidos = factory.Sequence(lambda n: f"Pérez {n}")
    email = factory.LazyAttribute(lambda o: f"{o.username}@example.cl")
    is_active = True
    rol = factory.SubFactory(RolFactory)

    @factory.post_generation
    def password(obj, create, extracted, **kwargs):
        obj.set_password(extracted or "clave-segura-123")
        if create:
            obj.save()
