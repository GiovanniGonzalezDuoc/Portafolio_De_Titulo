"""Tests de login, refresh, logout, /me y cambio de contraseña."""

import pytest

from apps.usuarios.models import IntentoLogin

pytestmark = pytest.mark.django_db


def test_login_correcto_devuelve_tokens_y_usuario(api, vendedor):
    r = api.post("/api/v1/auth/login/", {"username": "vende", "password": "clave-vende-123"})
    assert r.status_code == 200
    assert "access" in r.data and "refresh" in r.data
    assert r.data["usuario"]["username"] == "vende"
    assert r.data["usuario"]["rol"] == "vendedor"
    assert "ventas.crear" in r.data["usuario"]["permisos"]


def test_login_password_incorrecta_registra_intento_fallido(api, vendedor):
    r = api.post("/api/v1/auth/login/", {"username": "vende", "password": "mala"})
    assert r.status_code == 401
    assert IntentoLogin.objects.filter(username="vende", exito=False).count() == 1


def test_login_bloquea_tras_maximo_de_intentos(api, vendedor, settings):
    settings.LOGIN_MAX_INTENTOS = 3
    for _ in range(3):
        api.post("/api/v1/auth/login/", {"username": "vende", "password": "mala"})
    r = api.post("/api/v1/auth/login/", {"username": "vende", "password": "clave-vende-123"})
    assert r.status_code == 429
    assert r.data["error"]["codigo"] == "cuenta_bloqueada"


def test_usuario_inactivo_no_puede_iniciar_sesion(api, vendedor):
    vendedor.is_active = False
    vendedor.save()
    r = api.post("/api/v1/auth/login/", {"username": "vende", "password": "clave-vende-123"})
    assert r.status_code == 401


def test_refresh_entrega_nuevo_access(api, vendedor):
    login = api.post("/api/v1/auth/login/", {"username": "vende", "password": "clave-vende-123"})
    r = api.post("/api/v1/auth/refresh/", {"refresh": login.data["refresh"]})
    assert r.status_code == 200
    assert "access" in r.data


def test_logout_invalida_el_refresh(api, vendedor):
    login = api.post("/api/v1/auth/login/", {"username": "vende", "password": "clave-vende-123"})
    api.force_authenticate(vendedor)
    r = api.post("/api/v1/auth/logout/", {"refresh": login.data["refresh"]})
    assert r.status_code == 205
    r2 = api.post("/api/v1/auth/refresh/", {"refresh": login.data["refresh"]})
    assert r2.status_code == 401


def test_me_requiere_autenticacion(api):
    assert api.get("/api/v1/auth/me/").status_code == 401


def test_me_devuelve_permisos_efectivos(api_vendedor):
    r = api_vendedor.get("/api/v1/auth/me/")
    assert r.status_code == 200
    assert set(r.data["permisos"]) >= {"ventas.crear", "caja.operar"}
    assert "usuarios.administrar" not in r.data["permisos"]


def test_cambio_de_password(api, vendedor):
    api.force_authenticate(vendedor)
    r = api.post(
        "/api/v1/auth/cambiar-password/",
        {"password_actual": "clave-vende-123", "password_nuevo": "otra-clave-larga-9"},
    )
    assert r.status_code == 204
    vendedor.refresh_from_db()
    assert vendedor.check_password("otra-clave-larga-9")


def test_cambio_de_password_con_actual_incorrecta(api, vendedor):
    api.force_authenticate(vendedor)
    r = api.post(
        "/api/v1/auth/cambiar-password/",
        {"password_actual": "no-es", "password_nuevo": "otra-clave-larga-9"},
    )
    assert r.status_code == 400
    assert r.data["error"]["codigo"] == "password_incorrecta"


def test_cambio_de_password_revoca_los_refresh_vigentes(api, vendedor):
    """S9: un refresh robado deja de servir cuando la víctima cambia la clave."""
    login = api.post(
        "/api/v1/auth/login/", {"username": "vende", "password": "clave-vende-123"}
    )
    refresh_robado = login.data["refresh"]

    api.force_authenticate(vendedor)
    r = api.post(
        "/api/v1/auth/cambiar-password/",
        {"password_actual": "clave-vende-123", "password_nuevo": "otra-clave-larga-9"},
    )
    assert r.status_code == 204

    api.force_authenticate(user=None)
    r2 = api.post("/api/v1/auth/refresh/", {"refresh": refresh_robado})
    assert r2.status_code == 401


def test_reset_de_password_por_admin_revoca_sesiones(api_admin, vendedor, api):
    login = api.post(
        "/api/v1/auth/login/", {"username": "vende", "password": "clave-vende-123"}
    )
    r = api_admin.post(
        f"/api/v1/usuarios/{vendedor.id}/resetear-password/",
        {"password_nuevo": "clave-nueva-larga-1"},
    )
    assert r.status_code == 204
    r2 = api.post("/api/v1/auth/refresh/", {"refresh": login.data["refresh"]})
    assert r2.status_code == 401


def test_login_fallido_en_admin_cuenta_para_el_bloqueo(client, vendedor, settings):
    """S5: el lockout de fuerza bruta también cubre /admin/login/."""
    settings.LOGIN_MAX_INTENTOS = 3
    for _ in range(3):
        client.post("/admin/login/", {"username": "vende", "password": "mala"})
    assert IntentoLogin.objects.filter(username="vende", exito=False).count() >= 3
