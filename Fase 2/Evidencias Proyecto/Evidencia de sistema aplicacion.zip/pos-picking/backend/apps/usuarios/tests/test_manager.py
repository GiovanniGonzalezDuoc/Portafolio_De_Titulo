"""Tests del UsuarioManager (create_user / create_superuser)."""

import pytest

from apps.usuarios.models import Usuario

pytestmark = pytest.mark.django_db


def _datos_persona(**extra):
    base = {"nombres": "Ada", "apellidos": "Lovelace"}
    base.update(extra)
    return base


def test_create_user_basico(rol_vendedor):
    u = Usuario.objects.create_user(
        username="operador", password="clave-12345", rol=rol_vendedor, **_datos_persona()
    )
    assert u.check_password("clave-12345")
    assert u.is_staff is False
    assert u.is_superuser is False


def test_create_user_sin_username_falla():
    with pytest.raises(ValueError):
        Usuario.objects.create_user(username="", password="x")


def test_create_superuser_asigna_rol_administrador(datos_seguridad):
    u = Usuario.objects.create_superuser(username="root", password="clave-root-123")
    assert u.is_staff and u.is_superuser and u.is_active
    assert u.rol is not None
    assert u.rol.nombre == "administrador"
    # el rol administrador trae todos los permisos
    assert u.rol.permisos.exists()


def test_create_superuser_exige_flags():
    with pytest.raises(ValueError):
        Usuario.objects.create_superuser(username="x", password="y", is_staff=False)
    with pytest.raises(ValueError):
        Usuario.objects.create_superuser(username="x", password="y", is_superuser=False)


def test_create_user_normaliza_email(rol_vendedor):
    u = Usuario.objects.create_user(
        username="con_mail",
        password="clave-12345",
        email="Persona@Example.COM",
        rol=rol_vendedor,
        **_datos_persona(),
    )
    assert u.email == "Persona@example.com"
