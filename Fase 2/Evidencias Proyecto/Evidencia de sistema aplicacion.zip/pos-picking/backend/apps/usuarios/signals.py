"""
Registro unificado de intentos de login (API y admin de Django).

`django.contrib.auth.authenticate()` emite ``user_login_failed`` en cada fallo
(lo usan tanto simplejwt como el admin). ``user_logged_in`` lo emite el login
del admin al tener éxito. Con esto el bloqueo por fuerza bruta (`IntentoLogin`)
cubre también ``/admin/login/``, no solo ``/api/v1/auth/login/``.
"""

from __future__ import annotations

from django.contrib.auth.signals import user_logged_in, user_login_failed
from django.dispatch import receiver

from apps.core.middleware import _obtener_ip

from . import services


@receiver(user_login_failed)
def registrar_login_fallido(sender, credentials=None, request=None, **kwargs):
    username = (credentials or {}).get("username", "") or ""
    ip = _obtener_ip(request) if request is not None else ""
    services.registrar_intento(username, ip or "", exito=False)


@receiver(user_logged_in)
def limpiar_al_iniciar_sesion(sender, user=None, request=None, **kwargs):
    if user is not None:
        services.limpiar_intentos(user.get_username())
