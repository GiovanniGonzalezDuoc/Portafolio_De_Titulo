"""Clases de permiso de DRF basadas en el rol del usuario."""

from __future__ import annotations

from rest_framework.permissions import BasePermission


class TienePermiso(BasePermission):
    """
    Permite el acceso solo si el usuario tiene el permiso requerido.

    Uso en un ViewSet::

        permission_classes = [TienePermiso.para("ventas.crear")]

    o con permisos distintos por acción::

        def get_permissions(self):
            requeridos = {"list": "ventas.ver", "create": "ventas.crear"}
            return [TienePermiso.para(requeridos.get(self.action, "ventas.ver"))]
    """

    codigo_requerido: str | None = None
    message = "No tienes permiso para realizar esta acción."

    @classmethod
    def para(cls, codigo: str):
        return type(f"TienePermiso_{codigo}", (cls,), {"codigo_requerido": codigo})

    def has_permission(self, request, view) -> bool:
        usuario = request.user
        if not (usuario and usuario.is_authenticated):
            return False
        codigo = self.codigo_requerido or getattr(view, "permiso_requerido", None)
        if codigo is None:
            # Fail-closed: si la vista no declara permiso, se niega.
            return False
        return usuario.tiene_permiso(codigo)


class PermisoPorAccion(BasePermission):
    """
    Resuelve el permiso según ``view.permisos_por_accion`` (dict acción→código).

    Fail-closed: si la acción **no** está en el dict se **niega** el acceso. Toda
    acción (incluidas las ``@action`` personalizadas) debe declararse
    explícitamente en el ViewSet.
    """

    message = "No tienes permiso para realizar esta acción."

    def has_permission(self, request, view) -> bool:
        usuario = request.user
        if not (usuario and usuario.is_authenticated):
            return False
        accion = getattr(view, "action", None)
        mapa = getattr(view, "permisos_por_accion", {})
        codigo = mapa.get(accion)
        if codigo is None:
            return False
        return usuario.tiene_permiso(codigo)
