from django.apps import AppConfig


class UsuariosConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.usuarios"
    verbose_name = "Usuarios y seguridad"

    def ready(self):
        from django.contrib import admin

        from . import signals  # noqa: F401  (conecta los receivers)
        from .forms import AdminLoginConBloqueo

        # El login del admin comparte el bloqueo por fuerza bruta con la API.
        admin.site.login_form = AdminLoginConBloqueo
