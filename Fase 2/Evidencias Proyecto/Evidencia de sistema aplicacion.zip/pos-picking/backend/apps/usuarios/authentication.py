"""Autenticación JWT que además completa el contexto de auditoría."""

from __future__ import annotations

from rest_framework_simplejwt.authentication import JWTAuthentication

from apps.core.context import get_contexto


class JWTAuthAuditoria(JWTAuthentication):
    """
    Igual que ``JWTAuthentication`` pero, tras autenticar, escribe el id del
    usuario en el contexto de la petición.

    El ``RequestContextMiddleware`` corre **antes** que la autenticación de DRF,
    así que sin esto los logs de las peticiones a la API quedan sin usuario
    (``user=-``). Aquí se completa en cuanto el token se valida.
    """

    def authenticate(self, request):
        resultado = super().authenticate(request)
        if resultado is not None:
            usuario, _token = resultado
            get_contexto().usuario_id = getattr(usuario, "id", None)
        return resultado


try:  # pragma: no cover - solo afecta a la generación del esquema OpenAPI
    from drf_spectacular.extensions import OpenApiAuthenticationExtension

    class JWTAuthAuditoriaScheme(OpenApiAuthenticationExtension):
        """Hace que drf-spectacular reconozca el Bearer JWT en esta clase."""

        target_class = "apps.usuarios.authentication.JWTAuthAuditoria"
        name = "jwtAuth"

        def get_security_definition(self, auto_schema):
            return {"type": "http", "scheme": "bearer", "bearerFormat": "JWT"}

except ImportError:
    pass
