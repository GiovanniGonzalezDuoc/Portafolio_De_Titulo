"""Modelos de seguridad: Rol, Permiso, Usuario, IntentoLogin."""

from __future__ import annotations

from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin
from django.contrib.auth.validators import UnicodeUsernameValidator
from django.db import models
from django.utils import timezone

from apps.core.models import TimeStampedModel
from apps.core.validators import normalizar_rut, validar_rut

from .managers import UsuarioManager


class Permiso(models.Model):
    """Permiso atómico del sistema, identificado por un código ``modulo.accion``."""

    codigo = models.CharField("código", max_length=60, unique=True)
    modulo = models.CharField("módulo", max_length=30)
    descripcion = models.CharField("descripción", max_length=200, blank=True)

    class Meta:
        verbose_name = "permiso"
        verbose_name_plural = "permisos"
        ordering = ["modulo", "codigo"]

    def __str__(self) -> str:
        return self.codigo


class Rol(TimeStampedModel):
    """Conjunto de permisos. Un usuario tiene exactamente un rol."""

    nombre = models.CharField("nombre", max_length=50, unique=True)
    descripcion = models.CharField("descripción", max_length=200, blank=True)
    activo = models.BooleanField("activo", default=True)
    permisos = models.ManyToManyField(
        Permiso, related_name="roles", blank=True, verbose_name="permisos"
    )

    class Meta:
        verbose_name = "rol"
        verbose_name_plural = "roles"
        ordering = ["nombre"]

    def __str__(self) -> str:
        return self.nombre

    @property
    def codigos_permisos(self) -> set[str]:
        return set(self.permisos.values_list("codigo", flat=True))


class Usuario(AbstractBaseUser, PermissionsMixin, TimeStampedModel):
    """
    Usuario del sistema.

    ``is_active`` / ``is_staff`` / ``is_superuser`` se conservan por contrato de
    Django (backends de autenticación y admin). La autorización de negocio se
    resuelve por ``rol`` + ``Permiso`` (ver ``apps.usuarios.permissions``).
    """

    username = models.CharField(
        "nombre de usuario",
        max_length=150,
        unique=True,
        validators=[UnicodeUsernameValidator()],
        help_text="Letras, dígitos y @/./+/-/_ únicamente.",
    )
    email = models.EmailField("correo", max_length=254, blank=True)
    nombres = models.CharField("nombres", max_length=100)
    apellidos = models.CharField("apellidos", max_length=100)
    rut = models.CharField(
        "RUT", max_length=12, null=True, blank=True, unique=True, validators=[validar_rut]
    )
    rol = models.ForeignKey(
        Rol, on_delete=models.PROTECT, related_name="usuarios", verbose_name="rol"
    )
    is_active = models.BooleanField("activo", default=True)
    is_staff = models.BooleanField("acceso al admin", default=False)

    objects = UsuarioManager()

    USERNAME_FIELD = "username"
    REQUIRED_FIELDS = ["nombres", "apellidos"]

    class Meta:
        verbose_name = "usuario"
        verbose_name_plural = "usuarios"
        ordering = ["apellidos", "nombres"]

    def __str__(self) -> str:
        return f"{self.nombre_completo} ({self.username})"

    def save(self, *args, **kwargs):
        if self.rut:
            self.rut = normalizar_rut(self.rut)
        super().save(*args, **kwargs)

    @property
    def nombre_completo(self) -> str:
        return f"{self.nombres} {self.apellidos}".strip()

    @property
    def activo(self) -> bool:
        return self.is_active

    def tiene_permiso(self, codigo: str) -> bool:
        """True si el usuario puede ejecutar la acción ``codigo``."""
        if not self.is_active:
            return False
        if self.is_superuser:
            return True
        return self.rol.activo and self.rol.permisos.filter(codigo=codigo).exists()

    def permisos_efectivos(self) -> list[str]:
        if self.is_superuser:
            return sorted(Permiso.objects.values_list("codigo", flat=True))
        if not self.rol.activo:
            return []
        return sorted(self.rol.codigos_permisos)


class IntentoLogin(models.Model):
    """Registro de intentos de autenticación (para bloqueo por fuerza bruta)."""

    username = models.CharField("nombre de usuario", max_length=150)
    ip = models.CharField("IP", max_length=45)
    exito = models.BooleanField("exitoso", default=False)
    fecha = models.DateTimeField("fecha", default=timezone.now)

    class Meta:
        verbose_name = "intento de login"
        verbose_name_plural = "intentos de login"
        ordering = ["-fecha"]
        indexes = [
            models.Index(fields=["username", "fecha"]),
            models.Index(fields=["ip", "fecha"]),
        ]

    def __str__(self) -> str:
        estado = "OK" if self.exito else "fallido"
        return f"{self.username} @ {self.ip} — {estado}"
