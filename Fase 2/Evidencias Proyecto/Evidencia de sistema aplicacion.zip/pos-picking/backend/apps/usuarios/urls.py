"""Rutas de la app usuarios."""

from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import (
    CambioPasswordView,
    LoginView,
    LogoutView,
    MeView,
    PermisoViewSet,
    RefreshView,
    RolViewSet,
    UsuarioViewSet,
)

router = DefaultRouter()
router.register("usuarios", UsuarioViewSet, basename="usuario")
router.register("roles", RolViewSet, basename="rol")
router.register("permisos", PermisoViewSet, basename="permiso")

auth_patterns = [
    path("login/", LoginView.as_view(), name="login"),
    path("refresh/", RefreshView.as_view(), name="refresh"),
    path("logout/", LogoutView.as_view(), name="logout"),
    path("me/", MeView.as_view(), name="me"),
    path("cambiar-password/", CambioPasswordView.as_view(), name="cambiar-password"),
]

urlpatterns = [
    path("auth/", include((auth_patterns, "auth"))),
    path("", include(router.urls)),
]
