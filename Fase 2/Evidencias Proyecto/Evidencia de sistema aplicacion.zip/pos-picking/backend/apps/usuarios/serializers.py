"""Serializers de la app usuarios."""

from __future__ import annotations

from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from apps.core.validators import normalizar_rut, validar_rut

from .models import Permiso, Rol

Usuario = get_user_model()


class PermisoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Permiso
        fields = ["id", "codigo", "modulo", "descripcion"]


class RolSerializer(serializers.ModelSerializer):
    permisos = serializers.SlugRelatedField(
        slug_field="codigo", many=True, read_only=True
    )

    class Meta:
        model = Rol
        fields = ["id", "nombre", "descripcion", "activo", "permisos"]


class RolEscrituraSerializer(serializers.ModelSerializer):
    """Alta y edición de un rol (nombre, descripción, estado y permisos)."""

    permisos = serializers.ListField(
        child=serializers.CharField(), required=False, allow_empty=True
    )

    class Meta:
        model = Rol
        fields = ["nombre", "descripcion", "activo", "permisos"]
        extra_kwargs = {
            "descripcion": {"required": False},
            "activo": {"required": False},
        }


class RolPermisosSerializer(serializers.Serializer):
    """Payload para reemplazar el set de permisos de un rol."""

    permisos = serializers.ListField(child=serializers.CharField(), allow_empty=True)


class UsuarioSerializer(serializers.ModelSerializer):
    rol = serializers.SlugRelatedField(slug_field="nombre", read_only=True)
    nombre_completo = serializers.CharField(read_only=True)

    class Meta:
        model = Usuario
        fields = [
            "id", "username", "email", "nombres", "apellidos", "nombre_completo",
            "rut", "rol", "activo", "is_staff", "last_login", "creado_en",
        ]
        read_only_fields = fields


class UsuarioMeSerializer(UsuarioSerializer):
    """Como UsuarioSerializer pero incluye los permisos efectivos."""

    permisos = serializers.SerializerMethodField()

    class Meta(UsuarioSerializer.Meta):
        fields = [*UsuarioSerializer.Meta.fields, "permisos"]
        read_only_fields = fields

    def get_permisos(self, obj) -> list[str]:
        return obj.permisos_efectivos()


class UsuarioCrearSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    rol = serializers.SlugRelatedField(slug_field="nombre", queryset=Rol.objects.all())
    activo = serializers.BooleanField(source="is_active", required=False, default=True)

    class Meta:
        model = Usuario
        fields = [
            "id", "username", "email", "nombres", "apellidos", "rut", "rol",
            "activo", "password",
        ]

    def validate_rut(self, value):
        if not value:
            return value
        validar_rut(value)
        return normalizar_rut(value)

    def validate_password(self, value):
        validate_password(value)
        return value


class UsuarioActualizarSerializer(serializers.ModelSerializer):
    rol = serializers.SlugRelatedField(slug_field="nombre", queryset=Rol.objects.all())

    class Meta:
        model = Usuario
        fields = ["email", "nombres", "apellidos", "rut", "rol", "is_staff"]

    def validate_rut(self, value):
        if not value:
            return value
        validar_rut(value)
        return normalizar_rut(value)


class CambioPasswordSerializer(serializers.Serializer):
    password_actual = serializers.CharField(write_only=True)
    password_nuevo = serializers.CharField(write_only=True)

    def validate_password_nuevo(self, value):
        validate_password(value, user=self.context["request"].user)
        return value


class ResetPasswordSerializer(serializers.Serializer):
    password_nuevo = serializers.CharField(write_only=True)

    def validate_password_nuevo(self, value):
        validate_password(value)
        return value


class LoginSerializer(TokenObtainPairSerializer):
    """Login que además devuelve los datos del usuario y sus permisos."""

    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token["rol"] = user.rol.nombre
        token["nombre"] = user.nombre_completo
        return token

    def validate(self, attrs):
        data = super().validate(attrs)
        data["usuario"] = UsuarioMeSerializer(self.user).data
        return data
