"""Vistas de autenticación y gestión de usuarios/roles."""

from __future__ import annotations

from django.contrib.auth import get_user_model
from drf_spectacular.utils import extend_schema
from rest_framework import mixins, status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

from apps.core.exceptions import ErrorDominio
from apps.core.middleware import _obtener_ip

from . import services
from .models import Permiso, Rol
from .permissions import PermisoPorAccion, TienePermiso
from .serializers import (
    CambioPasswordSerializer,
    LoginSerializer,
    PermisoSerializer,
    ResetPasswordSerializer,
    RolEscrituraSerializer,
    RolPermisosSerializer,
    RolSerializer,
    UsuarioActualizarSerializer,
    UsuarioCrearSerializer,
    UsuarioMeSerializer,
    UsuarioSerializer,
)

Usuario = get_user_model()


class LoginView(TokenObtainPairView):
    """POST usuario/contraseña → access + refresh + datos del usuario."""

    serializer_class = LoginSerializer
    permission_classes = [AllowAny]
    throttle_scope = "login"

    def post(self, request, *args, **kwargs):
        username = str(request.data.get("username", ""))

        if username and services.esta_bloqueado(username):
            raise services.CuentaBloqueada()

        # Un fallo de credenciales lo registra la señal `user_login_failed`
        # (ver apps/usuarios/signals.py), común a la API y al admin.
        respuesta = super().post(request, *args, **kwargs)

        services.registrar_intento(username, _obtener_ip(request) or "", exito=True)
        services.limpiar_intentos(username)
        return respuesta


class RefreshView(TokenRefreshView):
    permission_classes = [AllowAny]
    throttle_scope = "login"


class LogoutView(APIView):
    """POST { refresh } → invalida el refresh token (blacklist)."""

    permission_classes = [IsAuthenticated]

    @extend_schema(request=None, responses={205: None})
    def post(self, request):
        token = request.data.get("refresh")
        if not token:
            raise ErrorDominio("Falta el token de refresco.", codigo="refresh_requerido")
        try:
            RefreshToken(token).blacklist()
        except TokenError as exc:
            raise ErrorDominio("Token inválido o expirado.", codigo="token_invalido") from exc
        return Response(status=status.HTTP_205_RESET_CONTENT)


class MeView(APIView):
    """Datos del usuario autenticado y sus permisos efectivos."""

    permission_classes = [IsAuthenticated]

    @extend_schema(responses=UsuarioMeSerializer)
    def get(self, request):
        return Response(UsuarioMeSerializer(request.user).data)


class CambioPasswordView(APIView):
    """El usuario cambia su propia contraseña."""

    permission_classes = [IsAuthenticated]

    @extend_schema(request=CambioPasswordSerializer, responses={204: None})
    def post(self, request):
        serializer = CambioPasswordSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        services.cambiar_password(
            request.user,
            password_actual=serializer.validated_data["password_actual"],
            password_nuevo=serializer.validated_data["password_nuevo"],
        )
        return Response(status=status.HTTP_204_NO_CONTENT)


class UsuarioViewSet(viewsets.ModelViewSet):
    """CRUD de usuarios. Requiere permisos de administración."""

    queryset = Usuario.objects.select_related("rol").all()
    permission_classes = [PermisoPorAccion]
    filterset_fields = ["rol__nombre", "is_active", "is_staff"]
    search_fields = ["username", "nombres", "apellidos", "email", "rut"]
    ordering_fields = ["apellidos", "username", "creado_en"]

    permisos_por_accion = {
        "list": "usuarios.ver",
        "retrieve": "usuarios.ver",
        "create": "usuarios.administrar",
        "update": "usuarios.administrar",
        "partial_update": "usuarios.administrar",
        "destroy": "usuarios.administrar",
        "activar": "usuarios.administrar",
        "desactivar": "usuarios.administrar",
        "resetear_password": "usuarios.administrar",
    }

    def get_serializer_class(self):
        if self.action == "create":
            return UsuarioCrearSerializer
        if self.action in ("update", "partial_update"):
            return UsuarioActualizarSerializer
        return UsuarioSerializer

    def perform_create(self, serializer):
        datos = dict(serializer.validated_data)
        password = datos.pop("password")
        self._instancia = services.crear_usuario(datos=datos, password=password)

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        salida = UsuarioSerializer(self._instancia)
        return Response(salida.data, status=status.HTTP_201_CREATED)

    def perform_update(self, serializer):
        services.actualizar_usuario(
            serializer.instance, datos=dict(serializer.validated_data)
        )

    def destroy(self, request, *args, **kwargs):
        """No se borra: se desactiva."""
        usuario = self.get_object()
        services.set_estado(usuario, activo=False)
        return Response(status=status.HTTP_204_NO_CONTENT)

    @action(detail=True, methods=["post"])
    def activar(self, request, pk=None):
        usuario = services.set_estado(self.get_object(), activo=True)
        return Response(UsuarioSerializer(usuario).data)

    @action(detail=True, methods=["post"])
    def desactivar(self, request, pk=None):
        usuario = services.set_estado(self.get_object(), activo=False)
        return Response(UsuarioSerializer(usuario).data)

    @extend_schema(request=ResetPasswordSerializer, responses={204: None})
    @action(detail=True, methods=["post"], url_path="resetear-password")
    def resetear_password(self, request, pk=None):
        serializer = ResetPasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        services.resetear_password(
            self.get_object(),
            password_nuevo=serializer.validated_data["password_nuevo"],
            por=request.user,
        )
        return Response(status=status.HTTP_204_NO_CONTENT)


class RolViewSet(viewsets.ModelViewSet):
    """CRUD de roles y edición de sus permisos."""

    queryset = Rol.objects.prefetch_related("permisos").all()
    serializer_class = RolSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        "list": "roles.ver",
        "retrieve": "roles.ver",
        "create": "roles.administrar",
        "update": "roles.administrar",
        "partial_update": "roles.administrar",
        "destroy": "roles.administrar",
        "set_permisos": "roles.administrar",
    }

    def get_serializer_class(self):
        if self.action in ("create", "update", "partial_update"):
            return RolEscrituraSerializer
        return RolSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        datos = dict(serializer.validated_data)
        codigos = datos.pop("permisos", None)
        rol = services.crear_rol(codigos_permisos=codigos, **datos)
        return Response(RolSerializer(rol).data, status=status.HTTP_201_CREATED)

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop("partial", False)
        rol = self.get_object()
        serializer = self.get_serializer(rol, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        datos = dict(serializer.validated_data)
        codigos = datos.pop("permisos", None)
        rol = services.actualizar_rol(rol, datos=datos)
        if codigos is not None:
            rol = services.sincronizar_permisos_rol(rol, codigos)
        return Response(RolSerializer(rol).data)

    def destroy(self, request, *args, **kwargs):
        services.eliminar_rol(self.get_object())
        return Response(status=status.HTTP_204_NO_CONTENT)

    @extend_schema(request=RolPermisosSerializer, responses=RolSerializer)
    @action(detail=True, methods=["put"], url_path="permisos")
    def set_permisos(self, request, pk=None):
        serializer = RolPermisosSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        rol = services.sincronizar_permisos_rol(
            self.get_object(), serializer.validated_data["permisos"]
        )
        return Response(RolSerializer(rol).data)


class PermisoViewSet(mixins.ListModelMixin, viewsets.GenericViewSet):
    """Catálogo de permisos del sistema (solo lectura)."""

    queryset = Permiso.objects.all()
    serializer_class = PermisoSerializer
    permission_classes = [TienePermiso.para("roles.ver")]
    pagination_class = None
    filterset_fields = ["modulo"]
