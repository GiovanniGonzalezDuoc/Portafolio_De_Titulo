"""Admin de Django para usuarios y roles (uso interno / soporte)."""

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from .models import IntentoLogin, Permiso, Rol, Usuario


@admin.register(Permiso)
class PermisoAdmin(admin.ModelAdmin):
    list_display = ["codigo", "modulo", "descripcion"]
    list_filter = ["modulo"]
    search_fields = ["codigo", "descripcion"]


@admin.register(Rol)
class RolAdmin(admin.ModelAdmin):
    list_display = ["nombre", "descripcion", "activo"]
    list_filter = ["activo"]
    filter_horizontal = ["permisos"]


@admin.register(Usuario)
class UsuarioAdmin(BaseUserAdmin):
    ordering = ["apellidos", "nombres"]
    list_display = ["username", "nombre_completo", "rol", "is_active", "is_staff"]
    list_filter = ["rol", "is_active", "is_staff"]
    search_fields = ["username", "nombres", "apellidos", "email", "rut"]
    fieldsets = (
        (None, {"fields": ("username", "password")}),
        ("Datos personales", {"fields": ("nombres", "apellidos", "email", "rut")}),
        ("Rol y estado", {"fields": ("rol", "is_active", "is_staff", "is_superuser")}),
        ("Permisos de Django", {"fields": ("groups", "user_permissions"), "classes": ("collapse",)}),
        ("Fechas", {"fields": ("last_login", "creado_en", "actualizado_en")}),
    )
    readonly_fields = ["last_login", "creado_en", "actualizado_en"]
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": ("username", "nombres", "apellidos", "rol", "password1", "password2"),
            },
        ),
    )


@admin.register(IntentoLogin)
class IntentoLoginAdmin(admin.ModelAdmin):
    list_display = ["username", "ip", "exito", "fecha"]
    list_filter = ["exito"]
    search_fields = ["username", "ip"]
    readonly_fields = ["username", "ip", "exito", "fecha"]
