"""
Catálogo de permisos del sistema y matriz rol → permisos.

Los permisos son códigos ``modulo.accion``. Esta es la única fuente de verdad;
la data migration ``0002_datos_iniciales`` los carga en la base y arma la
relación con los roles.
"""

from __future__ import annotations

# ─── Roles base ──────────────────────────────────────────────
ROL_ADMINISTRADOR = "administrador"
ROL_BODEGUERO = "bodeguero"
ROL_VENDEDOR = "vendedor"
ROL_MAYORISTA = "mayorista"

ROLES = {
    ROL_ADMINISTRADOR: "Administrador del sistema. Acceso total.",
    ROL_BODEGUERO: "Gestión de inventario, compras y abastecimiento.",
    ROL_VENDEDOR: "Operación del punto de venta y caja propia.",
    ROL_MAYORISTA: "Cliente mayorista (reservado para el portal B2B).",
}

# ─── Permisos: codigo -> (modulo, descripción) ───────────────
PERMISOS: dict[str, tuple[str, str]] = {
    "usuarios.ver": ("usuarios", "Ver usuarios"),
    "usuarios.administrar": ("usuarios", "Crear, editar y activar/desactivar usuarios"),
    "roles.ver": ("usuarios", "Ver roles y permisos"),
    "roles.administrar": ("usuarios", "Administrar roles y sus permisos"),
    "catalogo.ver": ("catalogo", "Ver productos, categorías y marcas"),
    "catalogo.administrar": ("catalogo", "Administrar el catálogo y los precios"),
    "ofertas.ver": ("ofertas", "Ver las ofertas vigentes"),
    "ofertas.administrar": ("ofertas", "Crear y administrar ofertas (carga masiva)"),
    "inventario.ver": ("inventario", "Consultar stock y movimientos"),
    "inventario.mover": ("inventario", "Registrar movimientos de inventario"),
    "inventario.ajustar": ("inventario", "Ajustar stock (autorizado)"),
    "inventario_fisico.contar": ("inventario_fisico", "Registrar conteos de inventario físico"),
    "inventario_fisico.autorizar": ("inventario_fisico", "Autorizar la regularización de discrepancias"),
    "proveedores.ver": ("proveedores", "Ver proveedores"),
    "proveedores.administrar": ("proveedores", "Administrar proveedores"),
    "compras.ver": ("compras", "Ver órdenes de compra"),
    "compras.crear": ("compras", "Crear órdenes de compra"),
    "compras.recibir": ("compras", "Recepcionar compras (actualiza stock)"),
    "ventas.crear": ("ventas", "Registrar ventas en el POS"),
    "ventas.ver": ("ventas", "Ver ventas"),
    "ventas.anular": ("ventas", "Anular ventas / devoluciones"),
    "ventas.autorizar_descuento": ("ventas", "Autorizar descuentos sobre el tope"),
    "caja.operar": ("caja", "Abrir/cerrar la caja propia y registrar movimientos"),
    "caja.ver_todas": ("caja", "Ver todas las cajas y arqueos"),
    "boleta.ver": ("boleta", "Ver documentos tributarios"),
    "boleta.reintentar": ("boleta", "Reintentar la emisión de documentos"),
    "boleta.anular": ("boleta", "Anular documentos tributarios"),
    "alertas.ver": ("alertas", "Ver alertas"),
    "alertas.resolver": ("alertas", "Marcar alertas como vistas/resueltas"),
    "alertas.configurar": ("alertas", "Configurar las reglas de alerta"),
    "dashboard.ver": ("dashboard", "Ver el dashboard (vista propia/operacional)"),
    "dashboard.ver_completo": ("dashboard", "Ver el dashboard completo del negocio"),
    "prediccion.ver": ("prediccion", "Ver predicciones de demanda"),
    "prediccion.entrenar": ("prediccion", "Ejecutar el entrenamiento del modelo"),
    "reposicion.ver": ("reposicion", "Ver recomendaciones de reposición"),
    "reposicion.ejecutar": ("reposicion", "Ejecutar el cálculo de reposición"),
    "auditoria.ver": ("auditoria", "Consultar el registro de auditoría"),
}

# ─── Matriz rol → permisos ───────────────────────────────────
_BODEGUERO = {
    "catalogo.ver", "catalogo.administrar",
    "ofertas.ver", "ofertas.administrar",
    "inventario.ver", "inventario.mover", "inventario.ajustar",
    "inventario_fisico.contar",
    "proveedores.ver", "proveedores.administrar",
    "compras.ver", "compras.crear", "compras.recibir",
    "alertas.ver", "alertas.resolver",
    "dashboard.ver",
    "prediccion.ver",
    "reposicion.ver", "reposicion.ejecutar",
}

_VENDEDOR = {
    "catalogo.ver",
    "ofertas.ver",
    "inventario.ver",  # el POS necesita consultar disponibilidad
    "ventas.crear", "ventas.ver",
    "caja.operar",
    "boleta.ver",
    "alertas.ver",
    "dashboard.ver",
}

_MAYORISTA = {
    # Cliente mayorista: solo el catálogo de ofertas vigentes con precio
    # mayorista. No ve el catálogo completo, categorías ni marcas.
    "ofertas.ver",
}

MATRIZ_ROL_PERMISOS: dict[str, set[str]] = {
    ROL_ADMINISTRADOR: set(PERMISOS.keys()),  # todos
    ROL_BODEGUERO: _BODEGUERO,
    ROL_VENDEDOR: _VENDEDOR,
    ROL_MAYORISTA: _MAYORISTA,
}


def sincronizar(apps=None):
    """
    Crea/actualiza permisos y roles y aplica la matriz. Idempotente.
    Usable desde una data migration (``apps`` = registry histórico) o desde
    código normal (``apps`` = None).
    """
    if apps is None:
        from .models import Permiso, Rol
    else:
        Permiso = apps.get_model("usuarios", "Permiso")
        Rol = apps.get_model("usuarios", "Rol")

    for codigo, (modulo, descripcion) in PERMISOS.items():
        Permiso.objects.update_or_create(
            codigo=codigo, defaults={"modulo": modulo, "descripcion": descripcion}
        )
    for nombre, descripcion in ROLES.items():
        rol, _ = Rol.objects.update_or_create(
            nombre=nombre, defaults={"descripcion": descripcion}
        )
        rol.permisos.set(
            Permiso.objects.filter(codigo__in=MATRIZ_ROL_PERMISOS.get(nombre, set()))
        )
