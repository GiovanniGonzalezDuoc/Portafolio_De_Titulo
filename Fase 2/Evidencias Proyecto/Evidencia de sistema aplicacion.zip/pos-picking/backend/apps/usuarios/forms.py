"""Formulario de login del admin con bloqueo por fuerza bruta."""

from __future__ import annotations

from django.contrib.admin.forms import AdminAuthenticationForm
from django.core.exceptions import ValidationError

from . import services


class AdminLoginConBloqueo(AdminAuthenticationForm):
    """Rechaza el login del admin si el usuario está bloqueado (``IntentoLogin``)."""

    def clean(self):
        username = self.cleaned_data.get("username") or self.data.get("username")
        if username and services.esta_bloqueado(str(username)):
            raise ValidationError(
                "Cuenta bloqueada temporalmente por intentos fallidos. Intenta más tarde.",
                code="cuenta_bloqueada",
            )
        return super().clean()
