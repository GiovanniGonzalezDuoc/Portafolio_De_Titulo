"""Manager del modelo Usuario."""

from __future__ import annotations

from django.contrib.auth.models import BaseUserManager


class UsuarioManager(BaseUserManager):
    """Crea usuarios y superusuarios con un rol asociado."""

    use_in_migrations = True

    def _crear(self, username: str, password: str | None, **extra):
        if not username:
            raise ValueError("El nombre de usuario es obligatorio.")
        email = extra.pop("email", "")
        if email:
            email = self.normalize_email(email)
        usuario = self.model(username=username, email=email, **extra)
        usuario.set_password(password)
        usuario.full_clean(exclude=["password"], validate_unique=False)
        usuario.save(using=self._db)
        return usuario

    def create_user(self, username, password=None, **extra):
        extra.setdefault("is_staff", False)
        extra.setdefault("is_superuser", False)
        return self._crear(username, password, **extra)

    def create_superuser(self, username, password=None, **extra):
        extra.setdefault("is_staff", True)
        extra.setdefault("is_superuser", True)
        extra.setdefault("is_active", True)
        if extra.get("is_staff") is not True:
            raise ValueError("El superusuario debe tener is_staff=True.")
        if extra.get("is_superuser") is not True:
            raise ValueError("El superusuario debe tener is_superuser=True.")

        if not extra.get("rol_id") and not extra.get("rol"):
            from .models import Rol
            from .permisos import ROL_ADMINISTRADOR

            rol, _ = Rol.objects.get_or_create(
                nombre=ROL_ADMINISTRADOR,
                defaults={"descripcion": "Administrador del sistema. Acceso total."},
            )
            extra["rol"] = rol

        extra.setdefault("nombres", "Administrador")
        extra.setdefault("apellidos", "del Sistema")
        return self._crear(username, password, **extra)
