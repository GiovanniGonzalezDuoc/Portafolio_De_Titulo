"""Validadores reutilizables."""

from __future__ import annotations

import re

from django.core.exceptions import ValidationError

_RUT_RE = re.compile(r"^\d{7,8}-[\dkK]$")


def normalizar_rut(valor: str) -> str:
    """Deja el RUT como ``12345678-9`` (sin puntos, dígito verificador en mayúscula)."""
    limpio = valor.strip().replace(".", "").replace(" ", "").upper()
    if "-" not in limpio and len(limpio) > 1:
        limpio = f"{limpio[:-1]}-{limpio[-1]}"
    return limpio


def _digito_verificador(cuerpo: str) -> str:
    suma = 0
    multiplicador = 2
    for digito in reversed(cuerpo):
        suma += int(digito) * multiplicador
        multiplicador = 2 if multiplicador == 7 else multiplicador + 1
    resto = 11 - (suma % 11)
    if resto == 11:
        return "0"
    if resto == 10:
        return "K"
    return str(resto)


def validar_rut(valor: str) -> None:
    """Valida un RUT chileno (formato y dígito verificador módulo 11)."""
    rut = normalizar_rut(valor)
    if not _RUT_RE.match(rut):
        raise ValidationError("RUT con formato inválido. Usa 12345678-9.")
    cuerpo, dv = rut.split("-")
    if _digito_verificador(cuerpo) != dv.upper():
        raise ValidationError("El dígito verificador del RUT no es correcto.")
