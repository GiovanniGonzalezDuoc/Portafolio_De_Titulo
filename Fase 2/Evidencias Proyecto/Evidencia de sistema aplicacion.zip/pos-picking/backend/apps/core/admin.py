from django.contrib import admin

from .models import ParametroSistema, Secuencia


@admin.register(ParametroSistema)
class ParametroSistemaAdmin(admin.ModelAdmin):
    list_display = ["__str__", "iva_porcentaje", "redondeo_efectivo", "actualizado_en"]

    def has_add_permission(self, request):
        return not ParametroSistema.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(Secuencia)
class SecuenciaAdmin(admin.ModelAdmin):
    list_display = ["nombre", "valor"]
    readonly_fields = ["nombre", "valor"]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
