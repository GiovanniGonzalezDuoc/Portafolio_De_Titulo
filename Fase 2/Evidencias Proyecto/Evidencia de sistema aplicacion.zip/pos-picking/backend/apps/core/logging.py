"""Filtro de logging que inyecta el contexto de la petición en cada registro."""

import logging

from .context import get_contexto


class RequestContextFilter(logging.Filter):
    """Agrega ``request_id`` y ``usuario_id`` a los registros de log."""

    def filter(self, record: logging.LogRecord) -> bool:
        ctx = get_contexto()
        record.request_id = getattr(record, "request_id", ctx.request_id)
        record.usuario_id = getattr(record, "usuario_id", ctx.usuario_id or "-")
        return True
