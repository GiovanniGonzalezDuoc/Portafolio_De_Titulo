"""
Contexto por petición (id de correlación, usuario, IP).

Se llena en ``RequestContextMiddleware`` y lo consumen el logging y la
auditoría. Usa ``contextvars`` para ser seguro entre hilos.
"""

from __future__ import annotations

import contextvars
from dataclasses import dataclass

_contexto: contextvars.ContextVar[ContextoPeticion | None] = contextvars.ContextVar(
    "contexto_peticion", default=None
)


@dataclass
class ContextoPeticion:
    request_id: str = "-"
    usuario_id: int | None = None
    ip: str | None = None
    user_agent: str | None = None


def set_contexto(ctx: ContextoPeticion) -> None:
    _contexto.set(ctx)


def get_contexto() -> ContextoPeticion:
    return _contexto.get() or ContextoPeticion()


def limpiar_contexto() -> None:
    _contexto.set(None)
