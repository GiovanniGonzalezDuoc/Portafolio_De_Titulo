"""Modelos base reutilizables por el resto de las apps."""

from decimal import Decimal

from django.db import models, transaction


class TimeStampedModel(models.Model):
    """Añade marcas de tiempo de creación y última actualización."""

    creado_en = models.DateTimeField("creado en", auto_now_add=True)
    actualizado_en = models.DateTimeField("actualizado en", auto_now=True)

    class Meta:
        abstract = True


class ModeloActivable(TimeStampedModel):
    """Entidad maestra que se inactiva en lugar de borrarse."""

    activo = models.BooleanField("activo", default=True)

    class Meta:
        abstract = True


class ParametroSistema(models.Model):
    """
    Configuración global del negocio (fila única, ``id=1``).

    Valores como IVA, redondeo y topes de descuento se leen de aquí en runtime.
    """

    emisor_rut = models.CharField("RUT del emisor", max_length=12, blank=True)
    emisor_razon_social = models.CharField("razón social", max_length=150, blank=True)
    emisor_giro = models.CharField("giro", max_length=120, blank=True)
    emisor_direccion = models.CharField("dirección", max_length=200, blank=True)

    iva_porcentaje = models.DecimalField(
        "IVA (%)", max_digits=5, decimal_places=2, default=Decimal("19.00")
    )
    redondeo_efectivo = models.PositiveSmallIntegerField(
        "múltiplo de redondeo en efectivo", default=10
    )
    tope_descuento_vendedor_pct = models.DecimalField(
        "tope de descuento del vendedor (%)", max_digits=5, decimal_places=2,
        default=Decimal("5.00"),
    )
    moneda = models.CharField("moneda", max_length=3, default="CLP")
    dte_proveedor = models.CharField("proveedor DTE", max_length=20, default="mock")

    actualizado_en = models.DateTimeField("actualizado en", auto_now=True)

    class Meta:
        verbose_name = "parámetro del sistema"
        verbose_name_plural = "parámetros del sistema"

    def __str__(self) -> str:
        return "Parámetros del sistema"

    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)

    @classmethod
    def get(cls) -> "ParametroSistema":
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj


class Secuencia(models.Model):
    """
    Contador con bloqueo para generar correlativos de documentos
    (órdenes de compra, recepciones, ventas, cajas, folios DTE, …)
    de forma segura ante concurrencia — sin secuencias de PostgreSQL.
    """

    nombre = models.CharField("nombre", max_length=50, primary_key=True)
    valor = models.PositiveBigIntegerField("valor", default=0)

    class Meta:
        verbose_name = "secuencia"
        verbose_name_plural = "secuencias"

    def __str__(self) -> str:
        return f"{self.nombre}={self.valor}"

    @classmethod
    def siguiente(cls, nombre: str) -> int:
        """Incrementa y devuelve el siguiente valor de la secuencia."""
        with transaction.atomic():
            sec, _ = cls.objects.select_for_update().get_or_create(nombre=nombre)
            sec.valor += 1
            sec.save(update_fields=["valor"])
            return sec.valor

    @classmethod
    def folio(cls, nombre: str, prefijo: str, ancho: int = 6) -> str:
        """Devuelve un correlativo con formato, p. ej. ``OC-000042``."""
        return f"{prefijo}-{cls.siguiente(nombre):0{ancho}d}"
