"""
Excel (.xlsx): reportes para leer y plantillas para llenar y volver a subir.

``excel_response``: reporte con título, "generado el …", filtros, tabla y pie
(período + total). ``plantilla_excel``: solo encabezado + datos desde la fila
1, para que la carga masiva (productos, stock) sea directa de importar.
``leer_filas_excel`` hace el camino inverso al subir un archivo.
"""

from __future__ import annotations

from datetime import date, datetime
from io import BytesIO
from typing import Iterable, Sequence

from django.http import HttpResponse
from django.utils import timezone
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

_AZUL = "1F5C4D"  # verde-azulado de la marca para el encabezado
_GRIS = "EDF3F1"


def _texto_periodo(desde: date | None, hasta: date | None) -> str:
    fmt = "%d/%m/%Y"
    if desde and hasta:
        return f"del {desde:{fmt}} al {hasta:{fmt}}"
    if desde:
        return f"desde el {desde:{fmt}}"
    if hasta:
        return f"hasta el {hasta:{fmt}}"
    return "todos los registros (sin filtro de fechas)"


def excel_response(
    *,
    nombre_archivo: str,
    titulo: str,
    encabezados: Sequence[str],
    filas: Iterable[Sequence[object]],
    generado_por: str = "",
    filtros: str = "",
    desde: date | None = None,
    hasta: date | None = None,
    anchos: Sequence[int] | None = None,
) -> HttpResponse:
    wb = Workbook()
    ws = wb.active
    ws.title = "Reporte"

    n_col = len(encabezados)
    ultima_col = get_column_letter(n_col)

    negrita = Font(bold=True)
    titulo_font = Font(bold=True, size=14)
    blanco_negrita = Font(bold=True, color="FFFFFF")
    relleno_enc = PatternFill("solid", fgColor=_AZUL)
    borde = Border(bottom=Side(style="thin", color="BBBBBB"))

    # ── Cabecera del documento ──────────────────────────────
    ws.merge_cells(f"A1:{ultima_col}1")
    ws["A1"] = titulo
    ws["A1"].font = titulo_font

    generado = timezone.localtime().strftime("%d/%m/%Y %H:%M")
    ws.merge_cells(f"A2:{ultima_col}2")
    ws["A2"] = f"Generado el {generado}" + (f" por {generado_por}" if generado_por else "")
    ws["A2"].font = Font(color="666666")

    fila_actual = 3
    if filtros:
        ws.merge_cells(f"A{fila_actual}:{ultima_col}{fila_actual}")
        ws[f"A{fila_actual}"] = f"Filtros: {filtros}"
        ws[f"A{fila_actual}"].font = Font(color="666666")
        fila_actual += 1

    fila_actual += 1  # línea en blanco

    # ── Encabezado de la tabla ──────────────────────────────
    fila_enc = fila_actual
    for i, texto in enumerate(encabezados, start=1):
        c = ws.cell(row=fila_enc, column=i, value=texto)
        c.font = blanco_negrita
        c.fill = relleno_enc
        c.alignment = Alignment(vertical="center")
    ws.freeze_panes = ws.cell(row=fila_enc + 1, column=1)

    # ── Datos ───────────────────────────────────────────────
    fila = fila_enc + 1
    total = 0
    for registro in filas:
        for i, valor in enumerate(registro, start=1):
            c = ws.cell(row=fila, column=i, value=valor)
            c.border = borde
            if isinstance(valor, (int, float)):
                c.alignment = Alignment(horizontal="right")
            if isinstance(valor, datetime):
                c.number_format = "DD/MM/YYYY HH:MM"
        fila += 1
        total += 1

    # AutoFiltro sobre el encabezado + los datos.
    ws.auto_filter.ref = f"A{fila_enc}:{ultima_col}{max(fila - 1, fila_enc)}"

    # ── Pie: período y total ────────────────────────────────
    fila += 1
    ws.cell(row=fila, column=1, value=f"Período contemplado: {_texto_periodo(desde, hasta)}").font = negrita
    ws.cell(row=fila + 1, column=1, value=f"Total de filas: {total}").font = negrita

    # ── Anchos de columna ───────────────────────────────────
    for i in range(1, n_col + 1):
        ancho = anchos[i - 1] if anchos and i - 1 < len(anchos) else 18
        ws.column_dimensions[get_column_letter(i)].width = ancho

    buffer = BytesIO()
    wb.save(buffer)

    resp = HttpResponse(
        buffer.getvalue(),
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    resp["Content-Disposition"] = f'attachment; filename="{nombre_archivo}"'
    return resp


def plantilla_excel(
    *,
    nombre_archivo: str,
    encabezados: Sequence[str],
    filas: Iterable[Sequence[object]] = (),
    anchos: Sequence[int] | None = None,
    instrucciones: Sequence[str] | None = None,
    listas_desplegables: dict[str, Sequence[str]] | None = None,
    filas_desplegable: int = 500,
) -> HttpResponse:
    """
    Plantilla lista para llenar y volver a subir: fila 1 = encabezados, los
    datos empiezan en la fila 2, sin título ni pie (para que importarla sea
    directo). ``instrucciones`` agrega una segunda hoja con notas de ayuda.

    ``listas_desplegables``: ``{encabezado: [opciones válidas]}`` — esa
    columna queda con un desplegable de Excel (clic y elegir) en vez de
    tener que escribir el valor exacto a mano. Las opciones viven en una
    hoja aparte ("Listas", oculta) para admitir listas largas o con comas.
    """
    wb = Workbook()
    ws = wb.active
    ws.title = "Datos"

    n_col = len(encabezados)
    blanco_negrita = Font(bold=True, color="FFFFFF")
    relleno_enc = PatternFill("solid", fgColor=_AZUL)
    borde = Border(bottom=Side(style="thin", color="BBBBBB"))

    for i, texto in enumerate(encabezados, start=1):
        c = ws.cell(row=1, column=i, value=texto)
        c.font = blanco_negrita
        c.fill = relleno_enc
    ws.freeze_panes = "A2"

    fila = 2
    for registro in filas:
        for i, valor in enumerate(registro, start=1):
            c = ws.cell(row=fila, column=i, value=valor)
            c.border = borde
            if isinstance(valor, (int, float)):
                c.alignment = Alignment(horizontal="right")
        fila += 1

    ws.auto_filter.ref = f"A1:{get_column_letter(n_col)}{max(fila - 1, 1)}"
    for i in range(1, n_col + 1):
        ancho = anchos[i - 1] if anchos and i - 1 < len(anchos) else 18
        ws.column_dimensions[get_column_letter(i)].width = ancho

    if listas_desplegables:
        hoja_listas = wb.create_sheet("Listas")
        hoja_listas.sheet_state = "hidden"
        ultima_fila_datos = max(fila - 1, 2, filas_desplegable)
        for col_lista, (encabezado, opciones) in enumerate(listas_desplegables.items(), start=1):
            opciones = [str(o) for o in opciones if str(o).strip()]
            if not opciones or encabezado not in encabezados:
                continue
            letra_lista = get_column_letter(col_lista)
            for i, opcion in enumerate(opciones, start=1):
                hoja_listas.cell(row=i, column=col_lista, value=opcion)
            columna_datos = get_column_letter(encabezados.index(encabezado) + 1)
            dv = DataValidation(
                type="list",
                formula1=f"Listas!${letra_lista}$1:${letra_lista}${len(opciones)}",
                allow_blank=True,
                showDropDown=False,  # falso = SÍ muestra la flechita (así es la API de openpyxl)
                errorStyle="warning",
                errorTitle="Valor fuera de la lista",
                error="Ese valor no está en las opciones sugeridas. Puedes igual dejarlo si estás seguro.",
            )
            dv.add(f"{columna_datos}2:{columna_datos}{ultima_fila_datos}")
            ws.add_data_validation(dv)

    if instrucciones:
        hoja = wb.create_sheet("Instrucciones")
        hoja.column_dimensions["A"].width = 100
        for i, texto in enumerate(instrucciones, start=1):
            c = hoja.cell(row=i, column=1, value=texto)
            c.alignment = Alignment(wrap_text=True, vertical="top")
            if i == 1:
                c.font = Font(bold=True, size=13)

    buffer = BytesIO()
    wb.save(buffer)

    resp = HttpResponse(
        buffer.getvalue(),
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    resp["Content-Disposition"] = f'attachment; filename="{nombre_archivo}"'
    return resp


def leer_filas_excel(archivo) -> list[tuple[int, dict[str, object]]]:
    """
    Lee un .xlsx subido para carga masiva: usa la hoja "Datos" si existe (si
    no, la activa), la fila 1 como encabezados (normalizados a snake_case) y
    devuelve ``(número de fila real en Excel, {encabezado: valor})`` por cada
    fila con al menos un dato.
    """
    from openpyxl import load_workbook

    wb = load_workbook(archivo, data_only=True, read_only=True)
    hoja = wb["Datos"] if "Datos" in wb.sheetnames else wb.active
    filas = hoja.iter_rows(values_only=True)
    try:
        encabezados_crudos = next(filas)
    except StopIteration:
        return []
    claves = [
        (str(h).strip().lower().replace(" ", "_") if h is not None else f"col_{i}")
        for i, h in enumerate(encabezados_crudos)
    ]
    resultado = []
    for n, fila in enumerate(filas, start=2):
        if fila is None or all(v is None or str(v).strip() == "" for v in fila):
            continue
        resultado.append((n, dict(zip(claves, fila, strict=False))))
    return resultado
