"""
Prepara datos para las pruebas de carga (``loadtest/``).

Crea usuarios vendedor dedicados (cada uno con su caja abierta) y un catálogo
grande con stock muy alto, para que las pruebas de carga no agoten inventario
salvo en el escenario que busca esa condición a propósito.

Idempotente. **No usar en producción.**

    python manage.py seed_carga --usuarios 30 --productos 500 --stock 1000000
"""

from __future__ import annotations

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.db import transaction

from apps.usuarios.models import Rol

Usuario = get_user_model()

PASSWORD = "carga-pass-12345"  # noqa: S105  (solo entornos de prueba)
CATEGORIA = "Carga"
MARCA = "Carga"


class Command(BaseCommand):
    help = "Crea usuarios/catálogo/stock para las pruebas de carga."

    def add_arguments(self, parser):
        parser.add_argument("--usuarios", type=int, default=30)
        parser.add_argument("--bodegueros", type=int, default=3)
        parser.add_argument("--productos", type=int, default=500)
        parser.add_argument("--stock", type=int, default=1_000_000)

    @transaction.atomic
    def handle(self, *args, **opts):
        from apps.caja import services as caja
        from apps.caja.models import EstadoCaja
        from apps.catalogo.models import Categoria, Marca, Producto
        from apps.inventario import services as inventario

        n_users, n_bod, n_prod, stock = (
            opts["usuarios"], opts["bodegueros"], opts["productos"], opts["stock"]
        )

        rol_vendedor, _ = Rol.objects.get_or_create(nombre="vendedor")
        rol_bodeguero, _ = Rol.objects.get_or_create(nombre="bodeguero")
        admin = Usuario.objects.filter(is_superuser=True).first() or Usuario.objects.filter(
            rol__nombre="administrador"
        ).first()
        if admin is None:
            self.stderr.write("Necesitas al menos un admin/superuser. Corre `cargar_demo` primero.")
            return

        # ── Usuarios de carga + caja abierta ──────────────────
        for i in range(1, n_users + 1):
            username = f"carga{i:02d}"
            u, creado = Usuario.objects.get_or_create(
                username=username,
                defaults={
                    "nombres": "Carga",
                    "apellidos": f"Tester {i:02d}",
                    "rol": rol_vendedor,
                    "is_active": True,
                },
            )
            if creado:
                u.set_password(PASSWORD)
                u.save(update_fields=["password"])
            if not u.cajas.filter(estado=EstadoCaja.ABIERTA).exists():
                caja.abrir_caja(usuario=u, monto_inicial=10_000)

        # ── Bodegueros de carga (para el escenario de ajuste de stock) ──
        for i in range(1, n_bod + 1):
            username = f"cargabod{i:02d}"
            u, creado = Usuario.objects.get_or_create(
                username=username,
                defaults={
                    "nombres": "Carga",
                    "apellidos": f"Bodega {i:02d}",
                    "rol": rol_bodeguero,
                    "is_active": True,
                },
            )
            if creado:
                u.set_password(PASSWORD)
                u.save(update_fields=["password"])

        # ── Catálogo con stock alto ───────────────────────────
        categoria, _ = Categoria.objects.get_or_create(nombre=CATEGORIA, defaults={"activo": True})
        marca, _ = Marca.objects.get_or_create(nombre=MARCA, defaults={"activo": True})

        nuevos = 0
        for i in range(1, n_prod + 1):
            sku = f"CARGA-{i:04d}"
            codigo = f"9990000{i:06d}"
            prod, creado = Producto.objects.get_or_create(
                sku=sku,
                defaults={
                    "codigo_barras": codigo,
                    "nombre": f"Producto de carga {i:04d}",
                    "categoria": categoria,
                    "marca": marca,
                    "precio_venta": 1000 + (i % 50) * 10,
                    "costo_referencial": 600,
                    "activo": True,
                },
            )
            if creado:
                nuevos += 1
            actual = inventario.stock_de(prod)
            if actual < stock:
                inventario.entrada(
                    producto=prod, cantidad=stock - actual, usuario=admin, motivo="seed_carga"
                )

        self.stdout.write(
            self.style.SUCCESS(
                f"Carga lista: {n_users} vendedores + {n_bod} bodegueros "
                f"(prefijos 'carga'/'cargabod', pass '{PASSWORD}'), "
                f"{n_prod} productos ({nuevos} nuevos), stock ~{stock} c/u. "
                f"Foco del test de concurrencia: CARGA-0001."
            )
        )
