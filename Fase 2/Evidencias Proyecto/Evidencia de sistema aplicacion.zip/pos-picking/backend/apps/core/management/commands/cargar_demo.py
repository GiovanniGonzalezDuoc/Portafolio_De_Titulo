"""
Carga datos de demostración para explorar el sistema.

Idempotente: se puede ejecutar varias veces. NO usar en producción.

    python manage.py cargar_demo
"""

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.db import transaction

from apps.usuarios.models import Rol

Usuario = get_user_model()

PASSWORD_DEMO = "demo12345"

USUARIOS_DEMO = [
    ("admin_demo", "administrador", "Ana", "Admin"),
    ("bodega_demo", "bodeguero", "Bruno", "Bodega"),
    ("vende_demo", "vendedor", "Vera", "Ventas"),
    ("mayor_demo", "mayorista", "Marta", "Mayor"),
]

CATEGORIAS = ["Bebidas", "Abarrotes", "Aseo", "Herramientas", "Mascotas"]
MARCAS = ["Genérica", "Andina", "CCU", "Bosch", "Sopraval"]

PRODUCTOS = [
    # sku, codigo_barras, nombre, categoria, marca, precio_venta, precio_mayorista, costo
    ("BEB-001", "7801234500017", "Agua mineral 500 ml", "Bebidas", "Andina", 790, 650, 420),
    ("BEB-002", "7801234500024", "Bebida cola 1.5 L", "Bebidas", "CCU", 1690, 1490, 990),
    ("ABA-001", "7801234500031", "Arroz grado 1, 1 kg", "Abarrotes", "Genérica", 1290, 1150, 850),
    ("ABA-002", "7801234500048", "Aceite vegetal 900 ml", "Abarrotes", "Genérica", 2490, 2200, 1700),
    ("ABA-003", "7801234500055", "Fideos spaghetti 400 g", "Abarrotes", "Genérica", 990, 850, 600),
    ("ASE-001", "7801234500062", "Detergente polvo 1 kg", "Aseo", "Genérica", 3490, 3100, 2400),
    ("ASE-002", "7801234500079", "Cloro gel 900 ml", "Aseo", "Genérica", 1190, 990, 700),
    ("HER-001", "7801234500086", "Taladro percutor 650 W", "Herramientas", "Bosch", 34990, 31990, 24000),
    ("HER-002", "7801234500093", "Set destornilladores 6 pzas", "Herramientas", "Bosch", 8990, 7990, 5500),
    ("MAS-001", "7801234500109", "Alimento perro adulto 3 kg", "Mascotas", "Sopraval", 9990, 8990, 6800),
]


class Command(BaseCommand):
    help = "Carga datos de demostración (usuarios, catálogo)."

    def add_arguments(self, parser):
        parser.add_argument(
            "--limpiar",
            action="store_true",
            help="Elimina lo que crea esta carga (lo que se pueda: los productos "
            "con ventas quedan y los usuarios demo se desactivan).",
        )

    @transaction.atomic
    def handle(self, *args, **options):
        from apps.catalogo.models import Categoria, Marca, Producto

        if options.get("limpiar"):
            self._limpiar()
            return

        # Usuarios
        for username, rol_nombre, nombres, apellidos in USUARIOS_DEMO:
            rol = Rol.objects.get(nombre=rol_nombre)
            usuario, creado = Usuario.objects.get_or_create(
                username=username,
                defaults={"nombres": nombres, "apellidos": apellidos, "rol": rol,
                          "email": f"{username}@demo.cl"},
            )
            if creado:
                usuario.set_password(PASSWORD_DEMO)
                usuario.save()

        # Catálogo
        categorias = {n: Categoria.objects.get_or_create(nombre=n)[0] for n in CATEGORIAS}
        marcas = {n: Marca.objects.get_or_create(nombre=n)[0] for n in MARCAS}

        from apps.inventario import services as inv_services
        from apps.inventario.models import ParametroInventario, Ubicacion

        ubicacion = Ubicacion.principal()
        admin_demo = Usuario.objects.get(username="admin_demo")

        for i, (sku, cb, nombre, cat, marca, pv, pm, costo) in enumerate(PRODUCTOS):
            producto, _ = Producto.objects.get_or_create(
                sku=sku,
                defaults={
                    "codigo_barras": cb,
                    "nombre": nombre,
                    "categoria": categorias[cat],
                    "marca": marcas[marca],
                    "precio_venta": pv,
                    "precio_mayorista": pm,
                    "costo_referencial": costo,
                },
            )
            ParametroInventario.objects.get_or_create(
                producto=producto,
                ubicacion=ubicacion,
                defaults={"stock_minimo": 8, "punto_reposicion": 20, "stock_seguridad": 5},
            )
            if inv_services.stock_de(producto, ubicacion) == 0:
                inicial = max(1, 28 - i * 3)  # los últimos productos quedan bajo el mínimo
                inv_services.entrada(
                    producto=producto, cantidad=inicial, usuario=admin_demo,
                    ubicacion=ubicacion, motivo="carga inicial demo",
                )

        # Proveedores + una orden de compra ya recibida
        from apps.compras import services as compras_services
        from apps.compras.models import OrdenCompra
        from apps.proveedores.models import ProductoProveedor, Proveedor

        proveedor, _ = Proveedor.objects.get_or_create(
            rut="76192083-9",
            defaults={
                "razon_social": "Distribuidora Central Ltda.",
                "giro": "Distribución de abarrotes",
                "contacto_nombre": "Carla Núñez",
                "contacto_email": "ventas@distcentral.cl",
                "lead_time_dias": 5,
            },
        )
        # El proveedor demo surte todo el catálogo (para que la reposición
        # tenga cobertura completa).
        for prod in Producto.objects.all():
            ProductoProveedor.objects.get_or_create(
                proveedor=proveedor,
                producto=prod,
                defaults={"costo": prod.costo_referencial, "es_preferente": True},
            )
        productos_abarrotes = list(Producto.objects.filter(categoria__nombre="Abarrotes"))

        if not OrdenCompra.objects.exists() and productos_abarrotes:
            orden = compras_services.crear_orden(
                proveedor=proveedor,
                lineas=[
                    {"producto": p, "cantidad": 24, "costo_unitario": p.costo_referencial or 500}
                    for p in productos_abarrotes
                ],
                usuario=admin_demo,
                observacion="Reposición demo",
            )
            compras_services.emitir_orden(orden, admin_demo)
            compras_services.recibir(
                orden=orden,
                lineas=[{"linea_orden": ln, "cantidad": ln.cantidad} for ln in orden.lineas.all()],
                usuario=admin_demo,
                documento_proveedor="F-1001",
            )

        # Un par de ventas de ejemplo (requieren caja abierta)
        from apps.caja.services import abrir_caja, caja_abierta_de
        from apps.ventas import services as ventas_services
        from apps.ventas.models import Venta

        vendedor_demo = Usuario.objects.get(username="vende_demo")
        if caja_abierta_de(vendedor_demo) is None:
            abrir_caja(usuario=vendedor_demo, monto_inicial=50000)

        if not Venta.objects.exists():
            bebida = Producto.objects.filter(sku="BEB-002").first()
            arroz = Producto.objects.filter(sku="ABA-001").first()
            if bebida and arroz:
                ventas_services.confirmar_venta(
                    items=[
                        {"producto": bebida, "cantidad": 2, "descuento_monto": 0},
                        {"producto": arroz, "cantidad": 1, "descuento_monto": 0},
                    ],
                    pagos=[{"medio": "EFECTIVO", "monto": bebida.precio_venta * 2 + arroz.precio_venta}],
                    vendedor=vendedor_demo,
                )
                ventas_services.confirmar_venta(
                    items=[{"producto": bebida, "cantidad": 1, "descuento_monto": 0}],
                    pagos=[{"medio": "DEBITO", "monto": bebida.precio_venta}],
                    vendedor=vendedor_demo,
                )

        # Motor de alertas: genera alertas de reposición/stock a partir del estado actual
        from apps.alertas.motor import escanear_inventario

        escanear_inventario()

        # Predicción de demanda + recomendaciones de reposición
        try:
            from apps.prediccion import services as pred_services
            from apps.reposicion import services as repo_services

            pred_services.entrenar_y_sincronizar()
            repo_services.generar_recomendaciones()
        except Exception as exc:  # noqa: BLE001 — la demo no debe fallar por el ML
            self.stdout.write(self.style.WARNING(f"ML omitido: {exc}"))

        self.stdout.write(self.style.SUCCESS("Datos de demostración cargados."))
        self.stdout.write(
            f"  Usuarios: {', '.join(u[0] for u in USUARIOS_DEMO)}  (contraseña: {PASSWORD_DEMO})"
        )
        self.stdout.write(
            f"  Catálogo: {len(CATEGORIAS)} categorías, {len(MARCAS)} marcas, "
            f"{len(PRODUCTOS)} productos con stock y parámetros."
        )
        self.stdout.write("  Para revertir: python manage.py cargar_demo --limpiar")

    def _limpiar(self):
        """Deshace la carga demo hasta donde la integridad lo permite."""
        from apps.catalogo.models import Categoria, Marca, Producto
        from apps.proveedores.models import Proveedor

        skus = [p[0] for p in PRODUCTOS]
        borrados, con_historial = 0, []
        for producto in Producto.objects.filter(sku__in=skus):
            if producto.lineas_venta.exists() or producto.lineas_orden_compra.exists():
                con_historial.append(producto.sku)
                continue
            # Solo tiene los movimientos/stock de la carga demo: se limpia todo.
            producto.movimientos.all().delete()
            producto.stocks.all().delete()
            producto.parametros_inventario.all().delete()
            producto.proveedor_info.all().delete()
            producto.ofertas.all().delete()
            producto.predicciones.all().delete()
            producto.recomendaciones_reposicion.all().delete()
            producto.delete()
            borrados += 1

        proveedor = Proveedor.objects.filter(rut="76192083-9").first()
        if proveedor and not proveedor.ordenes_compra.exists():
            proveedor.producto_info.all().delete()
            proveedor.delete()

        for modelo, nombres in ((Categoria, CATEGORIAS), (Marca, MARCAS)):
            for obj in modelo.objects.filter(nombre__in=nombres):
                if not obj.productos.exists():
                    obj.delete()

        demo = Usuario.objects.filter(email__endswith="@demo.cl")
        desactivados = demo.filter(is_active=True).count()
        demo.update(is_active=False)

        self.stdout.write(self.style.SUCCESS("Carga demo revertida."))
        self.stdout.write(f"  Productos eliminados: {borrados}")
        if con_historial:
            self.stdout.write(
                f"  Con ventas/compras (quedan; anúlalas primero si quieres borrarlos): "
                f"{', '.join(con_historial)}"
            )
        self.stdout.write(f"  Usuarios demo desactivados: {desactivados}")
        self.stdout.write("  Compras: 1 proveedor + 1 orden de compra recibida.")
        self.stdout.write("  Ventas: 2 ventas de ejemplo (vende_demo).")
