"""
Excepciones de dominio y manejador de errores unificado de la API.

Todas las respuestas de error tienen la forma::

    {
      "error": {
        "codigo": "stock_insuficiente",
        "mensaje": "Texto legible",
        "detalles": { ... } | null,
        "campo": "nombre_campo" | null
      }
    }
"""

from __future__ import annotations

import logging

from django.core.exceptions import PermissionDenied as DjangoPermissionDenied
from django.http import Http404
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import exception_handler as drf_exception_handler

logger = logging.getLogger("pos.core")


class ErrorDominio(Exception):
    """Error de regla de negocio. Se traduce a HTTP 4xx con un ``codigo`` estable."""

    codigo = "error_dominio"
    mensaje = "No se pudo completar la operación."
    http_status = status.HTTP_400_BAD_REQUEST

    def __init__(self, mensaje: str | None = None, *, codigo: str | None = None, detalles: dict | None = None):
        super().__init__(mensaje or self.mensaje)
        self.mensaje = mensaje or self.mensaje
        self.codigo = codigo or self.codigo
        self.detalles = detalles


class RecursoNoEncontrado(ErrorDominio):
    codigo = "no_encontrado"
    mensaje = "El recurso solicitado no existe."
    http_status = status.HTTP_404_NOT_FOUND


class OperacionNoPermitida(ErrorDominio):
    codigo = "operacion_no_permitida"
    mensaje = "No tienes permiso para realizar esta operación."
    http_status = status.HTTP_403_FORBIDDEN


class ConflictoEstado(ErrorDominio):
    codigo = "conflicto_estado"
    mensaje = "La operación no es válida para el estado actual."
    http_status = status.HTTP_409_CONFLICT


def _cuerpo(codigo: str, mensaje: str, detalles=None, campo=None) -> dict:
    return {"error": {"codigo": codigo, "mensaje": mensaje, "detalles": detalles, "campo": campo}}


def exception_handler_personalizado(exc, context):
    """Manejador de excepciones para DRF."""
    if isinstance(exc, ErrorDominio):
        return Response(_cuerpo(exc.codigo, exc.mensaje, exc.detalles), status=exc.http_status)

    if isinstance(exc, Http404):
        return Response(_cuerpo("no_encontrado", "El recurso solicitado no existe."), status=404)

    if isinstance(exc, DjangoPermissionDenied):
        return Response(_cuerpo("permiso_denegado", "No tienes permiso para esta acción."), status=403)

    respuesta = drf_exception_handler(exc, context)
    if respuesta is None:
        logger.exception("Error no controlado en %s", context.get("view"))
        return Response(
            _cuerpo("error_interno", "Ocurrió un error interno. Intenta nuevamente."),
            status=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )

    detalle = respuesta.data
    codigo = "solicitud_invalida"
    campo = None
    mensaje = "La solicitud no es válida."

    if isinstance(detalle, dict):
        if "detail" in detalle:
            mensaje = str(detalle["detail"])
            codigo = getattr(detalle["detail"], "code", codigo) or codigo
        else:
            campo = next(iter(detalle.keys()), None)
            primer_valor = detalle[campo] if campo else None
            if isinstance(primer_valor, list | tuple) and primer_valor:
                mensaje = str(primer_valor[0])
            elif primer_valor is not None:
                mensaje = str(primer_valor)
            codigo = "validacion"

    respuesta.data = _cuerpo(codigo, mensaje, detalles=detalle if isinstance(detalle, dict) else None, campo=campo)
    return respuesta
