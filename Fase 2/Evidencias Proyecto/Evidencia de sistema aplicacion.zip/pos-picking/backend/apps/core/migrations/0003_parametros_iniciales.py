"""Crea la fila única de ParametroSistema con valores por defecto (Chile)."""

from django.db import migrations


def crear(apps, schema_editor):
    ParametroSistema = apps.get_model("core", "ParametroSistema")
    ParametroSistema.objects.update_or_create(
        pk=1,
        defaults={
            "emisor_rut": "",
            "emisor_razon_social": "Liquidadora Los Europeos",
            "emisor_giro": "Venta al por menor",
            "iva_porcentaje": "19.00",
            "redondeo_efectivo": 10,
            "tope_descuento_vendedor_pct": "5.00",
            "moneda": "CLP",
            "dte_proveedor": "mock",
        },
    )


def revertir(apps, schema_editor):
    apps.get_model("core", "ParametroSistema").objects.filter(pk=1).delete()


class Migration(migrations.Migration):
    dependencies = [("core", "0002_parametrosistema")]
    operations = [migrations.RunPython(crear, revertir)]
