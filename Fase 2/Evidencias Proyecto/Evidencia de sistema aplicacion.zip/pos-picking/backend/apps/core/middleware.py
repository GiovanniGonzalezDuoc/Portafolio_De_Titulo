"""Middleware de contexto de petición: id de correlación + datos de auditoría."""

from __future__ import annotations

import re
import uuid

from .context import ContextoPeticion, limpiar_contexto, set_contexto

CABECERA_REQUEST_ID = "HTTP_X_REQUEST_ID"

# El id de correlación entrante se acepta solo si tiene forma inocua (evita
# inyección de saltos de línea u otros caracteres en los logs).
_REQUEST_ID_OK = re.compile(r"^[A-Za-z0-9._-]{1,64}$")


def _obtener_ip(request) -> str | None:
    """
    IP del cliente. Detrás de un proxy (LiteSpeed en cPanel) la real es la
    **última** entrada de ``X-Forwarded-For`` (la que añade el proxy de
    confianza); las anteriores las puede falsear el cliente.
    """
    adelantado = request.META.get("HTTP_X_FORWARDED_FOR")
    if adelantado:
        return adelantado.split(",")[-1].strip()
    return request.META.get("REMOTE_ADDR")


def _limpiar(texto: str) -> str:
    return texto.replace("\n", " ").replace("\r", " ")


class RequestContextMiddleware:
    """Asigna un ``request_id`` a cada petición y guarda el contexto."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        entrante = request.META.get(CABECERA_REQUEST_ID, "")
        request_id = entrante if _REQUEST_ID_OK.match(entrante) else uuid.uuid4().hex
        request.request_id = request_id

        # `request.user` aún no está autenticado por JWT aquí; el id real lo
        # completa `JWTAuthAuditoria` (apps/usuarios/authentication.py).
        set_contexto(
            ContextoPeticion(
                request_id=request_id,
                usuario_id=None,
                ip=_obtener_ip(request),
                user_agent=_limpiar(request.META.get("HTTP_USER_AGENT", ""))[:255],
            )
        )
        try:
            response = self.get_response(request)
        finally:
            limpiar_contexto()

        response["X-Request-ID"] = request_id
        return response
