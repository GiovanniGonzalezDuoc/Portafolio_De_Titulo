"""Tests del comando de datos de demostración."""

import pytest
from django.core.management import call_command

from apps.catalogo.models import Producto
from apps.usuarios.models import Usuario

pytestmark = pytest.mark.django_db


def test_cargar_demo_y_limpiar(datos_seguridad, settings):
    settings.PREDICCION_PERMITIR_SINTETICO = True

    call_command("cargar_demo")
    assert Producto.objects.filter(sku="BEB-001").exists()
    assert Usuario.objects.filter(username="admin_demo", is_active=True).exists()
    stock_inicial = Producto.objects.get(sku="HER-001")
    assert stock_inicial.movimientos.exists()

    # Sin ventas ni compras sobre esos productos → --limpiar los borra.
    call_command("cargar_demo", "--limpiar")

    # Los productos de abarrotes entran en la OC demo, así que quedan;
    # el resto se borra. Los usuarios demo quedan desactivados.
    assert not Producto.objects.filter(sku="BEB-001").exists()
    assert not Usuario.objects.filter(username="admin_demo", is_active=True).exists()
    assert Usuario.objects.filter(username="admin_demo", is_active=False).exists()


def test_cargar_demo_es_idempotente(datos_seguridad, settings):
    settings.PREDICCION_PERMITIR_SINTETICO = True
    call_command("cargar_demo")
    n = Producto.objects.count()
    call_command("cargar_demo")
    assert Producto.objects.count() == n
