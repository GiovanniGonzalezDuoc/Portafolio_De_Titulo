"""Tests de la app core."""

from django.test import Client


def test_healthcheck_responde_ok():
    respuesta = Client().get("/api/v1/health/")
    assert respuesta.status_code == 200
    assert respuesta.json() == {"estado": "ok", "servicio": "pos-picking-api"}


def test_healthcheck_incluye_request_id():
    respuesta = Client().get("/api/v1/health/")
    assert "X-Request-ID" in respuesta.headers


def test_schema_openapi_se_genera_sin_errores():
    """El esquema OpenAPI debe construirse (detecta serializers/vistas rotos)."""
    from drf_spectacular.generators import SchemaGenerator

    esquema = SchemaGenerator().get_schema(request=None, public=True)
    assert esquema["openapi"].startswith("3.")
    assert "/api/v1/ventas/" in esquema["paths"]


def test_schema_no_se_expone_sin_debug():
    """Con DEBUG=False (producción) la documentación no está publicada."""
    assert Client().get("/api/v1/schema/").status_code == 404
    assert Client().get("/api/v1/docs/").status_code == 404
