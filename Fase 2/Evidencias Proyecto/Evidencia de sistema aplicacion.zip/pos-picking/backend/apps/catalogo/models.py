"""Modelos del catálogo: categorías, marcas y productos."""

from __future__ import annotations

from django.core.validators import MinLengthValidator
from django.db import models

from apps.core.models import ModeloActivable


def _normalizar_codigo(valor: str | None) -> str | None:
    """Deja el código en mayúsculas, sin espacios; cadena vacía → None."""
    if valor is None:
        return None
    limpio = valor.strip().upper().replace(" ", "")
    return limpio or None


class UnidadMedida(models.TextChoices):
    UNIDAD = "UN", "Unidad"
    KILOGRAMO = "KG", "Kilogramo"
    LITRO = "LT", "Litro"
    METRO = "MT", "Metro"
    CAJA = "CJ", "Caja"


class Categoria(ModeloActivable):
    nombre = models.CharField("nombre", max_length=80, unique=True)
    descripcion = models.CharField("descripción", max_length=200, blank=True)

    class Meta:
        verbose_name = "categoría"
        verbose_name_plural = "categorías"
        ordering = ["nombre"]

    def __str__(self) -> str:
        return self.nombre


class Marca(ModeloActivable):
    nombre = models.CharField("nombre", max_length=80, unique=True)
    descripcion = models.CharField("descripción", max_length=200, blank=True)

    class Meta:
        verbose_name = "marca"
        verbose_name_plural = "marcas"
        ordering = ["nombre"]

    def __str__(self) -> str:
        return self.nombre


class ProductoQuerySet(models.QuerySet):
    def activos(self):
        return self.filter(activo=True)

    def buscar(self, texto: str):
        texto = (texto or "").strip()
        if not texto:
            return self
        return self.filter(
            models.Q(nombre__icontains=texto)
            | models.Q(sku__icontains=texto)
            | models.Q(codigo_barras__icontains=texto)
        )


class Producto(ModeloActivable):
    """
    Producto vendible. Los precios están en CLP (enteros) con **IVA incluido**;
    la boleta desglosa neto + IVA. ``costo_referencial`` es el último costo
    conocido (lo actualiza la recepción de compras — Etapa 7).
    """

    sku = models.CharField("SKU", max_length=40, unique=True)
    codigo_barras = models.CharField(
        "código de barras", max_length=64, null=True, blank=True, unique=True
    )
    nombre = models.CharField("nombre", max_length=150, validators=[MinLengthValidator(2)])
    descripcion = models.TextField("descripción", blank=True)

    categoria = models.ForeignKey(
        Categoria, on_delete=models.PROTECT, related_name="productos", verbose_name="categoría"
    )
    marca = models.ForeignKey(
        Marca,
        on_delete=models.PROTECT,
        related_name="productos",
        verbose_name="marca",
        null=True,
        blank=True,
    )

    unidad_medida = models.CharField(
        "unidad de medida", max_length=2, choices=UnidadMedida.choices, default=UnidadMedida.UNIDAD
    )
    precio_venta = models.PositiveIntegerField("precio de venta (CLP, IVA incl.)", default=0)
    precio_mayorista = models.PositiveIntegerField(
        "precio mayorista (CLP, IVA incl.)", null=True, blank=True
    )
    costo_referencial = models.PositiveIntegerField("costo referencial (CLP)", default=0)
    afecto_iva = models.BooleanField("afecto a IVA", default=True)

    # Fecha de vencimiento del producto (una por producto; opcional). Se usa
    # para detectar candidatos a oferta antes de que caduquen.
    fecha_vencimiento = models.DateField(
        "fecha de vencimiento", null=True, blank=True
    )

    # Se sube aparte (POST .../imagen/), no en el alta/edición normal del
    # producto — así el formulario sigue siendo JSON puro.
    imagen = models.ImageField("imagen", upload_to="productos/", null=True, blank=True)

    objects = ProductoQuerySet.as_manager()

    class Meta:
        verbose_name = "producto"
        verbose_name_plural = "productos"
        ordering = ["nombre"]
        indexes = [
            models.Index(fields=["nombre"]),
            models.Index(fields=["categoria", "activo"]),
            models.Index(fields=["marca", "activo"]),
        ]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(precio_venta__gte=0), name="producto_precio_venta_no_negativo"
            ),
            models.CheckConstraint(
                condition=models.Q(costo_referencial__gte=0),
                name="producto_costo_no_negativo",
            ),
            models.CheckConstraint(
                condition=models.Q(precio_mayorista__isnull=True)
                | models.Q(precio_mayorista__gte=0),
                name="producto_precio_mayorista_no_negativo",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.sku} — {self.nombre}"

    def clean(self):
        self.sku = (self.sku or "").strip().upper()
        self.codigo_barras = _normalizar_codigo(self.codigo_barras)

    def save(self, *args, **kwargs):
        self.sku = (self.sku or "").strip().upper()
        self.codigo_barras = _normalizar_codigo(self.codigo_barras)
        super().save(*args, **kwargs)

    def precio_para(self, *, mayorista: bool) -> int:
        if mayorista and self.precio_mayorista is not None:
            return self.precio_mayorista
        return self.precio_venta
