"""Admin del catálogo."""

from django.contrib import admin

from .models import Categoria, Marca, Producto


@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ["nombre", "activo", "creado_en"]
    list_filter = ["activo"]
    search_fields = ["nombre"]


@admin.register(Marca)
class MarcaAdmin(admin.ModelAdmin):
    list_display = ["nombre", "activo", "creado_en"]
    list_filter = ["activo"]
    search_fields = ["nombre"]


@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = ["sku", "nombre", "categoria", "marca", "precio_venta", "activo"]
    list_filter = ["activo", "categoria", "marca", "unidad_medida", "afecto_iva"]
    search_fields = ["sku", "nombre", "codigo_barras"]
    autocomplete_fields = []
    list_select_related = ["categoria", "marca"]
