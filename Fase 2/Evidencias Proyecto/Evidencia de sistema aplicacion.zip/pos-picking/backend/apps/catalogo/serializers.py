"""Serializers del catálogo."""

from __future__ import annotations

from django.db.models import Sum
from rest_framework import serializers

from .models import Categoria, Marca, Producto


class CategoriaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Categoria
        fields = ["id", "nombre", "descripcion", "activo", "creado_en", "actualizado_en"]
        read_only_fields = ["creado_en", "actualizado_en"]


class MarcaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Marca
        fields = ["id", "nombre", "descripcion", "activo", "creado_en", "actualizado_en"]
        read_only_fields = ["creado_en", "actualizado_en"]


class ProductoSerializer(serializers.ModelSerializer):
    """Salida de lectura: expande categoría y marca a su nombre."""

    categoria = serializers.SlugRelatedField(slug_field="nombre", read_only=True)
    marca = serializers.SlugRelatedField(slug_field="nombre", read_only=True)
    unidad_medida_display = serializers.CharField(
        source="get_unidad_medida_display", read_only=True
    )
    # Precio que realmente se cobra (una oferta vigente manda sobre el normal).
    precio_efectivo = serializers.SerializerMethodField()
    precio_efectivo_mayorista = serializers.SerializerMethodField()
    en_oferta = serializers.SerializerMethodField()
    oferta = serializers.SerializerMethodField()
    stock_total = serializers.SerializerMethodField()

    class Meta:
        model = Producto
        fields = [
            "id", "sku", "codigo_barras", "nombre", "descripcion",
            "categoria", "marca", "unidad_medida", "unidad_medida_display",
            "precio_venta", "precio_mayorista", "costo_referencial", "afecto_iva",
            "precio_efectivo", "precio_efectivo_mayorista", "en_oferta", "oferta",
            "stock_total", "fecha_vencimiento", "imagen", "activo", "creado_en", "actualizado_en",
        ]
        read_only_fields = fields

    def get_stock_total(self, obj) -> float:
        total = getattr(obj, "stock_total_ann", None)
        if total is None:
            total = obj.stocks.aggregate(t=Sum("cantidad"))["t"] or 0
        return round(float(total), 3)

    def _oferta(self, obj):
        from apps.ofertas.services import oferta_vigente

        if not hasattr(obj, "_oferta_cache"):
            obj._oferta_cache = oferta_vigente(obj)
        return obj._oferta_cache

    def get_precio_efectivo(self, obj) -> int:
        o = self._oferta(obj)
        return o.precio_oferta if o else obj.precio_venta

    def get_precio_efectivo_mayorista(self, obj):
        o = self._oferta(obj)
        if o:
            return o.precio_oferta_mayorista if o.precio_oferta_mayorista is not None else o.precio_oferta
        return obj.precio_mayorista

    def get_en_oferta(self, obj) -> bool:
        return self._oferta(obj) is not None

    def get_oferta(self, obj):
        o = self._oferta(obj)
        if not o:
            return None
        return {
            "precio_oferta": o.precio_oferta,
            "precio_oferta_mayorista": o.precio_oferta_mayorista,
            "descripcion": o.descripcion,
            "termina_en": o.termina_en,
        }


TAMANO_MAXIMO_IMAGEN = 5 * 1024 * 1024  # 5 MB


class ImagenProductoSerializer(serializers.Serializer):
    """Entrada del endpoint dedicado a subir/reemplazar la foto del producto."""

    imagen = serializers.ImageField()

    def validate_imagen(self, value):
        if value.size > TAMANO_MAXIMO_IMAGEN:
            raise serializers.ValidationError("La imagen no puede pesar más de 5 MB.")
        return value


class ProductoEscrituraSerializer(serializers.ModelSerializer):
    categoria = serializers.SlugRelatedField(
        slug_field="nombre", queryset=Categoria.objects.all()
    )
    marca = serializers.SlugRelatedField(
        slug_field="nombre", queryset=Marca.objects.all(), required=False, allow_null=True
    )
    # Al crear: stock inicial. Al editar: cantidad a la que dejar el stock.
    # La vista lo saca de validated_data y ajusta el inventario aparte.
    stock = serializers.IntegerField(write_only=True, required=False, min_value=0)

    class Meta:
        model = Producto
        fields = [
            "id", "sku", "codigo_barras", "nombre", "descripcion",
            "categoria", "marca", "unidad_medida",
            "precio_venta", "precio_mayorista", "costo_referencial", "afecto_iva",
            "fecha_vencimiento", "activo", "stock",
        ]

    def validate_sku(self, value):
        value = (value or "").strip().upper()
        if not value:
            raise serializers.ValidationError("El SKU es obligatorio.")
        qs = Producto.objects.filter(sku=value)
        if self.instance:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise serializers.ValidationError("Ya existe un producto con ese SKU.")
        return value

    def validate_codigo_barras(self, value):
        if not value:
            return None
        value = value.strip().upper().replace(" ", "")
        qs = Producto.objects.filter(codigo_barras=value)
        if self.instance:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise serializers.ValidationError("Ya existe un producto con ese código de barras.")
        return value

    def validate(self, attrs):
        categoria = attrs.get("categoria") or getattr(self.instance, "categoria", None)
        if categoria is not None and not categoria.activo:
            raise serializers.ValidationError(
                {"categoria": "La categoría está inactiva."}
            )
        marca = attrs.get("marca", getattr(self.instance, "marca", None))
        if marca is not None and not marca.activo:
            raise serializers.ValidationError({"marca": "La marca está inactiva."})
        return attrs
