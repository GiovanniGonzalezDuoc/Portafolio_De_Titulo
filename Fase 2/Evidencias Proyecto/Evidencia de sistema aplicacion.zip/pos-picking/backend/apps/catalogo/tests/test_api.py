"""Tests de la API del catálogo."""

import pytest

from apps.catalogo.models import Categoria, Producto

from .factories import CategoriaFactory, MarcaFactory, ProductoFactory

pytestmark = pytest.mark.django_db


# ─── Autorización ────────────────────────────────────────────
def test_vendedor_puede_ver_pero_no_crear_productos(api_vendedor):
    CategoriaFactory(nombre="Herramientas")
    assert api_vendedor.get("/api/v1/catalogo/productos/").status_code == 200
    r = api_vendedor.post(
        "/api/v1/catalogo/productos/",
        {"sku": "X", "nombre": "Y", "categoria": "Herramientas", "precio_venta": 1},
        format="json",
    )
    assert r.status_code == 403


def test_bodeguero_puede_administrar_catalogo(api_bodeguero):
    CategoriaFactory(nombre="Aseo")
    r = api_bodeguero.post(
        "/api/v1/catalogo/productos/",
        {"sku": "ase-1", "nombre": "Cloro", "categoria": "Aseo", "precio_venta": 990},
        format="json",
    )
    assert r.status_code == 201, r.data
    assert r.data["sku"] == "ASE-1"


def test_anonimo_no_accede(api):
    assert api.get("/api/v1/catalogo/productos/").status_code == 401


def test_crear_producto_con_stock_inicial(api_bodeguero):
    CategoriaFactory(nombre="Aseo")
    r = api_bodeguero.post(
        "/api/v1/catalogo/productos/",
        {"sku": "ase-2", "nombre": "Cloro", "categoria": "Aseo", "precio_venta": 990, "stock": 30},
        format="json",
    )
    assert r.status_code == 201, r.data
    assert r.data["stock_total"] == 30
    p = Producto.objects.get(sku="ASE-2")
    assert p.movimientos.count() == 1


def test_editar_producto_ajusta_stock(api_bodeguero):
    p = ProductoFactory()
    r = api_bodeguero.patch(
        f"/api/v1/catalogo/productos/{p.id}/",
        {"stock": 8},
        format="json",
    )
    assert r.status_code == 200, r.data
    assert r.data["stock_total"] == 8


# ─── CRUD y validaciones ────────────────────────────────────
def test_crear_producto_con_categoria_inactiva_falla(api_bodeguero):
    CategoriaFactory(nombre="Vieja", activo=False)
    r = api_bodeguero.post(
        "/api/v1/catalogo/productos/",
        {"sku": "v1", "nombre": "Producto viejo", "categoria": "Vieja", "precio_venta": 100},
        format="json",
    )
    assert r.status_code == 400
    assert r.data["error"]["campo"] == "categoria"


def test_sku_duplicado_devuelve_error_de_validacion(api_bodeguero):
    CategoriaFactory(nombre="C")
    ProductoFactory(sku="REP01")
    r = api_bodeguero.post(
        "/api/v1/catalogo/productos/",
        {"sku": "rep01", "nombre": "Otro", "categoria": "C", "precio_venta": 100},
        format="json",
    )
    assert r.status_code == 400
    assert r.data["error"]["campo"] == "sku"


def test_nombre_muy_corto_es_rechazado(api_bodeguero):
    CategoriaFactory(nombre="C")
    r = api_bodeguero.post(
        "/api/v1/catalogo/productos/",
        {"sku": "n1", "nombre": "X", "categoria": "C", "precio_venta": 100},
        format="json",
    )
    assert r.status_code == 400
    assert r.data["error"]["campo"] == "nombre"


def test_delete_producto_sin_referencias_lo_borra(api_bodeguero):
    p = ProductoFactory()
    r = api_bodeguero.delete(f"/api/v1/catalogo/productos/{p.id}/")
    assert r.status_code == 204
    assert not Producto.objects.filter(id=p.id).exists()


def test_delete_producto_con_stock_responde_409(api_bodeguero):
    from apps.inventario.models import Stock, Ubicacion

    p = ProductoFactory()
    ubic = Ubicacion.objects.create(nombre="Bodega central")
    Stock.objects.create(producto=p, ubicacion=ubic, cantidad=7)
    r = api_bodeguero.delete(f"/api/v1/catalogo/productos/{p.id}/")
    assert r.status_code == 409
    assert r.json()["error"]["codigo"] == "producto_referenciado"
    assert Producto.objects.filter(id=p.id).exists()


def _png_diminuto(bytes_extra: int = 0) -> bytes:
    """PNG 1×1 válido para Pillow; con `bytes_extra` de relleno al final
    (no rompe la decodificación, solo infla el tamaño del archivo)."""
    import io

    from PIL import Image

    buf = io.BytesIO()
    Image.new("RGB", (1, 1), color="red").save(buf, format="PNG")
    return buf.getvalue() + b"\0" * bytes_extra


def test_subir_imagen_de_producto(api_bodeguero, settings, tmp_path):
    settings.MEDIA_ROOT = tmp_path
    p = ProductoFactory()
    from django.core.files.uploadedfile import SimpleUploadedFile

    archivo = SimpleUploadedFile("foto.png", _png_diminuto(), content_type="image/png")
    r = api_bodeguero.post(
        f"/api/v1/catalogo/productos/{p.id}/imagen/", {"imagen": archivo}, format="multipart"
    )
    assert r.status_code == 200, r.data
    assert r.data["imagen"] is not None and "productos/" in r.data["imagen"]

    r = api_bodeguero.delete(f"/api/v1/catalogo/productos/{p.id}/imagen/")
    assert r.status_code == 200
    assert r.data["imagen"] is None


def test_imagen_muy_pesada_se_rechaza(api_bodeguero, settings, tmp_path):
    settings.MEDIA_ROOT = tmp_path
    p = ProductoFactory()
    from django.core.files.uploadedfile import SimpleUploadedFile

    archivo = SimpleUploadedFile(
        "foto.png", _png_diminuto(bytes_extra=6 * 1024 * 1024), content_type="image/png"
    )
    r = api_bodeguero.post(
        f"/api/v1/catalogo/productos/{p.id}/imagen/", {"imagen": archivo}, format="multipart"
    )
    assert r.status_code == 400


def test_vendedor_no_puede_subir_imagen(api_vendedor, settings, tmp_path):
    settings.MEDIA_ROOT = tmp_path
    p = ProductoFactory()
    from django.core.files.uploadedfile import SimpleUploadedFile

    archivo = SimpleUploadedFile("foto.png", _png_diminuto(), content_type="image/png")
    r = api_vendedor.post(
        f"/api/v1/catalogo/productos/{p.id}/imagen/", {"imagen": archivo}, format="multipart"
    )
    assert r.status_code == 403


def test_desactivar_producto(api_bodeguero):
    p = ProductoFactory()
    r = api_bodeguero.post(f"/api/v1/catalogo/productos/{p.id}/desactivar/")
    assert r.status_code == 200
    p.refresh_from_db()
    assert p.activo is False
    assert Producto.objects.filter(id=p.id).exists()


def test_activar_producto(api_bodeguero):
    p = ProductoFactory(activo=False)
    r = api_bodeguero.post(f"/api/v1/catalogo/productos/{p.id}/activar/")
    assert r.status_code == 200
    p.refresh_from_db()
    assert p.activo is True


def test_delete_categoria_la_desactiva(api_bodeguero):
    c = CategoriaFactory()
    r = api_bodeguero.delete(f"/api/v1/catalogo/categorias/{c.id}/")
    assert r.status_code == 204
    c.refresh_from_db()
    assert c.activo is False


# ─── Búsqueda / filtros ─────────────────────────────────────
def test_busqueda_por_texto(api_admin):
    ProductoFactory(nombre="Destornillador Phillips", sku="DES01")
    ProductoFactory(nombre="Alicate universal", sku="ALI01")
    r = api_admin.get("/api/v1/catalogo/productos/?search=phillips")
    assert r.data["conteo"] == 1


def test_filtro_por_categoria_y_precio(api_admin):
    herr = CategoriaFactory(nombre="Herr")
    aseo = CategoriaFactory(nombre="Aseo")
    ProductoFactory(categoria=herr, precio_venta=5000)
    ProductoFactory(categoria=herr, precio_venta=15000)
    ProductoFactory(categoria=aseo, precio_venta=1000)
    r = api_admin.get("/api/v1/catalogo/productos/?categoria=Herr&precio_max=10000")
    assert r.data["conteo"] == 1


def test_filtro_por_marca(api_admin):
    from .factories import MarcaFactory

    coca = MarcaFactory(nombre="Coca-Cola")
    otra = MarcaFactory(nombre="Watts")
    ProductoFactory(marca=coca)
    ProductoFactory(marca=coca)
    ProductoFactory(marca=otra)
    r = api_admin.get("/api/v1/catalogo/productos/?marca=coca-cola")
    assert r.data["conteo"] == 2


def test_paginacion(api_admin):
    ProductoFactory.create_batch(30)
    r = api_admin.get("/api/v1/catalogo/productos/?page_size=10")
    assert len(r.data["resultados"]) == 10
    assert r.data["conteo"] == 30
    assert r.data["paginas"] == 3


# ─── Endpoints del POS ──────────────────────────────────────
def test_por_codigo_devuelve_producto(api_vendedor):
    ProductoFactory(codigo_barras="7801234567890", nombre="Bebida")
    r = api_vendedor.get("/api/v1/catalogo/productos/por-codigo/7801234567890/")
    assert r.status_code == 200
    assert r.data["nombre"] == "Bebida"


def test_por_codigo_inexistente_da_404(api_vendedor):
    r = api_vendedor.get("/api/v1/catalogo/productos/por-codigo/000000/")
    assert r.status_code == 404
    assert r.data["error"]["codigo"] == "producto_no_encontrado"


def test_por_codigo_producto_inactivo_da_409(api_vendedor):
    ProductoFactory(codigo_barras="7809999999999", activo=False)
    r = api_vendedor.get("/api/v1/catalogo/productos/por-codigo/7809999999999/")
    assert r.status_code == 409
    assert r.data["error"]["codigo"] == "producto_inactivo"


# ─── Fecha de vencimiento / candidatos a oferta ─────────────
def test_crear_producto_con_fecha_vencimiento(api_bodeguero):
    CategoriaFactory(nombre="Lacteos")
    r = api_bodeguero.post(
        "/api/v1/catalogo/productos/",
        {
            "sku": "lac-1", "nombre": "Leche", "categoria": "Lacteos",
            "precio_venta": 990, "fecha_vencimiento": "2027-01-15",
        },
        format="json",
    )
    assert r.status_code == 201, r.data
    assert r.data["fecha_vencimiento"] == "2027-01-15"


def test_por_vencer_lista_ordenada(api_bodeguero):
    from datetime import timedelta

    from django.utils import timezone

    hoy = timezone.localdate()
    ProductoFactory(sku="VEN-1", fecha_vencimiento=hoy + timedelta(days=5))
    ProductoFactory(sku="VEN-2", fecha_vencimiento=hoy - timedelta(days=2))   # vencido
    ProductoFactory(sku="VEN-3", fecha_vencimiento=hoy + timedelta(days=90))  # fuera de rango
    ProductoFactory(sku="VEN-4")                                              # sin fecha

    r = api_bodeguero.get("/api/v1/catalogo/productos/por-vencer/?dias=15")
    assert r.status_code == 200
    assert [f["sku"] for f in r.data] == ["VEN-2", "VEN-1"]
    assert r.data[0]["vencido"] is True
    assert r.data[1]["dias_para_vencer"] == 5

    r100 = api_bodeguero.get("/api/v1/catalogo/productos/por-vencer/?dias=100")
    assert {f["sku"] for f in r100.data} == {"VEN-1", "VEN-2", "VEN-3"}


# ─── Carga masiva por Excel ──────────────────────────────────
def _excel_productos(filas: list[list]) -> "SimpleUploadedFile":  # noqa: F821
    import io

    from django.core.files.uploadedfile import SimpleUploadedFile
    from openpyxl import Workbook

    from apps.catalogo.services import CAMPOS_PLANTILLA_PRODUCTOS

    wb = Workbook()
    ws = wb.active
    ws.append(CAMPOS_PLANTILLA_PRODUCTOS)
    for fila in filas:
        ws.append(fila)
    buf = io.BytesIO()
    wb.save(buf)
    return SimpleUploadedFile(
        "productos.xlsx", buf.getvalue(),
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


def test_descargar_plantilla_de_carga_masiva(api_bodeguero):
    r = api_bodeguero.get("/api/v1/catalogo/productos/plantilla-carga-masiva/")
    assert r.status_code == 200
    assert r["Content-Type"] == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def test_plantilla_trae_desplegables_para_categoria_marca_y_unidad(api_bodeguero):
    import io

    from openpyxl import load_workbook

    CategoriaFactory(nombre="Abarrotes QA")
    MarcaFactory(nombre="Marca QA")

    r = api_bodeguero.get("/api/v1/catalogo/productos/plantilla-carga-masiva/")
    wb = load_workbook(io.BytesIO(r.content))
    assert "Listas" in wb.sheetnames
    assert wb["Listas"].sheet_state == "hidden"

    ws = wb["Datos"]
    columnas_con_desplegable = {
        next(iter(dv.sqref.ranges)).min_col for dv in ws.data_validations.dataValidation
    }
    # categoria=col 5, marca=col 6, unidad_medida=col 7, afecto_iva=col 11
    assert columnas_con_desplegable == {5, 6, 7, 11}

    valores_listas = {
        cell.value for row in wb["Listas"].iter_rows() for cell in row if cell.value
    }
    assert "Abarrotes QA" in valores_listas
    assert "Marca QA" in valores_listas
    assert "UN" in valores_listas
    assert "SI" in valores_listas


def test_carga_masiva_crea_productos_validos_y_reporta_los_malos(api_bodeguero):
    CategoriaFactory(nombre="Abarrotes")
    ProductoFactory(sku="CM-002")  # para forzar un SKU duplicado en la carga
    archivo = _excel_productos(
        [
            # sku, codigo_barras, nombre, descripcion, categoria, marca, unidad_medida,
            # precio_venta, precio_mayorista, costo_referencial, afecto_iva, fecha_vencimiento, stock
            ["CM-001", None, "Fideos", None, "Abarrotes", None, "UN", 990, None, 600, "SI", None, 20],
            ["CM-002", None, "SKU repetido", None, "Abarrotes", None, None, 500, None, None, None, None, None],
            [None, None, None, None, None, None, None, None, None, None, None, None, None],  # fila en blanco
        ]
    )
    r = api_bodeguero.post(
        "/api/v1/catalogo/productos/carga-masiva/", {"archivo": archivo}, format="multipart"
    )
    assert r.status_code == 200, r.data
    assert r.data["creados"] == 1
    assert r.data["total_filas"] == 2  # la fila en blanco no cuenta
    assert len(r.data["con_error"]) == 1
    assert r.data["con_error"][0]["sku"] == "CM-002"

    creado = Producto.objects.get(sku="CM-001")
    assert creado.precio_venta == 990
    assert creado.stocks.first().cantidad == 20


def test_carga_masiva_crea_categoria_nueva_si_no_existe(api_bodeguero):
    """Antes esto era un error de fila ("NoExiste" no era una categoría
    válida) — ahora la categoría se crea sola."""
    archivo = _excel_productos(
        [["CM-010", None, "Snack nuevo", None, "Snacks", None, None, 500, None, None, None, None, None]]
    )
    r = api_bodeguero.post(
        "/api/v1/catalogo/productos/carga-masiva/", {"archivo": archivo}, format="multipart"
    )
    assert r.status_code == 200, r.data
    assert r.data["creados"] == 1
    assert r.data["con_error"] == []

    categoria = Categoria.objects.get(nombre="Snacks")
    assert Producto.objects.get(sku="CM-010").categoria_id == categoria.id


def test_carga_masiva_reutiliza_categoria_parecida_sin_duplicar(api_bodeguero):
    existente = CategoriaFactory(nombre="Abarrotes")
    archivo = _excel_productos(
        [
            # variantes de mayúsculas/espacios/singular que NO deberían crear categorías nuevas
            ["CM-020", None, "Producto A", None, "abarrotes", None, None, 500, None, None, None, None, None],
            ["CM-021", None, "Producto B", None, " Abarrotes ", None, None, 500, None, None, None, None, None],
            ["CM-022", None, "Producto C", None, "Abarrote", None, None, 500, None, None, None, None, None],
        ]
    )
    r = api_bodeguero.post(
        "/api/v1/catalogo/productos/carga-masiva/", {"archivo": archivo}, format="multipart"
    )
    assert r.status_code == 200, r.data
    assert r.data["creados"] == 3
    assert r.data["con_error"] == []

    assert Categoria.objects.filter(nombre__iexact="abarrotes").count() == 1
    for sku in ("CM-020", "CM-021", "CM-022"):
        assert Producto.objects.get(sku=sku).categoria_id == existente.id


def test_carga_masiva_no_reutiliza_categoria_muy_distinta(api_bodeguero):
    """Dos nombres realmente distintos no deben fusionarse aunque compartan
    algunas letras — solo variantes de escritura del mismo nombre."""
    CategoriaFactory(nombre="Bebidas")
    archivo = _excel_productos(
        [["CM-030", None, "Bebida fría", None, "Bebidas frías", None, None, 500, None, None, None, None, None]]
    )
    r = api_bodeguero.post(
        "/api/v1/catalogo/productos/carga-masiva/", {"archivo": archivo}, format="multipart"
    )
    assert r.status_code == 200, r.data
    assert r.data["creados"] == 1
    assert Categoria.objects.filter(nombre="Bebidas frías").exists()
    assert Categoria.objects.count() == 2


def test_carga_masiva_requiere_permiso(api_vendedor):
    archivo = _excel_productos([["X-1", None, "Y", None, "Z", None, None, 100, None, None, None, None, None]])
    r = api_vendedor.post(
        "/api/v1/catalogo/productos/carga-masiva/", {"archivo": archivo}, format="multipart"
    )
    assert r.status_code == 403


def test_carga_masiva_sin_archivo_da_400(api_bodeguero):
    r = api_bodeguero.post("/api/v1/catalogo/productos/carga-masiva/", {}, format="multipart")
    assert r.status_code == 400
