"""Factories del catálogo."""

import factory

from apps.catalogo.models import Categoria, Marca, Producto


class CategoriaFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Categoria
        django_get_or_create = ("nombre",)

    nombre = factory.Sequence(lambda n: f"Categoría {n}")
    activo = True


class MarcaFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Marca
        django_get_or_create = ("nombre",)

    nombre = factory.Sequence(lambda n: f"Marca {n}")
    activo = True


class ProductoFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Producto

    sku = factory.Sequence(lambda n: f"SKU{n:05d}")
    codigo_barras = factory.Sequence(lambda n: f"78000000{n:05d}")
    nombre = factory.Sequence(lambda n: f"Producto {n}")
    categoria = factory.SubFactory(CategoriaFactory)
    marca = factory.SubFactory(MarcaFactory)
    precio_venta = 1000
    costo_referencial = 600
    activo = True
