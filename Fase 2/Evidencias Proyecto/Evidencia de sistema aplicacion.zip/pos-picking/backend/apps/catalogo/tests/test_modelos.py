"""Tests de los modelos del catálogo."""

import pytest
from django.db import IntegrityError

from apps.catalogo.models import Producto

from .factories import CategoriaFactory, ProductoFactory

pytestmark = pytest.mark.django_db


def test_sku_y_codigo_barras_se_normalizan_al_guardar():
    cat = CategoriaFactory()
    p = Producto.objects.create(
        sku=" abc-123 ", codigo_barras=" 78 00 111 ", nombre="Cosa", categoria=cat,
        precio_venta=500,
    )
    assert p.sku == "ABC-123"
    assert p.codigo_barras == "7800111"


def test_codigo_barras_vacio_se_guarda_como_null():
    cat = CategoriaFactory()
    p = Producto.objects.create(sku="X1", codigo_barras="", nombre="Sin código", categoria=cat)
    assert p.codigo_barras is None


def test_dos_productos_sin_codigo_de_barras_conviven():
    cat = CategoriaFactory()
    Producto.objects.create(sku="A1", codigo_barras="", nombre="A", categoria=cat)
    Producto.objects.create(sku="A2", codigo_barras=None, nombre="B", categoria=cat)
    assert Producto.objects.filter(codigo_barras__isnull=True).count() == 2


def test_sku_duplicado_falla():
    cat = CategoriaFactory()
    Producto.objects.create(sku="DUP", nombre="A", categoria=cat)
    with pytest.raises(IntegrityError):
        Producto.objects.create(sku="DUP", nombre="B", categoria=cat)


def test_precio_para_mayorista():
    p = ProductoFactory(precio_venta=1000, precio_mayorista=800)
    assert p.precio_para(mayorista=True) == 800
    assert p.precio_para(mayorista=False) == 1000


def test_precio_para_mayorista_sin_precio_mayorista_usa_venta():
    p = ProductoFactory(precio_venta=1000, precio_mayorista=None)
    assert p.precio_para(mayorista=True) == 1000


def test_buscar_por_nombre_sku_o_codigo():
    ProductoFactory(nombre="Taladro Bosch", sku="TAL001", codigo_barras="111222333")
    ProductoFactory(nombre="Martillo", sku="MAR001", codigo_barras="999888777")
    assert Producto.objects.buscar("taladro").count() == 1
    assert Producto.objects.buscar("MAR001").count() == 1
    assert Producto.objects.buscar("111222333").count() == 1
