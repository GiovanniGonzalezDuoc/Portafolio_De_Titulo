"""Filtros de listado del catálogo."""

import django_filters as filters

from .models import Producto


class ProductoFilter(filters.FilterSet):
    categoria = filters.CharFilter(field_name="categoria__nombre", lookup_expr="iexact")
    marca = filters.CharFilter(field_name="marca__nombre", lookup_expr="iexact")
    precio_min = filters.NumberFilter(field_name="precio_venta", lookup_expr="gte")
    precio_max = filters.NumberFilter(field_name="precio_venta", lookup_expr="lte")

    class Meta:
        model = Producto
        fields = ["categoria", "marca", "activo", "afecto_iva", "unidad_medida"]
