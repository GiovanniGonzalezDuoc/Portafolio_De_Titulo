"""ViewSets del catálogo."""

from __future__ import annotations

from datetime import timedelta

from django.db import transaction
from django.db.models import Sum
from django.shortcuts import get_object_or_404
from django.utils import timezone
from drf_spectacular.utils import OpenApiParameter, extend_schema
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.core.exceptions import ConflictoEstado, ErrorDominio, RecursoNoEncontrado
from apps.core.reportes import leer_filas_excel, plantilla_excel
from apps.usuarios.permissions import PermisoPorAccion

from . import services
from .filters import ProductoFilter
from .models import Categoria, Marca, Producto, UnidadMedida
from .serializers import (
    CategoriaSerializer,
    ImagenProductoSerializer,
    MarcaSerializer,
    ProductoEscrituraSerializer,
    ProductoSerializer,
)

_INSTRUCCIONES_PLANTILLA = [
    "Carga masiva de productos — instrucciones",
    "",
    "Completa la hoja \"Datos\" con un producto por fila. No cambies los nombres de las columnas.",
    "",
    "categoria, marca, unidad_medida y afecto_iva tienen un desplegable: haz clic en la celda y "
    "aparece la flechita para elegir el valor en vez de escribirlo (evita errores de tipeo).",
    "",
    "sku: obligatorio. Único; si ya existe otro producto con ese SKU, la fila se rechaza.",
    "codigo_barras: opcional. Único si se indica.",
    "nombre: obligatorio, mínimo 2 caracteres.",
    "descripcion: opcional.",
    "categoria: obligatorio. Elígela del desplegable (son las categorías activas al momento de descargar esta plantilla).",
    "marca: opcional. Elígela del desplegable si el producto tiene una.",
    "unidad_medida: opcional (por defecto UN). Elígela del desplegable: UN, KG, LT, MT, CJ.",
    "precio_venta: obligatorio, en pesos CLP con IVA incluido (número entero, sin puntos ni signo $).",
    "precio_mayorista: opcional, mismo formato que precio_venta.",
    "costo_referencial: opcional, mismo formato.",
    "afecto_iva: opcional (por defecto SI). Elígela del desplegable: SI o NO.",
    "fecha_vencimiento: opcional, formato AAAA-MM-DD (o una celda de fecha de Excel).",
    "stock: opcional. Cantidad inicial que entra a la Bodega Principal.",
    "",
    "Al subir el archivo, cada fila se procesa por separado: si una fila tiene un error no afecta a las demás.",
    "El resultado te dirá cuántos productos se crearon y, si algo falló, en qué fila y por qué.",
]

_PERMISOS_MAESTRA = {
    "list": "catalogo.ver",
    "retrieve": "catalogo.ver",
    "create": "catalogo.administrar",
    "update": "catalogo.administrar",
    "partial_update": "catalogo.administrar",
    "destroy": "catalogo.administrar",
    "activar": "catalogo.administrar",
}


class _MaestraViewSet(viewsets.ModelViewSet):
    """CRUD de una entidad maestra: ``DELETE`` la desactiva en lugar de borrarla."""

    permission_classes = [PermisoPorAccion]
    permisos_por_accion = _PERMISOS_MAESTRA
    search_fields = ["nombre"]
    ordering_fields = ["nombre", "creado_en"]
    filterset_fields = ["activo"]

    def destroy(self, request, *args, **kwargs):
        obj = self.get_object()
        obj.activo = False
        obj.save(update_fields=["activo", "actualizado_en"])
        return Response(status=status.HTTP_204_NO_CONTENT)

    @action(detail=True, methods=["post"])
    def activar(self, request, pk=None):
        obj = self.get_object()
        obj.activo = True
        obj.save(update_fields=["activo", "actualizado_en"])
        return Response(self.get_serializer(obj).data)


class CategoriaViewSet(_MaestraViewSet):
    queryset = Categoria.objects.all()
    serializer_class = CategoriaSerializer


class MarcaViewSet(_MaestraViewSet):
    queryset = Marca.objects.all()
    serializer_class = MarcaSerializer


class ProductoViewSet(viewsets.ModelViewSet):
    queryset = (
        Producto.objects.select_related("categoria", "marca")
        .prefetch_related("ofertas")
        .annotate(stock_total_ann=Sum("stocks__cantidad"))
        .order_by("nombre")
    )
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        **_PERMISOS_MAESTRA,
        "desactivar": "catalogo.administrar",
        "por_codigo": "catalogo.ver",
        "por_sku": "catalogo.ver",
        "por_vencer": "ofertas.ver",
        "imagen": "catalogo.administrar",
        "plantilla_carga_masiva": "catalogo.administrar",
        "carga_masiva": "catalogo.administrar",
    }
    filterset_class = ProductoFilter
    search_fields = ["sku", "nombre", "codigo_barras", "categoria__nombre", "marca__nombre"]
    ordering_fields = ["nombre", "precio_venta", "sku", "creado_en"]

    def get_serializer_class(self):
        if self.action in ("create", "update", "partial_update"):
            return ProductoEscrituraSerializer
        return ProductoSerializer

    @transaction.atomic
    def create(self, request, *args, **kwargs):
        entrada = ProductoEscrituraSerializer(data=request.data)
        entrada.is_valid(raise_exception=True)
        stock_inicial = entrada.validated_data.pop("stock", None)
        producto = entrada.save()
        if stock_inicial:
            from apps.inventario import services as inv

            inv.entrada(
                producto=producto,
                cantidad=stock_inicial,
                usuario=request.user,
                motivo="Stock inicial (alta de producto)",
            )
        return Response(ProductoSerializer(producto, context={"request": request}).data, status=status.HTTP_201_CREATED)

    @transaction.atomic
    def update(self, request, *args, **kwargs):
        parcial = kwargs.pop("partial", False)
        instancia = self.get_object()
        entrada = ProductoEscrituraSerializer(instancia, data=request.data, partial=parcial)
        entrada.is_valid(raise_exception=True)
        stock_objetivo = entrada.validated_data.pop("stock", None)
        producto = entrada.save()
        if stock_objetivo is not None:
            from apps.inventario import services as inv

            if int(stock_objetivo) != int(inv.stock_de(producto)):
                inv.ajustar_a_cantidad(
                    producto=producto,
                    cantidad_final=stock_objetivo,
                    usuario=request.user,
                    motivo="Ajuste desde la ficha del producto",
                )
        return Response(ProductoSerializer(producto, context={"request": request}).data)

    def destroy(self, request, *args, **kwargs):
        """
        Borra el producto de verdad si nunca se usó (sin ventas, compras,
        movimientos ni stock). Si tiene historial responde 409: hay que
        desactivarlo con ``POST .../desactivar/``.
        """
        producto = self.get_object()
        services.eliminar_producto(producto)
        return Response(status=status.HTTP_204_NO_CONTENT)

    @action(detail=True, methods=["post"])
    def activar(self, request, pk=None):
        producto = self.get_object()
        producto.activo = True
        producto.save(update_fields=["activo", "actualizado_en"])
        return Response(ProductoSerializer(producto, context={"request": request}).data)

    @action(detail=True, methods=["post"])
    def desactivar(self, request, pk=None):
        producto = self.get_object()
        producto.activo = False
        producto.save(update_fields=["activo", "actualizado_en"])
        return Response(ProductoSerializer(producto, context={"request": request}).data)

    @extend_schema(request=ImagenProductoSerializer, responses=ProductoSerializer)
    @action(detail=True, methods=["post", "delete"])
    def imagen(self, request, pk=None):
        """Sube (o reemplaza) la foto del producto; ``DELETE`` la quita."""
        producto = self.get_object()
        if request.method == "DELETE":
            producto.imagen.delete(save=False)
            producto.imagen = None
            producto.save(update_fields=["imagen", "actualizado_en"])
            return Response(ProductoSerializer(producto, context={"request": request}).data)

        entrada = ImagenProductoSerializer(data=request.data)
        entrada.is_valid(raise_exception=True)
        producto.imagen.delete(save=False)  # reemplaza: no deja huérfanas en el storage
        producto.imagen = entrada.validated_data["imagen"]
        producto.save(update_fields=["imagen", "actualizado_en"])
        return Response(ProductoSerializer(producto, context={"request": request}).data)

    # -- carga masiva por Excel --------------------------------
    @extend_schema(responses=None, description="Descarga la plantilla (.xlsx) para la carga masiva de productos.")
    @action(detail=False, methods=["get"], url_path="plantilla-carga-masiva")
    def plantilla_carga_masiva(self, request):
        categorias = list(Categoria.objects.filter(activo=True).order_by("nombre").values_list("nombre", flat=True))
        marcas = list(Marca.objects.filter(activo=True).order_by("nombre").values_list("nombre", flat=True))
        return plantilla_excel(
            nombre_archivo="plantilla_productos.xlsx",
            encabezados=services.CAMPOS_PLANTILLA_PRODUCTOS,
            anchos=[16, 16, 30, 30, 16, 16, 12, 12, 14, 16, 10, 16, 10],
            instrucciones=_INSTRUCCIONES_PLANTILLA,
            listas_desplegables={
                "categoria": categorias,
                "marca": marcas,
                "unidad_medida": [v for v, _ in UnidadMedida.choices],
                "afecto_iva": ["SI", "NO"],
            },
        )

    @extend_schema(request={"multipart/form-data": {"type": "object", "properties": {"archivo": {"type": "string", "format": "binary"}}}}, responses=None)
    @action(detail=False, methods=["post"], url_path="carga-masiva")
    def carga_masiva(self, request):
        archivo = request.FILES.get("archivo")
        if archivo is None:
            raise ErrorDominio("Adjunta el archivo Excel en el campo 'archivo'.", codigo="archivo_requerido")
        try:
            filas = leer_filas_excel(archivo)
        except Exception as exc:  # noqa: BLE001 — el archivo puede venir dañado o no ser un .xlsx
            raise ErrorDominio(
                f"No se pudo leer el archivo: {exc}", codigo="archivo_invalido"
            ) from exc
        if not filas:
            raise ErrorDominio("El archivo no tiene filas para cargar.", codigo="archivo_vacio")
        if len(filas) > 1000:
            raise ErrorDominio(
                "El archivo tiene más de 1000 filas; divídelo en tandas más chicas.",
                codigo="archivo_muy_grande",
            )
        resultado = services.carga_masiva_productos(filas, request.user)
        return Response(resultado)

    @extend_schema(
        parameters=[OpenApiParameter("codigo", str, OpenApiParameter.PATH)],
        responses=ProductoSerializer,
        description="Busca un producto por código de barras (uso del POS). "
        "404 si no existe; 409 si está inactivo.",
    )
    @action(detail=False, methods=["get"], url_path="por-codigo/(?P<codigo>[^/]+)")
    def por_codigo(self, request, codigo=None):
        normalizado = (codigo or "").strip().upper().replace(" ", "")
        producto = (
            Producto.objects.select_related("categoria", "marca").prefetch_related("ofertas")
            .filter(codigo_barras=normalizado)
            .first()
        )
        if producto is None:
            raise RecursoNoEncontrado(
                "No hay ningún producto con ese código de barras.",
                codigo="producto_no_encontrado",
            )
        if not producto.activo:
            raise ConflictoEstado(
                "El producto está inactivo y no puede venderse.",
                codigo="producto_inactivo",
            )
        return Response(ProductoSerializer(producto, context={"request": request}).data)

    @extend_schema(
        parameters=[OpenApiParameter("sku", str, OpenApiParameter.PATH)],
        responses=ProductoSerializer,
    )
    @action(detail=False, methods=["get"], url_path="por-sku/(?P<sku>[^/]+)")
    def por_sku(self, request, sku=None):
        producto = get_object_or_404(
            Producto.objects.select_related("categoria", "marca").prefetch_related("ofertas"),
            sku=(sku or "").strip().upper(),
        )
        return Response(ProductoSerializer(producto, context={"request": request}).data)

    @extend_schema(
        parameters=[OpenApiParameter("dias", int, description="Ventana en días (default 15).")],
        responses=ProductoSerializer,
        description="Productos activos que ya vencieron o vencen dentro de `dias` días "
        "(candidatos a oferta).",
    )
    @action(detail=False, methods=["get"], url_path="por-vencer")
    def por_vencer(self, request):
        try:
            dias = int(request.query_params.get("dias", 15))
        except (TypeError, ValueError):
            dias = 15
        dias = min(max(dias, 1), 365)

        hoy = timezone.localdate()
        limite = hoy + timedelta(days=dias)
        from apps.ofertas.services import oferta_vigente

        qs = (
            Producto.objects.filter(
                activo=True,
                fecha_vencimiento__isnull=False,
                fecha_vencimiento__lte=limite,
            )
            .select_related("categoria")
            .prefetch_related("ofertas")
            .annotate(stock_total_ann=Sum("stocks__cantidad"))
            .order_by("fecha_vencimiento", "nombre")
        )
        data = [
            {
                "sku": p.sku,
                "nombre": p.nombre,
                "categoria": p.categoria.nombre,
                "fecha_vencimiento": p.fecha_vencimiento.isoformat(),
                "dias_para_vencer": (p.fecha_vencimiento - hoy).days,
                "vencido": p.fecha_vencimiento < hoy,
                "precio_venta": p.precio_venta,
                "stock_total": round(float(getattr(p, "stock_total_ann", 0) or 0), 3),
                "tiene_oferta": oferta_vigente(p) is not None,
            }
            for p in qs
        ]
        return Response(data)
