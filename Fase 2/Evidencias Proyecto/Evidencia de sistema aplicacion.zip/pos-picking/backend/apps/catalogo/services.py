"""Operaciones de dominio del catálogo."""

from __future__ import annotations

import difflib
import unicodedata
from datetime import date, datetime

from django.db import transaction
from django.db.models import Sum

from apps.core.exceptions import ConflictoEstado

from .models import Categoria, Producto

_UMBRAL_CATEGORIA_PARECIDA = 0.85

CAMPOS_PLANTILLA_PRODUCTOS = [
    "sku", "codigo_barras", "nombre", "descripcion", "categoria", "marca",
    "unidad_medida", "precio_venta", "precio_mayorista", "costo_referencial",
    "afecto_iva", "fecha_vencimiento", "stock",
]


def _tiene_movimientos(producto: Producto) -> bool:
    return producto.movimientos.exists()


def _tiene_ventas(producto: Producto) -> bool:
    return producto.lineas_venta.exists()


def _tiene_compras(producto: Producto) -> bool:
    return producto.lineas_orden_compra.exists()


def _stock_actual(producto: Producto) -> float:
    total = producto.stocks.aggregate(t=Sum("cantidad"))["t"] or 0
    return float(total)


def puede_eliminarse(producto: Producto) -> tuple[bool, str]:
    """
    Un producto solo se borra de verdad si nunca se movió: sin movimientos de
    inventario, sin líneas de venta, sin líneas de orden de compra y sin stock.
    En cualquier otro caso se desactiva (para no romper el historial).
    """
    if _tiene_ventas(producto):
        return False, "El producto tiene ventas registradas."
    if _tiene_compras(producto):
        return False, "El producto está en una o más órdenes de compra."
    if _tiene_movimientos(producto):
        return False, "El producto tiene movimientos de inventario."
    if _stock_actual(producto) > 0:
        return False, "El producto todavía tiene stock."
    return True, ""


@transaction.atomic
def eliminar_producto(producto: Producto) -> None:
    """
    Borra definitivamente un producto sin referencias. Lanza ``ConflictoEstado``
    si está vinculado a ventas, compras, movimientos o stock: en ese caso el
    llamador debe desactivarlo en su lugar.
    """
    ok, motivo = puede_eliminarse(producto)
    if not ok:
        raise ConflictoEstado(
            f"{motivo} Desactívalo en lugar de eliminarlo.",
            codigo="producto_referenciado",
        )
    # Filas satélite en 0 que igual bloquean el DELETE (Stock es PROTECT).
    producto.stocks.all().delete()
    producto.parametros_inventario.all().delete()
    producto.delete()


# ─── Carga masiva por Excel ───────────────────────────────────
def _normalizar_nombre(texto: str) -> str:
    """Minúsculas, sin acentos y sin espacios de más — para comparar nombres
    de categoría ignorando diferencias que no son una categoría distinta."""
    sin_acentos = unicodedata.normalize("NFKD", texto).encode("ascii", "ignore").decode("ascii")
    return " ".join(sin_acentos.lower().split())


def _resolver_categoria(nombre_crudo: str, cache: dict[str, Categoria]) -> Categoria:
    """
    Reutiliza una categoría existente si el nombre es igual o muy parecido
    (para no duplicar "Abarrotes" / "abarrotes " / "Abarrote"); si no hay
    ninguna parecida, crea una categoría nueva con ese nombre. ``cache`` vive
    una sola carga masiva completa (nombre normalizado -> Categoria) y se
    actualiza acá mismo al crear una, así dos filas con el mismo nombre nuevo
    no crean dos categorías distintas.
    """
    nombre = nombre_crudo.strip()
    clave = _normalizar_nombre(nombre)
    if clave in cache:
        return cache[clave]

    parecidas = difflib.get_close_matches(clave, cache.keys(), n=1, cutoff=_UMBRAL_CATEGORIA_PARECIDA)
    if parecidas:
        return cache[parecidas[0]]

    categoria = Categoria.objects.create(nombre=nombre)
    cache[clave] = categoria
    return categoria


def _es_verdadero(valor) -> bool:
    if isinstance(valor, bool):
        return valor
    texto = str(valor if valor is not None else "").strip().lower()
    return texto in {"si", "sí", "s", "true", "1", "x", "yes"}


def _fila_a_dto(fila: dict) -> dict:
    """Traduce una fila de la plantilla (claves ya en snake_case) al dict
    que espera ``ProductoEscrituraSerializer``. Los campos vacíos se omiten
    (el serializer aplica sus propios valores por defecto)."""
    dto: dict = {
        "sku": str(fila.get("sku") or "").strip(),
        "nombre": str(fila.get("nombre") or "").strip(),
        "categoria": str(fila.get("categoria") or "").strip(),
    }
    if fila.get("codigo_barras") not in (None, ""):
        dto["codigo_barras"] = str(fila["codigo_barras"]).strip()
    if fila.get("descripcion") not in (None, ""):
        dto["descripcion"] = str(fila["descripcion"]).strip()
    if fila.get("marca") not in (None, ""):
        dto["marca"] = str(fila["marca"]).strip()
    if fila.get("unidad_medida") not in (None, ""):
        dto["unidad_medida"] = str(fila["unidad_medida"]).strip().upper()
    for campo in ("precio_venta", "precio_mayorista", "costo_referencial", "stock"):
        valor = fila.get(campo)
        if valor not in (None, ""):
            dto[campo] = valor
    if fila.get("afecto_iva") not in (None, ""):
        dto["afecto_iva"] = _es_verdadero(fila["afecto_iva"])
    venc = fila.get("fecha_vencimiento")
    if isinstance(venc, datetime):
        dto["fecha_vencimiento"] = venc.date().isoformat()
    elif isinstance(venc, date):
        dto["fecha_vencimiento"] = venc.isoformat()
    elif venc not in (None, ""):
        dto["fecha_vencimiento"] = str(venc).strip()
    return dto


def carga_masiva_productos(filas: list[tuple[int, dict]], usuario) -> dict:
    """
    ``filas``: ``[(número de fila del Excel, {encabezado: valor}), ...]``
    (las arma ``apps.core.reportes.leer_filas_excel``). Cada fila se valida
    y guarda de forma **independiente**: una fila con error no bloquea al
    resto, igual que al importar un catálogo en un marketplace.

    La categoría de cada fila se resuelve con ``_resolver_categoria`` ANTES
    de la transacción de la fila (no adentro): así, si una categoría nueva se
    crea pero el resto de la fila falla su validación, la categoría igual
    queda creada — y disponible para las filas siguientes que la usen —, en
    vez de deshacerse junto con el producto fallido.
    """
    from apps.inventario import services as inventario

    from .serializers import ProductoEscrituraSerializer

    cache_categorias: dict[str, Categoria] = {
        _normalizar_nombre(c.nombre): c for c in Categoria.objects.all()
    }

    creados = 0
    errores = []
    for numero_fila, fila in filas:
        dto = _fila_a_dto(fila)
        if not dto["sku"] and not dto["nombre"]:
            continue  # fila en blanco (solo espacios/celdas vacías)
        if dto.get("categoria"):
            dto["categoria"] = _resolver_categoria(dto["categoria"], cache_categorias).nombre
        try:
            with transaction.atomic():
                entrada = ProductoEscrituraSerializer(data=dto)
                if not entrada.is_valid():
                    errores.append(
                        {
                            "fila": numero_fila,
                            "sku": dto["sku"] or "(sin SKU)",
                            "errores": entrada.errors,
                        }
                    )
                    continue
                stock_inicial = entrada.validated_data.pop("stock", None)
                producto = entrada.save()
                if stock_inicial:
                    inventario.entrada(
                        producto=producto, cantidad=stock_inicial, usuario=usuario,
                        motivo="Stock inicial (carga masiva)",
                    )
                creados += 1
        except Exception as exc:  # noqa: BLE001 — una fila mala no debe tumbar el resto
            errores.append({"fila": numero_fila, "sku": dto["sku"] or "(sin SKU)", "errores": {"__all__": [str(exc)]}})
    return {"creados": creados, "con_error": errores, "total_filas": len(filas)}
