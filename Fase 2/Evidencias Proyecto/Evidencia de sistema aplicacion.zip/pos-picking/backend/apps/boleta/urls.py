"""Rutas de boleta electrónica."""

from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import BoletaViewSet

router = DefaultRouter()
router.register("boletas", BoletaViewSet, basename="boleta")

urlpatterns = [path("", include(router.urls))]
