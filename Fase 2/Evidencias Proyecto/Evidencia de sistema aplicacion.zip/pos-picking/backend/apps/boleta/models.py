"""
Modelos de boleta electrónica (DTE tipo 39 — SII Chile).

La emisión real depende de un proveedor externo o del SII con certificado y CAF.
Aquí solo se modela el documento y su ciclo de vida; la integración concreta
vive en ``apps/boleta/proveedores/`` (implementación MOCK por ahora).
"""

from __future__ import annotations

from django.db import models


class TipoDTE(models.IntegerChoices):
    BOLETA_AFECTA = 39, "Boleta electrónica afecta"


class EstadoDTE(models.TextChoices):
    PENDIENTE = "PENDIENTE", "Pendiente de emisión"
    EMITIDO = "EMITIDO", "Emitido"
    ACEPTADO = "ACEPTADO", "Aceptado"
    RECHAZADO = "RECHAZADO", "Rechazado"
    ANULADO = "ANULADO", "Anulado"


class TipoEventoDTE(models.TextChoices):
    EMISION_INTENTO = "EMISION_INTENTO", "Intento de emisión"
    EMISION_OK = "EMISION_OK", "Emisión exitosa"
    EMISION_ERROR = "EMISION_ERROR", "Error de emisión"
    ACEPTACION = "ACEPTACION", "Aceptación"
    ANULACION = "ANULACION", "Anulación"
    CONSULTA = "CONSULTA", "Consulta de estado"


class DocumentoTributarioQuerySet(models.QuerySet):
    def pendientes(self):
        return self.filter(estado=EstadoDTE.PENDIENTE)


class DocumentoTributario(models.Model):
    venta = models.OneToOneField(
        "ventas.Venta", on_delete=models.PROTECT, related_name="documento"
    )
    tipo_dte = models.PositiveSmallIntegerField(
        "tipo DTE", choices=TipoDTE.choices, default=TipoDTE.BOLETA_AFECTA
    )
    folio = models.PositiveIntegerField("folio", null=True, blank=True)
    estado = models.CharField(
        "estado", max_length=12, choices=EstadoDTE.choices, default=EstadoDTE.PENDIENTE
    )

    neto = models.PositiveIntegerField("neto (CLP)", default=0)
    iva = models.PositiveIntegerField("IVA (CLP)", default=0)
    exento = models.PositiveIntegerField("exento (CLP)", default=0)
    total = models.PositiveIntegerField("total (CLP)", default=0)

    emisor_rut = models.CharField("RUT del emisor", max_length=12, blank=True)
    fecha_emision = models.DateTimeField("fecha de emisión", null=True, blank=True)

    intentos = models.PositiveSmallIntegerField("intentos de emisión", default=0)
    ultimo_error = models.CharField("último error", max_length=300, blank=True)

    creado_en = models.DateTimeField("creado en", auto_now_add=True)
    actualizado_en = models.DateTimeField("actualizado en", auto_now=True)

    objects = DocumentoTributarioQuerySet.as_manager()

    class Meta:
        verbose_name = "documento tributario"
        verbose_name_plural = "documentos tributarios"
        ordering = ["-creado_en"]
        constraints = [
            # En MariaDB los NULL son distintos entre sí, por lo que varios
            # documentos "sin folio" conviven; una vez asignado, el par
            # (tipo, folio) es único.
            models.UniqueConstraint(
                fields=["tipo_dte", "folio"], name="dte_tipo_folio_unico"
            ),
        ]
        indexes = [models.Index(fields=["estado", "creado_en"])]

    def __str__(self) -> str:
        f = f"folio {self.folio}" if self.folio else "sin folio"
        return f"Boleta {f} ({self.get_estado_display()})"


class RespuestaProveedorDTE(models.Model):
    documento = models.OneToOneField(
        DocumentoTributario, on_delete=models.CASCADE, related_name="respuesta"
    )
    payload = models.JSONField("respuesta cruda", null=True, blank=True)
    track_id = models.CharField("track id", max_length=60, blank=True)
    timbre = models.TextField("timbre electrónico (TED)", blank=True)
    url_pdf = models.CharField("URL del documento", max_length=300, blank=True)
    recibido_en = models.DateTimeField("recibido en", auto_now=True)

    class Meta:
        verbose_name = "respuesta del proveedor DTE"
        verbose_name_plural = "respuestas del proveedor DTE"

    def __str__(self) -> str:
        return f"Respuesta de {self.documento}"


class EventoDTE(models.Model):
    documento = models.ForeignKey(
        DocumentoTributario, on_delete=models.CASCADE, related_name="eventos"
    )
    evento = models.CharField("evento", max_length=20, choices=TipoEventoDTE.choices)
    detalle = models.CharField("detalle", max_length=300, blank=True)
    creado_en = models.DateTimeField("creado en", auto_now_add=True)

    class Meta:
        verbose_name = "evento DTE"
        verbose_name_plural = "eventos DTE"
        ordering = ["creado_en", "id"]

    def __str__(self) -> str:
        return f"{self.evento} — {self.documento_id}"
