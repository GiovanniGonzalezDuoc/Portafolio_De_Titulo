from django.contrib import admin

from .models import DocumentoTributario, EventoDTE, RespuestaProveedorDTE


class EventoDTEInline(admin.TabularInline):
    model = EventoDTE
    extra = 0
    readonly_fields = ["evento", "detalle", "creado_en"]
    can_delete = False


class RespuestaInline(admin.StackedInline):
    model = RespuestaProveedorDTE
    extra = 0
    readonly_fields = ["payload", "track_id", "timbre", "url_pdf", "recibido_en"]
    can_delete = False


@admin.register(DocumentoTributario)
class DocumentoTributarioAdmin(admin.ModelAdmin):
    list_display = ["id", "venta", "tipo_dte", "folio", "estado", "total", "intentos", "creado_en"]
    list_filter = ["estado", "tipo_dte"]
    search_fields = ["folio", "venta__folio"]
    inlines = [RespuestaInline, EventoDTEInline]
    readonly_fields = [f.name for f in DocumentoTributario._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
