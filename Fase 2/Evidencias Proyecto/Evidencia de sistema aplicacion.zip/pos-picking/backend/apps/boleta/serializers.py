"""Serializers de boleta electrónica."""

from rest_framework import serializers

from .models import DocumentoTributario, EventoDTE


class EventoDTESerializer(serializers.ModelSerializer):
    evento_display = serializers.CharField(source="get_evento_display", read_only=True)

    class Meta:
        model = EventoDTE
        fields = ["id", "evento", "evento_display", "detalle", "creado_en"]


class DocumentoTributarioSerializer(serializers.ModelSerializer):
    venta_folio = serializers.CharField(source="venta.folio", read_only=True)
    estado_display = serializers.CharField(source="get_estado_display", read_only=True)
    track_id = serializers.CharField(source="respuesta.track_id", read_only=True, default="")
    url_pdf = serializers.CharField(source="respuesta.url_pdf", read_only=True, default="")

    class Meta:
        model = DocumentoTributario
        fields = [
            "id", "venta_folio", "tipo_dte", "folio", "estado", "estado_display",
            "neto", "iva", "exento", "total", "emisor_rut", "fecha_emision",
            "intentos", "ultimo_error", "track_id", "url_pdf", "creado_en",
        ]
        read_only_fields = fields


class DocumentoTributarioDetalleSerializer(DocumentoTributarioSerializer):
    eventos = EventoDTESerializer(many=True, read_only=True)

    class Meta(DocumentoTributarioSerializer.Meta):
        fields = [*DocumentoTributarioSerializer.Meta.fields, "eventos"]
        read_only_fields = fields


class AnularBoletaSerializer(serializers.Serializer):
    motivo = serializers.CharField(max_length=200, required=False, allow_blank=True, default="")
