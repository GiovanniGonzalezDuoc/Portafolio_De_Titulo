"""Factory del proveedor DTE activo."""

from __future__ import annotations

from functools import lru_cache

from apps.core.models import ParametroSistema

from .base import ProveedorDTE, ResultadoDTE
from .mock import ProveedorDTEMock

_REGISTRO: dict[str, type[ProveedorDTE]] = {
    "mock": ProveedorDTEMock,
}


@lru_cache(maxsize=4)
def _instancia(nombre: str) -> ProveedorDTE:
    clase = _REGISTRO.get(nombre, ProveedorDTEMock)
    return clase()


def obtener_proveedor() -> ProveedorDTE:
    """Devuelve el proveedor DTE configurado en ``ParametroSistema.dte_proveedor``."""
    nombre = (ParametroSistema.get().dte_proveedor or "mock").strip().lower()
    return _instancia(nombre)


__all__ = ["ProveedorDTE", "ResultadoDTE", "obtener_proveedor"]
