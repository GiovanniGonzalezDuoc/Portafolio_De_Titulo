"""
Proveedor DTE **simulado**.

No se conecta a ningún servicio real. Asigna un folio incremental, genera un
"timbre" ficticio y simula la aceptación por parte del SII. Puede simular fallos
de forma controlada para probar los reintentos:

- ``DTE_MOCK_FALLA_PROB`` (0..1): probabilidad de fallo por intento.
- ``DTE_MOCK_FORZAR_FALLO`` (bool): falla siempre (para tests).
"""

from __future__ import annotations

import base64
import hashlib
import os
import random

from django.conf import settings

from apps.core.models import Secuencia

from .base import ProveedorDTE, ResultadoDTE

SECUENCIA_FOLIO = "dte_folio_39"


def _debe_fallar() -> bool:
    if str(getattr(settings, "DTE_MOCK_FORZAR_FALLO", os.environ.get("DTE_MOCK_FORZAR_FALLO", ""))).lower() in ("1", "true", "yes"):
        return True
    try:
        prob = float(getattr(settings, "DTE_MOCK_FALLA_PROB", os.environ.get("DTE_MOCK_FALLA_PROB", 0)))
    except (TypeError, ValueError):
        prob = 0.0
    return prob > 0 and random.random() < prob


def _timbre(documento, folio: int) -> str:
    semilla = f"{documento.emisor_rut}|39|{folio}|{documento.total}|{documento.creado_en:%Y%m%d}"
    firma = hashlib.sha256(semilla.encode()).hexdigest()
    return base64.b64encode(f"<TED><DD>{semilla}</DD><FRMT>{firma}</FRMT></TED>".encode()).decode()


class ProveedorDTEMock(ProveedorDTE):
    nombre = "mock"

    def emitir(self, documento) -> ResultadoDTE:
        if _debe_fallar():
            return ResultadoDTE(
                ok=False,
                error="El servicio de emisión (simulado) no está disponible.",
                payload={"simulado": True, "http_status": 503},
            )
        folio = Secuencia.siguiente(SECUENCIA_FOLIO)
        timbre = _timbre(documento, folio)
        track_id = f"MOCK-{folio:08d}"
        return ResultadoDTE(
            ok=True,
            folio=folio,
            timbre=timbre,
            track_id=track_id,
            estado="ACEPTADO",  # el mock simula que el SII lo acepta de inmediato
            payload={
                "simulado": True,
                "folio": folio,
                "track_id": track_id,
                "estado_sii": "DOK",
                "glosa": "Documento recibido y aceptado (simulado).",
            },
        )

    def anular(self, documento) -> ResultadoDTE:
        return ResultadoDTE(
            ok=True,
            estado="ANULADO",
            payload={"simulado": True, "glosa": "Anulación registrada (simulada)."},
        )

    def consultar_estado(self, documento) -> ResultadoDTE:
        return ResultadoDTE(
            ok=True,
            estado=documento.estado,
            payload={"simulado": True, "estado": documento.estado},
        )
