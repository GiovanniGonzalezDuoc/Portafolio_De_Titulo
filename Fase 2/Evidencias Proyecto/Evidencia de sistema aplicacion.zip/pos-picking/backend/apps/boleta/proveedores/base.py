"""Interfaz (puerto) de un proveedor de documentos tributarios electrónicos."""

from __future__ import annotations

import abc
from dataclasses import dataclass, field


@dataclass
class ResultadoDTE:
    """Resultado de una operación con el proveedor DTE."""

    ok: bool
    folio: int | None = None
    timbre: str = ""
    track_id: str = ""
    estado: str = ""  # EMITIDO / ACEPTADO / RECHAZADO / ANULADO
    error: str = ""
    payload: dict = field(default_factory=dict)


class ProveedorDTE(abc.ABC):
    """
    Puerto para emitir/anular/consultar documentos tributarios.

    Las implementaciones concretas viven junto a este módulo. Hoy solo existe
    ``ProveedorDTEMock``; una implementación real (LibreDTE, SimpleAPI, SII…)
    se añade sin tocar el resto del sistema.
    """

    nombre: str = "base"

    @abc.abstractmethod
    def emitir(self, documento) -> ResultadoDTE: ...

    @abc.abstractmethod
    def anular(self, documento) -> ResultadoDTE: ...

    @abc.abstractmethod
    def consultar_estado(self, documento) -> ResultadoDTE: ...
