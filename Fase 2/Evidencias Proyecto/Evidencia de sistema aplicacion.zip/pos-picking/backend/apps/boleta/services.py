"""
Servicios de boleta electrónica.

``crear_documento_pendiente`` se llama **dentro** de la transacción de la venta
(solo escribe en BD). ``emitir_seguro`` se llama **después** del commit y nunca
propaga excepciones: si la emisión falla, el documento queda ``PENDIENTE`` y el
comando ``reintentar_dte`` (cron) lo reprocesa. La venta nunca queda inconsistente.
"""

from __future__ import annotations

import logging

from django.db import transaction
from django.utils import timezone
from django.utils.html import escape, format_html_join

from apps.core.exceptions import ConflictoEstado
from apps.core.models import ParametroSistema

from .models import (
    DocumentoTributario,
    EstadoDTE,
    EventoDTE,
    RespuestaProveedorDTE,
    TipoEventoDTE,
)
from .proveedores import obtener_proveedor

logger = logging.getLogger("pos.boleta")

MAX_INTENTOS = 5
ESTADOS_EMITIBLES = {EstadoDTE.PENDIENTE}


def _evento(documento, evento, detalle=""):
    EventoDTE.objects.create(documento=documento, evento=evento, detalle=detalle[:300])


def crear_documento_pendiente(venta) -> DocumentoTributario:
    """Crea el documento en estado PENDIENTE a partir de una venta confirmada."""
    params = ParametroSistema.get()
    documento = DocumentoTributario.objects.create(
        venta=venta,
        neto=venta.neto,
        iva=venta.iva,
        exento=venta.exento,
        total=venta.total,
        emisor_rut=params.emisor_rut,
        estado=EstadoDTE.PENDIENTE,
    )
    _evento(documento, TipoEventoDTE.EMISION_INTENTO, "Documento creado, pendiente de emisión.")
    return documento


def emitir(documento: DocumentoTributario) -> DocumentoTributario:
    """
    Intenta emitir el documento. Lanza ``ConflictoEstado`` si falla, pero **deja
    persistidos** el intento, el error y el evento (el rollback de la excepción
    no los revierte porque se guardan en su propia transacción).
    """
    # 1) Guard + incremento de intentos (se confirma antes de llamar al proveedor).
    with transaction.atomic():
        documento = DocumentoTributario.objects.select_for_update().get(pk=documento.pk)
        if documento.estado not in ESTADOS_EMITIBLES:
            raise ConflictoEstado(
                f"El documento ya está {documento.get_estado_display()}.",
                codigo="dte_no_emitible",
            )
        documento.intentos += 1
        documento.save(update_fields=["intentos", "actualizado_en"])

    # 2) Llamada al proveedor (fuera de toda transacción).
    proveedor = obtener_proveedor()
    _evento(documento, TipoEventoDTE.EMISION_INTENTO,
            f"Intento {documento.intentos} con proveedor '{proveedor.nombre}'.")
    resultado = proveedor.emitir(documento)

    # 3) Persistir el resultado (éxito o error) en una transacción que SÍ confirma.
    with transaction.atomic():
        respuesta, _ = RespuestaProveedorDTE.objects.get_or_create(documento=documento)
        respuesta.payload = resultado.payload
        respuesta.track_id = resultado.track_id
        respuesta.timbre = resultado.timbre

        if resultado.ok:
            documento.folio = resultado.folio
            documento.fecha_emision = timezone.now()
            documento.ultimo_error = ""
            documento.estado = EstadoDTE.EMITIDO
            documento.save(update_fields=["folio", "fecha_emision", "ultimo_error", "estado", "actualizado_en"])
            respuesta.url_pdf = f"/api/v1/boletas/{documento.pk}/imprimir/"
            respuesta.save()
            _evento(documento, TipoEventoDTE.EMISION_OK, f"Folio {resultado.folio} asignado.")
            if resultado.estado == EstadoDTE.ACEPTADO:
                documento.estado = EstadoDTE.ACEPTADO
                documento.save(update_fields=["estado", "actualizado_en"])
                _evento(documento, TipoEventoDTE.ACEPTACION, "Aceptado por el SII (simulado).")
        else:
            documento.ultimo_error = resultado.error
            documento.save(update_fields=["ultimo_error", "actualizado_en"])
            respuesta.save()
            _evento(documento, TipoEventoDTE.EMISION_ERROR, resultado.error)

    if not resultado.ok:
        logger.warning("Emisión DTE falló (venta %s): %s", documento.venta.folio, resultado.error)
        raise ConflictoEstado(resultado.error or "Fallo de emisión.", codigo="dte_emision_fallida")

    logger.info("Boleta emitida: folio %s (venta %s)", documento.folio, documento.venta.folio)
    return documento


def emitir_seguro(documento: DocumentoTributario) -> DocumentoTributario:
    """Emite sin propagar errores. Devuelve el documento (emitido o pendiente)."""
    try:
        return emitir(documento)
    except Exception as exc:  # noqa: BLE001 — resiliencia: la venta ya está confirmada
        logger.warning("emitir_seguro: %s", exc)
        documento.refresh_from_db()
        if documento.estado == EstadoDTE.PENDIENTE and documento.intentos >= MAX_INTENTOS:
            from apps.alertas import services as alertas

            alertas.notificar_dte_fallido(documento)
        return documento


@transaction.atomic
def anular(documento: DocumentoTributario, *, motivo: str = "") -> DocumentoTributario:
    documento = DocumentoTributario.objects.select_for_update().get(pk=documento.pk)
    if documento.estado == EstadoDTE.ANULADO:
        return documento
    proveedor = obtener_proveedor()
    resultado = proveedor.anular(documento)
    respuesta, _ = RespuestaProveedorDTE.objects.get_or_create(documento=documento)
    respuesta.payload = {**(respuesta.payload or {}), "anulacion": resultado.payload}
    respuesta.save()
    documento.estado = EstadoDTE.ANULADO
    documento.save(update_fields=["estado", "actualizado_en"])
    _evento(documento, TipoEventoDTE.ANULACION, motivo or "Documento anulado.")
    logger.info("Boleta anulada (venta %s): %s", documento.venta.folio, motivo)
    return documento


def reintentar_pendientes(*, limite: int = 100) -> dict:
    """Reprocesa documentos PENDIENTE con intentos < MAX_INTENTOS. Devuelve un resumen."""
    pendientes = (
        DocumentoTributario.objects.pendientes()
        .filter(intentos__lt=MAX_INTENTOS)
        .order_by("creado_en")[:limite]
    )
    emitidos = 0
    fallidos = 0
    for documento in pendientes:
        resultado = emitir_seguro(documento)
        if resultado.estado in (EstadoDTE.EMITIDO, EstadoDTE.ACEPTADO):
            emitidos += 1
        else:
            fallidos += 1
    return {"procesados": emitidos + fallidos, "emitidos": emitidos, "fallidos": fallidos}


def representacion_html(documento: DocumentoTributario) -> str:
    """
    HTML simple de la boleta (representación impresa del MOCK).

    Todos los valores dinámicos se escapan con :func:`django.utils.html.escape`
    para evitar XSS: la descripción de la línea proviene del nombre del producto
    y no debe poder inyectar marcado en la vista de impresión del POS.
    """
    venta = documento.venta

    def esc(valor) -> str:
        return escape("—" if valor is None or valor == "" else valor)

    filas = format_html_join(
        "",
        "<tr><td>{}</td><td style='text-align:right'>{}</td>"
        "<td style='text-align:right'>${}</td>"
        "<td style='text-align:right'>${}</td></tr>",
        (
            (ln.descripcion, ln.cantidad, ln.precio_unitario, ln.total_linea)
            for ln in venta.lineas.all()
        ),
    )
    timbre = getattr(getattr(documento, "respuesta", None), "timbre", "") or "(sin timbre)"
    fecha = (documento.fecha_emision or documento.creado_en).strftime("%d-%m-%Y %H:%M")
    params = ParametroSistema.get()
    return f"""<!doctype html><html lang="es"><meta charset="utf-8">
<title>Boleta {esc(documento.folio)}</title>
<body style="font-family:monospace;max-width:420px;margin:20px auto">
<h3 style="text-align:center">BOLETA ELECTRÓNICA</h3>
<p style="text-align:center">
{esc(params.emisor_razon_social)}<br>
{esc(params.emisor_giro)}<br>
{esc(params.emisor_direccion)}<br>
RUT: {esc(documento.emisor_rut)}</p>
<p style="text-align:center">DTE 39 · Folio {esc(documento.folio)} · {esc(documento.get_estado_display())}<br>
Fecha: {esc(fecha)}<br>
Venta: {esc(venta.folio)}</p>
<table style="width:100%;border-collapse:collapse">
<thead><tr><th style="text-align:left">Detalle</th><th>Cant</th><th>P.Unit</th><th>Total</th></tr></thead>
<tbody>{filas}</tbody></table>
<hr>
<p style="text-align:right">
Neto: ${esc(documento.neto)}<br>IVA: ${esc(documento.iva)}<br>
Exento: ${esc(documento.exento)}<br><b>TOTAL: ${esc(documento.total)}</b></p>
<p style="word-break:break-all;font-size:10px;color:#666">TED: {esc(timbre)}</p>
<p style="text-align:center;font-size:11px">Documento simulado — no válido tributariamente</p>
</body></html>"""
