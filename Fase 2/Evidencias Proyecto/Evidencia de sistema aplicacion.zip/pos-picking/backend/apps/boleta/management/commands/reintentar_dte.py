"""
Reintenta la emisión de las boletas pendientes.

Pensado para el cron de cPanel::

    */15 * * * *  cd ~/pos_backend && venv/bin/python manage.py reintentar_dte
"""

from django.core.management.base import BaseCommand

from apps.boleta import services


class Command(BaseCommand):
    help = "Reprocesa los documentos tributarios en estado PENDIENTE."

    def add_arguments(self, parser):
        parser.add_argument("--limite", type=int, default=100)

    def handle(self, *args, **options):
        resumen = services.reintentar_pendientes(limite=options["limite"])
        self.stdout.write(
            self.style.SUCCESS(
                f"Procesados: {resumen['procesados']} | "
                f"emitidos: {resumen['emitidos']} | fallidos: {resumen['fallidos']}"
            )
        )
