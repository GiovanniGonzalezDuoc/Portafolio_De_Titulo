from django.apps import AppConfig


class BoletaConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.boleta"
    verbose_name = "Boleta electrónica"
