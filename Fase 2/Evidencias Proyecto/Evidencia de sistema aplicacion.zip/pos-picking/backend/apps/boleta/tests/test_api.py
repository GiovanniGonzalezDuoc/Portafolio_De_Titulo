"""Tests de la API de boleta electrónica."""

import pytest

from apps.boleta.models import EstadoDTE
from apps.ventas import services as ventas_services
from apps.ventas.tests.factories import item, producto_con_stock

pytestmark = pytest.mark.django_db


def _venta_con_boleta(vendedor):
    prod = producto_con_stock(vendedor, cantidad=20, precio_venta=1000)
    return ventas_services.confirmar_venta(
        items=[item(prod, 2)], pagos=[{"medio": "DEBITO", "monto": 2000}], vendedor=vendedor
    )


def test_vendedor_lista_y_ve_boletas(api_vendedor, vendedor):
    _venta_con_boleta(vendedor)
    r = api_vendedor.get("/api/v1/boletas/")
    assert r.status_code == 200
    assert r.data["conteo"] == 1
    assert r.data["resultados"][0]["estado"] == "ACEPTADO"


def test_retrieve_incluye_eventos(api_vendedor, vendedor):
    venta = _venta_con_boleta(vendedor)
    r = api_vendedor.get(f"/api/v1/boletas/{venta.documento.id}/")
    assert r.status_code == 200
    assert len(r.data["eventos"]) >= 2


def test_imprimir_devuelve_html(api_vendedor, vendedor):
    venta = _venta_con_boleta(vendedor)
    r = api_vendedor.get(f"/api/v1/boletas/{venta.documento.id}/imprimir/")
    assert r.status_code == 200
    assert r["Content-Type"].startswith("text/html")
    assert b"BOLETA ELECTR" in r.content


def test_vendedor_no_puede_reintentar_ni_anular(api_vendedor, vendedor):
    venta = _venta_con_boleta(vendedor)
    d = venta.documento.id
    assert api_vendedor.post(f"/api/v1/boletas/{d}/reintentar/").status_code == 403
    assert api_vendedor.post(f"/api/v1/boletas/{d}/anular/").status_code == 403


def test_admin_reintenta_boleta_pendiente(api_admin, admin, settings):
    settings.DTE_MOCK_FORZAR_FALLO = True
    prod = producto_con_stock(admin, cantidad=20, precio_venta=1000)
    venta = ventas_services.confirmar_venta(
        items=[item(prod, 1)], pagos=[{"medio": "DEBITO", "monto": 1000}], vendedor=admin
    )
    assert venta.documento.estado == EstadoDTE.PENDIENTE

    settings.DTE_MOCK_FORZAR_FALLO = False
    r = api_admin.post(f"/api/v1/boletas/{venta.documento.id}/reintentar/")
    assert r.status_code == 200
    assert r.data["estado"] in ("EMITIDO", "ACEPTADO")


def test_admin_anula_boleta(api_admin, admin):
    prod = producto_con_stock(admin, cantidad=20, precio_venta=1000)
    venta = ventas_services.confirmar_venta(
        items=[item(prod, 1)], pagos=[{"medio": "DEBITO", "monto": 1000}], vendedor=admin
    )
    r = api_admin.post(
        f"/api/v1/boletas/{venta.documento.id}/anular/", {"motivo": "error"}, format="json"
    )
    assert r.status_code == 200
    assert r.data["estado"] == "ANULADO"


def test_filtro_por_estado(api_admin, admin, settings):
    # una aceptada
    p1 = producto_con_stock(admin, cantidad=20, precio_venta=1000)
    ventas_services.confirmar_venta(
        items=[item(p1, 1)], pagos=[{"medio": "DEBITO", "monto": 1000}], vendedor=admin
    )
    # una pendiente
    settings.DTE_MOCK_FORZAR_FALLO = True
    p2 = producto_con_stock(admin, cantidad=20, precio_venta=1000)
    ventas_services.confirmar_venta(
        items=[item(p2, 1)], pagos=[{"medio": "DEBITO", "monto": 1000}], vendedor=admin
    )
    r = api_admin.get("/api/v1/boletas/?estado=PENDIENTE")
    assert r.data["conteo"] == 1
