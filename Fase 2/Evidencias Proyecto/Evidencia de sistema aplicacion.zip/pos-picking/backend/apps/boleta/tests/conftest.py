"""Fixtures locales de los tests de boleta (necesitan caja abierta para vender)."""

import pytest


@pytest.fixture(autouse=True)
def _abrir_cajas(request):
    if "vendedor" not in request.fixturenames and "admin" not in request.fixturenames:
        yield
        return
    from apps.caja.services import abrir_caja, caja_abierta_de

    for nombre in ("vendedor", "admin"):
        if nombre in request.fixturenames:
            usuario = request.getfixturevalue(nombre)
            if caja_abierta_de(usuario) is None:
                abrir_caja(usuario=usuario, monto_inicial=50000)
    yield
