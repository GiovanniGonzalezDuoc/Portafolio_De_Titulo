"""Tests del servicio de boleta electrónica (proveedor MOCK)."""

import pytest

from apps.boleta import services
from apps.boleta.models import DocumentoTributario, EstadoDTE, TipoEventoDTE
from apps.core.exceptions import ConflictoEstado
from apps.ventas import services as ventas_services
from apps.ventas.tests.factories import item, producto_con_stock

pytestmark = pytest.mark.django_db


def _venta(vendedor, total_prod_precio=1190, cantidad=1):
    prod = producto_con_stock(vendedor, cantidad=20, precio_venta=total_prod_precio)
    return ventas_services._confirmar_venta_tx(
        items=[item(prod, cantidad)],
        pagos=[{"medio": "DEBITO", "monto": total_prod_precio * cantidad}],
        vendedor=vendedor,
    )


def test_crear_documento_pendiente(vendedor):
    venta = _venta(vendedor)
    doc = venta.documento
    assert doc.estado == EstadoDTE.PENDIENTE
    assert doc.total == venta.total
    assert doc.eventos.filter(evento=TipoEventoDTE.EMISION_INTENTO).exists()


def test_emitir_asigna_folio_y_timbre(vendedor):
    venta = _venta(vendedor)
    doc = services.emitir(venta.documento)
    assert doc.estado == EstadoDTE.ACEPTADO
    assert doc.folio is not None
    assert doc.fecha_emision is not None
    assert doc.respuesta.timbre != ""
    assert doc.respuesta.track_id.startswith("MOCK-")
    assert doc.eventos.filter(evento=TipoEventoDTE.EMISION_OK).exists()


def test_folios_incrementales_y_unicos(vendedor):
    d1 = services.emitir(_venta(vendedor).documento)
    d2 = services.emitir(_venta(vendedor).documento)
    assert d2.folio == d1.folio + 1


def test_emitir_falla_deja_pendiente(vendedor, settings):
    settings.DTE_MOCK_FORZAR_FALLO = True
    venta = _venta(vendedor)
    with pytest.raises(ConflictoEstado):
        services.emitir(venta.documento)
    doc = DocumentoTributario.objects.get(pk=venta.documento.pk)
    assert doc.estado == EstadoDTE.PENDIENTE
    assert doc.intentos == 1
    assert doc.ultimo_error != ""
    assert doc.eventos.filter(evento=TipoEventoDTE.EMISION_ERROR).exists()


def test_emitir_seguro_no_propaga_errores(vendedor, settings):
    settings.DTE_MOCK_FORZAR_FALLO = True
    venta = _venta(vendedor)
    doc = services.emitir_seguro(venta.documento)  # no lanza
    assert doc.estado == EstadoDTE.PENDIENTE


def test_no_se_emite_dos_veces(vendedor):
    venta = _venta(vendedor)
    services.emitir(venta.documento)
    with pytest.raises(ConflictoEstado):
        services.emitir(venta.documento)


# ─── Integración con la venta ──────────────────────────────
def test_venta_confirmada_emite_boleta(vendedor):
    prod = producto_con_stock(vendedor, cantidad=20, precio_venta=1190)
    venta = ventas_services.confirmar_venta(
        items=[item(prod, 2)],
        pagos=[{"medio": "DEBITO", "monto": 2380}],
        vendedor=vendedor,
    )
    assert venta.documento.estado == EstadoDTE.ACEPTADO
    assert venta.documento.folio is not None


def test_si_falla_el_dte_la_venta_queda_consistente(vendedor, settings):
    settings.DTE_MOCK_FORZAR_FALLO = True
    prod = producto_con_stock(vendedor, cantidad=20, precio_venta=1000)
    venta = ventas_services.confirmar_venta(
        items=[item(prod, 3)],
        pagos=[{"medio": "DEBITO", "monto": 3000}],
        vendedor=vendedor,
    )
    venta.refresh_from_db()
    assert venta.estado == "PAGADA"            # la venta NO se revierte
    from apps.inventario import services as inv
    assert inv.stock_de(prod) == 17            # el stock sí se descontó
    assert venta.documento.estado == EstadoDTE.PENDIENTE


def test_reintentar_pendientes_emite(vendedor, settings):
    settings.DTE_MOCK_FORZAR_FALLO = True
    prod = producto_con_stock(vendedor, cantidad=20, precio_venta=1000)
    venta = ventas_services.confirmar_venta(
        items=[item(prod, 1)], pagos=[{"medio": "DEBITO", "monto": 1000}], vendedor=vendedor
    )
    assert venta.documento.estado == EstadoDTE.PENDIENTE

    settings.DTE_MOCK_FORZAR_FALLO = False
    resumen = services.reintentar_pendientes()
    assert resumen["emitidos"] == 1
    venta.documento.refresh_from_db()
    assert venta.documento.estado == EstadoDTE.ACEPTADO


def test_anular_venta_anula_la_boleta(vendedor, admin):
    prod = producto_con_stock(vendedor, cantidad=20, precio_venta=1000)
    venta = ventas_services.confirmar_venta(
        items=[item(prod, 1)], pagos=[{"medio": "DEBITO", "monto": 1000}], vendedor=vendedor
    )
    ventas_services.anular_venta(venta, usuario=admin, motivo="prueba")
    venta.documento.refresh_from_db()
    assert venta.documento.estado == EstadoDTE.ANULADO
    assert venta.documento.eventos.filter(evento=TipoEventoDTE.ANULACION).exists()


def test_representacion_html_escapa_datos_del_producto(vendedor):
    """S1: el nombre del producto no debe poder inyectar HTML en la boleta."""
    prod = producto_con_stock(vendedor, cantidad=5, precio_venta=1000)
    prod.nombre = "<img src=x onerror=alert(1)>"
    prod.save(update_fields=["nombre"])
    venta = ventas_services._confirmar_venta_tx(
        items=[item(prod, 1)], pagos=[{"medio": "DEBITO", "monto": 1000}], vendedor=vendedor
    )
    html = services.representacion_html(venta.documento)
    assert "<img src=x onerror=alert(1)>" not in html
    assert "&lt;img src=x onerror=alert(1)&gt;" in html


def test_representacion_html_incluye_datos_del_emisor(vendedor):
    from apps.core.models import ParametroSistema

    params = ParametroSistema.get()
    params.emisor_rut = "12.682.310-K"
    params.emisor_razon_social = "Ingrid Paola Cisternas Espindoza"
    params.emisor_giro = "Venta al por menor"
    params.emisor_direccion = "Calle Los Europeos 1171, Quilicura"
    params.save()

    prod = producto_con_stock(vendedor, cantidad=5, precio_venta=1000)
    venta = ventas_services._confirmar_venta_tx(
        items=[item(prod, 1)], pagos=[{"medio": "DEBITO", "monto": 1000}], vendedor=vendedor
    )
    html = services.representacion_html(venta.documento)
    assert "Ingrid Paola Cisternas Espindoza" in html
    assert "Calle Los Europeos 1171, Quilicura" in html
    assert "Venta al por menor" in html
