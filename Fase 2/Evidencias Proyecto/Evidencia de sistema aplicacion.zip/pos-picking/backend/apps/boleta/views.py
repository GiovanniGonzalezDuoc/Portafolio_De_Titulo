"""ViewSets de boleta electrónica."""

from __future__ import annotations

from django.http import HttpResponse
from drf_spectacular.utils import OpenApiResponse, extend_schema
from rest_framework import mixins, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.usuarios.permissions import PermisoPorAccion

from . import services
from .models import DocumentoTributario
from .serializers import (
    AnularBoletaSerializer,
    DocumentoTributarioDetalleSerializer,
    DocumentoTributarioSerializer,
)


class BoletaViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = DocumentoTributario.objects.select_related("venta", "respuesta").all()
    serializer_class = DocumentoTributarioSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        "list": "boleta.ver",
        "retrieve": "boleta.ver",
        "imprimir": "boleta.ver",
        "reintentar": "boleta.reintentar",
        "anular": "boleta.anular",
    }
    filterset_fields = ["estado", "tipo_dte", "venta__folio"]
    ordering_fields = ["creado_en", "folio"]

    def get_queryset(self):
        qs = super().get_queryset()
        # El vendedor solo ve las boletas de sus propias ventas.
        u = self.request.user
        if (
            u.is_authenticated
            and not u.is_superuser
            and not u.tiene_permiso("dashboard.ver_completo")
        ):
            qs = qs.filter(venta__vendedor=u)
        return qs

    def get_serializer_class(self):
        if self.action == "retrieve":
            return DocumentoTributarioDetalleSerializer
        return DocumentoTributarioSerializer

    @extend_schema(responses={200: OpenApiResponse(description="HTML de la boleta")})
    @action(detail=True, methods=["get"])
    def imprimir(self, request, pk=None):
        documento = self.get_object()
        return HttpResponse(services.representacion_html(documento), content_type="text/html")

    @extend_schema(request=None, responses=DocumentoTributarioSerializer)
    @action(detail=True, methods=["post"])
    def reintentar(self, request, pk=None):
        documento = services.emitir_seguro(self.get_object())
        return Response(DocumentoTributarioSerializer(documento).data)

    @extend_schema(request=AnularBoletaSerializer, responses=DocumentoTributarioSerializer)
    @action(detail=True, methods=["post"])
    def anular(self, request, pk=None):
        serializer = AnularBoletaSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        documento = services.anular(
            self.get_object(), motivo=serializer.validated_data["motivo"]
        )
        return Response(DocumentoTributarioSerializer(documento).data)
