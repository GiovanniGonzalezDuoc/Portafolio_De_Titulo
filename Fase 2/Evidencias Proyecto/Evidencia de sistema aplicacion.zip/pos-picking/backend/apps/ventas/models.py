"""
Modelos de ventas (POS).

Una ``Venta`` confirmada es inmutable salvo su anulación. Los montos están en
CLP (enteros) con **IVA incluido** en los precios; la venta guarda el desglose
neto / IVA / exento para la boleta (Etapa 10).

``caja`` es obligatoria a nivel de negocio (el POS exige una caja abierta), pero
el FK admite ``null`` para no romper ventas históricas. La Etapa 10 agrega la
emisión de la boleta electrónica.
"""

from __future__ import annotations

from decimal import Decimal

from django.conf import settings
from django.db import models


class EstadoVenta(models.TextChoices):
    PAGADA = "PAGADA", "Pagada"
    ANULADA = "ANULADA", "Anulada"


class MedioPago(models.TextChoices):
    EFECTIVO = "EFECTIVO", "Efectivo"
    DEBITO = "DEBITO", "Débito"
    CREDITO = "CREDITO", "Crédito"
    TRANSFERENCIA = "TRANSFERENCIA", "Transferencia"


class Venta(models.Model):
    folio = models.CharField("folio", max_length=20, unique=True)
    caja = models.ForeignKey(
        "caja.Caja", on_delete=models.PROTECT, related_name="ventas",
        null=True, blank=True,
    )
    vendedor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="ventas"
    )
    estado = models.CharField(
        "estado", max_length=10, choices=EstadoVenta.choices, default=EstadoVenta.PAGADA
    )
    es_mayorista = models.BooleanField("precio mayorista", default=False)

    neto = models.PositiveIntegerField("neto (CLP)", default=0)
    iva = models.PositiveIntegerField("IVA (CLP)", default=0)
    exento = models.PositiveIntegerField("exento (CLP)", default=0)
    descuento_total = models.PositiveIntegerField("descuento total (CLP)", default=0)
    total = models.PositiveIntegerField("total documento (CLP)", default=0)
    redondeo = models.SmallIntegerField("redondeo efectivo (CLP)", default=0)

    anulada_por = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    anulada_en = models.DateTimeField("anulada en", null=True, blank=True)
    motivo_anulacion = models.CharField("motivo de anulación", max_length=200, blank=True)

    creado_en = models.DateTimeField("creado en", auto_now_add=True)

    class Meta:
        verbose_name = "venta"
        verbose_name_plural = "ventas"
        ordering = ["-creado_en", "-id"]
        indexes = [
            models.Index(fields=["vendedor", "creado_en"]),
            models.Index(fields=["estado", "creado_en"]),
            models.Index(fields=["creado_en"]),
        ]

    def __str__(self) -> str:
        return f"{self.folio} — ${self.total} ({self.get_estado_display()})"

    @property
    def total_a_cobrar(self) -> int:
        return self.total + self.redondeo


class LineaVenta(models.Model):
    venta = models.ForeignKey(Venta, on_delete=models.CASCADE, related_name="lineas")
    producto = models.ForeignKey(
        "catalogo.Producto", on_delete=models.PROTECT, related_name="lineas_venta"
    )
    descripcion = models.CharField("descripción", max_length=150)
    cantidad = models.DecimalField("cantidad", max_digits=12, decimal_places=3)
    precio_unitario = models.PositiveIntegerField("precio unitario (CLP, IVA incl.)")
    descuento_monto = models.PositiveIntegerField("descuento (CLP)", default=0)
    afecto_iva = models.BooleanField("afecto a IVA", default=True)
    total_linea = models.PositiveIntegerField("total de la línea (CLP)")

    class Meta:
        verbose_name = "línea de venta"
        verbose_name_plural = "líneas de venta"
        constraints = [
            models.CheckConstraint(condition=models.Q(cantidad__gt=0), name="linea_venta_cantidad_positiva"),
        ]
        indexes = [models.Index(fields=["producto", "venta"])]

    def __str__(self) -> str:
        return f"{self.descripcion} x{self.cantidad}"


class PagoVenta(models.Model):
    venta = models.ForeignKey(Venta, on_delete=models.CASCADE, related_name="pagos")
    medio = models.CharField("medio de pago", max_length=15, choices=MedioPago.choices)
    monto = models.PositiveIntegerField("monto (CLP)")
    referencia = models.CharField("referencia", max_length=40, blank=True)

    class Meta:
        verbose_name = "pago"
        verbose_name_plural = "pagos"
        constraints = [
            models.CheckConstraint(condition=models.Q(monto__gt=0), name="pago_monto_positivo"),
        ]

    def __str__(self) -> str:
        return f"{self.get_medio_display()}: ${self.monto}"


class AutorizacionDescuento(models.Model):
    venta = models.ForeignKey(
        Venta, on_delete=models.CASCADE, related_name="autorizaciones_descuento"
    )
    linea_venta = models.ForeignKey(
        LineaVenta, on_delete=models.CASCADE, related_name="autorizaciones",
        null=True, blank=True,
    )
    solicitado_por = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="descuentos_solicitados"
    )
    autorizado_por = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="descuentos_autorizados"
    )
    porcentaje = models.DecimalField("porcentaje", max_digits=5, decimal_places=2)
    monto = models.PositiveIntegerField("monto (CLP)")
    creado_en = models.DateTimeField("creado en", auto_now_add=True)

    class Meta:
        verbose_name = "autorización de descuento"
        verbose_name_plural = "autorizaciones de descuento"

    def __str__(self) -> str:
        return f"Autorización {self.porcentaje}% por {self.autorizado_por_id}"


class DevolucionVenta(models.Model):
    venta = models.ForeignKey(Venta, on_delete=models.PROTECT, related_name="devoluciones")
    motivo = models.CharField("motivo", max_length=200)
    autorizada_por = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="devoluciones_venta"
    )
    total_devuelto = models.PositiveIntegerField("total devuelto (CLP)", default=0)
    creado_en = models.DateTimeField("creado en", auto_now_add=True)

    class Meta:
        verbose_name = "devolución de venta"
        verbose_name_plural = "devoluciones de venta"

    def __str__(self) -> str:
        return f"Devolución de {self.venta.folio}"


class LineaDevolucion(models.Model):
    devolucion = models.ForeignKey(
        DevolucionVenta, on_delete=models.CASCADE, related_name="lineas"
    )
    linea_venta = models.ForeignKey(
        LineaVenta, on_delete=models.PROTECT, related_name="lineas_devolucion"
    )
    cantidad = models.DecimalField("cantidad", max_digits=12, decimal_places=3, default=Decimal("0"))
    movimiento = models.ForeignKey(
        "inventario.MovimientoInventario", on_delete=models.PROTECT, null=True, blank=True,
        related_name="+",
    )

    class Meta:
        verbose_name = "línea de devolución"
        verbose_name_plural = "líneas de devolución"
        constraints = [
            models.CheckConstraint(condition=models.Q(cantidad__gt=0), name="linea_devolucion_cantidad_positiva"),
        ]

    def __str__(self) -> str:
        return f"{self.linea_venta.descripcion} x{self.cantidad}"
