"""Serializers del POS."""

from __future__ import annotations

from decimal import Decimal

from drf_spectacular.utils import extend_schema_field
from rest_framework import serializers

from apps.catalogo.models import Producto

from .models import (
    DevolucionVenta,
    LineaVenta,
    MedioPago,
    PagoVenta,
    Venta,
)


# ─── Lectura ────────────────────────────────────────────────
class LineaVentaSerializer(serializers.ModelSerializer):
    producto = serializers.SlugRelatedField(slug_field="sku", read_only=True)

    class Meta:
        model = LineaVenta
        fields = [
            "id", "producto", "descripcion", "cantidad", "precio_unitario",
            "descuento_monto", "afecto_iva", "total_linea",
        ]


class PagoVentaSerializer(serializers.ModelSerializer):
    class Meta:
        model = PagoVenta
        fields = ["id", "medio", "monto", "referencia"]


class DocumentoResumenSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    estado = serializers.CharField()
    estado_display = serializers.CharField(source="get_estado_display")
    folio = serializers.IntegerField(allow_null=True)
    url_pdf = serializers.SerializerMethodField()

    def get_url_pdf(self, obj) -> str:
        return getattr(getattr(obj, "respuesta", None), "url_pdf", "") or ""


class VentaSerializer(serializers.ModelSerializer):
    vendedor = serializers.CharField(source="vendedor.username", read_only=True)
    caja = serializers.CharField(source="caja.codigo", read_only=True, default=None)
    estado_display = serializers.CharField(source="get_estado_display", read_only=True)
    total_a_cobrar = serializers.IntegerField(read_only=True)
    lineas = LineaVentaSerializer(many=True, read_only=True)
    pagos = PagoVentaSerializer(many=True, read_only=True)
    documento = serializers.SerializerMethodField()

    class Meta:
        model = Venta
        fields = [
            "id", "folio", "caja", "vendedor", "estado", "estado_display", "es_mayorista",
            "neto", "iva", "exento", "descuento_total", "total", "redondeo",
            "total_a_cobrar", "motivo_anulacion", "creado_en", "lineas", "pagos",
            "documento",
        ]
        read_only_fields = fields

    @extend_schema_field(DocumentoResumenSerializer)
    def get_documento(self, obj):
        doc = getattr(obj, "documento", None)
        if doc is None:
            return None
        return DocumentoResumenSerializer(doc).data


# ─── Escritura ──────────────────────────────────────────────
class _ItemSerializer(serializers.Serializer):
    producto = serializers.SlugRelatedField(slug_field="sku", queryset=Producto.objects.all())
    cantidad = serializers.DecimalField(max_digits=12, decimal_places=3, min_value=Decimal("0.001"))
    descuento_monto = serializers.IntegerField(min_value=0, required=False, default=0)
    # None → la línea sigue el flag de la venta (`es_mayorista`); True/False lo
    # fuerza solo para ese producto.
    mayorista = serializers.BooleanField(required=False, allow_null=True, default=None)


class _PagoSerializer(serializers.Serializer):
    medio = serializers.ChoiceField(choices=MedioPago.choices)
    monto = serializers.IntegerField(min_value=1)
    referencia = serializers.CharField(max_length=40, required=False, allow_blank=True, default="")


class _AutorizacionSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField()


class CalcularVentaSerializer(serializers.Serializer):
    items = _ItemSerializer(many=True, allow_empty=False)
    es_mayorista = serializers.BooleanField(required=False, default=False)
    hay_efectivo = serializers.BooleanField(required=False, default=False)


class ConfirmarVentaSerializer(serializers.Serializer):
    items = _ItemSerializer(many=True, allow_empty=False)
    pagos = _PagoSerializer(many=True, allow_empty=False)
    es_mayorista = serializers.BooleanField(required=False, default=False)
    autorizacion = _AutorizacionSerializer(required=False)


class AnularVentaSerializer(serializers.Serializer):
    motivo = serializers.CharField(max_length=200)


class DevolucionVentaSerializer(serializers.ModelSerializer):
    venta = serializers.SlugRelatedField(slug_field="folio", read_only=True)
    autorizada_por = serializers.CharField(source="autorizada_por.username", read_only=True)

    class Meta:
        model = DevolucionVenta
        fields = ["id", "venta", "motivo", "autorizada_por", "total_devuelto", "creado_en"]
