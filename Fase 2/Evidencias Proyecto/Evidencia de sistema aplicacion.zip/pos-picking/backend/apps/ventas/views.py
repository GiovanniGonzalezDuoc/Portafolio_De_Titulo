"""ViewSets del POS."""

from __future__ import annotations

import django_filters as filters
from drf_spectacular.utils import extend_schema
from rest_framework import mixins, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.usuarios.permissions import PermisoPorAccion

from . import services
from .models import Venta


class VentaFilter(filters.FilterSet):
    documento__estado = filters.CharFilter(
        field_name="documento__estado", lookup_expr="iexact"
    )
    sin_boleta = filters.BooleanFilter(method="_sin_boleta")

    class Meta:
        model = Venta
        fields = ["estado", "vendedor__username", "es_mayorista"]

    def _sin_boleta(self, queryset, name, value):
        return queryset.filter(documento__isnull=True) if value else queryset
from .serializers import (
    AnularVentaSerializer,
    CalcularVentaSerializer,
    ConfirmarVentaSerializer,
    VentaSerializer,
)


class VentaViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = Venta.objects.select_related(
        "vendedor", "documento", "documento__respuesta"
    ).prefetch_related("lineas__producto", "pagos")
    serializer_class = VentaSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        "list": "ventas.ver",
        "retrieve": "ventas.ver",
        "create": "ventas.crear",
        "calcular": "ventas.crear",
        "anular": "ventas.anular",
    }
    filterset_class = VentaFilter
    search_fields = ["folio"]
    ordering_fields = ["creado_en", "total"]

    def get_queryset(self):
        qs = super().get_queryset()
        # Solo se ven las ventas propias, salvo que se tenga la vista completa
        # del negocio. No se basa en el nombre del rol (frágil): cualquier rol
        # operativo sin `dashboard.ver_completo` queda acotado a lo suyo.
        u = self.request.user
        if (
            u.is_authenticated
            and not u.is_superuser
            and not u.tiene_permiso("dashboard.ver_completo")
        ):
            qs = qs.filter(vendedor=u)
        return qs

    @extend_schema(request=CalcularVentaSerializer, responses=None)
    @action(detail=False, methods=["post"])
    def calcular(self, request):
        """Calcula los totales de un carrito sin registrar la venta."""
        entrada = CalcularVentaSerializer(data=request.data)
        entrada.is_valid(raise_exception=True)
        d = entrada.validated_data
        calc = services.calcular(
            items=[
                {"producto": it["producto"], "cantidad": it["cantidad"],
                 "descuento_monto": it.get("descuento_monto", 0),
                 "mayorista": it.get("mayorista")}
                for it in d["items"]
            ],
            es_mayorista=d["es_mayorista"],
            hay_efectivo=d["hay_efectivo"],
        )
        return Response(
            {
                "neto": calc.neto,
                "iva": calc.iva,
                "exento": calc.exento,
                "descuento_total": calc.descuento_total,
                "total": calc.total,
                "redondeo": calc.redondeo,
                "total_a_cobrar": calc.total_a_cobrar,
                "lineas": [
                    {
                        "producto": lc.producto.sku,
                        "descripcion": lc.descripcion,
                        "cantidad": str(lc.cantidad),
                        "precio_unitario": lc.precio_unitario,
                        "descuento_monto": lc.descuento_monto,
                        "descuento_pct": str(lc.descuento_pct),
                        "afecto_iva": lc.afecto_iva,
                        "total_linea": lc.total_linea,
                    }
                    for lc in calc.lineas
                ],
                "requiere_autorizacion_descuento": bool(calc.lineas_sobre_tope),
            }
        )

    @extend_schema(request=ConfirmarVentaSerializer, responses=VentaSerializer)
    def create(self, request, *args, **kwargs):
        entrada = ConfirmarVentaSerializer(data=request.data)
        entrada.is_valid(raise_exception=True)
        d = entrada.validated_data
        venta = services.confirmar_venta(
            items=[
                {"producto": it["producto"], "cantidad": it["cantidad"],
                 "descuento_monto": it.get("descuento_monto", 0),
                 "mayorista": it.get("mayorista")}
                for it in d["items"]
            ],
            pagos=[dict(p) for p in d["pagos"]],
            vendedor=request.user,
            es_mayorista=d["es_mayorista"],
            autorizacion=dict(d["autorizacion"]) if d.get("autorizacion") else None,
        )
        return Response(VentaSerializer(venta).data, status=status.HTTP_201_CREATED)

    @extend_schema(request=AnularVentaSerializer, responses=VentaSerializer)
    @action(detail=True, methods=["post"])
    def anular(self, request, pk=None):
        serializer = AnularVentaSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        venta = services.anular_venta(
            self.get_object(), usuario=request.user, motivo=serializer.validated_data["motivo"]
        )
        return Response(VentaSerializer(venta).data)
