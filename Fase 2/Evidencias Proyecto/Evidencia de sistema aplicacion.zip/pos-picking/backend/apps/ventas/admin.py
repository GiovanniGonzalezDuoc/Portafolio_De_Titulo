from django.contrib import admin

from .models import (
    AutorizacionDescuento,
    DevolucionVenta,
    LineaVenta,
    PagoVenta,
    Venta,
)


class LineaVentaInline(admin.TabularInline):
    model = LineaVenta
    extra = 0
    readonly_fields = [f.name for f in LineaVenta._meta.fields]
    can_delete = False


class PagoVentaInline(admin.TabularInline):
    model = PagoVenta
    extra = 0
    readonly_fields = ["medio", "monto", "referencia"]
    can_delete = False


@admin.register(Venta)
class VentaAdmin(admin.ModelAdmin):
    list_display = ["folio", "creado_en", "vendedor", "total", "estado", "es_mayorista"]
    list_filter = ["estado", "es_mayorista"]
    search_fields = ["folio"]
    inlines = [LineaVentaInline, PagoVentaInline]
    readonly_fields = [f.name for f in Venta._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(DevolucionVenta)
class DevolucionVentaAdmin(admin.ModelAdmin):
    list_display = ["venta", "motivo", "autorizada_por", "total_devuelto", "creado_en"]
    readonly_fields = ["venta", "motivo", "autorizada_por", "total_devuelto"]


@admin.register(AutorizacionDescuento)
class AutorizacionDescuentoAdmin(admin.ModelAdmin):
    list_display = ["venta", "solicitado_por", "autorizado_por", "porcentaje", "monto", "creado_en"]
