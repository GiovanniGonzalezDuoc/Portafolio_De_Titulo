"""Tests de la API del POS."""

from decimal import Decimal

import pytest

from apps.inventario import services as inventario

from .factories import producto_con_stock

pytestmark = pytest.mark.django_db


def test_calcular_endpoint(api_vendedor, vendedor):
    p = producto_con_stock(vendedor, cantidad=10, precio_venta=1190)
    r = api_vendedor.post(
        "/api/v1/ventas/calcular/",
        {"items": [{"producto": p.sku, "cantidad": "2"}], "hay_efectivo": True},
        format="json",
    )
    assert r.status_code == 200
    assert r.data["total"] == 2380
    assert r.data["neto"] == 2000
    assert r.data["total_a_cobrar"] % 10 == 0


def test_calcular_respeta_el_mayorista_por_linea(api_vendedor, vendedor):
    p = producto_con_stock(
        vendedor, cantidad=10, precio_venta=1000, precio_mayorista=700, afecto_iva=False
    )
    base = {"producto": p.sku, "cantidad": "1"}

    # Sin nada: precio normal.
    r = api_vendedor.post("/api/v1/ventas/calcular/", {"items": [base]}, format="json")
    assert r.data["total"] == 1000

    # La línea fuerza el mayorista aunque la venta no lo sea.
    r = api_vendedor.post(
        "/api/v1/ventas/calcular/",
        {"items": [{**base, "mayorista": True}], "es_mayorista": False},
        format="json",
    )
    assert r.data["total"] == 700

    # La línea se excluye del mayorista general de la venta.
    r = api_vendedor.post(
        "/api/v1/ventas/calcular/",
        {"items": [{**base, "mayorista": False}], "es_mayorista": True},
        format="json",
    )
    assert r.data["total"] == 1000


def test_confirmar_venta_por_api(api_vendedor, vendedor):
    p = producto_con_stock(vendedor, cantidad=10, precio_venta=1000)
    r = api_vendedor.post(
        "/api/v1/ventas/",
        {
            "items": [{"producto": p.sku, "cantidad": "3"}],
            "pagos": [{"medio": "DEBITO", "monto": 3000}],
        },
        format="json",
    )
    assert r.status_code == 201, r.data
    assert inventario.stock_de(p) == Decimal("7")
    assert r.data["folio"].startswith("V-")


def test_producto_inexistente_da_400(api_vendedor):
    r = api_vendedor.post(
        "/api/v1/ventas/",
        {"items": [{"producto": "NO-EXISTE", "cantidad": "1"}],
         "pagos": [{"medio": "DEBITO", "monto": 1}]},
        format="json",
    )
    assert r.status_code == 400


def test_stock_insuficiente_da_409(api_vendedor, vendedor):
    p = producto_con_stock(vendedor, cantidad=1, precio_venta=1000)
    r = api_vendedor.post(
        "/api/v1/ventas/",
        {"items": [{"producto": p.sku, "cantidad": "5"}],
         "pagos": [{"medio": "DEBITO", "monto": 5000}]},
        format="json",
    )
    assert r.status_code == 409
    assert r.data["error"]["codigo"] == "stock_insuficiente"


def test_pagos_incorrectos_da_400(api_vendedor, vendedor):
    p = producto_con_stock(vendedor, cantidad=10, precio_venta=1000)
    r = api_vendedor.post(
        "/api/v1/ventas/",
        {"items": [{"producto": p.sku, "cantidad": "1"}],
         "pagos": [{"medio": "DEBITO", "monto": 500}]},
        format="json",
    )
    assert r.status_code == 400
    assert r.data["error"]["codigo"] == "pago_invalido"


def test_descuento_sobre_tope_sin_autorizacion_da_403(api_vendedor, vendedor):
    p = producto_con_stock(vendedor, cantidad=10, precio_venta=1000)
    r = api_vendedor.post(
        "/api/v1/ventas/",
        {"items": [{"producto": p.sku, "cantidad": "1", "descuento_monto": 300}],
         "pagos": [{"medio": "DEBITO", "monto": 700}]},
        format="json",
    )
    assert r.status_code == 403
    assert r.data["error"]["codigo"] == "descuento_no_autorizado"


def test_vendedor_solo_ve_sus_ventas(api, vendedor, admin, rol_vendedor):
    from apps.caja.services import abrir_caja
    from apps.usuarios.tests.factories import UsuarioFactory
    otro = UsuarioFactory(rol=rol_vendedor, username="otro_vendedor")
    abrir_caja(usuario=otro, monto_inicial=10000)

    p = producto_con_stock(admin, cantidad=20, precio_venta=1000)
    from apps.ventas import services
    services.confirmar_venta(items=[{"producto": p, "cantidad": Decimal("1"), "descuento_monto": 0}],
                             pagos=[{"medio": "DEBITO", "monto": 1000}], vendedor=vendedor)
    services.confirmar_venta(items=[{"producto": p, "cantidad": Decimal("1"), "descuento_monto": 0}],
                             pagos=[{"medio": "DEBITO", "monto": 1000}], vendedor=otro)

    api.force_authenticate(vendedor)
    r = api.get("/api/v1/ventas/")
    assert r.data["conteo"] == 1

    api.force_authenticate(admin)
    r = api.get("/api/v1/ventas/")
    assert r.data["conteo"] == 2


def test_anular_requiere_permiso(api_vendedor, vendedor):
    p = producto_con_stock(vendedor, cantidad=10, precio_venta=1000)
    r = api_vendedor.post(
        "/api/v1/ventas/",
        {"items": [{"producto": p.sku, "cantidad": "1"}],
         "pagos": [{"medio": "DEBITO", "monto": 1000}]},
        format="json",
    )
    venta_id = r.data["id"]
    # vendedor no tiene ventas.anular
    r = api_vendedor.post(f"/api/v1/ventas/{venta_id}/anular/", {"motivo": "x"}, format="json")
    assert r.status_code == 403


def test_admin_anula_venta(api_admin, admin):
    p = producto_con_stock(admin, cantidad=10, precio_venta=1000)
    from apps.ventas import services
    venta = services.confirmar_venta(
        items=[{"producto": p, "cantidad": Decimal("2"), "descuento_monto": 0}],
        pagos=[{"medio": "DEBITO", "monto": 2000}], vendedor=admin,
    )
    r = api_admin.post(f"/api/v1/ventas/{venta.id}/anular/", {"motivo": "error de digitación"}, format="json")
    assert r.status_code == 200
    assert r.data["estado"] == "ANULADA"
    assert inventario.stock_de(p) == Decimal("10")


def test_venta_registrada_aparece_en_movimientos(api_admin, admin):
    p = producto_con_stock(admin, cantidad=10, precio_venta=1000, sku="MOV-V")
    from apps.ventas import services
    venta = services.confirmar_venta(
        items=[{"producto": p, "cantidad": Decimal("3"), "descuento_monto": 0}],
        pagos=[{"medio": "DEBITO", "monto": 3000}], vendedor=admin,
    )
    r = api_admin.get("/api/v1/inventario/movimientos/?producto=MOV-V&tipo=VENTA")
    assert r.data["conteo"] == 1
    assert r.data["resultados"][0]["doc_id"] == venta.id
