"""Helpers para tests de ventas."""

from decimal import Decimal

from apps.catalogo.tests.factories import ProductoFactory
from apps.inventario import services as inventario
from apps.inventario.models import Ubicacion


def producto_con_stock(usuario, *, cantidad=100, **kwargs):
    """Crea un producto y le carga stock inicial en la ubicación principal."""
    producto = ProductoFactory(**kwargs)
    inventario.entrada(
        producto=producto, cantidad=cantidad, usuario=usuario,
        ubicacion=Ubicacion.principal(), motivo="stock inicial test",
    )
    return producto


def item(producto, cantidad, descuento=0):
    return {"producto": producto, "cantidad": Decimal(str(cantidad)), "descuento_monto": descuento}
