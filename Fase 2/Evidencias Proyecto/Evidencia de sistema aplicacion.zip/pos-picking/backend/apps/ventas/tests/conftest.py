"""Fixtures locales de los tests de ventas."""

import pytest


@pytest.fixture(autouse=True)
def _abrir_cajas(request):
    """
    Abre una caja para los fixtures de usuario que el test utilice
    (el POS exige caja abierta desde la Etapa 9).
    """
    if "db" not in request.fixturenames and "datos_seguridad" not in request.fixturenames:
        yield
        return

    from apps.caja.services import abrir_caja, caja_abierta_de

    for nombre in ("vendedor", "admin", "bodeguero"):
        if nombre in request.fixturenames:
            usuario = request.getfixturevalue(nombre)
            if caja_abierta_de(usuario) is None:
                abrir_caja(usuario=usuario, monto_inicial=50000)
    yield
