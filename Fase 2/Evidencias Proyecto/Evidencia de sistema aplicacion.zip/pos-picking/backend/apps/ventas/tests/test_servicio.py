"""Tests del servicio del POS (cálculo, confirmación, anulación)."""

from decimal import Decimal

import pytest

from apps.catalogo.tests.factories import ProductoFactory
from apps.core.exceptions import ConflictoEstado
from apps.inventario import services as inventario
from apps.inventario.models import MovimientoInventario, TipoMovimiento
from apps.ventas import services
from apps.ventas.models import EstadoVenta, LineaVenta, PagoVenta, Venta

from .factories import item, producto_con_stock

pytestmark = pytest.mark.django_db


# ─── Cálculo de totales ─────────────────────────────────────
def test_calculo_iva_incluido():
    prod = ProductoFactory(precio_venta=1190, afecto_iva=True)  # 1000 neto + 190 IVA
    calc = services.calcular(items=[{"producto": prod, "cantidad": Decimal("1"), "descuento_monto": 0}])
    assert calc.total == 1190
    assert calc.neto == 1000
    assert calc.iva == 190


def test_calculo_producto_exento():

    prod = ProductoFactory(precio_venta=1000, afecto_iva=False)
    calc = services.calcular(items=[{"producto": prod, "cantidad": Decimal("2"), "descuento_monto": 0}])
    assert calc.exento == 2000
    assert calc.iva == 0
    assert calc.total == 2000


def test_calculo_con_redondeo_efectivo():

    prod = ProductoFactory(precio_venta=1234, afecto_iva=True)
    calc = services.calcular(
        items=[{"producto": prod, "cantidad": Decimal("1"), "descuento_monto": 0}],
        hay_efectivo=True,
    )
    assert calc.total == 1234
    assert calc.total_a_cobrar % 10 == 0
    assert calc.redondeo in (-4, 6)  # 1234 -> 1230


def test_calculo_multiples_lineas_y_descuento():

    p1 = ProductoFactory(precio_venta=1000, afecto_iva=True)
    p2 = ProductoFactory(precio_venta=500, afecto_iva=True)
    calc = services.calcular(items=[
        {"producto": p1, "cantidad": Decimal("2"), "descuento_monto": 200},
        {"producto": p2, "cantidad": Decimal("3"), "descuento_monto": 0},
    ])
    # (2000-200) + 1500 = 3300 afecto
    assert calc.total == 3300
    assert calc.descuento_total == 200


# ─── Confirmar venta ────────────────────────────────────────
def test_venta_correcta_descuenta_stock_y_registra_movimientos(vendedor):
    prod = producto_con_stock(vendedor, cantidad=50, precio_venta=1190)
    venta = services.confirmar_venta(
        items=[item(prod, 3)],
        pagos=[{"medio": "DEBITO", "monto": 3570}],
        vendedor=vendedor,
    )
    assert venta.estado == EstadoVenta.PAGADA
    assert venta.folio.startswith("V-")
    assert inventario.stock_de(prod) == Decimal("47")
    mov = MovimientoInventario.objects.get(doc_tipo="venta", doc_id=venta.id)
    assert mov.tipo == TipoMovimiento.VENTA and mov.cantidad == Decimal("-3")
    assert PagoVenta.objects.filter(venta=venta).count() == 1


def test_venta_multiples_productos(vendedor):
    p1 = producto_con_stock(vendedor, cantidad=20, precio_venta=1000, afecto_iva=True)
    p2 = producto_con_stock(vendedor, cantidad=20, precio_venta=2000, afecto_iva=True)
    venta = services.confirmar_venta(
        items=[item(p1, 2), item(p2, 1)],
        pagos=[{"medio": "TRANSFERENCIA", "monto": 4000}],
        vendedor=vendedor,
    )
    assert venta.total == 4000
    assert LineaVenta.objects.filter(venta=venta).count() == 2
    assert inventario.stock_de(p1) == Decimal("18")
    assert inventario.stock_de(p2) == Decimal("19")


def test_venta_producto_inactivo_falla(vendedor):
    prod = producto_con_stock(vendedor, cantidad=10)
    prod.activo = False
    prod.save()
    with pytest.raises(services.VentaError):
        services.confirmar_venta(
            items=[item(prod, 1)], pagos=[{"medio": "EFECTIVO", "monto": 1000}], vendedor=vendedor
        )


def test_venta_sin_stock_falla_y_no_persiste_nada(vendedor):
    prod = producto_con_stock(vendedor, cantidad=2, precio_venta=1000)
    with pytest.raises(inventario.StockInsuficiente):
        services.confirmar_venta(
            items=[item(prod, 5)], pagos=[{"medio": "DEBITO", "monto": 5000}], vendedor=vendedor
        )
    assert Venta.objects.count() == 0
    assert inventario.stock_de(prod) == Decimal("2")
    assert not MovimientoInventario.objects.filter(tipo=TipoMovimiento.VENTA).exists()


def test_venta_es_atomica_si_una_linea_no_tiene_stock(vendedor):
    p1 = producto_con_stock(vendedor, cantidad=100, precio_venta=1000)
    p2 = producto_con_stock(vendedor, cantidad=1, precio_venta=1000)
    with pytest.raises(inventario.StockInsuficiente):
        services.confirmar_venta(
            items=[item(p1, 5), item(p2, 10)],
            pagos=[{"medio": "DEBITO", "monto": 15000}],
            vendedor=vendedor,
        )
    assert Venta.objects.count() == 0
    assert inventario.stock_de(p1) == Decimal("100")  # no se descontó


def test_pagos_que_no_cuadran_fallan(vendedor):
    prod = producto_con_stock(vendedor, cantidad=10, precio_venta=1000)
    with pytest.raises(services.PagoInvalido):
        services.confirmar_venta(
            items=[item(prod, 1)], pagos=[{"medio": "DEBITO", "monto": 900}], vendedor=vendedor
        )


def test_pago_mixto_cuadra(vendedor):
    prod = producto_con_stock(vendedor, cantidad=10, precio_venta=1000)
    venta = services.confirmar_venta(
        items=[item(prod, 3)],
        pagos=[{"medio": "EFECTIVO", "monto": 2000}, {"medio": "DEBITO", "monto": 1000}],
        vendedor=vendedor,
    )
    # 3000 total, con efectivo -> redondeo a 3000 (ya múltiplo de 10)
    assert venta.total_a_cobrar == 3000


# ─── Descuentos y autorización ─────────────────────────────
def test_descuento_bajo_el_tope_no_requiere_autorizacion(vendedor):
    prod = producto_con_stock(vendedor, cantidad=10, precio_venta=1000)
    # 3% de descuento (tope vendedor = 5%)
    venta = services.confirmar_venta(
        items=[item(prod, 1, descuento=30)],
        pagos=[{"medio": "DEBITO", "monto": 970}],
        vendedor=vendedor,
    )
    assert venta.descuento_total == 30


def test_descuento_sobre_el_tope_sin_autorizacion_falla(vendedor):
    prod = producto_con_stock(vendedor, cantidad=10, precio_venta=1000)
    with pytest.raises(services.DescuentoNoAutorizado):
        services.confirmar_venta(
            items=[item(prod, 1, descuento=200)],  # 20%
            pagos=[{"medio": "DEBITO", "monto": 800}],
            vendedor=vendedor,
        )


def test_descuento_sobre_el_tope_con_autorizacion_valida(vendedor, admin):
    admin.set_password("clave-admin-123")
    admin.save()
    prod = producto_con_stock(vendedor, cantidad=10, precio_venta=1000)
    venta = services.confirmar_venta(
        items=[item(prod, 1, descuento=200)],
        pagos=[{"medio": "DEBITO", "monto": 800}],
        vendedor=vendedor,
        autorizacion={"username": admin.username, "password": "clave-admin-123"},
    )
    assert venta.autorizaciones_descuento.count() == 1
    assert venta.autorizaciones_descuento.first().autorizado_por == admin


# ─── Anulación ─────────────────────────────────────────────
def test_anular_venta_reingresa_stock(vendedor, admin):
    prod = producto_con_stock(vendedor, cantidad=10, precio_venta=1000)
    venta = services.confirmar_venta(
        items=[item(prod, 4)], pagos=[{"medio": "DEBITO", "monto": 4000}], vendedor=vendedor
    )
    assert inventario.stock_de(prod) == Decimal("6")

    services.anular_venta(venta, usuario=admin, motivo="cliente se arrepintió")
    venta.refresh_from_db()
    assert venta.estado == EstadoVenta.ANULADA
    assert inventario.stock_de(prod) == Decimal("10")
    mov = MovimientoInventario.objects.filter(tipo=TipoMovimiento.DEVOLUCION, producto=prod).first()
    assert mov is not None and mov.cantidad == Decimal("4")


def test_no_se_puede_anular_dos_veces(vendedor, admin):
    prod = producto_con_stock(vendedor, cantidad=10, precio_venta=1000)
    venta = services.confirmar_venta(
        items=[item(prod, 1)], pagos=[{"medio": "DEBITO", "monto": 1000}], vendedor=vendedor
    )
    services.anular_venta(venta, usuario=admin, motivo="x")
    with pytest.raises(ConflictoEstado):
        services.anular_venta(venta, usuario=admin, motivo="x")


def test_no_se_anula_venta_de_otro_dia(vendedor, admin):
    from freezegun import freeze_time
    prod = producto_con_stock(vendedor, cantidad=10, precio_venta=1000)
    with freeze_time("2026-01-01 10:00:00"):
        venta = services.confirmar_venta(
            items=[item(prod, 1)], pagos=[{"medio": "DEBITO", "monto": 1000}], vendedor=vendedor
        )
    with freeze_time("2026-01-02 10:00:00"), pytest.raises(ConflictoEstado):
        services.anular_venta(venta, usuario=admin, motivo="tarde")
