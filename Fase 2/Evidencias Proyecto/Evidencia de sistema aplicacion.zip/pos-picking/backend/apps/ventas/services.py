"""
Lógica de negocio del POS.

- ``calcular``: calcula totales de un carrito sin persistir nada (para el
  preview del POS).
- ``confirmar_venta``: operación transaccional que crea la venta, descuenta el
  stock (movimiento tipo VENTA) y registra los pagos. Controla la concurrencia
  a través del ``select_for_update`` del servicio de inventario.
- ``anular_venta``: anulación el mismo día; reingresa el stock (DEVOLUCION).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal

from django.contrib.auth import authenticate, get_user_model
from django.db import transaction
from django.utils import timezone

from apps.caja import services as caja_services
from apps.core.exceptions import ConflictoEstado, ErrorDominio
from apps.core.models import ParametroSistema, Secuencia
from apps.inventario import services as inventario
from apps.inventario.models import TipoMovimiento

from .models import (
    AutorizacionDescuento,
    DevolucionVenta,
    EstadoVenta,
    LineaDevolucion,
    LineaVenta,
    MedioPago,
    PagoVenta,
    Venta,
)

logger = logging.getLogger("pos.ventas")
Usuario = get_user_model()

DOC_TIPO_VENTA = "venta"
DOC_TIPO_DEVOLUCION = "devolucion_venta"
PERMISO_AUTORIZAR_DESCUENTO = "ventas.autorizar_descuento"


class VentaError(ErrorDominio):
    codigo = "venta_error"


class DescuentoNoAutorizado(ErrorDominio):
    codigo = "descuento_no_autorizado"
    http_status = 403


class PagoInvalido(ErrorDominio):
    codigo = "pago_invalido"


def _entero(valor) -> int:
    return int(Decimal(str(valor)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


@dataclass
class LineaCalculada:
    producto: object
    descripcion: str
    cantidad: Decimal
    precio_unitario: int
    descuento_monto: int
    afecto_iva: bool
    bruto: int
    total_linea: int
    descuento_pct: Decimal


@dataclass
class VentaCalculada:
    lineas: list[LineaCalculada]
    neto: int = 0
    iva: int = 0
    exento: int = 0
    descuento_total: int = 0
    total: int = 0
    redondeo: int = 0
    lineas_sobre_tope: list[int] = field(default_factory=list)

    @property
    def total_a_cobrar(self) -> int:
        return self.total + self.redondeo


def calcular(*, items: list[dict], es_mayorista: bool = False, hay_efectivo: bool = False) -> VentaCalculada:
    """
    ``items``: ``[{"producto": <Producto>, "cantidad": Decimal, "descuento_monto": int}]``
    """
    if not items:
        raise VentaError("El carrito está vacío.", codigo="carrito_vacio")

    params = ParametroSistema.get()
    iva_factor = Decimal(1) + params.iva_porcentaje / Decimal(100)
    tope = params.tope_descuento_vendedor_pct

    lineas: list[LineaCalculada] = []
    total_afecto = 0
    exento = 0
    descuento_total = 0
    sobre_tope: list[int] = []

    for idx, item in enumerate(items):
        producto = item["producto"]
        cantidad = Decimal(str(item["cantidad"]))
        if cantidad <= 0:
            raise VentaError("Las cantidades deben ser mayores que cero.", codigo="cantidad_invalida")
        if not producto.activo:
            raise VentaError(
                f"El producto {producto.sku} está inactivo.", codigo="producto_inactivo"
            )

        # El precio vigente considera la oferta del producto (si la hay): una
        # oferta activa manda sobre el precio normal y sobre el mayorista.
        from apps.ofertas.services import precio_vigente

        # Cada línea puede forzar (o excluir) el precio mayorista; si no dice
        # nada, sigue el flag de la venta.
        linea_mayorista = item.get("mayorista")
        if linea_mayorista is None:
            linea_mayorista = es_mayorista
        precio, _oferta = precio_vigente(producto, mayorista=linea_mayorista)
        bruto = _entero(precio * cantidad)
        descuento = int(item.get("descuento_monto") or 0)
        if descuento < 0:
            raise VentaError("El descuento no puede ser negativo.", codigo="descuento_invalido")
        if descuento > bruto:
            raise VentaError(
                f"El descuento de {producto.sku} supera el valor de la línea.",
                codigo="descuento_excesivo",
            )

        total_linea = bruto - descuento
        descuento_pct = (Decimal(descuento) / Decimal(bruto) * 100) if bruto else Decimal(0)
        if descuento_pct > tope:
            sobre_tope.append(idx)

        lineas.append(
            LineaCalculada(
                producto=producto,
                descripcion=producto.nombre,
                cantidad=cantidad,
                precio_unitario=precio,
                descuento_monto=descuento,
                afecto_iva=producto.afecto_iva,
                bruto=bruto,
                total_linea=total_linea,
                descuento_pct=descuento_pct.quantize(Decimal("0.01")),
            )
        )
        descuento_total += descuento
        if producto.afecto_iva:
            total_afecto += total_linea
        else:
            exento += total_linea

    neto = _entero(Decimal(total_afecto) / iva_factor) if total_afecto else 0
    iva = total_afecto - neto
    total = neto + iva + exento

    redondeo = 0
    if hay_efectivo and params.redondeo_efectivo > 1:
        m = params.redondeo_efectivo
        total_redondeado = int(round(total / m) * m)
        redondeo = total_redondeado - total

    return VentaCalculada(
        lineas=lineas, neto=neto, iva=iva, exento=exento,
        descuento_total=descuento_total, total=total, redondeo=redondeo,
        lineas_sobre_tope=sobre_tope,
    )


def _validar_autorizacion_descuento(*, calc: VentaCalculada, vendedor, autorizacion: dict | None):
    """Devuelve el usuario autorizador si corresponde, o None."""
    if not calc.lineas_sobre_tope:
        return None
    if vendedor.tiene_permiso(PERMISO_AUTORIZAR_DESCUENTO):
        return vendedor  # el propio usuario puede autorizar
    if not autorizacion:
        raise DescuentoNoAutorizado(
            "Hay descuentos sobre el tope permitido. Se requiere autorización de un supervisor."
        )
    autorizador = authenticate(
        username=autorizacion.get("username"), password=autorizacion.get("password")
    )
    if autorizador is None or not autorizador.tiene_permiso(PERMISO_AUTORIZAR_DESCUENTO):
        raise DescuentoNoAutorizado("Las credenciales del autorizador no son válidas.")
    return autorizador


def confirmar_venta(
    *,
    items: list[dict],
    pagos: list[dict],
    vendedor,
    es_mayorista: bool = False,
    autorizacion: dict | None = None,
    caja=None,
) -> Venta:
    """
    Confirma la venta (transaccional) y luego intenta emitir la boleta.

    La emisión de la boleta ocurre **después** del commit de la venta y no puede
    dejarla inconsistente: si falla, el documento queda PENDIENTE y lo reintenta
    el comando ``reintentar_dte``.
    """
    from apps.boleta import services as boleta_services

    venta = _confirmar_venta_tx(
        items=items, pagos=pagos, vendedor=vendedor,
        es_mayorista=es_mayorista, autorizacion=autorizacion, caja=caja,
    )
    boleta_services.emitir_seguro(venta.documento)
    venta.refresh_from_db()
    return venta


@transaction.atomic
def _confirmar_venta_tx(
    *,
    items: list[dict],
    pagos: list[dict],
    vendedor,
    es_mayorista: bool = False,
    autorizacion: dict | None = None,
    caja=None,
) -> Venta:
    from apps.boleta import services as boleta_services

    caja = caja or caja_services.caja_abierta_de(vendedor)
    if caja is None:
        raise caja_services.CajaNoAbierta()

    hay_efectivo = any(p["medio"] == MedioPago.EFECTIVO for p in pagos)
    calc = calcular(items=items, es_mayorista=es_mayorista, hay_efectivo=hay_efectivo)

    autorizador = _validar_autorizacion_descuento(
        calc=calc, vendedor=vendedor, autorizacion=autorizacion
    )

    total_pagos = sum(int(p["monto"]) for p in pagos)
    if not pagos or any(int(p["monto"]) <= 0 for p in pagos):
        raise PagoInvalido("Cada pago debe tener un monto mayor que cero.")
    if total_pagos != calc.total_a_cobrar:
        raise PagoInvalido(
            f"Los pagos suman ${total_pagos} y el total a cobrar es ${calc.total_a_cobrar}.",
            detalles={"pagado": total_pagos, "a_cobrar": calc.total_a_cobrar},
        )

    venta = Venta.objects.create(
        folio=Secuencia.folio("venta", "V"),
        caja=caja,
        vendedor=vendedor,
        es_mayorista=es_mayorista,
        neto=calc.neto,
        iva=calc.iva,
        exento=calc.exento,
        descuento_total=calc.descuento_total,
        total=calc.total,
        redondeo=calc.redondeo,
    )

    for lc in calc.lineas:
        LineaVenta.objects.create(
            venta=venta,
            producto=lc.producto,
            descripcion=lc.descripcion,
            cantidad=lc.cantidad,
            precio_unitario=lc.precio_unitario,
            descuento_monto=lc.descuento_monto,
            afecto_iva=lc.afecto_iva,
            total_linea=lc.total_linea,
        )
        inventario.registrar_movimiento(
            producto=lc.producto,
            tipo=TipoMovimiento.VENTA,
            cantidad=lc.cantidad,
            usuario=vendedor,
            motivo=f"Venta {venta.folio}",
            doc_tipo=DOC_TIPO_VENTA,
            doc_id=venta.id,
        )

    medios_usados: list[str] = []
    for p in pagos:
        pago = PagoVenta.objects.create(
            venta=venta,
            medio=p["medio"],
            monto=int(p["monto"]),
            referencia=p.get("referencia", ""),
        )
        medios_usados.append(pago.get_medio_display())

    # Un movimiento de caja por venta (cualquier medio de pago), con el detalle
    # de los medios usados: "Venta V-000012 · Efectivo / Débito".
    caja_services.registrar_venta(
        caja=caja,
        venta=venta,
        monto=venta.total_a_cobrar,
        usuario=vendedor,
        medios=" / ".join(dict.fromkeys(medios_usados)),
    )

    if autorizador and calc.lineas_sobre_tope:
        for idx in calc.lineas_sobre_tope:
            lc = calc.lineas[idx]
            AutorizacionDescuento.objects.create(
                venta=venta,
                solicitado_por=vendedor,
                autorizado_por=autorizador,
                porcentaje=lc.descuento_pct,
                monto=lc.descuento_monto,
            )

    boleta_services.crear_documento_pendiente(venta)

    logger.info(
        "Venta %s confirmada por %s: $%s (%s líneas)",
        venta.folio, vendedor.username, venta.total, len(calc.lineas),
    )
    return venta


@transaction.atomic
def anular_venta(venta: Venta, *, usuario, motivo: str) -> Venta:
    venta = Venta.objects.select_for_update().get(pk=venta.pk)
    if venta.estado != EstadoVenta.PAGADA:
        raise ConflictoEstado("La venta ya está anulada.", codigo="venta_ya_anulada")
    if timezone.localtime(venta.creado_en).date() != timezone.localdate():
        raise ConflictoEstado(
            "Solo se pueden anular ventas del mismo día.", codigo="anulacion_fuera_de_plazo"
        )

    devolucion = DevolucionVenta.objects.create(
        venta=venta, motivo=motivo, autorizada_por=usuario, total_devuelto=venta.total_a_cobrar
    )
    for linea in venta.lineas.select_related("producto"):
        movimiento = inventario.registrar_movimiento(
            producto=linea.producto,
            tipo=TipoMovimiento.DEVOLUCION,
            cantidad=linea.cantidad,
            usuario=usuario,
            motivo=f"Anulación de venta {venta.folio}",
            doc_tipo=DOC_TIPO_DEVOLUCION,
            doc_id=devolucion.id,
        )
        LineaDevolucion.objects.create(
            devolucion=devolucion, linea_venta=linea, cantidad=linea.cantidad,
            movimiento=movimiento,
        )

    venta.estado = EstadoVenta.ANULADA
    venta.anulada_por = usuario
    venta.anulada_en = timezone.now()
    venta.motivo_anulacion = motivo
    venta.save(update_fields=["estado", "anulada_por", "anulada_en", "motivo_anulacion"])

    documento = getattr(venta, "documento", None)
    if documento is not None:
        from apps.boleta import services as boleta_services

        boleta_services.anular(documento, motivo=f"Anulación de venta {venta.folio}: {motivo}")

    logger.info("Venta %s anulada por %s: %s", venta.folio, usuario.username, motivo)
    return venta
