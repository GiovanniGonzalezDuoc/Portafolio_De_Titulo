"""Factories de proveedores."""

import factory

from apps.proveedores.models import Proveedor

_RUTS_VALIDOS = [
    "76192083-9", "77111222-6", "79876543-4", "76543210-3", "77888999-4",
    "78123456-7", "76111000-4", "77222333-1", "79111222-2", "76999888-8",
]


class ProveedorFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Proveedor

    razon_social = factory.Sequence(lambda n: f"Distribuidora {n} SpA")
    rut = factory.Sequence(lambda n: _RUTS_VALIDOS[n % len(_RUTS_VALIDOS)])
    giro = "Comercio al por mayor"
    lead_time_dias = 7
    activo = True
