"""Tests de la API de proveedores."""

from decimal import Decimal

import pytest

from apps.catalogo.tests.factories import ProductoFactory
from apps.proveedores.models import ProductoProveedor, Proveedor

from .factories import ProveedorFactory

pytestmark = pytest.mark.django_db


def test_bodeguero_crea_proveedor(api_bodeguero):
    r = api_bodeguero.post(
        "/api/v1/proveedores/",
        {"razon_social": "Comercial Los Andes", "rut": "76.192.083-9",
         "lead_time_dias": 10},
        format="json",
    )
    assert r.status_code == 201, r.data
    p = Proveedor.objects.get(rut="76192083-9")
    assert p.lead_time_dias == 10


def test_vendedor_no_administra_proveedores(api_vendedor):
    r = api_vendedor.post(
        "/api/v1/proveedores/", {"razon_social": "X", "rut": "76192083-9"}, format="json"
    )
    assert r.status_code == 403


def test_rut_invalido_rechazado(api_bodeguero):
    r = api_bodeguero.post(
        "/api/v1/proveedores/",
        {"razon_social": "X", "rut": "76192083-0"},
        format="json",
    )
    assert r.status_code == 400
    assert r.data["error"]["campo"] == "rut"


def test_rut_duplicado_rechazado(api_bodeguero):
    ProveedorFactory(rut="77111222-6")
    r = api_bodeguero.post(
        "/api/v1/proveedores/",
        {"razon_social": "Otro", "rut": "77.111.222-6"},
        format="json",
    )
    assert r.status_code == 400


def test_delete_desactiva_proveedor(api_bodeguero):
    p = ProveedorFactory()
    r = api_bodeguero.delete(f"/api/v1/proveedores/{p.id}/")
    assert r.status_code == 204
    p.refresh_from_db()
    assert p.activo is False


def test_asociar_producto_a_proveedor(api_bodeguero):
    p = ProveedorFactory()
    ProductoFactory(sku="ASOC-1")
    r = api_bodeguero.post(
        f"/api/v1/proveedores/{p.id}/asociar-producto/",
        {"producto": "ASOC-1", "costo": 1200, "es_preferente": True, "codigo_proveedor": "P-99"},
        format="json",
    )
    assert r.status_code == 201, r.data
    pp = ProductoProveedor.objects.get(proveedor=p)
    assert pp.costo == 1200 and pp.es_preferente


def test_lead_time_semanas():
    p = ProveedorFactory(lead_time_dias=14)
    assert p.lead_time_semanas == Decimal(2)


def test_activar_reactiva_proveedor(api_bodeguero):
    p = ProveedorFactory(activo=False)
    r = api_bodeguero.post(f"/api/v1/proveedores/{p.id}/activar/")
    assert r.status_code == 200, r.data
    p.refresh_from_db()
    assert p.activo is True


def test_productos_lista_asociaciones_del_proveedor(api_bodeguero):
    p = ProveedorFactory()
    ProductoFactory(sku="LIST-1")
    ProductoFactory(sku="LIST-2")
    for sku in ("LIST-1", "LIST-2"):
        api_bodeguero.post(
            f"/api/v1/proveedores/{p.id}/asociar-producto/",
            {"producto": sku, "costo": 100},
            format="json",
        )
    r = api_bodeguero.get(f"/api/v1/proveedores/{p.id}/productos/")
    assert r.status_code == 200
    assert {fila["producto"] for fila in r.data} == {"LIST-1", "LIST-2"}


def test_quitar_producto_elimina_la_asociacion(api_bodeguero):
    p = ProveedorFactory()
    ProductoFactory(sku="QUIT-1")
    api_bodeguero.post(
        f"/api/v1/proveedores/{p.id}/asociar-producto/",
        {"producto": "QUIT-1", "costo": 100},
        format="json",
    )
    r = api_bodeguero.post(
        f"/api/v1/proveedores/{p.id}/quitar-producto/",
        {"producto": "quit-1"},
        format="json",
    )
    assert r.status_code == 204
    assert not ProductoProveedor.objects.filter(proveedor=p).exists()


def test_vendedor_no_ve_proveedores(api_vendedor):
    r = api_vendedor.get("/api/v1/proveedores/")
    assert r.status_code == 403
