"""Serializers de proveedores."""

from __future__ import annotations

from rest_framework import serializers

from apps.catalogo.models import Producto
from apps.core.validators import normalizar_rut, validar_rut

from .models import ProductoProveedor, Proveedor


class ProductoProveedorSerializer(serializers.ModelSerializer):
    producto = serializers.SlugRelatedField(slug_field="sku", queryset=Producto.objects.all())
    producto_nombre = serializers.CharField(source="producto.nombre", read_only=True)

    class Meta:
        model = ProductoProveedor
        fields = [
            "id", "producto", "producto_nombre", "codigo_proveedor",
            "costo", "es_preferente",
        ]


class ProveedorSerializer(serializers.ModelSerializer):
    productos_asociados = serializers.SerializerMethodField()

    class Meta:
        model = Proveedor
        fields = [
            "id", "razon_social", "rut", "giro",
            "contacto_nombre", "contacto_email", "contacto_telefono",
            "direccion", "lead_time_dias", "activo",
            "productos_asociados", "creado_en", "actualizado_en",
        ]
        read_only_fields = ["creado_en", "actualizado_en"]

    def get_productos_asociados(self, obj) -> int:
        return obj.producto_info.count()

    def validate_rut(self, value):
        validar_rut(value)
        value = normalizar_rut(value)
        qs = Proveedor.objects.filter(rut=value)
        if self.instance:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise serializers.ValidationError("Ya existe un proveedor con ese RUT.")
        return value
