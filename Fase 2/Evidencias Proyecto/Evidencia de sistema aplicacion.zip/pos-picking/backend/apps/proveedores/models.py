"""Modelos de proveedores y su relación con los productos."""

from __future__ import annotations

from decimal import Decimal

from django.db import models

from apps.core.models import ModeloActivable
from apps.core.validators import normalizar_rut, validar_rut


class Proveedor(ModeloActivable):
    razon_social = models.CharField("razón social", max_length=150)
    rut = models.CharField("RUT", max_length=12, unique=True, validators=[validar_rut])
    giro = models.CharField("giro", max_length=120, blank=True)
    contacto_nombre = models.CharField("contacto", max_length=100, blank=True)
    contacto_email = models.EmailField("email de contacto", max_length=254, blank=True)
    contacto_telefono = models.CharField("teléfono de contacto", max_length=20, blank=True)
    direccion = models.CharField("dirección", max_length=200, blank=True)
    lead_time_dias = models.PositiveSmallIntegerField("lead time (días)", default=7)

    productos = models.ManyToManyField(
        "catalogo.Producto",
        through="ProductoProveedor",
        related_name="proveedores",
        verbose_name="productos",
    )

    class Meta:
        verbose_name = "proveedor"
        verbose_name_plural = "proveedores"
        ordering = ["razon_social"]
        indexes = [models.Index(fields=["razon_social"])]

    def __str__(self) -> str:
        return self.razon_social

    def save(self, *args, **kwargs):
        if self.rut:
            self.rut = normalizar_rut(self.rut)
        super().save(*args, **kwargs)

    @property
    def lead_time_semanas(self) -> Decimal:
        return Decimal(self.lead_time_dias) / Decimal(7)


class ProductoProveedor(models.Model):
    """Costo y código de un producto según un proveedor."""

    producto = models.ForeignKey(
        "catalogo.Producto", on_delete=models.CASCADE, related_name="proveedor_info"
    )
    proveedor = models.ForeignKey(
        Proveedor, on_delete=models.CASCADE, related_name="producto_info"
    )
    codigo_proveedor = models.CharField("código del proveedor", max_length=40, blank=True)
    costo = models.PositiveIntegerField("costo (CLP)", default=0)
    es_preferente = models.BooleanField("proveedor preferente para reposición", default=False)

    class Meta:
        verbose_name = "producto por proveedor"
        verbose_name_plural = "productos por proveedor"
        constraints = [
            models.UniqueConstraint(
                fields=["producto", "proveedor"], name="producto_proveedor_unico"
            )
        ]
        indexes = [models.Index(fields=["producto", "es_preferente"])]

    def __str__(self) -> str:
        return f"{self.producto.sku} — {self.proveedor.razon_social}"
