from django.contrib import admin

from .models import ProductoProveedor, Proveedor


class ProductoProveedorInline(admin.TabularInline):
    model = ProductoProveedor
    extra = 0
    autocomplete_fields = ["producto"]


@admin.register(Proveedor)
class ProveedorAdmin(admin.ModelAdmin):
    list_display = ["razon_social", "rut", "lead_time_dias", "activo"]
    list_filter = ["activo"]
    search_fields = ["razon_social", "rut"]
    inlines = [ProductoProveedorInline]
