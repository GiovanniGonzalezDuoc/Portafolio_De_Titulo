"""ViewSets de proveedores."""

from __future__ import annotations

from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.usuarios.permissions import PermisoPorAccion

from .models import ProductoProveedor, Proveedor
from .serializers import ProductoProveedorSerializer, ProveedorSerializer


class ProveedorViewSet(viewsets.ModelViewSet):
    queryset = Proveedor.objects.all()
    serializer_class = ProveedorSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        "list": "proveedores.ver",
        "retrieve": "proveedores.ver",
        "create": "proveedores.administrar",
        "update": "proveedores.administrar",
        "partial_update": "proveedores.administrar",
        "destroy": "proveedores.administrar",
        "activar": "proveedores.administrar",
        "productos": "proveedores.ver",
        "asociar_producto": "proveedores.administrar",
        "quitar_producto": "proveedores.administrar",
    }
    filterset_fields = ["activo"]
    search_fields = ["razon_social", "rut", "giro"]
    ordering_fields = ["razon_social", "lead_time_dias", "creado_en"]

    def destroy(self, request, *args, **kwargs):
        obj = self.get_object()
        obj.activo = False
        obj.save(update_fields=["activo", "actualizado_en"])
        return Response(status=status.HTTP_204_NO_CONTENT)

    @action(detail=True, methods=["post"])
    def activar(self, request, pk=None):
        obj = self.get_object()
        obj.activo = True
        obj.save(update_fields=["activo", "actualizado_en"])
        return Response(ProveedorSerializer(obj).data)

    @action(detail=True, methods=["get"])
    def productos(self, request, pk=None):
        proveedor = self.get_object()
        qs = proveedor.producto_info.select_related("producto").all()
        return Response(ProductoProveedorSerializer(qs, many=True).data)

    @action(detail=True, methods=["post"], url_path="asociar-producto")
    def asociar_producto(self, request, pk=None):
        proveedor = self.get_object()
        serializer = ProductoProveedorSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        obj, _ = ProductoProveedor.objects.update_or_create(
            proveedor=proveedor,
            producto=serializer.validated_data["producto"],
            defaults={
                "codigo_proveedor": serializer.validated_data.get("codigo_proveedor", ""),
                "costo": serializer.validated_data.get("costo", 0),
                "es_preferente": serializer.validated_data.get("es_preferente", False),
            },
        )
        return Response(ProductoProveedorSerializer(obj).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"], url_path="quitar-producto")
    def quitar_producto(self, request, pk=None):
        proveedor = self.get_object()
        sku = request.data.get("producto")
        ProductoProveedor.objects.filter(
            proveedor=proveedor, producto__sku=str(sku).upper()
        ).delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
