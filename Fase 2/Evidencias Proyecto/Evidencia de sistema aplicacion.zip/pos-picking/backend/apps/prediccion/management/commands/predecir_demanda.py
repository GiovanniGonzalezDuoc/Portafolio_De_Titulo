"""Genera predicciones de demanda para todos los productos activos (cron)."""

from django.core.management.base import BaseCommand

from apps.prediccion import services


class Command(BaseCommand):
    help = "Predice la demanda de todos los productos activos."

    def add_arguments(self, parser):
        parser.add_argument("--horizonte", type=int, default=4)

    def handle(self, *args, **options):
        r = services.predecir_todos(horizonte_semanas=options["horizonte"])
        self.stdout.write(
            self.style.SUCCESS(
                f"Predicciones: {r['generadas']} generadas, {r['sin_datos']} sin datos."
            )
        )
