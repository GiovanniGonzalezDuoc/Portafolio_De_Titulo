"""
Entrena el modelo de predicción de demanda y lo registra en la BD.

Cron de cPanel (mensual)::

    0 3 1 * *  cd ~/pos_backend && venv/bin/python manage.py entrenar_demanda
"""

from django.core.management.base import BaseCommand

from apps.prediccion import services


class Command(BaseCommand):
    help = "Entrena el modelo (paquete ml) y activa el nuevo artefacto."

    def handle(self, *args, **options):
        modelo = services.entrenar_y_sincronizar()
        comparativa = modelo.metricas.get("comparativa", {})
        m = comparativa.get(modelo.algoritmo, {})
        self.stdout.write(
            self.style.SUCCESS(
                f"Modelo {modelo.version} ({modelo.algoritmo}) activo. "
                f"MAE={m.get('mae')} RMSE={m.get('rmse')}"
            )
        )
