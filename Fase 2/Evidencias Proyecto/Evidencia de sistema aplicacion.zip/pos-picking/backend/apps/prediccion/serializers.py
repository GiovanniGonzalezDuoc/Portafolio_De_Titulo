"""Serializers de predicción."""

from rest_framework import serializers

from .models import ModeloPrediccion, PrediccionDemanda


class ModeloPrediccionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ModeloPrediccion
        fields = [
            "id", "version", "algoritmo", "granularidad", "metricas",
            "entrenado_en", "activo", "notas",
        ]
        read_only_fields = fields


class PrediccionDemandaSerializer(serializers.ModelSerializer):
    producto = serializers.SlugRelatedField(slug_field="sku", read_only=True)
    modelo = serializers.CharField(source="modelo.version", read_only=True)
    nivel_confianza_display = serializers.CharField(source="get_nivel_confianza_display", read_only=True)

    class Meta:
        model = PrediccionDemanda
        fields = [
            "id", "producto", "modelo", "horizonte_semanas",
            "demanda_estimada", "desviacion", "fuente",
            "semanas_con_ventas", "nivel_confianza", "nivel_confianza_display",
            "generado_en",
        ]
        read_only_fields = fields
