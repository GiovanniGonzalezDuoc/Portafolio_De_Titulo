"""
Servicio de predicción de demanda.

Puente entre el paquete ``ml/`` (Python puro) y Django:
- construye el histórico semanal de un producto a partir de ``ventas``;
- si no hay suficiente histórico real y estamos en desarrollo, usa el dataset
  sintético (marcando la predicción como tal);
- llama a ``ml.src.predict`` y persiste el resultado.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

from django.conf import settings
from django.utils import timezone as dj_tz

from apps.core.exceptions import ErrorDominio

from .models import FuenteDatos, ModeloPrediccion, NivelConfianza, PrediccionDemanda

# pandas/numpy se importan de forma perezosa (dentro de las funciones que los
# usan) para no cargar el stack de ML — pesado en RAM — en los workers web que
# no tocan predicción. Ver `config/__init__.py` (límite de hilos de OpenBLAS).
if TYPE_CHECKING:
    import pandas as pd

logger = logging.getLogger("pos.prediccion")


class SinModeloEntrenado(ErrorDominio):
    codigo = "sin_modelo"
    mensaje = "No hay un modelo de predicción entrenado. Ejecuta 'entrenar_demanda'."
    http_status = 409


class DatosInsuficientes(ErrorDominio):
    codigo = "datos_insuficientes"
    http_status = 422


class EntrenamientoNoDisponible(ErrorDominio):
    codigo = "entrenamiento_no_disponible"
    http_status = 503
    mensaje = (
        "El entrenamiento del modelo no está disponible en este servidor. "
        "Ejecútalo desde la línea de comandos con "
        "'python manage.py entrenar_demanda' o inténtalo más tarde."
    )


# ─── Sincronizar el artefacto entrenado ────────────────────
def sincronizar_modelo() -> ModeloPrediccion:
    """Lee ``ml/models/demanda_actual.metrics.json`` y registra/activa el modelo."""
    try:
        from ml.src.config import ARTEFACTO_ACTIVO, MODELS_DIR
    except ImportError as exc:
        logger.warning("Paquete ml no disponible: %s", exc)
        raise SinModeloEntrenado() from exc

    metrics_path = Path(MODELS_DIR) / f"{ARTEFACTO_ACTIVO}.metrics.json"
    art_path = Path(MODELS_DIR) / f"{ARTEFACTO_ACTIVO}.joblib"
    if not metrics_path.exists() or not art_path.exists():
        raise SinModeloEntrenado()

    m = json.loads(metrics_path.read_text(encoding="utf-8"))
    modelo, _ = ModeloPrediccion.objects.update_or_create(
        version=m["version"],
        defaults={
            "algoritmo": m["algoritmo_elegido"],
            "ruta_artefacto": str(art_path),
            "metricas": m,
            "granularidad": "SEMANAL",
            "entrenado_en": datetime.fromisoformat(m["entrenado_en"]),
        },
    )
    ModeloPrediccion.objects.exclude(pk=modelo.pk).update(activo=False)
    modelo.activo = True
    modelo.save(update_fields=["activo"])
    logger.info("Modelo de predicción activo: %s", modelo.version)
    return modelo


def modelo_activo() -> ModeloPrediccion:
    modelo = ModeloPrediccion.objects.filter(activo=True).first()
    if modelo is None:
        try:
            return sincronizar_modelo()
        except SinModeloEntrenado:
            raise
    return modelo


# ─── Histórico semanal de un producto ──────────────────────
def historia_real(producto) -> pd.DataFrame:
    """Serie semanal de unidades vendidas (ventas PAGADAS) del producto."""
    import pandas as pd

    from apps.ventas.models import EstadoVenta, LineaVenta

    filas = (
        LineaVenta.objects.filter(producto=producto, venta__estado=EstadoVenta.PAGADA)
        .values_list("venta__creado_en", "cantidad", "precio_unitario")
    )
    if not filas:
        return pd.DataFrame(columns=["producto_sku", "categoria", "semana", "anio",
                                     "semana_iso", "precio", "en_promocion",
                                     "quiebre_stock", "unidades", "simulado"])
    df = pd.DataFrame(filas, columns=["fecha", "cantidad", "precio"])
    # `cantidad` llega como Decimal (columna del modelo): a float antes de
    # cualquier cuenta, si no numpy revienta mezclando float y Decimal más
    # adelante (medias móviles, desviación estándar, etc.).
    df["cantidad"] = df["cantidad"].astype(float)
    # `creado_en` está en UTC; se pasa a hora local antes de agrupar por
    # semana (si no, una venta de la noche puede "saltar" al día/semana
    # siguiente en UTC — el mismo tipo de bug ya visto en `anular_venta`).
    df["fecha"] = pd.to_datetime(df["fecha"]).dt.tz_convert(dj_tz.get_current_timezone()).dt.tz_localize(None)
    # Lunes de la semana de cada venta. OJO: `Period("W-MON").start_time`
    # ancla en **martes** (el día siguiente al lunes de corte), mientras que
    # `date_range(freq="W-MON")` genera **lunes** reales — mezclar ambos hace
    # que el `reindex` de más abajo no encuentre ninguna semana en común y
    # todo quede en 0 (bug real, detectado al probar con ventas reales).
    df["semana"] = (df["fecha"] - pd.to_timedelta(df["fecha"].dt.weekday, unit="D")).dt.normalize()
    agg = df.groupby("semana").agg(unidades=("cantidad", "sum"), precio=("precio", "mean")).reset_index()

    # Rellena semanas sin ventas con 0.
    rango = pd.date_range(agg["semana"].min(), agg["semana"].max(), freq="W-MON")
    agg = agg.set_index("semana").reindex(rango).rename_axis("semana").reset_index()
    agg["unidades"] = agg["unidades"].fillna(0.0)
    agg["precio"] = agg["precio"].ffill().bfill().fillna(producto.precio_venta)

    agg["producto_sku"] = producto.sku
    agg["categoria"] = producto.categoria.nombre
    agg["anio"] = agg["semana"].dt.isocalendar().year
    agg["semana_iso"] = agg["semana"].dt.isocalendar().week
    agg["en_promocion"] = False
    agg["quiebre_stock"] = False
    agg["simulado"] = False
    return agg


def historia_sintetica(producto) -> pd.DataFrame:
    from ml.src.dataset import cargar_raw

    df = cargar_raw()
    return df[df["producto_sku"] == producto.sku].copy()


def historia_producto(producto, *, permitir_sintetico: bool | None = None, minimo_semanas: int | None = None):
    """
    Devuelve ``(DataFrame, fuente, semanas_con_ventas)``. ``semanas_con_ventas``
    es siempre el conteo del histórico **real** (0 si terminó usando el
    sintético) — sirve para etiquetar el nivel de confianza de la predicción.

    ``minimo_semanas`` reemplaza puntualmente a ``MIN_SEMANAS_HISTORIA`` (RF-K8)
    para esta consulta — lo usa el panel de Predicción para demostrar el
    mecanismo con un umbral más bajo sin cambiar la configuración general.
    """
    from ml.src.config import MIN_SEMANAS_HISTORIA

    if permitir_sintetico is None:
        permitir_sintetico = getattr(settings, "PREDICCION_PERMITIR_SINTETICO", settings.DEBUG)
    minimo = MIN_SEMANAS_HISTORIA if minimo_semanas is None else minimo_semanas

    real = historia_real(producto)
    semanas_con_ventas = int((real["unidades"] > 0).sum()) if not real.empty else 0
    # `not real.empty` de guarda aparte del mínimo: con `minimo_semanas=0` (o
    # muy bajo) igual no tiene sentido "usar" un histórico real que no existe.
    if not real.empty and semanas_con_ventas >= minimo:
        return real, FuenteDatos.REAL, semanas_con_ventas

    if permitir_sintetico:
        sint = historia_sintetica(producto)
        if not sint.empty:
            return sint, FuenteDatos.SINTETICO, 0

    raise DatosInsuficientes(
        f"{producto.sku}: {semanas_con_ventas} semanas con ventas (mínimo {minimo}).",
        detalles={"semanas": semanas_con_ventas, "minimo": minimo},
    )


def nivel_confianza(fuente: str, semanas_con_ventas: int) -> str:
    """
    Nivel de confianza a mostrar junto a la predicción: solo con histórico
    real y suficientes semanas se considera "estable"/"confiable" — el
    sintético siempre es "no estable" (aún sin validar con ventas reales).
    """
    from ml.src.config import UMBRAL_CONFIANZA_CONFIABLE, UMBRAL_CONFIANZA_ESTABLE

    if fuente != FuenteDatos.REAL:
        return NivelConfianza.NO_ESTABLE
    if semanas_con_ventas >= UMBRAL_CONFIANZA_CONFIABLE:
        return NivelConfianza.CONFIABLE
    if semanas_con_ventas >= UMBRAL_CONFIANZA_ESTABLE:
        return NivelConfianza.ESTABLE
    return NivelConfianza.NO_ESTABLE


# ─── Predecir ──────────────────────────────────────────────
def predecir(
    producto, *, horizonte_semanas: int = 4, persistir: bool = True, minimo_semanas: int | None = None
) -> PrediccionDemanda:
    try:
        from ml.src import predict as ml_predict
    except ImportError as exc:
        raise SinModeloEntrenado() from exc

    modelo = modelo_activo()
    if not ml_predict.hay_modelo():
        sincronizar_modelo()
    ml_predict.limpiar_cache()

    historia, fuente, semanas_con_ventas = historia_producto(producto, minimo_semanas=minimo_semanas)
    try:
        p = ml_predict.predecir(historia, horizonte_semanas=horizonte_semanas, minimo_semanas=minimo_semanas)
    except ValueError as exc:
        raise DatosInsuficientes(str(exc)) from exc

    pred = PrediccionDemanda(
        producto=producto,
        modelo=modelo,
        horizonte_semanas=horizonte_semanas,
        demanda_estimada=p.demanda_estimada,
        desviacion=p.desviacion,
        fuente=fuente,
        semanas_con_ventas=semanas_con_ventas,
        nivel_confianza=nivel_confianza(fuente, semanas_con_ventas),
    )
    if persistir:
        pred.save()
    logger.info(
        "Predicción %s: %.1f en %s sem (%s, fuente %s, confianza %s)",
        producto.sku, p.demanda_estimada, horizonte_semanas, p.algoritmo, fuente, pred.nivel_confianza,
    )
    return pred


def predecir_todos(*, horizonte_semanas: int = 4) -> dict:
    from apps.catalogo.models import Producto

    ok, sin_datos = 0, 0
    for producto in Producto.objects.filter(activo=True):
        try:
            predecir(producto, horizonte_semanas=horizonte_semanas)
            ok += 1
        except DatosInsuficientes:
            sin_datos += 1
    return {"generadas": ok, "sin_datos": sin_datos, "fecha": dj_tz.now().isoformat()}


def entrenar_y_sincronizar() -> ModeloPrediccion:
    """
    Entrena el modelo (paquete ``ml/``) y lo registra en la BD.

    El entrenamiento corre sklearn de forma síncrona; en hosting compartido
    puede no estar disponible (paquete ``ml`` ausente, o límites de CPU/RAM de
    la cuenta). En ese caso se lanza ``EntrenamientoNoDisponible`` con un
    mensaje claro en lugar de un error 500.
    """
    try:
        from ml.src.train import entrenar
    except ImportError as exc:
        logger.warning("No se pudo importar ml.src.train: %s", exc)
        raise EntrenamientoNoDisponible() from exc

    try:
        entrenar()
    except MemoryError as exc:
        raise EntrenamientoNoDisponible() from exc
    except Exception as exc:  # noqa: BLE001 - queremos un mensaje de dominio
        logger.exception("Falló el entrenamiento del modelo de demanda")
        raise EntrenamientoNoDisponible(
            f"El entrenamiento falló: {exc}. Revisa los logs del servidor."
        ) from exc

    return sincronizar_modelo()
