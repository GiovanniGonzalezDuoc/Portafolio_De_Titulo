"""API de predicción de demanda (lectura + acciones de entrenamiento)."""

from __future__ import annotations

from django.shortcuts import get_object_or_404
from drf_spectacular.utils import OpenApiParameter, extend_schema
from rest_framework import mixins, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.throttling import ScopedRateThrottle

from apps.catalogo.models import Producto
from apps.usuarios.permissions import PermisoPorAccion, TienePermiso

from . import services
from .models import ModeloPrediccion, PrediccionDemanda
from .serializers import ModeloPrediccionSerializer, PrediccionDemandaSerializer


class ModeloPrediccionViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = ModeloPrediccion.objects.all()
    serializer_class = ModeloPrediccionSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        "list": "prediccion.ver",
        "retrieve": "prediccion.ver",
        "entrenar": "prediccion.entrenar",
        "sincronizar": "prediccion.entrenar",
    }

    @extend_schema(request=None, responses=ModeloPrediccionSerializer)
    @action(detail=False, methods=["post"])
    def entrenar(self, request):
        modelo = services.entrenar_y_sincronizar()
        return Response(ModeloPrediccionSerializer(modelo).data)

    @extend_schema(request=None, responses=ModeloPrediccionSerializer)
    @action(detail=False, methods=["post"])
    def sincronizar(self, request):
        modelo = services.sincronizar_modelo()
        return Response(ModeloPrediccionSerializer(modelo).data)


class PrediccionDemandaViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = PrediccionDemanda.objects.select_related("producto", "modelo").all()
    serializer_class = PrediccionDemandaSerializer
    permission_classes = [TienePermiso.para("prediccion.ver")]
    filterset_fields = ["producto__sku", "fuente", "horizonte_semanas", "nivel_confianza"]
    ordering_fields = ["generado_en", "demanda_estimada"]

    def get_throttles(self):
        # `calcular` ejecuta inferencia y **persiste** una fila: se limita para
        # que un usuario de solo lectura no genere carga/escrituras sin tope.
        if getattr(self, "action", None) == "calcular":
            self.throttle_scope = "prediccion_calcular"
            return [ScopedRateThrottle()]
        return super().get_throttles()

    @extend_schema(
        parameters=[
            OpenApiParameter("producto", str, required=True, description="SKU"),
            OpenApiParameter("horizonte", int, description="semanas (default 4)"),
            OpenApiParameter(
                "minimo_semanas", int,
                description="Reemplaza puntualmente el mínimo de semanas con ventas (RF-K8) "
                "solo para esta consulta — para demostrar el mecanismo sin tocar la configuración.",
            ),
        ],
        responses=PrediccionDemandaSerializer,
    )
    @action(detail=False, methods=["get"])
    def calcular(self, request):
        """Calcula (y persiste) la predicción de un producto ahora."""
        producto = get_object_or_404(
            Producto, sku=str(request.query_params.get("producto", "")).upper()
        )
        try:
            horizonte = int(request.query_params.get("horizonte", 4))
        except (TypeError, ValueError):
            horizonte = 4

        minimo_semanas = None
        crudo = request.query_params.get("minimo_semanas")
        if crudo not in (None, ""):
            try:
                minimo_semanas = max(1, min(52, int(crudo)))
            except (TypeError, ValueError):
                minimo_semanas = None

        pred = services.predecir(producto, horizonte_semanas=horizonte, minimo_semanas=minimo_semanas)
        return Response(PrediccionDemandaSerializer(pred).data)
