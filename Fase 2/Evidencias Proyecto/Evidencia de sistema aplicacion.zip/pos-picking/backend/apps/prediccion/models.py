"""Modelos de predicción de demanda (metadatos del modelo ML + predicciones)."""

from __future__ import annotations

from django.db import models


class ModeloPrediccion(models.Model):
    version = models.CharField("versión", max_length=40, unique=True)
    algoritmo = models.CharField("algoritmo", max_length=40)
    ruta_artefacto = models.CharField("ruta del artefacto", max_length=300)
    metricas = models.JSONField("métricas", default=dict)
    granularidad = models.CharField("granularidad", max_length=10, default="SEMANAL")
    entrenado_en = models.DateTimeField("entrenado en")
    activo = models.BooleanField("activo", default=False)
    notas = models.CharField("notas", max_length=300, blank=True)

    class Meta:
        verbose_name = "modelo de predicción"
        verbose_name_plural = "modelos de predicción"
        ordering = ["-entrenado_en"]

    def __str__(self) -> str:
        return f"{self.version} ({self.algoritmo}){' *' if self.activo else ''}"


class FuenteDatos(models.TextChoices):
    REAL = "REAL", "Histórico real"
    SINTETICO = "SINTETICO", "Dataset sintético"


class NivelConfianza(models.TextChoices):
    """
    Qué tanto respaldo de historial real tiene la predicción — aparte de si
    alcanzó el mínimo de RF-K8 para siquiera intentarse (ver
    ``ml.src.config``). Con dataset sintético siempre es "no estable": no está
    validada con ventas reales todavía.
    """

    NO_ESTABLE = "NO_ESTABLE", "No estable"
    ESTABLE = "ESTABLE", "Estable"
    CONFIABLE = "CONFIABLE", "Confiable"


class PrediccionDemanda(models.Model):
    producto = models.ForeignKey(
        "catalogo.Producto", on_delete=models.CASCADE, related_name="predicciones"
    )
    modelo = models.ForeignKey(
        ModeloPrediccion, on_delete=models.PROTECT, related_name="predicciones"
    )
    horizonte_semanas = models.PositiveSmallIntegerField("horizonte (semanas)")
    demanda_estimada = models.DecimalField("demanda estimada", max_digits=12, decimal_places=3)
    desviacion = models.DecimalField("desviación", max_digits=12, decimal_places=3, default=0)
    fuente = models.CharField(
        "fuente de datos", max_length=10, choices=FuenteDatos.choices, default=FuenteDatos.REAL
    )
    semanas_con_ventas = models.PositiveSmallIntegerField(
        "semanas con ventas usadas", default=0,
        help_text="Semanas con ventas reales que respaldan la predicción (0 si es sintética).",
    )
    nivel_confianza = models.CharField(
        "nivel de confianza", max_length=12,
        choices=NivelConfianza.choices, default=NivelConfianza.NO_ESTABLE,
    )
    generado_en = models.DateTimeField("generado en", auto_now_add=True)

    class Meta:
        verbose_name = "predicción de demanda"
        verbose_name_plural = "predicciones de demanda"
        ordering = ["-generado_en"]
        indexes = [models.Index(fields=["producto", "generado_en"])]

    def __str__(self) -> str:
        return f"{self.producto.sku}: {self.demanda_estimada} en {self.horizonte_semanas} sem"
