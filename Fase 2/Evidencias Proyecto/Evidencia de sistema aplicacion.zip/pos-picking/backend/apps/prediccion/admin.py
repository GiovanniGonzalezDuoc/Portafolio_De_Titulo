from django.contrib import admin

from .models import ModeloPrediccion, PrediccionDemanda


@admin.register(ModeloPrediccion)
class ModeloPrediccionAdmin(admin.ModelAdmin):
    list_display = ["version", "algoritmo", "granularidad", "entrenado_en", "activo"]
    list_filter = ["activo", "algoritmo"]
    readonly_fields = [f.name for f in ModeloPrediccion._meta.fields]

    def has_add_permission(self, request):
        return False


@admin.register(PrediccionDemanda)
class PrediccionDemandaAdmin(admin.ModelAdmin):
    list_display = ["producto", "horizonte_semanas", "demanda_estimada", "fuente", "generado_en"]
    list_filter = ["fuente", "horizonte_semanas"]
    search_fields = ["producto__sku"]
    readonly_fields = [f.name for f in PrediccionDemanda._meta.fields]

    def has_add_permission(self, request):
        return False
