"""Tests de la API de predicción de demanda."""

import pytest

from apps.catalogo.tests.factories import ProductoFactory
from apps.prediccion.models import ModeloPrediccion

pytestmark = pytest.mark.django_db


def test_listar_modelos(modelo_entrenado, api_bodeguero):
    r = api_bodeguero.get("/api/v1/prediccion/modelos/")
    assert r.status_code == 200
    assert r.data["conteo"] >= 1
    assert any(m["activo"] for m in r.data["resultados"])


def test_listar_demanda_y_filtro_por_sku(modelo_entrenado, api_bodeguero):
    ProductoFactory(sku="BEB-001")
    ProductoFactory(sku="BEB-002")
    api_bodeguero.get("/api/v1/prediccion/demanda/calcular/?producto=BEB-001&horizonte=4")
    api_bodeguero.get("/api/v1/prediccion/demanda/calcular/?producto=BEB-002&horizonte=4")

    r = api_bodeguero.get("/api/v1/prediccion/demanda/?producto__sku=BEB-001")
    assert r.status_code == 200
    assert r.data["conteo"] == 1
    assert r.data["resultados"][0]["producto"] == "BEB-001"


def test_calcular_producto_inexistente_da_404(modelo_entrenado, api_bodeguero):
    r = api_bodeguero.get("/api/v1/prediccion/demanda/calcular/?producto=NO-EXISTE&horizonte=4")
    assert r.status_code == 404


def test_calcular_horizonte_invalido_usa_default(modelo_entrenado, api_bodeguero):
    ProductoFactory(sku="BEB-001")
    r = api_bodeguero.get("/api/v1/prediccion/demanda/calcular/?producto=BEB-001&horizonte=abc")
    assert r.status_code == 200
    assert r.data["horizonte_semanas"] == 4


def test_vendedor_no_ve_predicciones(api_vendedor):
    assert api_vendedor.get("/api/v1/prediccion/demanda/").status_code == 403


def test_admin_entrena_modelo(modelo_entrenado, api_admin):
    antes = ModeloPrediccion.objects.count()
    r = api_admin.post("/api/v1/prediccion/modelos/entrenar/")
    assert r.status_code == 200, r.data
    assert r.data["activo"] is True
    assert ModeloPrediccion.objects.filter(activo=True).count() == 1
    assert ModeloPrediccion.objects.count() >= antes
