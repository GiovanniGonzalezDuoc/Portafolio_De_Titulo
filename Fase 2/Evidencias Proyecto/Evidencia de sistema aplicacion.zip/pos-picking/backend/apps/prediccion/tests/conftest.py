"""Fixtures de los tests de predicción."""

import pytest


@pytest.fixture
def modelo_entrenado(tmp_path, monkeypatch, db):
    """Entrena un modelo (dataset sintético) en un dir temporal y lo registra."""
    from ml.src import config as ml_config
    from ml.src import predict as ml_predict
    from ml.src import train

    monkeypatch.setattr(ml_config, "MODELS_DIR", tmp_path)
    ml_predict.limpiar_cache()
    train.entrenar()

    from apps.prediccion import services

    return services.sincronizar_modelo()
