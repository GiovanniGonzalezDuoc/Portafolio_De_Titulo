"""Tests del servicio de predicción de demanda."""

import pytest

from apps.catalogo.tests.factories import ProductoFactory
from apps.prediccion import services
from apps.prediccion.models import FuenteDatos, ModeloPrediccion, NivelConfianza, PrediccionDemanda

pytestmark = pytest.mark.django_db


def test_sincronizar_modelo_lo_activa(modelo_entrenado):
    assert modelo_entrenado.activo
    assert ModeloPrediccion.objects.filter(activo=True).count() == 1
    assert "metricas_test" in modelo_entrenado.metricas


def test_sin_modelo_entrenado_falla(monkeypatch, tmp_path):
    from ml.src import config as ml_config

    monkeypatch.setattr(ml_config, "MODELS_DIR", tmp_path)
    with pytest.raises(services.SinModeloEntrenado):
        services.sincronizar_modelo()


def test_predice_con_dataset_sintetico(modelo_entrenado):
    # SKU que existe en el dataset sintético
    prod = ProductoFactory(sku="BEB-001")
    pred = services.predecir(prod, horizonte_semanas=4)
    assert isinstance(pred, PrediccionDemanda)
    assert pred.demanda_estimada > 0
    assert pred.fuente == FuenteDatos.SINTETICO
    assert PrediccionDemanda.objects.filter(producto=prod).count() == 1


def test_producto_sin_historia_ni_sintetico_da_error(modelo_entrenado, settings):
    settings.PREDICCION_PERMITIR_SINTETICO = False
    prod = ProductoFactory(sku="ZZZ-999")   # no está en el sintético
    with pytest.raises(services.DatosInsuficientes):
        services.predecir(prod, horizonte_semanas=4)


# ─── Mínimo puntual (RF-K8) y nivel de confianza ─────────────
def test_nivel_confianza_sintetico_siempre_no_estable():
    assert services.nivel_confianza(FuenteDatos.SINTETICO, 999) == NivelConfianza.NO_ESTABLE


def test_nivel_confianza_segun_semanas_reales():
    assert services.nivel_confianza(FuenteDatos.REAL, 5) == NivelConfianza.NO_ESTABLE
    assert services.nivel_confianza(FuenteDatos.REAL, 20) == NivelConfianza.ESTABLE
    assert services.nivel_confianza(FuenteDatos.REAL, 60) == NivelConfianza.CONFIABLE


def test_predecir_con_pocas_semanas_reales_usa_datos_reales(modelo_entrenado, vendedor):
    """
    Antes de relajar `lag_52` en `construir()`, un producto necesitaba ~53
    semanas reales para poder predecirse con su propio histórico (sin importar
    RF-K8). Con 8 semanas — por debajo de las 12 "completas" pero sobre el
    mínimo operativo (6) — ya debe usar la rama REAL.
    """
    from datetime import timedelta

    from django.utils import timezone

    from apps.caja.services import abrir_caja
    from apps.ventas import services as ventas_services
    from apps.ventas.models import Venta
    from apps.ventas.tests.factories import item, producto_con_stock

    abrir_caja(usuario=vendedor, monto_inicial=1000)
    producto = producto_con_stock(vendedor, cantidad=200, precio_venta=1000)

    ahora = timezone.now()
    for i in range(8):
        venta = ventas_services.confirmar_venta(
            items=[item(producto, 3)],
            pagos=[{"medio": "DEBITO", "monto": 3000}],
            vendedor=vendedor,
        )
        Venta.objects.filter(id=venta.id).update(creado_en=ahora - timedelta(weeks=i))

    pred = services.predecir(producto, horizonte_semanas=4)
    assert pred.fuente == FuenteDatos.REAL
    assert pred.semanas_con_ventas == 8
    assert pred.nivel_confianza == NivelConfianza.NO_ESTABLE  # 8 < 16 (umbral "estable")


def test_calcular_con_minimo_puntual_mas_bajo_no_inventa_historial_vacio(modelo_entrenado, api_bodeguero):
    """
    `minimo_semanas=0` no debe tratar un histórico real VACÍO como usable
    (regresión: antes de la guarda `not real.empty`, esto reventaba con un
    IndexError en vez de responder 422 datos_insuficientes).
    """
    ProductoFactory(sku="MIN-TEST")  # no está en el sintético ni tiene ventas reales
    r = api_bodeguero.get(
        "/api/v1/prediccion/demanda/calcular/?producto=MIN-TEST&horizonte=4&minimo_semanas=0"
    )
    assert r.status_code == 422
    assert r.data["error"]["codigo"] == "datos_insuficientes"


def test_api_calcular(modelo_entrenado, api_bodeguero):
    ProductoFactory(sku="BEB-002")
    r = api_bodeguero.get("/api/v1/prediccion/demanda/calcular/?producto=BEB-002&horizonte=4")
    assert r.status_code == 200
    assert r.data["horizonte_semanas"] == 4
    assert float(r.data["demanda_estimada"]) > 0


def test_api_entrenar_requiere_permiso(modelo_entrenado, api_vendedor):
    assert api_vendedor.post("/api/v1/prediccion/modelos/entrenar/").status_code == 403
