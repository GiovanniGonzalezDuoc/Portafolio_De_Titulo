"""Rutas de predicción."""

from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import ModeloPrediccionViewSet, PrediccionDemandaViewSet

router = DefaultRouter()
router.register("modelos", ModeloPrediccionViewSet, basename="modelo-prediccion")
router.register("demanda", PrediccionDemandaViewSet, basename="prediccion-demanda")

urlpatterns = [path("", include(router.urls))]
