"""Serializers de ofertas."""

from __future__ import annotations

from rest_framework import serializers

from apps.catalogo.models import Producto

from .models import Oferta
from .services import TIPO_PORCENTAJE, TIPO_PRECIO_FIJO


class OfertaSerializer(serializers.ModelSerializer):
    producto = serializers.SlugRelatedField(slug_field="sku", queryset=Producto.objects.all())
    producto_nombre = serializers.CharField(source="producto.nombre", read_only=True)
    precio_normal = serializers.IntegerField(source="producto.precio_venta", read_only=True)
    precio_normal_mayorista = serializers.IntegerField(
        source="producto.precio_mayorista", read_only=True
    )
    descuento_pct = serializers.SerializerMethodField()
    vigente = serializers.BooleanField(read_only=True)
    creada_por = serializers.CharField(source="creada_por.username", read_only=True)

    class Meta:
        model = Oferta
        fields = [
            "id", "producto", "producto_nombre", "precio_normal", "precio_normal_mayorista",
            "precio_oferta", "precio_oferta_mayorista", "descuento_pct", "descripcion",
            "inicia_en", "termina_en", "activa", "vigente", "lote",
            "creada_por", "creado_en",
        ]
        read_only_fields = ["lote", "creada_por", "creado_en"]

    def get_descuento_pct(self, obj) -> int:
        base = obj.producto.precio_venta or 0
        if not base or obj.precio_oferta >= base:
            return 0
        return round((1 - obj.precio_oferta / base) * 100)

    def validate(self, attrs):
        producto = attrs.get("producto") or getattr(self.instance, "producto", None)
        precio = attrs.get("precio_oferta", getattr(self.instance, "precio_oferta", None))
        if producto and precio is not None and precio >= producto.precio_venta:
            raise serializers.ValidationError(
                {"precio_oferta": "El precio de oferta debe ser menor que el precio normal."}
            )
        inicia = attrs.get("inicia_en", getattr(self.instance, "inicia_en", None))
        termina = attrs.get("termina_en", getattr(self.instance, "termina_en", None))
        if inicia and termina and termina <= inicia:
            raise serializers.ValidationError(
                {"termina_en": "La fecha de término debe ser posterior al inicio."}
            )
        return attrs


class _AlcanceSerializer(serializers.Serializer):
    """Define a qué productos aplica la operación masiva."""

    productos = serializers.ListField(child=serializers.CharField(), required=False)
    categoria = serializers.CharField(required=False, allow_blank=True)
    marca = serializers.CharField(required=False, allow_blank=True)
    todos = serializers.BooleanField(required=False, default=False)

    def validate(self, attrs):
        if not (attrs.get("productos") or attrs.get("categoria") or attrs.get("marca") or attrs.get("todos")):
            raise serializers.ValidationError(
                "Indica los productos: lista de SKU, categoría, marca o «todos»."
            )
        return attrs


class AplicarMasivoSerializer(_AlcanceSerializer):
    tipo = serializers.ChoiceField(choices=[TIPO_PORCENTAJE, TIPO_PRECIO_FIJO])
    valor = serializers.DecimalField(max_digits=10, decimal_places=2, min_value=1)
    inicia_en = serializers.DateTimeField(required=False)
    termina_en = serializers.DateTimeField(required=False, allow_null=True)
    descripcion = serializers.CharField(required=False, allow_blank=True, max_length=120)


class QuitarMasivoSerializer(_AlcanceSerializer):
    pass
