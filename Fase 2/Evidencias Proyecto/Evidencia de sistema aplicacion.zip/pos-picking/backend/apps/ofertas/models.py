"""
Ofertas: precio rebajado y temporal de un producto.

Una oferta **vigente** (activa + dentro de su ventana de fechas) tiene
prioridad sobre el precio normal y sobre el precio mayorista del producto.
Solo puede haber una oferta vigente por producto: al crear/activar una, las
demás del mismo producto se desactivan (MariaDB no soporta índices únicos
condicionales, así que se garantiza en el servicio).
"""

from __future__ import annotations

from django.conf import settings
from django.db import models
from django.utils import timezone

from apps.core.models import TimeStampedModel


class OfertaQuerySet(models.QuerySet):
    def vigentes(self, ahora=None):
        ahora = ahora or timezone.now()
        return self.filter(activa=True, inicia_en__lte=ahora).filter(
            models.Q(termina_en__isnull=True) | models.Q(termina_en__gte=ahora)
        )


class Oferta(TimeStampedModel):
    producto = models.ForeignKey(
        "catalogo.Producto", on_delete=models.CASCADE, related_name="ofertas"
    )
    precio_oferta = models.PositiveIntegerField("precio en oferta (CLP, IVA incl.)")
    precio_oferta_mayorista = models.PositiveIntegerField(
        "precio en oferta mayorista (CLP)", null=True, blank=True,
        help_text="Opcional. Si se deja vacío, el precio de oferta aplica también al mayorista.",
    )
    descripcion = models.CharField("descripción", max_length=120, blank=True)

    inicia_en = models.DateTimeField("inicia", default=timezone.now)
    termina_en = models.DateTimeField(
        "termina", null=True, blank=True, help_text="Opcional. Vacío = indefinida."
    )
    activa = models.BooleanField("activa", default=True)

    creada_por = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    lote = models.CharField(
        "lote de carga", max_length=40, blank=True,
        help_text="Identifica las ofertas creadas juntas en una carga masiva.",
    )

    objects = OfertaQuerySet.as_manager()

    class Meta:
        verbose_name = "oferta"
        verbose_name_plural = "ofertas"
        ordering = ["-creado_en"]
        indexes = [
            models.Index(fields=["producto", "activa"]),
            models.Index(fields=["activa", "inicia_en", "termina_en"]),
        ]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(precio_oferta__gte=0), name="oferta_precio_no_negativo"
            ),
        ]

    def __str__(self) -> str:
        return f"{self.producto_id} → ${self.precio_oferta}"

    @property
    def vigente(self) -> bool:
        ahora = timezone.now()
        return (
            self.activa
            and self.inicia_en <= ahora
            and (self.termina_en is None or ahora <= self.termina_en)
        )
