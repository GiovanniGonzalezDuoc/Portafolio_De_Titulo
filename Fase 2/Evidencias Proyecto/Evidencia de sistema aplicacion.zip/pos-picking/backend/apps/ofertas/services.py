"""Lógica de negocio de las ofertas."""

from __future__ import annotations

import logging
import uuid
from decimal import ROUND_HALF_UP, Decimal

from django.db import transaction
from django.utils import timezone

from apps.catalogo.models import Producto
from apps.core.exceptions import ErrorDominio

from .models import Oferta

logger = logging.getLogger("pos.ofertas")

TIPO_PORCENTAJE = "porcentaje"
TIPO_PRECIO_FIJO = "precio_fijo"


class OfertaError(ErrorDominio):
    codigo = "oferta_error"


def _entero(valor) -> int:
    return int(Decimal(str(valor)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


# ─── Precio vigente ────────────────────────────────────────
def oferta_vigente(producto, ahora=None) -> Oferta | None:
    """
    Oferta aplicable ahora para el producto (la más barata si hubiera varias).
    Usa el prefetch de ``ofertas`` si está disponible (evita N+1 en listados).
    """
    ahora = ahora or timezone.now()
    candidatas = [
        o for o in producto.ofertas.all()
        if o.activa and o.inicia_en <= ahora and (o.termina_en is None or ahora <= o.termina_en)
    ]
    return min(candidatas, key=lambda o: o.precio_oferta) if candidatas else None


def precio_vigente(producto, *, mayorista: bool = False) -> tuple[int, Oferta | None]:
    """
    Precio que realmente se cobra por el producto. La oferta manda sobre el
    precio normal y sobre el mayorista.
    """
    oferta = oferta_vigente(producto)
    if oferta is not None:
        if mayorista and oferta.precio_oferta_mayorista is not None:
            return oferta.precio_oferta_mayorista, oferta
        return oferta.precio_oferta, oferta
    return producto.precio_para(mayorista=mayorista), None


# ─── Alta individual ──────────────────────────────────────
@transaction.atomic
def crear_o_reemplazar(
    *, producto: Producto, precio_oferta: int, precio_oferta_mayorista: int | None = None,
    inicia_en=None, termina_en=None, descripcion: str = "", usuario=None, lote: str = "",
) -> Oferta:
    """Crea la oferta y desactiva cualquier otra activa del mismo producto."""
    if precio_oferta <= 0:
        raise OfertaError("El precio de oferta debe ser mayor que cero.", codigo="precio_invalido")
    if termina_en is not None and inicia_en is not None and termina_en <= inicia_en:
        raise OfertaError("La fecha de término debe ser posterior al inicio.", codigo="fechas_invalidas")

    Oferta.objects.filter(producto=producto, activa=True).update(activa=False)
    return Oferta.objects.create(
        producto=producto,
        precio_oferta=precio_oferta,
        precio_oferta_mayorista=precio_oferta_mayorista,
        inicia_en=inicia_en or timezone.now(),
        termina_en=termina_en,
        descripcion=descripcion,
        creada_por=usuario,
        lote=lote,
    )


# ─── Carga masiva ─────────────────────────────────────────
def _productos_del_alcance(*, skus=None, categoria=None, marca=None, todos=False):
    qs = Producto.objects.filter(activo=True).select_related("categoria")
    if todos:
        return qs
    if skus:
        return qs.filter(sku__in=[str(s).strip().upper() for s in skus])
    if categoria:
        return qs.filter(categoria__nombre__iexact=categoria)
    if marca:
        return qs.filter(marca__nombre__iexact=marca)
    return qs.none()


@transaction.atomic
def aplicar_masivo(
    *, tipo: str, valor: Decimal, skus=None, categoria=None, marca=None, todos=False,
    inicia_en=None, termina_en=None, descripcion: str = "", usuario=None,
) -> dict:
    """
    Crea ofertas para un conjunto de productos de una sola vez.

    - ``tipo='porcentaje'``: ``valor`` es el % de descuento (0-95) sobre el
      precio normal (y el mayorista si existe).
    - ``tipo='precio_fijo'``: ``valor`` es el precio de oferta en CLP para todos.

    Omite los productos donde el resultado no sería más barato.
    """
    productos = list(_productos_del_alcance(
        skus=skus, categoria=categoria, marca=marca, todos=todos
    ))
    if not productos:
        raise OfertaError("El alcance seleccionado no incluye productos.", codigo="sin_productos")

    valor = Decimal(str(valor))
    if tipo == TIPO_PORCENTAJE and not (Decimal(0) < valor < Decimal(96)):
        raise OfertaError("El porcentaje de descuento debe estar entre 1 y 95.", codigo="pct_invalido")
    if tipo == TIPO_PRECIO_FIJO and valor <= 0:
        raise OfertaError("El precio fijo debe ser mayor que cero.", codigo="precio_invalido")
    if tipo not in (TIPO_PORCENTAJE, TIPO_PRECIO_FIJO):
        raise OfertaError("Tipo de descuento no válido.", codigo="tipo_invalido")

    lote = uuid.uuid4().hex[:12]
    creadas, omitidas = 0, 0
    for p in productos:
        if tipo == TIPO_PORCENTAJE:
            factor = (Decimal(100) - valor) / Decimal(100)
            precio = _entero(p.precio_venta * factor)
            precio_may = (
                _entero(p.precio_mayorista * factor) if p.precio_mayorista is not None else None
            )
        else:
            precio = _entero(valor)
            precio_may = None

        if precio <= 0 or precio >= p.precio_venta:
            omitidas += 1
            continue

        Oferta.objects.filter(producto=p, activa=True).update(activa=False)
        Oferta.objects.create(
            producto=p, precio_oferta=precio, precio_oferta_mayorista=precio_may,
            inicia_en=inicia_en or timezone.now(), termina_en=termina_en,
            descripcion=descripcion, creada_por=usuario, lote=lote,
        )
        creadas += 1

    resumen = {
        "lote": lote, "creadas": creadas, "omitidas": omitidas,
        "total": len(productos),
    }
    logger.info("Ofertas masivas: %s", resumen)
    return resumen


@transaction.atomic
def quitar_masivo(*, skus=None, categoria=None, marca=None, todos=False, usuario=None) -> dict:
    """Desactiva las ofertas activas de un conjunto de productos."""
    productos = _productos_del_alcance(
        skus=skus, categoria=categoria, marca=marca, todos=todos
    )
    n = Oferta.objects.filter(producto__in=productos, activa=True).update(activa=False)
    logger.info("Ofertas desactivadas en masa: %d por %s", n, getattr(usuario, "username", "-"))
    return {"desactivadas": n}
