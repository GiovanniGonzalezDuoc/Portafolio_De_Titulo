from django.contrib import admin

from .models import Oferta


@admin.register(Oferta)
class OfertaAdmin(admin.ModelAdmin):
    list_display = ("producto", "precio_oferta", "activa", "vigente", "inicia_en", "termina_en")
    list_filter = ("activa",)
    search_fields = ("producto__sku", "producto__nombre", "descripcion", "lote")
    raw_id_fields = ("producto", "creada_por")
    readonly_fields = ("creado_en", "actualizado_en", "vigente")
