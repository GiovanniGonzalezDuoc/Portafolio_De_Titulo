"""API de ofertas."""

from __future__ import annotations

import django_filters as filters
from drf_spectacular.utils import extend_schema
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.usuarios.permissions import PermisoPorAccion

from . import services
from .models import Oferta
from .serializers import (
    AplicarMasivoSerializer,
    OfertaSerializer,
    QuitarMasivoSerializer,
)


class OfertaFilter(filters.FilterSet):
    producto = filters.CharFilter(field_name="producto__sku", lookup_expr="iexact")
    categoria = filters.CharFilter(field_name="producto__categoria__nombre", lookup_expr="iexact")
    marca = filters.CharFilter(field_name="producto__marca__nombre", lookup_expr="iexact")
    vigente = filters.BooleanFilter(method="_vigente")
    lote = filters.CharFilter(field_name="lote", lookup_expr="exact")

    class Meta:
        model = Oferta
        fields = ["activa", "producto", "categoria", "marca"]

    def _vigente(self, qs, name, value):
        return qs.vigentes() if value else qs


class OfertaViewSet(viewsets.ModelViewSet):
    queryset = Oferta.objects.select_related(
        "producto", "producto__categoria", "creada_por"
    ).all()
    serializer_class = OfertaSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        "list": "ofertas.ver",
        "retrieve": "ofertas.ver",
        "create": "ofertas.administrar",
        "update": "ofertas.administrar",
        "partial_update": "ofertas.administrar",
        "destroy": "ofertas.administrar",
        "activar": "ofertas.administrar",
        "desactivar": "ofertas.administrar",
        "aplicar_masivo": "ofertas.administrar",
        "quitar_masivo": "ofertas.administrar",
    }
    filterset_class = OfertaFilter
    search_fields = ["producto__sku", "producto__nombre", "descripcion"]
    ordering_fields = ["creado_en", "precio_oferta", "termina_en"]

    def perform_create(self, serializer):
        serializer.save(creada_por=self.request.user)
        # Al crear una oferta, desactiva las demás activas del mismo producto.
        Oferta.objects.filter(
            producto=serializer.instance.producto, activa=True
        ).exclude(pk=serializer.instance.pk).update(activa=False)

    @action(detail=True, methods=["post"])
    def activar(self, request, pk=None):
        oferta = self.get_object()
        Oferta.objects.filter(producto=oferta.producto, activa=True).exclude(pk=oferta.pk).update(
            activa=False
        )
        oferta.activa = True
        oferta.save(update_fields=["activa", "actualizado_en"])
        return Response(OfertaSerializer(oferta).data)

    @action(detail=True, methods=["post"])
    def desactivar(self, request, pk=None):
        oferta = self.get_object()
        oferta.activa = False
        oferta.save(update_fields=["activa", "actualizado_en"])
        return Response(OfertaSerializer(oferta).data)

    @extend_schema(request=AplicarMasivoSerializer, responses=None)
    @action(detail=False, methods=["post"], url_path="aplicar-masivo")
    def aplicar_masivo(self, request):
        s = AplicarMasivoSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        d = s.validated_data
        resumen = services.aplicar_masivo(
            tipo=d["tipo"], valor=d["valor"],
            skus=d.get("productos"), categoria=d.get("categoria"),
            marca=d.get("marca"), todos=d.get("todos", False),
            inicia_en=d.get("inicia_en"), termina_en=d.get("termina_en"),
            descripcion=d.get("descripcion", ""), usuario=request.user,
        )
        return Response(resumen, status=status.HTTP_201_CREATED)

    @extend_schema(request=QuitarMasivoSerializer, responses=None)
    @action(detail=False, methods=["post"], url_path="quitar-masivo")
    def quitar_masivo(self, request):
        s = QuitarMasivoSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        d = s.validated_data
        resumen = services.quitar_masivo(
            skus=d.get("productos"), categoria=d.get("categoria"),
            marca=d.get("marca"), todos=d.get("todos", False), usuario=request.user,
        )
        return Response(resumen)
