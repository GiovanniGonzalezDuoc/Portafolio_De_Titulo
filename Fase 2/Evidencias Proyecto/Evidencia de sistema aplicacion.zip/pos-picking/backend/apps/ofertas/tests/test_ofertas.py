"""Tests del módulo de ofertas."""

from datetime import timedelta
from decimal import Decimal

import pytest
from django.utils import timezone

from apps.catalogo.tests.factories import ProductoFactory
from apps.ofertas import services
from apps.ofertas.models import Oferta

pytestmark = pytest.mark.django_db


# ─── Servicio: precio vigente ──────────────────────────────
def test_oferta_vigente_manda_sobre_el_precio_normal():
    p = ProductoFactory(sku="OF-1", precio_venta=1000, precio_mayorista=800)
    Oferta.objects.create(producto=p, precio_oferta=700)

    assert services.precio_vigente(p)[0] == 700
    # La oferta también manda sobre el mayorista si no hay precio mayorista de oferta.
    assert services.precio_vigente(p, mayorista=True)[0] == 700


def test_oferta_mayorista_propia():
    p = ProductoFactory(sku="OF-2", precio_venta=1000, precio_mayorista=800)
    Oferta.objects.create(producto=p, precio_oferta=700, precio_oferta_mayorista=600)
    assert services.precio_vigente(p, mayorista=True)[0] == 600


def test_oferta_fuera_de_ventana_no_aplica():
    p = ProductoFactory(sku="OF-3", precio_venta=1000)
    ayer = timezone.now() - timedelta(days=1)
    Oferta.objects.create(producto=p, precio_oferta=500, inicia_en=ayer - timedelta(days=1), termina_en=ayer)
    assert services.precio_vigente(p)[0] == 1000


def test_oferta_inactiva_no_aplica():
    p = ProductoFactory(sku="OF-4", precio_venta=1000)
    Oferta.objects.create(producto=p, precio_oferta=500, activa=False)
    assert services.precio_vigente(p)[0] == 1000


# ─── Carga masiva ─────────────────────────────────────────
def test_aplicar_masivo_por_porcentaje(admin):
    ProductoFactory(sku="M-1", precio_venta=1000, categoria__nombre="Bebidas")
    ProductoFactory(sku="M-2", precio_venta=2000, categoria__nombre="Bebidas")
    r = services.aplicar_masivo(tipo="porcentaje", valor=Decimal(20), categoria="Bebidas", usuario=admin)
    assert r["creadas"] == 2
    assert services.precio_vigente(__prod("M-1"))[0] == 800
    assert services.precio_vigente(__prod("M-2"))[0] == 1600


def test_aplicar_masivo_precio_fijo_omite_los_que_no_bajan(admin):
    ProductoFactory(sku="F-1", precio_venta=1500)
    ProductoFactory(sku="F-2", precio_venta=800)   # 800 < 990 → no baja → omitido
    r = services.aplicar_masivo(
        tipo="precio_fijo", valor=Decimal(990), skus=["F-1", "F-2"], usuario=admin
    )
    assert r["creadas"] == 1 and r["omitidas"] == 1


def test_aplicar_masivo_reemplaza_la_oferta_anterior(admin):
    p = ProductoFactory(sku="R-1", precio_venta=1000)
    services.aplicar_masivo(tipo="porcentaje", valor=Decimal(10), skus=["R-1"], usuario=admin)
    services.aplicar_masivo(tipo="porcentaje", valor=Decimal(30), skus=["R-1"], usuario=admin)
    assert Oferta.objects.filter(producto=p, activa=True).count() == 1
    assert services.precio_vigente(p)[0] == 700


def test_quitar_masivo(admin):
    ProductoFactory(sku="Q-1", precio_venta=1000, marca__nombre="ACME")
    services.aplicar_masivo(tipo="porcentaje", valor=Decimal(15), marca="ACME", usuario=admin)
    r = services.quitar_masivo(marca="ACME", usuario=admin)
    assert r["desactivadas"] == 1
    assert services.precio_vigente(__prod("Q-1"))[0] == 1000


# ─── Integración con la venta ─────────────────────────────
def test_la_venta_cobra_el_precio_de_oferta(vendedor):
    from apps.ventas import services as ventas
    from apps.ventas.tests.factories import item, producto_con_stock

    p = producto_con_stock(vendedor, cantidad=10, precio_venta=1000)
    Oferta.objects.create(producto=p, precio_oferta=700)
    calc = ventas.calcular(items=[item(p, 2)])
    assert calc.lineas[0].precio_unitario == 700
    assert calc.total == 1400


# ─── API ──────────────────────────────────────────────────
def test_bodeguero_crea_oferta_masiva(api_bodeguero):
    ProductoFactory(sku="API-1", precio_venta=1000)
    r = api_bodeguero.post(
        "/api/v1/ofertas/aplicar-masivo/",
        {"tipo": "porcentaje", "valor": 25, "productos": ["API-1"]},
        format="json",
    )
    assert r.status_code == 201, r.data
    assert r.data["creadas"] == 1


def test_vendedor_ve_pero_no_administra(api_vendedor):
    assert api_vendedor.get("/api/v1/ofertas/").status_code == 200
    r = api_vendedor.post(
        "/api/v1/ofertas/aplicar-masivo/",
        {"tipo": "porcentaje", "valor": 10, "todos": True},
        format="json",
    )
    assert r.status_code == 403


def test_producto_serializer_expone_precio_efectivo(api_vendedor):
    ProductoFactory(sku="SER-1", precio_venta=1000)
    Oferta.objects.create(producto=__prod("SER-1"), precio_oferta=650)
    r = api_vendedor.get("/api/v1/catalogo/productos/por-sku/SER-1/")
    assert r.status_code == 200
    assert r.data["precio_efectivo"] == 650
    assert r.data["en_oferta"] is True


def __prod(sku):
    from apps.catalogo.models import Producto

    return Producto.objects.get(sku=sku)
