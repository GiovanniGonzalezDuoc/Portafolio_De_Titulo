"""Tests del PDF de cotización/orden (apps.compras.pdf)."""

from decimal import Decimal

import pytest

from apps.compras import pdf

pytestmark = pytest.mark.django_db


# ─── Formato de cantidad ────────────────────────────────────
def test_cantidad_sin_ceros_de_relleno():
    """
    Regresión: ``cantidad`` se guarda con 3 decimales fijos (p. ej.
    Decimal("15.000")). Formatearlo con ``f"{valor:g}"`` imprime literal
    "15.000" — que en español se lee como QUINCE MIL, no quince. El PDF le
    mostraba al usuario "15.000" cuando había pedido 15 unidades.
    """
    assert pdf._cantidad(Decimal("15.000")) == "15"
    assert pdf._cantidad(Decimal("1.000")) == "1"
    assert pdf._cantidad(Decimal("0.001")) == "0,001"


def test_cantidad_con_decimales_usa_coma_chilena():
    assert pdf._cantidad(Decimal("1.500")) == "1,5"


def test_cantidad_miles_usa_punto_chileno():
    assert pdf._cantidad(Decimal("1234.000")) == "1.234"


# ─── Contenido del PDF ──────────────────────────────────────
def test_pdf_no_incluye_precios(admin):
    """
    El PDF que se le manda al proveedor no debe llevar costo unitario ni
    subtotal: se le pide la cantidad, el precio lo cotiza el proveedor de
    vuelta. El costo interno es solo para comparar contra la última compra.
    """
    from .factories import crear_orden_simple

    orden = crear_orden_simple(admin)
    filas = pdf._filas_tabla(orden)
    encabezado = filas[0]
    assert encabezado == ["Producto", "SKU", "Cantidad"]
    assert not any("costo" in c.lower() or "subtotal" in c.lower() for c in encabezado)


def test_filas_tabla_no_repite_el_bug_de_las_cantidades(admin):
    """Reproduce el reporte exacto del cliente: cotizar 15 unidades no debe
    verse como "15.000" (quince mil) en la tabla del PDF."""
    from apps.catalogo.tests.factories import ProductoFactory

    from .factories import crear_orden_simple

    p = ProductoFactory(sku="PDF-1")
    orden = crear_orden_simple(admin, productos=[(p, Decimal("15"), 1000)])
    fila = pdf._filas_tabla(orden)[1]
    assert fila == [p.nombre, "PDF-1", "15"]


def test_pdf_se_genera_sin_errores(admin):
    """Smoke test: que el documento realmente se construya (reportlab no
    tira una excepción tardía por algún flowable mal armado)."""
    from .factories import crear_orden_simple

    orden = crear_orden_simple(admin)
    contenido = pdf.orden_pdf_bytes(orden)
    assert contenido.startswith(b"%PDF")
