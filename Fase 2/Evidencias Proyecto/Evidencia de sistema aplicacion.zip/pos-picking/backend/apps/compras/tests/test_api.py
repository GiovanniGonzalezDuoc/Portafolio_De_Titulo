"""Tests de la API de compras."""

from decimal import Decimal

import pytest

from apps.catalogo.tests.factories import ProductoFactory
from apps.inventario import services as inventario
from apps.proveedores.tests.factories import ProveedorFactory

from .factories import crear_orden_simple

pytestmark = pytest.mark.django_db


def _payload_orden(proveedor_rut, sku):
    return {
        "proveedor": proveedor_rut,
        "observacion": "compra mensual",
        "lineas": [{"producto": sku, "cantidad": "15", "costo_unitario": 800}],
    }


def test_bodeguero_crea_orden(api_bodeguero):
    prov = ProveedorFactory()
    ProductoFactory(sku="OC-P1")
    r = api_bodeguero.post("/api/v1/compras/ordenes/", _payload_orden(prov.rut, "OC-P1"), format="json")
    assert r.status_code == 201, r.data
    assert r.data["estado"] == "BORRADOR"
    assert r.data["total_estimado"] == 15 * 800


def test_vendedor_no_crea_ordenes(api_vendedor):
    prov = ProveedorFactory()
    ProductoFactory(sku="OC-P2")
    r = api_vendedor.post("/api/v1/compras/ordenes/", _payload_orden(prov.rut, "OC-P2"), format="json")
    assert r.status_code == 403


def test_flujo_completo_por_api(api_bodeguero, bodeguero):
    prov = ProveedorFactory()
    producto = ProductoFactory(sku="OC-P3")

    # crear
    r = api_bodeguero.post("/api/v1/compras/ordenes/", _payload_orden(prov.rut, "OC-P3"), format="json")
    orden_id = r.data["id"]
    linea_id = r.data["lineas"][0]["id"]

    # emitir
    r = api_bodeguero.post(f"/api/v1/compras/ordenes/{orden_id}/emitir/")
    assert r.data["estado"] == "EMITIDA"

    # recibir
    r = api_bodeguero.post(
        f"/api/v1/compras/ordenes/{orden_id}/recibir/",
        {"lineas": [{"linea_orden": linea_id, "cantidad": "15"}], "documento_proveedor": "F-1"},
        format="json",
    )
    assert r.status_code == 201, r.data
    assert inventario.stock_de(producto) == Decimal("15")

    r = api_bodeguero.get(f"/api/v1/compras/ordenes/{orden_id}/")
    assert r.data["estado"] == "RECIBIDA"


def test_recibir_requiere_permiso_recibir(api_bodeguero, admin):
    """El bodeguero SÍ tiene compras.recibir; comprobamos que sin él da 403."""
    from apps.usuarios.models import Rol

    rol = Rol.objects.get(nombre="vendedor")
    orden = crear_orden_simple(admin, emitir=True)
    linea = orden.lineas.first()

    # vendedor no tiene compras.recibir
    from rest_framework.test import APIClient

    from apps.usuarios.tests.factories import UsuarioFactory
    cli = APIClient()
    cli.force_authenticate(UsuarioFactory(rol=rol))
    r = cli.post(
        f"/api/v1/compras/ordenes/{orden.id}/recibir/",
        {"lineas": [{"linea_orden": linea.id, "cantidad": "1"}]},
        format="json",
    )
    assert r.status_code == 403


def test_recibir_de_mas_da_409(api_bodeguero, admin):
    orden = crear_orden_simple(admin, emitir=True)
    linea = orden.lineas.first()
    r = api_bodeguero.post(
        f"/api/v1/compras/ordenes/{orden.id}/recibir/",
        {"lineas": [{"linea_orden": linea.id, "cantidad": "9999"}]},
        format="json",
    )
    assert r.status_code == 409
    assert r.data["error"]["codigo"] == "excede_pendiente"


def test_anular_orden_por_api(api_bodeguero, admin):
    orden = crear_orden_simple(admin, emitir=True)
    r = api_bodeguero.post(
        f"/api/v1/compras/ordenes/{orden.id}/anular/", {"motivo": "cancelada"}, format="json"
    )
    assert r.status_code == 200
    assert r.data["estado"] == "ANULADA"


def test_listar_recepciones_de_una_orden(api_bodeguero, admin):
    orden = crear_orden_simple(admin, emitir=True)
    linea = orden.lineas.first()
    api_bodeguero.post(
        f"/api/v1/compras/ordenes/{orden.id}/recibir/",
        {"lineas": [{"linea_orden": linea.id, "cantidad": "3"}]},
        format="json",
    )
    r = api_bodeguero.get(f"/api/v1/compras/ordenes/{orden.id}/recepciones/")
    assert r.status_code == 200
    assert len(r.data) == 1
    assert r.data[0]["lineas"][0]["cantidad"] == "3.000"


# ─── info-producto: último costo + pedido pendiente ─────────
def test_info_producto_sin_historial(api_bodeguero):
    ProductoFactory(sku="NUEVO-1")
    r = api_bodeguero.get("/api/v1/compras/ordenes/info-producto/NUEVO-1/")
    assert r.status_code == 200
    assert r.data["ultimo_costo"] is None
    assert r.data["pedido_pendiente"] is None


def test_info_producto_devuelve_ultimo_costo_y_pedido_abierto(api_bodeguero, admin):
    p = ProductoFactory(sku="REP-1")
    prov = ProveedorFactory()
    orden = crear_orden_simple(admin, proveedor=prov, productos=[(p, 5, 800)], emitir=True)

    r = api_bodeguero.get(f"/api/v1/compras/ordenes/info-producto/{p.sku}/?proveedor={prov.rut}")
    assert r.status_code == 200
    assert r.data["ultimo_costo"]["costo_unitario"] == 800
    assert r.data["ultimo_costo"]["mismo_proveedor"] is True
    assert r.data["pedido_pendiente"]["orden_codigo"] == orden.codigo
    assert r.data["pedido_pendiente"]["estado"] == "EMITIDA"


def test_info_producto_no_avisa_si_la_orden_ya_llego(api_bodeguero, admin):
    p = ProductoFactory(sku="REP-2")
    orden = crear_orden_simple(admin, productos=[(p, Decimal("5"), 800)], emitir=True)
    linea = orden.lineas.first()
    api_bodeguero.post(
        f"/api/v1/compras/ordenes/{orden.id}/recibir/",
        {"lineas": [{"linea_orden": linea.id, "cantidad": "5"}]},
        format="json",
    )
    r = api_bodeguero.get(f"/api/v1/compras/ordenes/info-producto/{p.sku}/")
    assert r.status_code == 200
    assert r.data["pedido_pendiente"] is None  # RECIBIDA: ya no está abierta
    assert r.data["ultimo_costo"]["costo_unitario"] == 800


# ─── PDF / envío al proveedor ───────────────────────────────
def test_descargar_pdf(api_bodeguero, admin):
    orden = crear_orden_simple(admin)
    r = api_bodeguero.get(f"/api/v1/compras/ordenes/{orden.id}/pdf/")
    assert r.status_code == 200
    assert r["Content-Type"] == "application/pdf"
    assert orden.codigo in r["Content-Disposition"]
    assert r.content.startswith(b"%PDF")


def test_enviar_usa_el_email_del_proveedor_por_defecto(api_bodeguero, admin, mailoutbox):
    prov = ProveedorFactory(contacto_email="compras@distribuidora.cl")
    orden = crear_orden_simple(admin, proveedor=prov)
    r = api_bodeguero.post(f"/api/v1/compras/ordenes/{orden.id}/enviar/", {}, format="json")
    assert r.status_code == 200, r.data
    assert r.data == {"enviado": True, "para": "compras@distribuidora.cl"}
    assert len(mailoutbox) == 1
    correo = mailoutbox[0]
    assert correo.to == ["compras@distribuidora.cl"]
    assert orden.codigo in correo.subject
    assert len(correo.attachments) == 1
    assert correo.attachments[0][0] == f"{orden.codigo}.pdf"
    # Sin montos en el cuerpo: el precio lo cotiza el proveedor de vuelta.
    assert "$" not in correo.body
    assert "total" not in correo.body.lower()


def test_enviar_permite_indicar_otro_email(api_bodeguero, admin, mailoutbox):
    prov = ProveedorFactory(contacto_email="original@proveedor.cl")
    orden = crear_orden_simple(admin, proveedor=prov)
    r = api_bodeguero.post(
        f"/api/v1/compras/ordenes/{orden.id}/enviar/",
        {"email": "otra-persona@proveedor.cl", "mensaje": "Confirmar plazo de entrega."},
        format="json",
    )
    assert r.status_code == 200
    assert r.data["para"] == "otra-persona@proveedor.cl"
    assert mailoutbox[0].to == ["otra-persona@proveedor.cl"]
    assert "Confirmar plazo de entrega." in mailoutbox[0].body


def test_enviar_sin_email_es_error_de_dominio(api_bodeguero, admin):
    prov = ProveedorFactory(contacto_email="")
    orden = crear_orden_simple(admin, proveedor=prov)
    r = api_bodeguero.post(f"/api/v1/compras/ordenes/{orden.id}/enviar/", {}, format="json")
    assert r.status_code == 400
    assert r.data["error"]["codigo"] == "sin_email"


def test_enviar_con_fallo_de_smtp_no_es_un_500(api_bodeguero, admin, monkeypatch):
    """Regresión: un error de correo (SMTP mal configurado, host caído…) debe
    verse como un error de negocio claro, no un 500 sin explicación."""
    from django.core.mail import EmailMessage

    def falla(self, *args, **kwargs):
        raise ConnectionRefusedError("servidor SMTP no disponible")

    monkeypatch.setattr(EmailMessage, "send", falla)
    prov = ProveedorFactory(contacto_email="prov@x.cl")
    orden = crear_orden_simple(admin, proveedor=prov)
    r = api_bodeguero.post(f"/api/v1/compras/ordenes/{orden.id}/enviar/", {}, format="json")
    assert r.status_code == 400
    assert r.data["error"]["codigo"] == "envio_fallido"
