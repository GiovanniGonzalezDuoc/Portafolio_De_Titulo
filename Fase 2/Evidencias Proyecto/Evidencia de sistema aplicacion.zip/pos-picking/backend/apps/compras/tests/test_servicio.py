"""Tests del servicio de compras (flujo orden → recepción → stock)."""

from decimal import Decimal

import pytest

from apps.catalogo.tests.factories import ProductoFactory
from apps.compras import services
from apps.compras.models import EstadoOrdenCompra, LineaRecepcion, RecepcionCompra
from apps.core.exceptions import ConflictoEstado
from apps.inventario import services as inventario
from apps.inventario.models import MovimientoInventario, TipoMovimiento

from .factories import crear_orden_simple

pytestmark = pytest.mark.django_db


# ─── Crear / emitir / anular ────────────────────────────────
def test_crear_orden_queda_en_borrador_y_calcula_total(admin):
    p1, p2 = ProductoFactory(), ProductoFactory()
    orden = crear_orden_simple(admin, productos=[(p1, 10, 500), (p2, 4, 1000)])
    assert orden.estado == EstadoOrdenCompra.BORRADOR
    assert orden.total_estimado == 10 * 500 + 4 * 1000
    assert orden.codigo.startswith("OC-")


def test_crear_orden_no_modifica_el_stock(admin):
    p = ProductoFactory()
    crear_orden_simple(admin, productos=[(p, 50, 300)])
    assert inventario.stock_de(p) == Decimal("0")
    assert MovimientoInventario.objects.count() == 0


def test_crear_orden_rechaza_producto_repetido(admin):
    p = ProductoFactory()
    with pytest.raises(services.ComprasError):
        crear_orden_simple(admin, productos=[(p, 5, 100), (p, 3, 100)])


def test_crear_orden_rechaza_producto_inactivo(admin):
    p = ProductoFactory(activo=False)
    with pytest.raises(services.ComprasError):
        crear_orden_simple(admin, productos=[(p, 5, 100)])


def test_emitir_solo_desde_borrador(admin):
    orden = crear_orden_simple(admin, emitir=True)
    assert orden.estado == EstadoOrdenCompra.EMITIDA
    assert orden.fecha_emision is not None
    with pytest.raises(ConflictoEstado):
        services.emitir_orden(orden, admin)


def test_anular_orden_emitida(admin):
    orden = crear_orden_simple(admin, emitir=True)
    services.anular_orden(orden, admin, "proveedor sin stock")
    assert orden.estado == EstadoOrdenCompra.ANULADA


def test_no_se_anula_orden_con_recepciones(admin):
    p = ProductoFactory()
    orden = crear_orden_simple(admin, productos=[(p, 10, 500)], emitir=True)
    linea = orden.lineas.first()
    services.recibir(orden=orden, lineas=[{"linea_orden": linea, "cantidad": Decimal("5")}], usuario=admin)
    with pytest.raises(ConflictoEstado):
        services.anular_orden(orden, admin, "x")


# ─── Recepción ──────────────────────────────────────────────
def test_recepcion_total_aumenta_stock_y_cierra_orden(admin):
    p = ProductoFactory(costo_referencial=0)
    orden = crear_orden_simple(admin, productos=[(p, 20, 750)], emitir=True)
    linea = orden.lineas.first()

    recepcion = services.recibir(
        orden=orden,
        lineas=[{"linea_orden": linea, "cantidad": Decimal("20")}],
        usuario=admin,
        documento_proveedor="F-12345",
    )

    assert inventario.stock_de(p) == Decimal("20")
    linea.refresh_from_db()
    assert linea.cantidad_recibida == Decimal("20")
    orden.refresh_from_db()
    assert orden.estado == EstadoOrdenCompra.RECIBIDA
    p.refresh_from_db()
    assert p.costo_referencial == 750

    mov = MovimientoInventario.objects.get(doc_tipo="recepcion_compra", doc_id=recepcion.id)
    assert mov.tipo == TipoMovimiento.COMPRA
    assert mov.cantidad == Decimal("20")
    assert LineaRecepcion.objects.get(recepcion=recepcion).movimiento == mov


def test_recepcion_parcial_deja_orden_parcial(admin):
    p = ProductoFactory()
    orden = crear_orden_simple(admin, productos=[(p, 30, 400)], emitir=True)
    linea = orden.lineas.first()

    services.recibir(orden=orden, lineas=[{"linea_orden": linea, "cantidad": Decimal("10")}], usuario=admin)
    orden.refresh_from_db()
    assert orden.estado == EstadoOrdenCompra.RECIBIDA_PARCIAL
    assert inventario.stock_de(p) == Decimal("10")

    services.recibir(orden=orden, lineas=[{"linea_orden": linea, "cantidad": Decimal("20")}], usuario=admin)
    orden.refresh_from_db()
    assert orden.estado == EstadoOrdenCompra.RECIBIDA
    assert inventario.stock_de(p) == Decimal("30")


def test_recepcion_permite_ajustar_el_precio_real(admin):
    """Si el precio cambió entre la cotización y la llegada, se puede indicar
    el costo real al recibir: queda guardado en la recepción y es el que
    actualiza el costo referencial del producto (no el cotizado)."""
    p = ProductoFactory(costo_referencial=0)
    orden = crear_orden_simple(admin, productos=[(p, 20, 750)], emitir=True)
    linea = orden.lineas.first()

    recepcion = services.recibir(
        orden=orden,
        lineas=[{"linea_orden": linea, "cantidad": Decimal("20"), "costo_unitario": 820}],
        usuario=admin,
    )

    p.refresh_from_db()
    assert p.costo_referencial == 820
    linea_recepcion = LineaRecepcion.objects.get(recepcion=recepcion)
    assert linea_recepcion.costo_unitario == 820
    # La línea de la orden conserva lo cotizado originalmente.
    linea.refresh_from_db()
    assert linea.costo_unitario == 750


def test_no_se_puede_recibir_mas_de_lo_pendiente(admin):
    p = ProductoFactory()
    orden = crear_orden_simple(admin, productos=[(p, 10, 400)], emitir=True)
    linea = orden.lineas.first()
    with pytest.raises(ConflictoEstado):
        services.recibir(orden=orden, lineas=[{"linea_orden": linea, "cantidad": Decimal("11")}], usuario=admin)
    assert inventario.stock_de(p) == Decimal("0")


def test_no_se_recibe_una_orden_en_borrador(admin):
    orden = crear_orden_simple(admin)
    linea = orden.lineas.first()
    with pytest.raises(ConflictoEstado):
        services.recibir(orden=orden, lineas=[{"linea_orden": linea, "cantidad": Decimal("1")}], usuario=admin)


def test_recepcion_es_atomica_si_una_linea_falla(admin):
    p1, p2 = ProductoFactory(), ProductoFactory()
    orden = crear_orden_simple(admin, productos=[(p1, 10, 400), (p2, 10, 400)], emitir=True)
    l1, l2 = orden.lineas.order_by("id")

    with pytest.raises(ConflictoEstado):
        services.recibir(
            orden=orden,
            lineas=[
                {"linea_orden": l1, "cantidad": Decimal("5")},
                {"linea_orden": l2, "cantidad": Decimal("999")},  # excede
            ],
            usuario=admin,
        )

    assert RecepcionCompra.objects.count() == 0
    assert inventario.stock_de(p1) == Decimal("0")
    l1.refresh_from_db()
    assert l1.cantidad_recibida == Decimal("0")


# ─── Stock en tránsito ──────────────────────────────────────
def test_stock_en_transito(admin):
    p = ProductoFactory()
    orden = crear_orden_simple(admin, productos=[(p, 40, 400)], emitir=True)
    assert services.stock_en_transito(p) == Decimal("40")

    linea = orden.lineas.first()
    services.recibir(orden=orden, lineas=[{"linea_orden": linea, "cantidad": Decimal("15")}], usuario=admin)
    assert services.stock_en_transito(p) == Decimal("25")


def test_orden_anulada_no_cuenta_como_transito(admin):
    p = ProductoFactory()
    orden = crear_orden_simple(admin, productos=[(p, 40, 400)], emitir=True)
    services.anular_orden(orden, admin, "x")
    assert services.stock_en_transito(p) == Decimal("0")
