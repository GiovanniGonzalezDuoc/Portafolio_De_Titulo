"""Factories de compras."""

from decimal import Decimal

from apps.catalogo.tests.factories import ProductoFactory
from apps.compras import services
from apps.proveedores.tests.factories import ProveedorFactory


def crear_orden_simple(usuario, *, proveedor=None, productos=None, emitir=False):
    """Helper: crea (y opcionalmente emite) una OC con líneas dadas.

    ``productos``: lista de ``(Producto, cantidad, costo)``. Si es None, genera 1.
    """
    proveedor = proveedor or ProveedorFactory()
    if productos is None:
        productos = [(ProductoFactory(), Decimal("10"), 500)]
    orden = services.crear_orden(
        proveedor=proveedor,
        lineas=[
            {"producto": p, "cantidad": Decimal(str(c)), "costo_unitario": int(costo)}
            for p, c, costo in productos
        ],
        usuario=usuario,
    )
    if emitir:
        services.emitir_orden(orden, usuario)
    return orden
