"""
Modelos de compras.

Flujo: BORRADOR → EMITIDA → (RECIBIDA_PARCIAL) → RECIBIDA / CERRADA, o ANULADA.

**Regla clave:** crear u emitir una orden de compra NO modifica el stock.
El stock solo cambia al registrar una ``RecepcionCompra`` (ver ``services``).
"""

from __future__ import annotations

from decimal import Decimal

from django.conf import settings
from django.db import models


class EstadoOrdenCompra(models.TextChoices):
    BORRADOR = "BORRADOR", "Borrador"
    EMITIDA = "EMITIDA", "Emitida"
    RECIBIDA_PARCIAL = "RECIBIDA_PARCIAL", "Recibida parcialmente"
    RECIBIDA = "RECIBIDA", "Recibida"
    CERRADA = "CERRADA", "Cerrada"
    ANULADA = "ANULADA", "Anulada"


ESTADOS_RECIBIBLES = {EstadoOrdenCompra.EMITIDA, EstadoOrdenCompra.RECIBIDA_PARCIAL}
ESTADOS_ANULABLES = {EstadoOrdenCompra.BORRADOR, EstadoOrdenCompra.EMITIDA}


class OrdenCompra(models.Model):
    codigo = models.CharField("código", max_length=20, unique=True)
    proveedor = models.ForeignKey(
        "proveedores.Proveedor", on_delete=models.PROTECT, related_name="ordenes_compra"
    )
    estado = models.CharField(
        "estado", max_length=20, choices=EstadoOrdenCompra.choices,
        default=EstadoOrdenCompra.BORRADOR,
    )
    fecha_emision = models.DateTimeField("fecha de emisión", null=True, blank=True)
    observacion = models.CharField("observación", max_length=300, blank=True)
    total_estimado = models.PositiveIntegerField("total estimado (CLP)", default=0)

    creada_por = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="ordenes_compra"
    )
    anulada_por = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    motivo_anulacion = models.CharField("motivo de anulación", max_length=200, blank=True)

    creado_en = models.DateTimeField("creado en", auto_now_add=True)
    actualizado_en = models.DateTimeField("actualizado en", auto_now=True)

    class Meta:
        verbose_name = "orden de compra"
        verbose_name_plural = "órdenes de compra"
        ordering = ["-creado_en"]
        indexes = [
            models.Index(fields=["proveedor", "estado"]),
            models.Index(fields=["estado", "fecha_emision"]),
        ]

    def __str__(self) -> str:
        return f"{self.codigo} ({self.get_estado_display()})"

    def recalcular_total(self) -> None:
        self.total_estimado = sum(
            int(linea.cantidad * linea.costo_unitario) for linea in self.lineas.all()
        )


class LineaOrdenCompra(models.Model):
    orden = models.ForeignKey(OrdenCompra, on_delete=models.CASCADE, related_name="lineas")
    producto = models.ForeignKey(
        "catalogo.Producto", on_delete=models.PROTECT, related_name="lineas_orden_compra"
    )
    cantidad = models.DecimalField("cantidad", max_digits=12, decimal_places=3)
    cantidad_recibida = models.DecimalField(
        "cantidad recibida", max_digits=12, decimal_places=3, default=Decimal("0")
    )
    costo_unitario = models.PositiveIntegerField("costo unitario (CLP)")

    class Meta:
        verbose_name = "línea de orden de compra"
        verbose_name_plural = "líneas de orden de compra"
        constraints = [
            models.UniqueConstraint(
                fields=["orden", "producto"], name="linea_oc_producto_unico"
            ),
            models.CheckConstraint(condition=models.Q(cantidad__gt=0), name="linea_oc_cantidad_positiva"),
            models.CheckConstraint(
                condition=models.Q(cantidad_recibida__gte=0)
                & models.Q(cantidad_recibida__lte=models.F("cantidad")),
                name="linea_oc_recibida_valida",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.producto.sku} x{self.cantidad}"

    @property
    def pendiente(self) -> Decimal:
        return self.cantidad - self.cantidad_recibida


class RecepcionCompra(models.Model):
    codigo = models.CharField("código", max_length=20, unique=True)
    orden = models.ForeignKey(
        OrdenCompra, on_delete=models.PROTECT, related_name="recepciones"
    )
    ubicacion = models.ForeignKey(
        "inventario.Ubicacion", on_delete=models.PROTECT, related_name="recepciones"
    )
    documento_proveedor = models.CharField("documento del proveedor", max_length=40, blank=True)
    recibida_por = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="recepciones_compra"
    )
    creado_en = models.DateTimeField("creado en", auto_now_add=True)

    class Meta:
        verbose_name = "recepción de compra"
        verbose_name_plural = "recepciones de compra"
        ordering = ["-creado_en"]

    def __str__(self) -> str:
        return f"{self.codigo} (OC {self.orden.codigo})"


class LineaRecepcion(models.Model):
    recepcion = models.ForeignKey(
        RecepcionCompra, on_delete=models.CASCADE, related_name="lineas"
    )
    linea_orden = models.ForeignKey(
        LineaOrdenCompra, on_delete=models.PROTECT, related_name="lineas_recepcion"
    )
    cantidad = models.DecimalField("cantidad", max_digits=12, decimal_places=3)
    costo_unitario = models.PositiveIntegerField(
        "costo unitario real (CLP)", default=0,
        help_text="Precio al que realmente se pagó/llegó el producto — puede diferir del "
        "cotizado en la orden si cambió entre la cotización y la llegada.",
    )
    movimiento = models.ForeignKey(
        "inventario.MovimientoInventario",
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="+",
    )

    class Meta:
        verbose_name = "línea de recepción"
        verbose_name_plural = "líneas de recepción"
        constraints = [
            models.CheckConstraint(
                condition=models.Q(cantidad__gt=0), name="linea_recepcion_cantidad_positiva"
            )
        ]

    def __str__(self) -> str:
        return f"{self.linea_orden.producto.sku} x{self.cantidad}"
