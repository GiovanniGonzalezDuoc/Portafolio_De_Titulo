from django.contrib import admin

from .models import (
    LineaOrdenCompra,
    LineaRecepcion,
    OrdenCompra,
    RecepcionCompra,
)


class LineaOrdenCompraInline(admin.TabularInline):
    model = LineaOrdenCompra
    extra = 0
    autocomplete_fields = ["producto"]


@admin.register(OrdenCompra)
class OrdenCompraAdmin(admin.ModelAdmin):
    list_display = ["codigo", "proveedor", "estado", "total_estimado", "creada_por", "creado_en"]
    list_filter = ["estado", "proveedor"]
    search_fields = ["codigo", "proveedor__razon_social"]
    inlines = [LineaOrdenCompraInline]
    readonly_fields = ["codigo", "total_estimado", "fecha_emision"]


class LineaRecepcionInline(admin.TabularInline):
    model = LineaRecepcion
    extra = 0
    readonly_fields = ["linea_orden", "cantidad", "movimiento"]


@admin.register(RecepcionCompra)
class RecepcionCompraAdmin(admin.ModelAdmin):
    list_display = ["codigo", "orden", "ubicacion", "recibida_por", "creado_en"]
    search_fields = ["codigo", "orden__codigo"]
    inlines = [LineaRecepcionInline]
    readonly_fields = ["codigo", "orden", "ubicacion", "documento_proveedor", "recibida_por"]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
