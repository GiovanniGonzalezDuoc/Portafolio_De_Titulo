"""
Lógica de negocio de compras.

- ``crear_orden`` / ``emitir_orden`` / ``anular_orden``: gestionan la orden sin
  tocar el stock.
- ``recibir``: única operación que aumenta el stock, y lo hace a través del
  servicio de inventario (movimiento tipo COMPRA), todo dentro de una transacción.
"""

from __future__ import annotations

import logging
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from apps.core.exceptions import ConflictoEstado, ErrorDominio
from apps.core.models import Secuencia
from apps.inventario import services as inventario
from apps.inventario.models import TipoMovimiento, Ubicacion

from .models import (
    ESTADOS_ANULABLES,
    ESTADOS_RECIBIBLES,
    EstadoOrdenCompra,
    LineaOrdenCompra,
    LineaRecepcion,
    OrdenCompra,
    RecepcionCompra,
)

logger = logging.getLogger("pos.compras")
CERO = Decimal("0")

DOC_TIPO_RECEPCION = "recepcion_compra"


class ComprasError(ErrorDominio):
    codigo = "compras_error"


@transaction.atomic
def crear_orden(*, proveedor, lineas: list[dict], usuario, observacion: str = "") -> OrdenCompra:
    """
    ``lineas``: ``[{"producto": <Producto>, "cantidad": Decimal, "costo_unitario": int}, ...]``
    """
    if not lineas:
        raise ComprasError("La orden debe tener al menos una línea.", codigo="orden_vacia")
    if not proveedor.activo:
        raise ComprasError("El proveedor está inactivo.", codigo="proveedor_inactivo")

    vistos = set()
    for linea in lineas:
        producto = linea["producto"]
        if producto.id in vistos:
            raise ComprasError(
                f"El producto {producto.sku} está repetido en la orden.",
                codigo="producto_repetido",
            )
        vistos.add(producto.id)
        if not producto.activo:
            raise ComprasError(
                f"El producto {producto.sku} está inactivo.", codigo="producto_inactivo"
            )
        if Decimal(str(linea["cantidad"])) <= 0:
            raise ComprasError("Las cantidades deben ser mayores que cero.", codigo="cantidad_invalida")
        if int(linea["costo_unitario"]) < 0:
            raise ComprasError("El costo no puede ser negativo.", codigo="costo_invalido")

    orden = OrdenCompra.objects.create(
        codigo=Secuencia.folio("orden_compra", "OC"),
        proveedor=proveedor,
        creada_por=usuario,
        observacion=observacion,
        estado=EstadoOrdenCompra.BORRADOR,
    )
    for linea in lineas:
        LineaOrdenCompra.objects.create(
            orden=orden,
            producto=linea["producto"],
            cantidad=Decimal(str(linea["cantidad"])),
            costo_unitario=int(linea["costo_unitario"]),
        )
    orden.recalcular_total()
    orden.save(update_fields=["total_estimado", "actualizado_en"])
    logger.info("OC %s creada por %s (%s líneas)", orden.codigo, usuario.username, len(lineas))
    return orden


@transaction.atomic
def emitir_orden(orden: OrdenCompra, usuario) -> OrdenCompra:
    if orden.estado != EstadoOrdenCompra.BORRADOR:
        raise ConflictoEstado(
            f"Solo se pueden emitir órdenes en borrador (esta está {orden.get_estado_display()}).",
            codigo="orden_no_emitible",
        )
    orden.estado = EstadoOrdenCompra.EMITIDA
    orden.fecha_emision = timezone.now()
    orden.save(update_fields=["estado", "fecha_emision", "actualizado_en"])
    logger.info("OC %s emitida por %s", orden.codigo, usuario.username)
    return orden


@transaction.atomic
def anular_orden(orden: OrdenCompra, usuario, motivo: str) -> OrdenCompra:
    if orden.estado not in ESTADOS_ANULABLES:
        raise ConflictoEstado(
            f"No se puede anular una orden {orden.get_estado_display()}.",
            codigo="orden_no_anulable",
        )
    if orden.recepciones.exists():
        raise ConflictoEstado(
            "La orden tiene recepciones registradas y no puede anularse.",
            codigo="orden_con_recepciones",
        )
    orden.estado = EstadoOrdenCompra.ANULADA
    orden.anulada_por = usuario
    orden.motivo_anulacion = motivo
    orden.save(update_fields=["estado", "anulada_por", "motivo_anulacion", "actualizado_en"])
    logger.info("OC %s anulada por %s: %s", orden.codigo, usuario.username, motivo)
    return orden


@transaction.atomic
def recibir(
    *,
    orden: OrdenCompra,
    lineas: list[dict],
    usuario,
    ubicacion: Ubicacion | None = None,
    documento_proveedor: str = "",
) -> RecepcionCompra:
    """
    Registra una recepción (total o parcial).

    ``lineas``: ``[{"linea_orden": <LineaOrdenCompra>, "cantidad": Decimal,
    "costo_unitario": <int, opcional>}, ...]``. ``costo_unitario`` es el precio
    real al que llegó el producto (puede haber cambiado desde que se cotizó la
    orden); si no se indica, se usa el cotizado en la línea de la orden.

    Efectos (todo dentro de la transacción):
      1. valida estado de la orden y cantidades pendientes;
      2. crea ``RecepcionCompra`` + ``LineaRecepcion`` (con el costo real);
      3. por cada línea, movimiento de inventario tipo COMPRA (aumenta stock);
      4. acumula ``cantidad_recibida`` en las líneas de la orden;
      5. actualiza el ``costo_referencial`` del producto al costo real recibido;
      6. recalcula el estado de la orden.
    """
    orden = OrdenCompra.objects.select_for_update().get(pk=orden.pk)
    if orden.estado not in ESTADOS_RECIBIBLES:
        raise ConflictoEstado(
            f"La orden está {orden.get_estado_display()} y no admite recepciones.",
            codigo="orden_no_recibible",
        )
    if not lineas:
        raise ComprasError("Debes indicar al menos una línea a recibir.", codigo="recepcion_vacia")

    ubicacion = ubicacion or Ubicacion.principal()

    # Validación previa (no persiste nada si algo falla).
    normalizadas = []
    for item in lineas:
        linea_orden: LineaOrdenCompra = item["linea_orden"]
        cantidad = Decimal(str(item["cantidad"]))
        costo_unitario = item.get("costo_unitario")
        costo_unitario = linea_orden.costo_unitario if costo_unitario is None else int(costo_unitario)
        if linea_orden.orden_id != orden.id:
            raise ComprasError("Una línea no pertenece a esta orden.", codigo="linea_ajena")
        if cantidad <= 0:
            raise ComprasError("Las cantidades a recibir deben ser positivas.", codigo="cantidad_invalida")
        if cantidad > linea_orden.pendiente:
            raise ConflictoEstado(
                f"{linea_orden.producto.sku}: se intenta recibir {cantidad} pero "
                f"solo quedan {linea_orden.pendiente} pendientes.",
                codigo="excede_pendiente",
            )
        normalizadas.append((linea_orden, cantidad, costo_unitario))

    recepcion = RecepcionCompra.objects.create(
        codigo=Secuencia.folio("recepcion_compra", "REC"),
        orden=orden,
        ubicacion=ubicacion,
        documento_proveedor=documento_proveedor,
        recibida_por=usuario,
    )

    for linea_orden, cantidad, costo_unitario in normalizadas:
        movimiento = inventario.registrar_movimiento(
            producto=linea_orden.producto,
            tipo=TipoMovimiento.COMPRA,
            cantidad=cantidad,
            usuario=usuario,
            ubicacion=ubicacion,
            motivo=f"Recepción {recepcion.codigo} (OC {orden.codigo})",
            doc_tipo=DOC_TIPO_RECEPCION,
            doc_id=recepcion.id,
        )
        LineaRecepcion.objects.create(
            recepcion=recepcion,
            linea_orden=linea_orden,
            cantidad=cantidad,
            costo_unitario=costo_unitario,
            movimiento=movimiento,
        )
        linea_orden.cantidad_recibida += cantidad
        linea_orden.save(update_fields=["cantidad_recibida"])

        producto = linea_orden.producto
        producto.costo_referencial = costo_unitario
        producto.save(update_fields=["costo_referencial", "actualizado_en"])

    _recalcular_estado(orden)
    logger.info(
        "Recepción %s de OC %s por %s (%s líneas)",
        recepcion.codigo, orden.codigo, usuario.username, len(normalizadas),
    )
    return recepcion


def _recalcular_estado(orden: OrdenCompra) -> None:
    lineas = list(orden.lineas.all())
    if all(linea.cantidad_recibida >= linea.cantidad for linea in lineas):
        orden.estado = EstadoOrdenCompra.RECIBIDA
    elif any(linea.cantidad_recibida > 0 for linea in lineas):
        orden.estado = EstadoOrdenCompra.RECIBIDA_PARCIAL
    orden.save(update_fields=["estado", "actualizado_en"])


# ─── Envío al proveedor (cotización / orden en PDF) ─────────
def enviar_a_proveedor(orden: OrdenCompra, *, email: str | None = None, mensaje: str = "") -> str:
    """
    Envía el PDF de ``orden`` por correo al proveedor. ``email`` reemplaza
    puntualmente el contacto guardado (útil si hay que mandarla a otra
    persona); si no se indica ninguno de los dos, es un error de dominio, no
    un 500. Devuelve el email al que se envió.
    """
    from django.conf import settings
    from django.core.mail import EmailMessage

    from .pdf import orden_pdf_bytes

    destino = (email or orden.proveedor.contacto_email or "").strip()
    if not destino:
        raise ComprasError(
            "El proveedor no tiene un email de contacto guardado; indica uno para enviar.",
            codigo="sin_email",
        )

    # Sin montos en el cuerpo: el precio lo cotiza el proveedor de vuelta,
    # no algo que debamos revelarle nosotros (mismo criterio que el PDF).
    asunto = f"Cotización {orden.codigo} — Liquidadora Los Europeos"
    cuerpo = (
        f"Estimado(a) {orden.proveedor.contacto_nombre or orden.proveedor.razon_social},\n\n"
        f"Adjuntamos la cotización de compra {orden.codigo}.\n\n"
        + (f"{mensaje.strip()}\n\n" if mensaje.strip() else "")
        + "Quedamos atentos a su confirmación.\n\nSaludos,\nLiquidadora Los Europeos"
    )
    correo = EmailMessage(
        asunto, cuerpo,
        from_email=getattr(settings, "DEFAULT_FROM_EMAIL", None),
        to=[destino],
    )
    correo.attach(f"{orden.codigo}.pdf", orden_pdf_bytes(orden), "application/pdf")
    try:
        correo.send(fail_silently=False)
    except Exception as exc:
        # Cualquier falla de SMTP (credenciales, host caído, timeout…) debe
        # verse como un error de negocio claro, no un 500 genérico — el envío
        # de correo depende de una configuración externa que puede fallar.
        logger.warning("No se pudo enviar la OC %s a %s: %s", orden.codigo, destino, exc)
        raise ComprasError(
            "No se pudo enviar el correo. Revisa la configuración de correo saliente e intenta de nuevo.",
            codigo="envio_fallido",
        ) from exc

    logger.info("OC %s enviada por correo a %s", orden.codigo, destino)
    return destino


# ─── Consultas ──────────────────────────────────────────────
# Estados que aún no cerraron el ciclo de compra (para avisar de pedidos
# repetidos): un borrador o algo emitido/parcial todavía puede llegar.
ESTADOS_ABIERTOS = {
    EstadoOrdenCompra.BORRADOR,
    EstadoOrdenCompra.EMITIDA,
    EstadoOrdenCompra.RECIBIDA_PARCIAL,
}


def ultimo_costo(producto, proveedor=None) -> dict | None:
    """
    Precio al que se compró este producto la última vez (línea de la orden no
    anulada más reciente). Si se indica ``proveedor``, prioriza una línea de
    ese mismo proveedor; si no hay, cae al último costo con cualquiera —
    dejando claro de qué proveedor era, para cotizar el precio actual.
    """
    base = (
        LineaOrdenCompra.objects.filter(producto=producto)
        .exclude(orden__estado=EstadoOrdenCompra.ANULADA)
        .select_related("orden", "orden__proveedor")
    )
    linea = None
    if proveedor is not None:
        linea = base.filter(orden__proveedor=proveedor).order_by("-orden__creado_en").first()
    if linea is None:
        linea = base.order_by("-orden__creado_en").first()
    if linea is None:
        return None
    return {
        "costo_unitario": linea.costo_unitario,
        "proveedor": linea.orden.proveedor.razon_social,
        "mismo_proveedor": proveedor is not None and linea.orden.proveedor_id == proveedor.id,
        "fecha": linea.orden.creado_en,
        "orden_codigo": linea.orden.codigo,
    }


def pedido_pendiente(producto, proveedor=None) -> dict | None:
    """
    Orden abierta (sin llegar del todo) más reciente que ya incluye este
    producto — para avisar antes de generar un pedido repetido al mismo
    proveedor. Si no se indica ``proveedor``, avisa de cualquiera.
    """
    qs = LineaOrdenCompra.objects.filter(
        producto=producto, orden__estado__in=ESTADOS_ABIERTOS
    ).select_related("orden", "orden__proveedor")
    if proveedor is not None:
        qs = qs.filter(orden__proveedor=proveedor)
    linea = qs.order_by("-orden__creado_en").first()
    if linea is None:
        return None
    return {
        "orden_id": linea.orden_id,
        "orden_codigo": linea.orden.codigo,
        "estado": linea.orden.estado,
        "estado_display": linea.orden.get_estado_display(),
        "proveedor": linea.orden.proveedor.razon_social,
        "cantidad_pendiente": linea.pendiente,
    }


def stock_en_transito(producto, ubicacion: Ubicacion | None = None) -> Decimal:
    """
    Unidades pedidas y aún no recibidas de un producto
    (órdenes EMITIDA o RECIBIDA_PARCIAL). Lo usa el módulo de reposición.
    """
    lineas = LineaOrdenCompra.objects.filter(
        producto=producto, orden__estado__in=ESTADOS_RECIBIBLES
    )
    total = CERO
    for linea in lineas:
        total += linea.pendiente
    return total
