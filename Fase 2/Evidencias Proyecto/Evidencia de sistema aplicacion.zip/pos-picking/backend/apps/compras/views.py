"""ViewSets de compras."""

from __future__ import annotations

from django.shortcuts import get_object_or_404
from drf_spectacular.utils import OpenApiParameter, extend_schema
from rest_framework import mixins, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.catalogo.models import Producto
from apps.core.exceptions import ErrorDominio
from apps.proveedores.models import Proveedor
from apps.usuarios.permissions import PermisoPorAccion

from . import services
from .models import LineaOrdenCompra, OrdenCompra, RecepcionCompra
from .pdf import orden_pdf_response
from .serializers import (
    AnularOrdenSerializer,
    EnviarProveedorSerializer,
    OrdenCompraCrearSerializer,
    OrdenCompraSerializer,
    RecepcionCompraSerializer,
    RecepcionCrearSerializer,
)


class OrdenCompraViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = OrdenCompra.objects.select_related("proveedor", "creada_por").prefetch_related(
        "lineas__producto"
    )
    serializer_class = OrdenCompraSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        "list": "compras.ver",
        "retrieve": "compras.ver",
        "create": "compras.crear",
        "emitir": "compras.crear",
        "anular": "compras.crear",
        "recibir": "compras.recibir",
        "recepciones": "compras.ver",
        "info_producto": "compras.crear",
        "pdf": "compras.ver",
        "enviar": "compras.crear",
    }
    filterset_fields = ["estado", "proveedor__rut"]
    search_fields = ["codigo", "proveedor__razon_social"]
    ordering_fields = ["creado_en", "fecha_emision", "total_estimado"]

    # -- crear --------------------------------------------------
    @extend_schema(request=OrdenCompraCrearSerializer, responses=OrdenCompraSerializer)
    def create(self, request, *args, **kwargs):
        entrada = OrdenCompraCrearSerializer(data=request.data)
        entrada.is_valid(raise_exception=True)
        d = entrada.validated_data
        orden = services.crear_orden(
            proveedor=d["proveedor"],
            lineas=[
                {
                    "producto": ln["producto"],
                    "cantidad": ln["cantidad"],
                    "costo_unitario": ln["costo_unitario"],
                }
                for ln in d["lineas"]
            ],
            usuario=request.user,
            observacion=d.get("observacion", ""),
        )
        return Response(OrdenCompraSerializer(orden).data, status=status.HTTP_201_CREATED)

    # -- transiciones -----------------------------------------
    @action(detail=True, methods=["post"])
    def emitir(self, request, pk=None):
        orden = services.emitir_orden(self.get_object(), request.user)
        return Response(OrdenCompraSerializer(orden).data)

    @extend_schema(request=AnularOrdenSerializer, responses=OrdenCompraSerializer)
    @action(detail=True, methods=["post"])
    def anular(self, request, pk=None):
        serializer = AnularOrdenSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        orden = services.anular_orden(
            self.get_object(), request.user, serializer.validated_data["motivo"]
        )
        return Response(OrdenCompraSerializer(orden).data)

    # -- recepción -------------------------------------------
    @extend_schema(request=RecepcionCrearSerializer, responses=RecepcionCompraSerializer)
    @action(detail=True, methods=["post"])
    def recibir(self, request, pk=None):
        orden = self.get_object()
        entrada = RecepcionCrearSerializer(data=request.data)
        entrada.is_valid(raise_exception=True)
        d = entrada.validated_data

        lineas = []
        for item in d["lineas"]:
            linea_orden = LineaOrdenCompra.objects.filter(
                pk=item["linea_orden"], orden=orden
            ).select_related("producto").first()
            if linea_orden is None:
                raise ErrorDominio(
                    f"La línea {item['linea_orden']} no pertenece a la orden {orden.codigo}.",
                    codigo="linea_ajena",
                )
            lineas.append({
                "linea_orden": linea_orden,
                "cantidad": item["cantidad"],
                "costo_unitario": item.get("costo_unitario"),
            })

        recepcion = services.recibir(
            orden=orden,
            lineas=lineas,
            usuario=request.user,
            ubicacion=d.get("ubicacion"),
            documento_proveedor=d.get("documento_proveedor", ""),
        )
        return Response(
            RecepcionCompraSerializer(recepcion).data, status=status.HTTP_201_CREATED
        )

    @action(detail=True, methods=["get"])
    def recepciones(self, request, pk=None):
        orden = self.get_object()
        qs = orden.recepciones.prefetch_related("lineas__linea_orden__producto").all()
        return Response(RecepcionCompraSerializer(qs, many=True).data)

    # -- PDF / envío al proveedor -------------------------------
    @extend_schema(responses={200: {"type": "string", "format": "binary"}})
    @action(detail=True, methods=["get"])
    def pdf(self, request, pk=None):
        return orden_pdf_response(self.get_object())

    @extend_schema(
        request=EnviarProveedorSerializer,
        responses=None,
        description="Envía el PDF de la cotización/orden por correo al proveedor. "
        "`email` es opcional: si no se indica, usa el contacto guardado del proveedor.",
    )
    @action(detail=True, methods=["post"])
    def enviar(self, request, pk=None):
        entrada = EnviarProveedorSerializer(data=request.data)
        entrada.is_valid(raise_exception=True)
        d = entrada.validated_data
        enviado_a = services.enviar_a_proveedor(
            self.get_object(), email=d.get("email") or None, mensaje=d.get("mensaje", "")
        )
        return Response({"enviado": True, "para": enviado_a})

    # -- ayuda al armar una línea nueva ------------------------
    @extend_schema(
        parameters=[
            OpenApiParameter("sku", str, OpenApiParameter.PATH),
            OpenApiParameter("proveedor", str, description="RUT del proveedor elegido (opcional)."),
        ],
        responses=None,
        description="Último precio de compra del producto y si ya tiene un pedido abierto "
        "sin llegar del todo (para cotizar y evitar pedidos repetidos).",
    )
    @action(detail=False, methods=["get"], url_path="info-producto/(?P<sku>[^/]+)")
    def info_producto(self, request, sku=None):
        producto = get_object_or_404(Producto, sku=(sku or "").strip().upper())
        proveedor = None
        rut = request.query_params.get("proveedor")
        if rut:
            proveedor = Proveedor.objects.filter(rut=rut).first()
        return Response(
            {
                "ultimo_costo": services.ultimo_costo(producto, proveedor),
                "pedido_pendiente": services.pedido_pendiente(producto, proveedor),
            }
        )


class RecepcionCompraViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = RecepcionCompra.objects.select_related("orden", "ubicacion", "recibida_por")
    serializer_class = RecepcionCompraSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {"list": "compras.ver", "retrieve": "compras.ver"}
    filterset_fields = ["orden__codigo", "ubicacion__nombre"]
    ordering_fields = ["creado_en"]
