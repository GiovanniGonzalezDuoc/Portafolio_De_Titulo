"""
PDF de una orden de compra / cotización, para descargar o adjuntar en un
correo al proveedor.

Usa ``reportlab`` (Python puro, no requiere compilar — mismo criterio que
``openpyxl`` en ``apps.core.reportes``, pensado para hosting compartido).

**El PDF que se le manda al proveedor NO lleva precios.** Se pide la
cantidad; el precio lo cotiza el proveedor de vuelta — el costo unitario
guardado en la orden es solo referencia interna (para comparar contra la
última compra), no algo que debamos revelarle a quien nos vende.
"""

from __future__ import annotations

from decimal import Decimal
from io import BytesIO
from pathlib import Path

from django.http import HttpResponse
from django.utils import timezone
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    Image,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from .models import OrdenCompra

EMPRESA_NOMBRE = "Liquidadora Los Europeos"
_VERDE = colors.HexColor("#00794a")
_GRIS = colors.HexColor("#666666")
_LOGO = Path(__file__).resolve().parent / "assets" / "logo.png"
_LOGO_ANCHO_ORIGINAL, _LOGO_ALTO_ORIGINAL = 480, 376  # proporción real del PNG


def _cantidad(valor) -> str:
    """
    Cantidad en formato chileno, sin ceros de más: ``Decimal("15.000")`` (así
    la guarda el modelo, con 3 decimales fijos) se ve "15", no "15.000" — que
    en español se leería como quince MIL. Mismo criterio que
    ``shared/pipes/cantidad.pipe.ts`` en el frontend.
    """
    texto = format(Decimal(valor), "f")
    if "." in texto:
        texto = texto.rstrip("0").rstrip(".")
    entero, _, decimales = texto.partition(".")
    entero_fmt = f"{int(entero):,}".replace(",", ".")
    return f"{entero_fmt},{decimales}" if decimales else entero_fmt


def _filas_tabla(orden: OrdenCompra) -> list[list[str]]:
    """
    Filas de la tabla de líneas — sin precios: se le pide la cantidad al
    proveedor, el costo unitario es solo referencia interna (para comparar
    contra la última compra), no algo que debamos revelarle a quien nos vende.
    """
    filas = [["Producto", "SKU", "Cantidad"]]
    for linea in orden.lineas.select_related("producto").all():
        filas.append([linea.producto.nombre, linea.producto.sku, _cantidad(linea.cantidad)])
    return filas


def _logo() -> Image | None:
    if not _LOGO.exists():
        return None
    ancho = 2.8 * cm
    alto = ancho * (_LOGO_ALTO_ORIGINAL / _LOGO_ANCHO_ORIGINAL)
    return Image(str(_LOGO), width=ancho, height=alto)


def orden_pdf_bytes(orden: OrdenCompra) -> bytes:
    """Genera el PDF de ``orden`` (cotización u orden ya emitida) en memoria."""
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=letter,
        topMargin=2 * cm, bottomMargin=2 * cm, leftMargin=2 * cm, rightMargin=2 * cm,
    )
    estilos = getSampleStyleSheet()
    titulo = ParagraphStyle("titulo", parent=estilos["Heading1"], textColor=_VERDE, spaceAfter=2)
    subtitulo = ParagraphStyle("subtitulo", parent=estilos["Normal"], textColor=_GRIS, spaceAfter=14)
    etiqueta = ParagraphStyle("etiqueta", parent=estilos["Normal"], textColor=_GRIS, fontSize=9)

    # Encabezado: título/fecha a la izquierda, logo a la derecha.
    bloque_titulo = [
        Paragraph(EMPRESA_NOMBRE, titulo),
        Paragraph(
            f"Cotización / orden de compra {orden.codigo} — "
            f"generada el {timezone.localtime().strftime('%d/%m/%Y %H:%M')}",
            subtitulo,
        ),
    ]
    logo = _logo()
    fila_encabezado = [bloque_titulo, logo] if logo else [bloque_titulo]
    anchos_encabezado = [13.5 * cm, 3.5 * cm] if logo else [17 * cm]
    encabezado = Table([fila_encabezado], colWidths=anchos_encabezado)
    encabezado.setStyle(
        TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("ALIGN", (-1, 0), (-1, 0), "RIGHT"),
            ("LEFTPADDING", (0, 0), (-1, -1), 0),
            ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ])
    )

    elementos = [
        encabezado,
        Spacer(1, 4),
        Paragraph("Proveedor", etiqueta),
        Paragraph(f"<b>{orden.proveedor.razon_social}</b> — RUT {orden.proveedor.rut}", estilos["Normal"]),
    ]
    if orden.proveedor.giro:
        elementos.append(Paragraph(orden.proveedor.giro, estilos["Normal"]))
    if orden.proveedor.contacto_nombre or orden.proveedor.contacto_email:
        contacto = " · ".join(
            filter(None, [orden.proveedor.contacto_nombre, orden.proveedor.contacto_email])
        )
        elementos.append(Paragraph(contacto, estilos["Normal"]))
    elementos.append(Spacer(1, 16))

    filas = _filas_tabla(orden)
    tabla = Table(filas, colWidths=[9.5 * cm, 4 * cm, 3.5 * cm])
    tabla.setStyle(
        TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), _VERDE),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("ALIGN", (2, 0), (2, -1), "RIGHT"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dddddd")),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ])
    )
    elementos.append(tabla)

    if orden.observacion:
        elementos.append(Spacer(1, 16))
        elementos.append(Paragraph("Observación", etiqueta))
        elementos.append(Paragraph(orden.observacion, estilos["Normal"]))

    doc.build(elementos)
    return buffer.getvalue()


def orden_pdf_response(orden: OrdenCompra) -> HttpResponse:
    """Respuesta HTTP con el PDF como archivo adjunto para descargar."""
    resp = HttpResponse(orden_pdf_bytes(orden), content_type="application/pdf")
    resp["Content-Disposition"] = f'attachment; filename="{orden.codigo}.pdf"'
    return resp
