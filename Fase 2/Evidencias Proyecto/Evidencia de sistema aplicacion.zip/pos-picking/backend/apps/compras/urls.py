"""Rutas de compras."""

from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import OrdenCompraViewSet, RecepcionCompraViewSet

router = DefaultRouter()
router.register("ordenes", OrdenCompraViewSet, basename="orden-compra")
router.register("recepciones", RecepcionCompraViewSet, basename="recepcion-compra")

urlpatterns = [path("", include(router.urls))]
