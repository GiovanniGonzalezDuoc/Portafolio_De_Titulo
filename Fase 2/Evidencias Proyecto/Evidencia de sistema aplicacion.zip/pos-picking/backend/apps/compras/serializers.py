"""Serializers de compras."""

from __future__ import annotations

from decimal import Decimal

from rest_framework import serializers

from apps.catalogo.models import Producto
from apps.inventario.models import Ubicacion
from apps.proveedores.models import Proveedor

from .models import (
    LineaOrdenCompra,
    LineaRecepcion,
    OrdenCompra,
    RecepcionCompra,
)


# ─── Lectura ────────────────────────────────────────────────
class LineaOrdenCompraSerializer(serializers.ModelSerializer):
    producto = serializers.SlugRelatedField(slug_field="sku", read_only=True)
    producto_nombre = serializers.CharField(source="producto.nombre", read_only=True)
    pendiente = serializers.DecimalField(max_digits=12, decimal_places=3, read_only=True)

    class Meta:
        model = LineaOrdenCompra
        fields = [
            "id", "producto", "producto_nombre", "cantidad",
            "cantidad_recibida", "pendiente", "costo_unitario",
        ]


class OrdenCompraSerializer(serializers.ModelSerializer):
    proveedor = serializers.SlugRelatedField(slug_field="razon_social", read_only=True)
    proveedor_rut = serializers.CharField(source="proveedor.rut", read_only=True)
    proveedor_email = serializers.CharField(source="proveedor.contacto_email", read_only=True)
    creada_por = serializers.CharField(source="creada_por.username", read_only=True)
    estado_display = serializers.CharField(source="get_estado_display", read_only=True)
    lineas = LineaOrdenCompraSerializer(many=True, read_only=True)

    class Meta:
        model = OrdenCompra
        fields = [
            "id", "codigo", "proveedor", "proveedor_rut", "proveedor_email", "estado", "estado_display",
            "fecha_emision", "observacion", "total_estimado", "creada_por",
            "motivo_anulacion", "creado_en", "actualizado_en", "lineas",
        ]
        read_only_fields = fields


class EnviarProveedorSerializer(serializers.Serializer):
    email = serializers.EmailField(required=False, allow_blank=True)
    mensaje = serializers.CharField(max_length=500, required=False, allow_blank=True)


class LineaRecepcionSerializer(serializers.ModelSerializer):
    producto = serializers.CharField(source="linea_orden.producto.sku", read_only=True)

    class Meta:
        model = LineaRecepcion
        fields = ["id", "linea_orden", "producto", "cantidad", "costo_unitario", "movimiento"]


class RecepcionCompraSerializer(serializers.ModelSerializer):
    orden = serializers.SlugRelatedField(slug_field="codigo", read_only=True)
    ubicacion = serializers.SlugRelatedField(slug_field="nombre", read_only=True)
    recibida_por = serializers.CharField(source="recibida_por.username", read_only=True)
    lineas = LineaRecepcionSerializer(many=True, read_only=True)

    class Meta:
        model = RecepcionCompra
        fields = [
            "id", "codigo", "orden", "ubicacion", "documento_proveedor",
            "recibida_por", "creado_en", "lineas",
        ]
        read_only_fields = fields


# ─── Escritura ──────────────────────────────────────────────
class _LineaOCEntradaSerializer(serializers.Serializer):
    producto = serializers.SlugRelatedField(slug_field="sku", queryset=Producto.objects.all())
    cantidad = serializers.DecimalField(max_digits=12, decimal_places=3, min_value=Decimal("0.001"))
    costo_unitario = serializers.IntegerField(min_value=0)


class OrdenCompraCrearSerializer(serializers.Serializer):
    proveedor = serializers.SlugRelatedField(
        slug_field="rut", queryset=Proveedor.objects.all()
    )
    observacion = serializers.CharField(max_length=300, required=False, allow_blank=True)
    lineas = _LineaOCEntradaSerializer(many=True, allow_empty=False)


class _LineaRecepcionEntradaSerializer(serializers.Serializer):
    linea_orden = serializers.IntegerField(min_value=1)
    cantidad = serializers.DecimalField(max_digits=12, decimal_places=3, min_value=Decimal("0.001"))
    # Opcional: precio real al que llegó el producto, si difiere del cotizado
    # en la orden. Si no se manda, se usa el costo_unitario de la línea de OC.
    costo_unitario = serializers.IntegerField(min_value=0, required=False, allow_null=True)


class RecepcionCrearSerializer(serializers.Serializer):
    ubicacion = serializers.SlugRelatedField(
        slug_field="nombre", queryset=Ubicacion.objects.all(), required=False
    )
    documento_proveedor = serializers.CharField(max_length=40, required=False, allow_blank=True)
    lineas = _LineaRecepcionEntradaSerializer(many=True, allow_empty=False)


class AnularOrdenSerializer(serializers.Serializer):
    motivo = serializers.CharField(max_length=200)
