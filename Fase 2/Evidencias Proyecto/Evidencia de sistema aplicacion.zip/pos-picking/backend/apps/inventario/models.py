"""
Modelos de inventario.

- ``Stock``: cantidad actual por producto/ubicación (estado).
- ``MovimientoInventario``: libro mayor append-only. Toda variación de stock
  genera exactamente un movimiento (regla 14 del proyecto).
- ``ParametroInventario``: umbrales por producto/ubicación.
"""

from __future__ import annotations

from decimal import Decimal

from django.conf import settings
from django.db import models

from apps.core.models import ModeloActivable


class TipoUbicacion(models.TextChoices):
    SALA = "SALA", "Sala de ventas"
    BODEGA = "BODEGA", "Bodega"


class Ubicacion(ModeloActivable):
    nombre = models.CharField("nombre", max_length=60, unique=True)
    tipo = models.CharField(
        "tipo", max_length=10, choices=TipoUbicacion.choices, default=TipoUbicacion.BODEGA
    )
    es_principal = models.BooleanField("es la ubicación principal", default=False)

    class Meta:
        verbose_name = "ubicación"
        verbose_name_plural = "ubicaciones"
        ordering = ["nombre"]

    def __str__(self) -> str:
        return self.nombre

    @classmethod
    def principal(cls) -> Ubicacion:
        """Ubicación por defecto para operaciones que no la especifican."""
        return (
            cls.objects.filter(activo=True).order_by("-es_principal", "id").first()
            or cls.objects.create(nombre="Bodega Principal", tipo=TipoUbicacion.BODEGA, es_principal=True)
        )


class TipoMovimiento(models.TextChoices):
    COMPRA = "COMPRA", "Recepción de compra"
    VENTA = "VENTA", "Venta"
    DEVOLUCION = "DEVOLUCION", "Devolución de cliente"
    AJUSTE_POSITIVO = "AJUSTE_POSITIVO", "Ajuste positivo"
    AJUSTE_NEGATIVO = "AJUSTE_NEGATIVO", "Ajuste negativo / merma"
    CONTEO = "CONTEO", "Regularización de inventario físico"
    TRASPASO_ENTRADA = "TRASPASO_ENTRADA", "Traspaso (entrada)"
    TRASPASO_SALIDA = "TRASPASO_SALIDA", "Traspaso (salida)"


# Signo que aplica cada tipo sobre el stock.
SIGNO_MOVIMIENTO: dict[str, int] = {
    TipoMovimiento.COMPRA: +1,
    TipoMovimiento.VENTA: -1,
    TipoMovimiento.DEVOLUCION: +1,
    TipoMovimiento.AJUSTE_POSITIVO: +1,
    TipoMovimiento.AJUSTE_NEGATIVO: -1,
    TipoMovimiento.CONTEO: +1,  # el servicio ajusta el signo real del delta
    TipoMovimiento.TRASPASO_ENTRADA: +1,
    TipoMovimiento.TRASPASO_SALIDA: -1,
}

# Tipos que un usuario puede registrar manualmente por la API.
TIPOS_MANUALES = {TipoMovimiento.AJUSTE_POSITIVO, TipoMovimiento.AJUSTE_NEGATIVO}


class Stock(models.Model):
    producto = models.ForeignKey(
        "catalogo.Producto", on_delete=models.PROTECT, related_name="stocks"
    )
    ubicacion = models.ForeignKey(Ubicacion, on_delete=models.PROTECT, related_name="stocks")
    cantidad = models.DecimalField(
        "cantidad", max_digits=12, decimal_places=3, default=Decimal("0")
    )
    actualizado_en = models.DateTimeField("actualizado en", auto_now=True)

    class Meta:
        verbose_name = "stock"
        verbose_name_plural = "stocks"
        ordering = ["producto__nombre"]
        constraints = [
            models.UniqueConstraint(
                fields=["producto", "ubicacion"], name="stock_producto_ubicacion_unico"
            ),
            models.CheckConstraint(
                condition=models.Q(cantidad__gte=0), name="stock_cantidad_no_negativa"
            ),
        ]
        indexes = [models.Index(fields=["ubicacion", "cantidad"])]

    def __str__(self) -> str:
        return f"{self.producto.sku} @ {self.ubicacion.nombre}: {self.cantidad}"


class ParametroInventario(models.Model):
    producto = models.ForeignKey(
        "catalogo.Producto", on_delete=models.CASCADE, related_name="parametros_inventario"
    )
    ubicacion = models.ForeignKey(
        Ubicacion, on_delete=models.CASCADE, related_name="parametros_inventario"
    )
    stock_minimo = models.DecimalField(
        "stock mínimo", max_digits=12, decimal_places=3, default=Decimal("0")
    )
    punto_reposicion = models.DecimalField(
        "punto de reposición", max_digits=12, decimal_places=3, default=Decimal("0")
    )
    stock_seguridad = models.DecimalField(
        "stock de seguridad", max_digits=12, decimal_places=3, default=Decimal("0")
    )
    multiplo_compra = models.DecimalField(
        "múltiplo de compra", max_digits=12, decimal_places=3, default=Decimal("1")
    )

    class Meta:
        verbose_name = "parámetro de inventario"
        verbose_name_plural = "parámetros de inventario"
        constraints = [
            models.UniqueConstraint(
                fields=["producto", "ubicacion"], name="parametro_producto_ubicacion_unico"
            ),
            models.CheckConstraint(
                condition=models.Q(stock_minimo__gte=0)
                & models.Q(punto_reposicion__gte=0)
                & models.Q(stock_seguridad__gte=0)
                & models.Q(multiplo_compra__gt=0),
                name="parametro_inventario_valores_validos",
            ),
        ]

    def __str__(self) -> str:
        return f"Parámetros {self.producto.sku} @ {self.ubicacion.nombre}"


class MovimientoInventario(models.Model):
    """Registro inmutable de cada variación de stock."""

    producto = models.ForeignKey(
        "catalogo.Producto", on_delete=models.PROTECT, related_name="movimientos"
    )
    ubicacion = models.ForeignKey(
        Ubicacion, on_delete=models.PROTECT, related_name="movimientos"
    )
    tipo = models.CharField("tipo", max_length=20, choices=TipoMovimiento.choices)
    cantidad = models.DecimalField(
        "cantidad (con signo)", max_digits=12, decimal_places=3,
        help_text="Negativa = salida, positiva = entrada.",
    )
    stock_antes = models.DecimalField("stock antes", max_digits=12, decimal_places=3)
    stock_despues = models.DecimalField("stock después", max_digits=12, decimal_places=3)

    motivo = models.CharField("motivo", max_length=200, blank=True)
    doc_tipo = models.CharField("tipo de documento", max_length=20, blank=True, default="")
    doc_id = models.BigIntegerField("id de documento", null=True, blank=True)

    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="movimientos_inventario"
    )
    creado_en = models.DateTimeField("creado en", auto_now_add=True)

    class Meta:
        verbose_name = "movimiento de inventario"
        verbose_name_plural = "movimientos de inventario"
        ordering = ["-creado_en", "-id"]
        indexes = [
            models.Index(fields=["producto", "creado_en"]),
            models.Index(fields=["tipo", "creado_en"]),
            models.Index(fields=["usuario", "creado_en"]),
            models.Index(fields=["doc_tipo", "doc_id"]),
        ]
        constraints = [
            models.CheckConstraint(
                condition=~models.Q(cantidad=0), name="movimiento_cantidad_no_cero"
            )
        ]

    def __str__(self) -> str:
        return f"{self.tipo} {self.cantidad:+} {self.producto.sku} @ {self.ubicacion.nombre}"
