"""Rutas de inventario."""

from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import (
    MovimientoInventarioViewSet,
    ParametroInventarioViewSet,
    StockViewSet,
    UbicacionViewSet,
)

router = DefaultRouter()
router.register("ubicaciones", UbicacionViewSet, basename="ubicacion")
router.register("stock", StockViewSet, basename="stock")
router.register("parametros", ParametroInventarioViewSet, basename="parametro-inventario")
router.register("movimientos", MovimientoInventarioViewSet, basename="movimiento-inventario")

urlpatterns = [path("", include(router.urls))]
