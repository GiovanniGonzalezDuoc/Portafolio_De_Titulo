"""Factories de inventario."""

import factory

from apps.catalogo.tests.factories import ProductoFactory
from apps.inventario.models import ParametroInventario, Stock, Ubicacion


class UbicacionFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Ubicacion
        django_get_or_create = ("nombre",)

    nombre = factory.Sequence(lambda n: f"Ubicación {n}")
    tipo = "BODEGA"
    activo = True


class StockFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Stock

    producto = factory.SubFactory(ProductoFactory)
    ubicacion = factory.SubFactory(UbicacionFactory)
    cantidad = 0


class ParametroInventarioFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = ParametroInventario

    producto = factory.SubFactory(ProductoFactory)
    ubicacion = factory.SubFactory(UbicacionFactory)
    stock_minimo = 5
    punto_reposicion = 10
    stock_seguridad = 3
    multiplo_compra = 1
