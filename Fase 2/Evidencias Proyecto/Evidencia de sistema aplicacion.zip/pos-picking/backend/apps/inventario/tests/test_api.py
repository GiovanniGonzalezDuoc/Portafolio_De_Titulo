"""Tests de la API de inventario."""

from decimal import Decimal

import pytest

from apps.catalogo.tests.factories import ProductoFactory
from apps.inventario import services
from apps.inventario.models import Stock

from .factories import ParametroInventarioFactory, UbicacionFactory

pytestmark = pytest.mark.django_db


@pytest.fixture
def ubic():
    return UbicacionFactory(nombre="Bodega Central", tipo="BODEGA")


# ─── Registrar movimiento manual ────────────────────────────
def test_bodeguero_registra_entrada(api_bodeguero, bodeguero, ubic):
    p = ProductoFactory(sku="SKU-A")
    r = api_bodeguero.post(
        "/api/v1/inventario/movimientos/registrar/",
        {"producto": "SKU-A", "ubicacion": "Bodega Central", "tipo": "AJUSTE_POSITIVO",
         "cantidad": "12", "motivo": "carga inicial"},
        format="json",
    )
    assert r.status_code == 201, r.data
    assert services.stock_de(p, ubic) == Decimal("12")


def test_vendedor_no_puede_registrar_movimientos(api_vendedor, ubic):
    ProductoFactory(sku="SKU-B")
    r = api_vendedor.post(
        "/api/v1/inventario/movimientos/registrar/",
        {"producto": "SKU-B", "tipo": "AJUSTE_POSITIVO", "cantidad": "1", "motivo": "x"},
        format="json",
    )
    assert r.status_code == 403


def test_registrar_salida_sin_stock_da_409(api_bodeguero, ubic):
    ProductoFactory(sku="SKU-C")
    r = api_bodeguero.post(
        "/api/v1/inventario/movimientos/registrar/",
        {"producto": "SKU-C", "ubicacion": "Bodega Central", "tipo": "AJUSTE_NEGATIVO",
         "cantidad": "5", "motivo": "merma"},
        format="json",
    )
    assert r.status_code == 409
    assert r.data["error"]["codigo"] == "stock_insuficiente"


def test_registrar_movimiento_de_producto_inactivo_falla(api_bodeguero, ubic):
    ProductoFactory(sku="SKU-D", activo=False)
    r = api_bodeguero.post(
        "/api/v1/inventario/movimientos/registrar/",
        {"producto": "SKU-D", "tipo": "AJUSTE_POSITIVO", "cantidad": "1", "motivo": "x"},
        format="json",
    )
    assert r.status_code == 400


def test_tipo_venta_no_es_valido_como_movimiento_manual(api_bodeguero, ubic):
    ProductoFactory(sku="SKU-E")
    r = api_bodeguero.post(
        "/api/v1/inventario/movimientos/registrar/",
        {"producto": "SKU-E", "tipo": "VENTA", "cantidad": "1", "motivo": "x"},
        format="json",
    )
    assert r.status_code == 400


# ─── Ajuste a cantidad absoluta ─────────────────────────────
def test_ajuste_a_cantidad_absoluta(api_admin, admin, ubic):
    p = ProductoFactory(sku="SKU-F")
    services.entrada(producto=p, cantidad=10, usuario=admin, ubicacion=ubic)
    r = api_admin.post(
        "/api/v1/inventario/movimientos/ajustar/",
        {"producto": "SKU-F", "ubicacion": "Bodega Central", "cantidad_final": "8",
         "motivo": "conteo cíclico"},
        format="json",
    )
    assert r.status_code == 201
    assert services.stock_de(p, ubic) == Decimal("8")


def test_bodeguero_tambien_puede_ajustar(api_bodeguero, ubic):
    ProductoFactory(sku="SKU-G")
    r = api_bodeguero.post(
        "/api/v1/inventario/movimientos/ajustar/",
        {"producto": "SKU-G", "ubicacion": "Bodega Central", "cantidad_final": "3", "motivo": "c"},
        format="json",
    )
    assert r.status_code == 201


# ─── Consulta de stock ──────────────────────────────────────
def test_stock_list_y_filtro_sin_stock(api_admin, admin, ubic):
    p1 = ProductoFactory(sku="CON")
    p2 = ProductoFactory(sku="SIN")
    services.entrada(producto=p1, cantidad=5, usuario=admin, ubicacion=ubic)
    Stock.objects.create(producto=p2, ubicacion=ubic, cantidad=0)

    r = api_admin.get("/api/v1/inventario/stock/?sin_stock=true")
    skus = [row["producto_sku"] for row in r.data["resultados"]]
    assert "SIN" in skus and "CON" not in skus


def test_stock_filtro_bajo_minimo(api_admin, admin, ubic):
    p = ProductoFactory(sku="BAJO")
    ParametroInventarioFactory(producto=p, ubicacion=ubic, stock_minimo=10)
    services.entrada(producto=p, cantidad=4, usuario=admin, ubicacion=ubic)

    r = api_admin.get("/api/v1/inventario/stock/?bajo_minimo=true")
    assert r.data["conteo"] == 1
    assert r.data["resultados"][0]["producto_sku"] == "BAJO"


def test_vendedor_puede_ver_stock(api_vendedor, ubic):
    assert api_vendedor.get("/api/v1/inventario/stock/").status_code == 200


def test_stock_incluye_la_marca_del_producto(api_admin, admin, ubic):
    from apps.catalogo.tests.factories import MarcaFactory

    con = ProductoFactory(sku="CON-MARCA", marca=MarcaFactory(nombre="ACME QA"))
    sin = ProductoFactory(sku="SIN-MARCA", marca=None)
    services.entrada(producto=con, cantidad=3, usuario=admin, ubicacion=ubic)
    services.entrada(producto=sin, cantidad=3, usuario=admin, ubicacion=ubic)

    filas = {f["producto_sku"]: f for f in api_admin.get("/api/v1/inventario/stock/").data["resultados"]}
    assert filas["CON-MARCA"]["producto_marca"] == "ACME QA"
    assert filas["SIN-MARCA"]["producto_marca"] is None


# ─── Historial de movimientos ───────────────────────────────
def test_historial_filtrado_por_producto(api_admin, admin, ubic):
    p1 = ProductoFactory(sku="H1")
    p2 = ProductoFactory(sku="H2")
    services.entrada(producto=p1, cantidad=5, usuario=admin, ubicacion=ubic)
    services.entrada(producto=p2, cantidad=5, usuario=admin, ubicacion=ubic)

    r = api_admin.get("/api/v1/inventario/movimientos/?producto=H1")
    assert r.data["conteo"] == 1
    assert r.data["resultados"][0]["producto_sku"] == "H1"


def test_historial_registra_stock_antes_y_despues(api_admin, admin, ubic):
    p = ProductoFactory(sku="H3")
    services.entrada(producto=p, cantidad=10, usuario=admin, ubicacion=ubic)
    services.salida(producto=p, cantidad=3, usuario=admin, ubicacion=ubic)

    r = api_admin.get("/api/v1/inventario/movimientos/?producto=H3&ordering=creado_en")
    filas = r.data["resultados"]
    assert (filas[-1]["stock_antes"], filas[-1]["stock_despues"]) == ("10.000", "7.000")


def test_historial_filtro_por_fecha(api_admin, admin, ubic):
    from django.utils import timezone

    p = ProductoFactory(sku="HF")
    services.entrada(producto=p, cantidad=5, usuario=admin, ubicacion=ubic)
    hoy = timezone.localdate().isoformat()

    assert api_admin.get(f"/api/v1/inventario/movimientos/?desde={hoy}&hasta={hoy}").data["conteo"] == 1
    assert api_admin.get("/api/v1/inventario/movimientos/?hasta=2000-01-01").data["conteo"] == 0


def test_exportar_movimientos_excel(api_admin, admin, ubic):
    from io import BytesIO

    from openpyxl import load_workbook

    p = ProductoFactory(sku="EXP-1", nombre="Café molido")
    services.entrada(producto=p, cantidad=7, usuario=admin, ubicacion=ubic)

    r = api_admin.get("/api/v1/inventario/movimientos/exportar/?desde=2026-01-01&hasta=2026-12-31")
    assert r.status_code == 200
    assert "spreadsheetml" in r["Content-Type"]
    assert r["Content-Disposition"].endswith('.xlsx"')

    ws = load_workbook(BytesIO(r.content)).active
    textos = [c.value for row in ws.iter_rows() for c in row if isinstance(c.value, str)]
    assert any("Reporte de movimientos" in t for t in textos)
    assert "Café molido" in textos
    assert "EXP-1" in textos
    assert any("Período contemplado: del 01/01/2026 al 31/12/2026" in t for t in textos)


def test_exportar_movimientos_requiere_permiso(api_bodeguero):
    # bodeguero tiene inventario.ver → puede exportar
    assert api_bodeguero.get("/api/v1/inventario/movimientos/exportar/").status_code == 200


# ─── Parámetros de inventario ───────────────────────────────
def test_bodeguero_define_parametros(api_bodeguero, ubic):
    ProductoFactory(sku="PARAM-1")
    r = api_bodeguero.post(
        "/api/v1/inventario/parametros/",
        {"producto": "PARAM-1", "ubicacion": "Bodega Central", "stock_minimo": "8",
         "punto_reposicion": "15", "stock_seguridad": "4"},
        format="json",
    )
    assert r.status_code == 201, r.data


def test_parametros_rechaza_valores_negativos(api_bodeguero, ubic):
    ProductoFactory(sku="PARAM-2")
    r = api_bodeguero.post(
        "/api/v1/inventario/parametros/",
        {"producto": "PARAM-2", "ubicacion": "Bodega Central", "stock_minimo": "-1"},
        format="json",
    )
    assert r.status_code == 400


# ─── Edición masiva de stock por Excel ───────────────────────
def _excel_stock(filas: list[list]):
    import io

    from django.core.files.uploadedfile import SimpleUploadedFile
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.append(["sku", "producto", "marca", "categoria", "ubicacion", "cantidad_actual", "cantidad_nueva"])
    for fila in filas:
        ws.append(fila)
    buf = io.BytesIO()
    wb.save(buf)
    return SimpleUploadedFile(
        "stock.xlsx", buf.getvalue(),
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


def test_exportar_stock_respeta_el_filtro_de_categoria(api_bodeguero, admin, ubic):
    from apps.catalogo.tests.factories import CategoriaFactory

    p1 = ProductoFactory(sku="EXP-CAT-1", categoria=CategoriaFactory(nombre="Aseo QA"))
    p2 = ProductoFactory(sku="EXP-CAT-2", categoria=CategoriaFactory(nombre="Otra QA"))
    services.entrada(producto=p1, cantidad=5, usuario=admin, ubicacion=ubic)
    services.entrada(producto=p2, cantidad=5, usuario=admin, ubicacion=ubic)

    r = api_bodeguero.get("/api/v1/inventario/stock/exportar/?categoria=Aseo QA")
    assert r.status_code == 200
    assert "spreadsheetml" in r["Content-Type"]

    from io import BytesIO

    from openpyxl import load_workbook

    ws = load_workbook(BytesIO(r.content))["Datos"]
    skus = [row[0].value for row in ws.iter_rows(min_row=2)]
    assert skus == ["EXP-CAT-1"]


def test_importar_stock_ajusta_solo_lo_que_cambio(api_bodeguero, admin, ubic):
    p1 = ProductoFactory(sku="IMP-1")
    p2 = ProductoFactory(sku="IMP-2")
    services.entrada(producto=p1, cantidad=10, usuario=admin, ubicacion=ubic)
    services.entrada(producto=p2, cantidad=10, usuario=admin, ubicacion=ubic)

    archivo = _excel_stock(
        [
            ["IMP-1", "x", "", "", "Bodega Central", 10, 25],  # cambia
            ["IMP-2", "x", "", "", "Bodega Central", 10, 10],  # sin cambio
            ["NO-EXISTE", "x", "", "", "Bodega Central", 0, 5],  # sku inválido
        ]
    )
    r = api_bodeguero.post("/api/v1/inventario/stock/importar/", {"archivo": archivo}, format="multipart")
    assert r.status_code == 200, r.data
    assert r.data["actualizados"] == 1
    assert r.data["sin_cambios"] == 1
    assert len(r.data["con_error"]) == 1
    assert r.data["con_error"][0]["sku"] == "NO-EXISTE"
    assert services.stock_de(p1, ubic) == Decimal("25")
    assert services.stock_de(p2, ubic) == Decimal("10")


def test_importar_stock_requiere_permiso_de_ajuste(api_vendedor):
    archivo = _excel_stock([["X", "y", "", "", "Bodega Central", 0, 5]])
    r = api_vendedor.post("/api/v1/inventario/stock/importar/", {"archivo": archivo}, format="multipart")
    assert r.status_code == 403
