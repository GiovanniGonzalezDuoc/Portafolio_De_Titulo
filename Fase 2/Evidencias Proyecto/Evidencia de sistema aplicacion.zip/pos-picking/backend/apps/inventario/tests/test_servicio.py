"""Tests del servicio central de inventario."""

from decimal import Decimal

import pytest

from apps.catalogo.tests.factories import ProductoFactory
from apps.inventario import services
from apps.inventario.models import MovimientoInventario, TipoMovimiento, Ubicacion

from .factories import ParametroInventarioFactory, UbicacionFactory

pytestmark = pytest.mark.django_db


@pytest.fixture
def ubic():
    return UbicacionFactory(nombre="Bodega Test")


def test_entrada_aumenta_stock_y_registra_movimiento(admin, ubic):
    p = ProductoFactory()
    mov = services.entrada(producto=p, cantidad=10, usuario=admin, ubicacion=ubic, motivo="carga inicial")

    assert services.stock_de(p, ubic) == Decimal("10")
    assert mov.tipo == TipoMovimiento.AJUSTE_POSITIVO
    assert mov.cantidad == Decimal("10")
    assert mov.stock_antes == Decimal("0")
    assert mov.stock_despues == Decimal("10")
    assert mov.usuario == admin
    assert MovimientoInventario.objects.count() == 1


def test_salida_disminuye_stock(admin, ubic):
    p = ProductoFactory()
    services.entrada(producto=p, cantidad=10, usuario=admin, ubicacion=ubic)
    services.salida(producto=p, cantidad=4, usuario=admin, ubicacion=ubic, motivo="merma")

    assert services.stock_de(p, ubic) == Decimal("6")
    ultimo = MovimientoInventario.objects.order_by("id").last()
    assert ultimo.cantidad == Decimal("-4")


def test_salida_que_deja_negativo_falla_y_no_altera_stock(admin, ubic):
    p = ProductoFactory()
    services.entrada(producto=p, cantidad=3, usuario=admin, ubicacion=ubic)

    with pytest.raises(services.StockInsuficiente):
        services.salida(producto=p, cantidad=5, usuario=admin, ubicacion=ubic)

    assert services.stock_de(p, ubic) == Decimal("3")
    assert MovimientoInventario.objects.filter(cantidad__lt=0).count() == 0


def test_el_stock_nunca_queda_negativo(admin, ubic):
    """Ni el servicio ni la BD permiten stock negativo (CHECK constraint)."""
    p = ProductoFactory()
    services.entrada(producto=p, cantidad=1, usuario=admin, ubicacion=ubic)
    with pytest.raises(services.StockInsuficiente):
        services.salida(producto=p, cantidad=3, usuario=admin, ubicacion=ubic)
    assert services.stock_de(p, ubic) == Decimal("1")


def test_ajustar_a_cantidad_sube_y_baja(admin, ubic):
    p = ProductoFactory()
    services.entrada(producto=p, cantidad=10, usuario=admin, ubicacion=ubic)

    m1 = services.ajustar_a_cantidad(producto=p, cantidad_final=7, usuario=admin, ubicacion=ubic, motivo="conteo")
    assert m1.tipo == TipoMovimiento.AJUSTE_NEGATIVO
    assert services.stock_de(p, ubic) == Decimal("7")

    m2 = services.ajustar_a_cantidad(producto=p, cantidad_final=20, usuario=admin, ubicacion=ubic, motivo="conteo")
    assert m2.tipo == TipoMovimiento.AJUSTE_POSITIVO
    assert services.stock_de(p, ubic) == Decimal("20")


def test_ajustar_a_misma_cantidad_es_error(admin, ubic):
    p = ProductoFactory()
    services.entrada(producto=p, cantidad=5, usuario=admin, ubicacion=ubic)
    with pytest.raises(services.MovimientoInvalido):
        services.ajustar_a_cantidad(producto=p, cantidad_final=5, usuario=admin, ubicacion=ubic)


def test_conteo_acepta_delta_con_signo(admin, ubic):
    p = ProductoFactory()
    services.entrada(producto=p, cantidad=10, usuario=admin, ubicacion=ubic)
    services.registrar_movimiento(
        producto=p, tipo=TipoMovimiento.CONTEO, cantidad=Decimal("-3"),
        usuario=admin, ubicacion=ubic, motivo="regularización",
    )
    assert services.stock_de(p, ubic) == Decimal("7")


def test_ubicacion_por_defecto_es_la_principal(admin):
    p = ProductoFactory()
    mov = services.entrada(producto=p, cantidad=1, usuario=admin)
    assert mov.ubicacion == Ubicacion.principal()


def test_secuencia_de_salidas_respeta_el_stock(admin, ubic):
    """Simula ventas sucesivas: no se puede pasar del stock disponible."""
    p = ProductoFactory()
    services.entrada(producto=p, cantidad=5, usuario=admin, ubicacion=ubic)
    services.salida(producto=p, cantidad=3, usuario=admin, ubicacion=ubic)
    services.salida(producto=p, cantidad=2, usuario=admin, ubicacion=ubic)
    with pytest.raises(services.StockInsuficiente):
        services.salida(producto=p, cantidad=1, usuario=admin, ubicacion=ubic)
    assert services.stock_de(p, ubic) == Decimal("0")


def test_mensaje_de_stock_insuficiente_sin_ceros_de_relleno(admin, ubic):
    """El mensaje debe decir '12' y no '12.000' (que se lee como doce mil)."""
    p = ProductoFactory()
    services.entrada(producto=p, cantidad=12, usuario=admin, ubicacion=ubic)
    with pytest.raises(services.StockInsuficiente) as exc:
        services.salida(producto=p, cantidad=20, usuario=admin, ubicacion=ubic)
    assert "disponible 12," in str(exc.value)
    assert "retirar 20." in str(exc.value)
    assert exc.value.detalles["disponible"] == "12"
    assert exc.value.detalles["solicitado"] == "20"


def test_alerta_stock_bajo_al_cruzar_el_minimo(admin, ubic, django_capture_on_commit_callbacks):
    from apps.alertas.models import Alerta, TipoAlerta

    p = ProductoFactory()
    ParametroInventarioFactory(producto=p, ubicacion=ubic, stock_minimo=5)
    services.entrada(producto=p, cantidad=10, usuario=admin, ubicacion=ubic)

    with django_capture_on_commit_callbacks(execute=True):
        services.salida(producto=p, cantidad=6, usuario=admin, ubicacion=ubic)  # queda en 4

    assert Alerta.objects.filter(tipo=TipoAlerta.STOCK_BAJO, producto=p).exists()


def test_alerta_sin_stock(admin, ubic, django_capture_on_commit_callbacks):
    from apps.alertas.models import Alerta, TipoAlerta

    p = ProductoFactory()
    services.entrada(producto=p, cantidad=2, usuario=admin, ubicacion=ubic)
    with django_capture_on_commit_callbacks(execute=True):
        services.salida(producto=p, cantidad=2, usuario=admin, ubicacion=ubic)

    assert Alerta.objects.filter(tipo=TipoAlerta.SIN_STOCK, producto=p).exists()


def test_alerta_no_se_duplica(admin, ubic, django_capture_on_commit_callbacks):
    from apps.alertas.models import Alerta

    p = ProductoFactory()
    ParametroInventarioFactory(producto=p, ubicacion=ubic, stock_minimo=5)
    services.entrada(producto=p, cantidad=10, usuario=admin, ubicacion=ubic)
    with django_capture_on_commit_callbacks(execute=True):
        services.salida(producto=p, cantidad=6, usuario=admin, ubicacion=ubic)
    with django_capture_on_commit_callbacks(execute=True):
        services.salida(producto=p, cantidad=1, usuario=admin, ubicacion=ubic)

    assert Alerta.objects.filter(producto=p, tipo="STOCK_BAJO").count() == 1
