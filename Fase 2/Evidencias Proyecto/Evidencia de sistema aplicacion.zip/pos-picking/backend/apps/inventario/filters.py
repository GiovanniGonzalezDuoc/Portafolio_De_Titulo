"""Filtros de inventario."""

from datetime import datetime, time, timedelta

import django_filters as filters
from django.utils import timezone

from .models import MovimientoInventario, Stock


class StockFilter(filters.FilterSet):
    producto = filters.CharFilter(field_name="producto__sku", lookup_expr="iexact")
    ubicacion = filters.CharFilter(field_name="ubicacion__nombre", lookup_expr="iexact")
    categoria = filters.CharFilter(
        field_name="producto__categoria__nombre", lookup_expr="iexact"
    )
    marca = filters.CharFilter(field_name="producto__marca__nombre", lookup_expr="iexact")
    sin_stock = filters.BooleanFilter(method="_sin_stock")
    bajo_minimo = filters.BooleanFilter(method="_bajo_minimo")

    class Meta:
        model = Stock
        fields = ["producto", "ubicacion", "categoria", "marca"]

    def _sin_stock(self, queryset, name, value):
        if value:
            return queryset.filter(cantidad__lte=0)
        return queryset

    def _bajo_minimo(self, queryset, name, value):
        if not value:
            return queryset
        from django.db.models import OuterRef, Subquery

        from .models import ParametroInventario

        minimo = ParametroInventario.objects.filter(
            producto=OuterRef("producto"), ubicacion=OuterRef("ubicacion")
        ).values("stock_minimo")[:1]
        return queryset.annotate(_minimo=Subquery(minimo)).filter(
            cantidad__lte=Subquery(minimo), _minimo__gt=0
        )


class MovimientoInventarioFilter(filters.FilterSet):
    producto = filters.CharFilter(field_name="producto__sku", lookup_expr="iexact")
    ubicacion = filters.CharFilter(field_name="ubicacion__nombre", lookup_expr="iexact")
    usuario = filters.CharFilter(field_name="usuario__username", lookup_expr="iexact")
    # Fechas por día completo (en hora local). `hasta` incluye todo ese día.
    desde = filters.DateFilter(method="_desde", label="Desde (YYYY-MM-DD)")
    hasta = filters.DateFilter(method="_hasta", label="Hasta (YYYY-MM-DD)")

    class Meta:
        model = MovimientoInventario
        fields = ["producto", "ubicacion", "usuario", "tipo", "doc_tipo"]

    def _desde(self, queryset, name, value):
        ini = timezone.make_aware(datetime.combine(value, time.min))
        return queryset.filter(creado_en__gte=ini)

    def _hasta(self, queryset, name, value):
        fin = timezone.make_aware(datetime.combine(value + timedelta(days=1), time.min))
        return queryset.filter(creado_en__lt=fin)
