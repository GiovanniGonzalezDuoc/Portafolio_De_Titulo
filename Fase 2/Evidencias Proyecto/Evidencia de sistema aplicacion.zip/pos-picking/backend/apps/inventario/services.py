"""
Servicio central de inventario.

**Toda** variación de stock pasa por aquí. Garantías:
- transacción atómica + ``select_for_update`` sobre la fila de ``Stock``
  (evita sobreventa y condiciones de carrera);
- se registra un ``MovimientoInventario`` por cada cambio (trazabilidad);
- no se permite stock negativo salvo que se pida explícitamente;
- se generan alertas de stock bajo / sin stock.
"""

from __future__ import annotations

import logging
from decimal import Decimal

from django.db import transaction

from apps.alertas import services as alertas
from apps.core.exceptions import ErrorDominio

from .models import (
    SIGNO_MOVIMIENTO,
    MovimientoInventario,
    ParametroInventario,
    Stock,
    TipoMovimiento,
    Ubicacion,
)

logger = logging.getLogger("pos.inventario")

CERO = Decimal("0")


def _cantidad_legible(valor) -> str:
    """
    Cantidad sin ceros de relleno para los mensajes: ``12.000`` → ``12`` (que
    en español no se confunda con "doce mil"), ``12.5`` → ``12,5``.
    """
    d = Decimal(str(valor))
    if d == d.to_integral_value():
        return f"{d:.0f}"
    return f"{d.normalize():f}".replace(".", ",")


class StockInsuficiente(ErrorDominio):
    codigo = "stock_insuficiente"
    mensaje = "No hay stock suficiente para la operación."
    http_status = 409


class MovimientoInvalido(ErrorDominio):
    codigo = "movimiento_invalido"
    http_status = 400


def _a_decimal(valor) -> Decimal:
    try:
        return Decimal(str(valor))
    except (TypeError, ValueError, ArithmeticError) as exc:
        raise MovimientoInvalido("Cantidad inválida.") from exc


def _lock_stock(producto, ubicacion) -> Stock:
    Stock.objects.get_or_create(producto=producto, ubicacion=ubicacion)
    return Stock.objects.select_for_update().get(producto=producto, ubicacion=ubicacion)


def _stock_minimo(producto, ubicacion) -> Decimal:
    param = ParametroInventario.objects.filter(
        producto=producto, ubicacion=ubicacion
    ).first()
    return param.stock_minimo if param else CERO


@transaction.atomic
def registrar_movimiento(
    *,
    producto,
    tipo: str,
    cantidad,
    usuario,
    ubicacion: Ubicacion | None = None,
    motivo: str = "",
    doc_tipo: str | None = None,
    doc_id: int | None = None,
) -> MovimientoInventario:
    """
    Aplica un movimiento de inventario.

    ``cantidad`` es la **magnitud** (positiva); el signo lo determina ``tipo``.
    Para ``CONTEO`` se acepta ``cantidad`` con signo (delta real de la
    regularización).
    """
    if tipo not in TipoMovimiento.values:
        raise MovimientoInvalido(f"Tipo de movimiento desconocido: {tipo}")

    ubicacion = ubicacion or Ubicacion.principal()
    magnitud = _a_decimal(cantidad)

    if tipo == TipoMovimiento.CONTEO:
        delta = magnitud  # puede venir con signo
    else:
        if magnitud <= 0:
            raise MovimientoInvalido("La cantidad debe ser mayor que cero.")
        delta = magnitud * SIGNO_MOVIMIENTO[tipo]

    if delta == 0:
        raise MovimientoInvalido("El movimiento no cambia el stock.")

    stock = _lock_stock(producto, ubicacion)
    antes = stock.cantidad
    despues = antes + delta

    if despues < 0:
        raise StockInsuficiente(
            f"Stock insuficiente de {producto.nombre} ({producto.sku}): "
            f"disponible {_cantidad_legible(antes)}, "
            f"se intenta retirar {_cantidad_legible(abs(delta))}.",
            detalles={
                "producto": producto.sku,
                "disponible": _cantidad_legible(antes),
                "solicitado": _cantidad_legible(abs(delta)),
            },
        )

    stock.cantidad = despues
    stock.save(update_fields=["cantidad", "actualizado_en"])

    movimiento = MovimientoInventario.objects.create(
        producto=producto,
        ubicacion=ubicacion,
        tipo=tipo,
        cantidad=delta,
        stock_antes=antes,
        stock_despues=despues,
        motivo=motivo,
        doc_tipo=doc_tipo or "",
        doc_id=doc_id,
        usuario=usuario,
    )
    logger.info(
        "Movimiento %s %s%s de %s @ %s (%s -> %s) por %s",
        tipo, "+" if delta > 0 else "", delta, producto.sku, ubicacion.nombre,
        antes, despues, getattr(usuario, "username", usuario),
    )

    transaction.on_commit(
        lambda: alertas.notificar_stock(
            producto=producto,
            ubicacion=ubicacion,
            cantidad=despues,
            stock_minimo=_stock_minimo(producto, ubicacion),
        )
    )
    return movimiento


# ─── Envoltorios de conveniencia ────────────────────────────
def entrada(*, producto, cantidad, usuario, ubicacion=None, motivo="", doc_tipo=None, doc_id=None):
    return registrar_movimiento(
        producto=producto, tipo=TipoMovimiento.AJUSTE_POSITIVO, cantidad=cantidad,
        usuario=usuario, ubicacion=ubicacion, motivo=motivo, doc_tipo=doc_tipo, doc_id=doc_id,
    )


def salida(*, producto, cantidad, usuario, ubicacion=None, motivo="", doc_tipo=None, doc_id=None):
    return registrar_movimiento(
        producto=producto, tipo=TipoMovimiento.AJUSTE_NEGATIVO, cantidad=cantidad,
        usuario=usuario, ubicacion=ubicacion, motivo=motivo,
        doc_tipo=doc_tipo, doc_id=doc_id,
    )


@transaction.atomic
def ajustar_a_cantidad(*, producto, cantidad_final, usuario, ubicacion=None, motivo=""):
    """Deja el stock en un valor absoluto (uso: corrección manual autorizada)."""
    ubicacion = ubicacion or Ubicacion.principal()
    objetivo = _a_decimal(cantidad_final)
    if objetivo < 0:
        raise MovimientoInvalido("El stock final no puede ser negativo.")

    stock = _lock_stock(producto, ubicacion)
    delta = objetivo - stock.cantidad
    if delta == 0:
        raise MovimientoInvalido("El stock ya está en esa cantidad.")

    tipo = TipoMovimiento.AJUSTE_POSITIVO if delta > 0 else TipoMovimiento.AJUSTE_NEGATIVO
    return registrar_movimiento(
        producto=producto, tipo=tipo, cantidad=abs(delta), usuario=usuario,
        ubicacion=ubicacion, motivo=motivo or f"Ajuste a {objetivo}",
    )


def stock_de(producto, ubicacion=None) -> Decimal:
    ubicacion = ubicacion or Ubicacion.principal()
    fila = Stock.objects.filter(producto=producto, ubicacion=ubicacion).first()
    return fila.cantidad if fila else CERO


# ─── Edición masiva de stock por Excel ────────────────────────
def importar_stock(filas: list[tuple[int, dict]], usuario) -> dict:
    """
    ``filas``: ``[(número de fila del Excel, {encabezado: valor}), ...]``
    (las arma ``apps.core.reportes.leer_filas_excel`` sobre el Excel que
    generó ``StockViewSet.exportar``). Solo se toca la fila si "cantidad_
    nueva" cambió respecto al stock actual; cada cambio queda como un ajuste
    normal (con motivo y usuario). Una fila con error no bloquea al resto.
    """
    from apps.catalogo.models import Producto

    actualizados = 0
    sin_cambios = 0
    errores = []
    for numero_fila, fila in filas:
        sku = str(fila.get("sku") or "").strip().upper()
        if not sku:
            continue
        try:
            valor_nuevo = fila.get("cantidad_nueva")
            if valor_nuevo in (None, ""):
                errores.append({"fila": numero_fila, "sku": sku, "motivo": "Falta la cantidad nueva."})
                continue

            producto = Producto.objects.filter(sku=sku).first()
            if producto is None:
                errores.append({"fila": numero_fila, "sku": sku, "motivo": "No existe un producto con ese SKU."})
                continue

            nombre_ubicacion = str(fila.get("ubicacion") or "").strip()
            if nombre_ubicacion:
                ubicacion = Ubicacion.objects.filter(nombre__iexact=nombre_ubicacion).first()
                if ubicacion is None:
                    errores.append(
                        {"fila": numero_fila, "sku": sku, "motivo": f"No existe la ubicación «{nombre_ubicacion}»."}
                    )
                    continue
            else:
                ubicacion = Ubicacion.principal()

            objetivo = _a_decimal(valor_nuevo)
            if objetivo == stock_de(producto, ubicacion):
                sin_cambios += 1
                continue

            ajustar_a_cantidad(
                producto=producto, cantidad_final=objetivo, usuario=usuario,
                ubicacion=ubicacion, motivo="Edición masiva de stock (Excel)",
            )
            actualizados += 1
        except Exception as exc:  # noqa: BLE001 — una fila mala no debe tumbar el resto
            errores.append({"fila": numero_fila, "sku": sku, "motivo": str(exc)})
    return {
        "actualizados": actualizados,
        "sin_cambios": sin_cambios,
        "con_error": errores,
        "total_filas": len(filas),
    }
