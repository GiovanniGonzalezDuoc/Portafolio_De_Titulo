from django.contrib import admin

from .models import MovimientoInventario, ParametroInventario, Stock, Ubicacion


@admin.register(Ubicacion)
class UbicacionAdmin(admin.ModelAdmin):
    list_display = ["nombre", "tipo", "es_principal", "activo"]
    list_filter = ["tipo", "activo"]


@admin.register(Stock)
class StockAdmin(admin.ModelAdmin):
    list_display = ["producto", "ubicacion", "cantidad", "actualizado_en"]
    list_filter = ["ubicacion"]
    search_fields = ["producto__sku", "producto__nombre"]
    list_select_related = ["producto", "ubicacion"]


@admin.register(ParametroInventario)
class ParametroInventarioAdmin(admin.ModelAdmin):
    list_display = ["producto", "ubicacion", "stock_minimo", "punto_reposicion", "stock_seguridad"]
    search_fields = ["producto__sku", "producto__nombre"]
    list_select_related = ["producto", "ubicacion"]


@admin.register(MovimientoInventario)
class MovimientoInventarioAdmin(admin.ModelAdmin):
    list_display = ["creado_en", "tipo", "producto", "cantidad", "stock_antes", "stock_despues", "usuario"]
    list_filter = ["tipo", "ubicacion"]
    search_fields = ["producto__sku", "producto__nombre", "motivo"]
    list_select_related = ["producto", "ubicacion", "usuario"]
    readonly_fields = [f.name for f in MovimientoInventario._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
