"""ViewSets de inventario."""

from __future__ import annotations

from datetime import date

from django.utils import timezone
from drf_spectacular.utils import extend_schema
from rest_framework import mixins, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.core.exceptions import ErrorDominio
from apps.core.reportes import excel_response, leer_filas_excel, plantilla_excel
from apps.usuarios.permissions import PermisoPorAccion, TienePermiso

from . import services
from .filters import MovimientoInventarioFilter, StockFilter
from .models import MovimientoInventario, ParametroInventario, Stock, Ubicacion
from .serializers import (
    AjusteStockSerializer,
    MovimientoInventarioSerializer,
    MovimientoManualSerializer,
    ParametroInventarioSerializer,
    StockSerializer,
    UbicacionSerializer,
)


class UbicacionViewSet(viewsets.ModelViewSet):
    queryset = Ubicacion.objects.all()
    serializer_class = UbicacionSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        "list": "inventario.ver",
        "retrieve": "inventario.ver",
        "create": "inventario.ajustar",
        "update": "inventario.ajustar",
        "partial_update": "inventario.ajustar",
        "destroy": "inventario.ajustar",
    }
    filterset_fields = ["tipo", "activo"]

    def destroy(self, request, *args, **kwargs):
        obj = self.get_object()
        obj.activo = False
        obj.save(update_fields=["activo"])
        return Response(status=status.HTTP_204_NO_CONTENT)


class StockViewSet(mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet):
    queryset = Stock.objects.select_related(
        "producto", "producto__categoria", "producto__marca", "ubicacion"
    ).all()
    serializer_class = StockSerializer
    permission_classes = [TienePermiso.para("inventario.ver")]
    filterset_class = StockFilter
    search_fields = ["producto__sku", "producto__nombre", "producto__codigo_barras"]
    ordering_fields = ["cantidad", "actualizado_en"]

    def get_permissions(self):
        # Exportar es de lectura (misma regla que el resto); importar cambia
        # stock de verdad, así que exige el permiso de ajuste.
        if self.action == "importar":
            return [TienePermiso.para("inventario.ajustar")()]
        return super().get_permissions()

    @extend_schema(responses={200: None})
    @action(detail=False, methods=["get"])
    def exportar(self, request):
        """
        Excel para editar el stock masivamente: "cantidad_nueva" arranca
        igual a la actual — se cambian solo las filas necesarias y se vuelve
        a subir con ``POST .../importar/``. Respeta los filtros aplicados
        (categoría, marca, búsqueda, sin stock, bajo mínimo, etc.).
        """
        qs = self.filter_queryset(self.get_queryset()).order_by("producto__nombre")
        filas = (
            [
                s.producto.sku,
                s.producto.nombre,
                s.producto.marca.nombre if s.producto.marca_id else "",
                s.producto.categoria.nombre,
                s.ubicacion.nombre,
                float(s.cantidad),
                float(s.cantidad),
            ]
            for s in qs
        )
        return plantilla_excel(
            nombre_archivo=f"stock_{timezone.localdate():%Y%m%d}.xlsx",
            encabezados=[
                "sku", "producto", "marca", "categoria", "ubicacion",
                "cantidad_actual", "cantidad_nueva",
            ],
            filas=filas,
            anchos=[16, 32, 16, 16, 18, 15, 15],
            instrucciones=[
                "Edición masiva de stock — instrucciones",
                "",
                "Cambia solo la columna \"cantidad_nueva\" de las filas que quieras corregir; deja el resto igual.",
                "No cambies \"sku\" ni \"ubicacion\": son los que identifican la fila al volver a subir el archivo.",
                "Las filas donde \"cantidad_nueva\" quede igual a \"cantidad_actual\" no generan ningún cambio.",
                "Cada cambio queda registrado como un movimiento de inventario con tu usuario, igual que un ajuste manual.",
            ],
        )

    @extend_schema(
        request={"multipart/form-data": {"type": "object", "properties": {"archivo": {"type": "string", "format": "binary"}}}},
        responses=None,
    )
    @action(detail=False, methods=["post"])
    def importar(self, request):
        archivo = request.FILES.get("archivo")
        if archivo is None:
            raise ErrorDominio("Adjunta el archivo Excel en el campo 'archivo'.", codigo="archivo_requerido")
        try:
            filas = leer_filas_excel(archivo)
        except Exception as exc:  # noqa: BLE001 — el archivo puede venir dañado o no ser un .xlsx
            raise ErrorDominio(f"No se pudo leer el archivo: {exc}", codigo="archivo_invalido") from exc
        if not filas:
            raise ErrorDominio("El archivo no tiene filas para importar.", codigo="archivo_vacio")
        if len(filas) > 2000:
            raise ErrorDominio(
                "El archivo tiene más de 2000 filas; divídelo en tandas más chicas.",
                codigo="archivo_muy_grande",
            )
        return Response(services.importar_stock(filas, request.user))


class ParametroInventarioViewSet(viewsets.ModelViewSet):
    queryset = ParametroInventario.objects.select_related("producto", "ubicacion").all()
    serializer_class = ParametroInventarioSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        "list": "inventario.ver",
        "retrieve": "inventario.ver",
        "create": "inventario.ajustar",
        "update": "inventario.ajustar",
        "partial_update": "inventario.ajustar",
        "destroy": "inventario.ajustar",
    }
    filterset_fields = {"producto__sku": ["iexact"], "ubicacion__nombre": ["iexact"]}


class MovimientoInventarioViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    """Historial de movimientos (solo lectura) + acciones para registrarlos."""

    queryset = MovimientoInventario.objects.select_related(
        "producto", "ubicacion", "usuario"
    ).all()
    serializer_class = MovimientoInventarioSerializer
    permission_classes = [PermisoPorAccion]
    permisos_por_accion = {
        "list": "inventario.ver",
        "retrieve": "inventario.ver",
        "exportar": "inventario.ver",
        "registrar": "inventario.mover",
        "ajustar": "inventario.ajustar",
    }
    filterset_class = MovimientoInventarioFilter
    ordering_fields = ["creado_en"]

    _ENCABEZADOS = [
        "Fecha y hora", "Producto", "SKU", "Movimiento", "Cantidad",
        "Stock antes", "Stock después", "Bodega", "Usuario", "Motivo",
    ]
    _ANCHOS = [17, 30, 12, 24, 11, 11, 12, 18, 16, 34]

    @extend_schema(responses={200: None})
    @action(detail=False, methods=["get"])
    def exportar(self, request):
        """Reporte Excel de los movimientos que pasan los filtros (desde/hasta/tipo/…)."""
        qs = self.filter_queryset(self.get_queryset()).order_by("creado_en")

        def _fecha(clave):
            valor = request.query_params.get(clave)
            try:
                return date.fromisoformat(valor) if valor else None
            except ValueError:
                return None

        desde, hasta = _fecha("desde"), _fecha("hasta")

        partes = []
        if request.query_params.get("tipo"):
            partes.append(f"tipo {request.query_params['tipo']}")
        if request.query_params.get("producto"):
            partes.append(f"producto {request.query_params['producto']}")
        filtros = ", ".join(partes)

        filas = (
            [
                timezone.localtime(m.creado_en).replace(tzinfo=None, microsecond=0),
                m.producto.nombre,
                m.producto.sku,
                m.get_tipo_display(),
                float(m.cantidad),
                float(m.stock_antes),
                float(m.stock_despues),
                m.ubicacion.nombre if m.ubicacion_id else "",
                m.usuario.username if m.usuario_id else "",
                m.motivo or "",
            ]
            for m in qs.iterator()
        )

        return excel_response(
            nombre_archivo=f"reporte_movimientos_{timezone.localdate():%Y%m%d}.xlsx",
            titulo="Reporte de movimientos de inventario",
            encabezados=self._ENCABEZADOS,
            filas=filas,
            generado_por=getattr(request.user, "username", ""),
            filtros=filtros,
            desde=desde,
            hasta=hasta,
            anchos=self._ANCHOS,
        )

    @extend_schema(request=MovimientoManualSerializer, responses=MovimientoInventarioSerializer)
    @action(detail=False, methods=["post"])
    def registrar(self, request):
        """Registra un movimiento manual (ajuste positivo o negativo)."""
        entrada = MovimientoManualSerializer(data=request.data)
        entrada.is_valid(raise_exception=True)
        d = entrada.validated_data
        movimiento = services.registrar_movimiento(
            producto=d["producto"],
            tipo=d["tipo"],
            cantidad=d["cantidad"],
            usuario=request.user,
            ubicacion=d.get("ubicacion"),
            motivo=d["motivo"],
        )
        return Response(
            MovimientoInventarioSerializer(movimiento).data, status=status.HTTP_201_CREATED
        )

    @extend_schema(request=AjusteStockSerializer, responses=MovimientoInventarioSerializer)
    @action(detail=False, methods=["post"])
    def ajustar(self, request):
        """Deja el stock de un producto en una cantidad absoluta (autorizado)."""
        entrada = AjusteStockSerializer(data=request.data)
        entrada.is_valid(raise_exception=True)
        d = entrada.validated_data
        movimiento = services.ajustar_a_cantidad(
            producto=d["producto"],
            cantidad_final=d["cantidad_final"],
            usuario=request.user,
            ubicacion=d.get("ubicacion"),
            motivo=d["motivo"],
        )
        return Response(
            MovimientoInventarioSerializer(movimiento).data, status=status.HTTP_201_CREATED
        )
