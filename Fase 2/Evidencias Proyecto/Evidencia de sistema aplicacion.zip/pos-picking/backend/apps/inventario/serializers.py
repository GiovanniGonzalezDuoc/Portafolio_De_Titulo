"""Serializers de inventario."""

from __future__ import annotations

from rest_framework import serializers

from apps.catalogo.models import Producto

from .models import (
    MovimientoInventario,
    ParametroInventario,
    Stock,
    TipoMovimiento,
    Ubicacion,
)

TIPOS_MANUALES_CHOICES = [
    (TipoMovimiento.AJUSTE_POSITIVO, "Ajuste positivo"),
    (TipoMovimiento.AJUSTE_NEGATIVO, "Ajuste negativo / merma"),
]


class UbicacionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ubicacion
        fields = ["id", "nombre", "tipo", "es_principal", "activo"]


class StockSerializer(serializers.ModelSerializer):
    producto_sku = serializers.CharField(source="producto.sku", read_only=True)
    producto_nombre = serializers.CharField(source="producto.nombre", read_only=True)
    producto_marca = serializers.SlugRelatedField(
        source="producto.marca", slug_field="nombre", read_only=True
    )
    ubicacion_nombre = serializers.CharField(source="ubicacion.nombre", read_only=True)
    ubicacion_tipo = serializers.CharField(source="ubicacion.tipo", read_only=True)

    class Meta:
        model = Stock
        fields = [
            "id", "producto", "producto_sku", "producto_nombre", "producto_marca",
            "ubicacion", "ubicacion_nombre", "ubicacion_tipo", "cantidad", "actualizado_en",
        ]
        read_only_fields = fields


class ParametroInventarioSerializer(serializers.ModelSerializer):
    producto = serializers.SlugRelatedField(
        slug_field="sku", queryset=Producto.objects.all()
    )
    ubicacion = serializers.SlugRelatedField(
        slug_field="nombre", queryset=Ubicacion.objects.all(), required=False
    )

    class Meta:
        model = ParametroInventario
        fields = [
            "id", "producto", "ubicacion", "stock_minimo", "punto_reposicion",
            "stock_seguridad", "multiplo_compra",
        ]

    def validate(self, attrs):
        if not attrs.get("ubicacion") and not self.instance:
            attrs["ubicacion"] = Ubicacion.principal()
        for campo in ("stock_minimo", "punto_reposicion", "stock_seguridad"):
            if attrs.get(campo) is not None and attrs[campo] < 0:
                raise serializers.ValidationError({campo: "No puede ser negativo."})
        if attrs.get("multiplo_compra") is not None and attrs["multiplo_compra"] <= 0:
            raise serializers.ValidationError(
                {"multiplo_compra": "Debe ser mayor que cero."}
            )
        return attrs


class MovimientoInventarioSerializer(serializers.ModelSerializer):
    producto_sku = serializers.CharField(source="producto.sku", read_only=True)
    ubicacion_nombre = serializers.CharField(source="ubicacion.nombre", read_only=True)
    usuario_username = serializers.CharField(source="usuario.username", read_only=True)
    tipo_display = serializers.CharField(source="get_tipo_display", read_only=True)

    class Meta:
        model = MovimientoInventario
        fields = [
            "id", "producto", "producto_sku", "ubicacion", "ubicacion_nombre",
            "tipo", "tipo_display", "cantidad", "stock_antes", "stock_despues",
            "motivo", "doc_tipo", "doc_id", "usuario", "usuario_username", "creado_en",
        ]
        read_only_fields = fields


class MovimientoManualSerializer(serializers.Serializer):
    """Entrada para registrar un movimiento manual (ajuste +/-)."""

    producto = serializers.SlugRelatedField(
        slug_field="sku", queryset=Producto.objects.all()
    )
    ubicacion = serializers.SlugRelatedField(
        slug_field="nombre", queryset=Ubicacion.objects.all(), required=False
    )
    tipo = serializers.ChoiceField(choices=TIPOS_MANUALES_CHOICES)
    cantidad = serializers.DecimalField(max_digits=12, decimal_places=3, min_value=0)
    motivo = serializers.CharField(max_length=200)

    def validate_cantidad(self, value):
        if value <= 0:
            raise serializers.ValidationError("Debe ser mayor que cero.")
        return value

    def validate_producto(self, value):
        if not value.activo:
            raise serializers.ValidationError("El producto está inactivo.")
        return value


class AjusteStockSerializer(serializers.Serializer):
    """Entrada para dejar el stock en una cantidad absoluta."""

    producto = serializers.SlugRelatedField(
        slug_field="sku", queryset=Producto.objects.all()
    )
    ubicacion = serializers.SlugRelatedField(
        slug_field="nombre", queryset=Ubicacion.objects.all(), required=False
    )
    cantidad_final = serializers.DecimalField(
        max_digits=12, decimal_places=3, min_value=0
    )
    motivo = serializers.CharField(max_length=200)
