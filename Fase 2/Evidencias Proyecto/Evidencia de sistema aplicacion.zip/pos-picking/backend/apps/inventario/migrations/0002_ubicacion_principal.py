"""Crea la ubicación principal por defecto."""

from django.db import migrations


def crear_ubicacion(apps, schema_editor):
    Ubicacion = apps.get_model("inventario", "Ubicacion")
    if not Ubicacion.objects.exists():
        Ubicacion.objects.create(
            nombre="Bodega Principal", tipo="BODEGA", es_principal=True, activo=True
        )


def revertir(apps, schema_editor):
    Ubicacion = apps.get_model("inventario", "Ubicacion")
    Ubicacion.objects.filter(nombre="Bodega Principal", es_principal=True).delete()


class Migration(migrations.Migration):
    dependencies = [("inventario", "0001_initial")]
    operations = [migrations.RunPython(crear_ubicacion, revertir)]
