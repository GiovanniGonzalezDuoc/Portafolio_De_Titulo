#!/bin/sh
# Backup diario de la BD de POS Picking (cron de cPanel).
# Lee las credenciales de ~/pos-backend/.env. Retención: 7 días.
#
#   0 3 * * *  /bin/sh /home/zmgtmpop/pos-backend/deploy/backup_db.sh >> /home/zmgtmpop/pos-backend/logs/backup.log 2>&1
#
set -e

ENV_FILE="${ENV_FILE:-${HOME}/pos-backend/.env}"
DEST="${HOME}/backups"
KEEP_DAYS=7

val() { grep "^$1=" "$ENV_FILE" | head -1 | cut -d= -f2-; }
DB=$(val DB_NAME)
DBU=$(val DB_USER)
DBP=$(val DB_PASSWORD)

[ -n "$DB" ] && [ -n "$DBU" ] && [ -n "$DBP" ] || {
    echo "$(date '+%F %T') ERROR: no pude leer DB_* de $ENV_FILE" >&2
    exit 1
}

mkdir -p "$DEST"
FILE="${DEST}/pospicking_$(date +%F_%H%M).sql.gz"

mysqldump -u"$DBU" -p"$DBP" --single-transaction --routines --triggers \
          --no-tablespaces "$DB" 2>/dev/null | gzip > "$FILE"

find "$DEST" -name 'pospicking_*.sql.gz' -type f -mtime +"$KEEP_DAYS" -delete

echo "$(date '+%F %T') backup OK: $FILE ($(du -h "$FILE" | cut -f1))"
