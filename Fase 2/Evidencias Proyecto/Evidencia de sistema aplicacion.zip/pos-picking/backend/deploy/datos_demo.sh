#!/bin/sh
# ─────────────────────────────────────────────────────────────
# Carga (o revierte) los datos de demostración en el servidor.
#
# Para la ENTREGA / demo del proyecto: deja el catálogo demo, un
# proveedor, el modelo de predicción entrenado y las recomendaciones
# de reposición, de modo que se pueda mostrar cada módulo funcionando.
#
#   Cargar:    sh ~/pos-backend/deploy/datos_demo.sh
#   Revertir:  sh ~/pos-backend/deploy/datos_demo.sh --limpiar
#
# Idempotente: se puede correr varias veces sin duplicar nada.
# ─────────────────────────────────────────────────────────────
set -e

APP_DIR="${APP_DIR:-${HOME}/pos-backend}"
PY="${PY:-${HOME}/virtualenv/pos-backend/3.13/bin/python}"
export DJANGO_SETTINGS_MODULE="config.settings.prod"
# Permite que la predicción use la serie sintética del paquete ml/
# mientras no haya 12+ semanas de ventas reales.
export DJANGO_PREDICCION_SINTETICO="True"

cd "$APP_DIR"

if [ "$1" = "--limpiar" ]; then
    echo ">> Revirtiendo datos de demostración…"
    "$PY" manage.py cargar_demo --limpiar
    echo ">> Listo. Recuerda quitar 'DJANGO_PREDICCION_SINTETICO=True' de ~/pos-backend/.env"
    echo "   si no quieres que la predicción siga usando datos sintéticos."
    exit 0
fi

echo ">> 1/3  Catálogo demo + proveedor + entrenamiento del modelo…"
"$PY" manage.py cargar_demo

echo ">> 2/3  Generando predicciones de demanda (horizonte 4 semanas)…"
"$PY" manage.py predecir_demanda --horizonte 4

echo ">> 3/3  Recalculando recomendaciones de reposición…"
"$PY" manage.py calcular_reposicion

echo ""
echo ">> Datos de demo listos."
echo "   Usuarios:  admin_demo / bodega_demo / vende_demo   (clave: demo12345)"
echo "   Predicción y Reposición: pobladas (fuente SINTETICO)."
echo "   Para revertir:  sh ~/pos-backend/deploy/datos_demo.sh --limpiar"
