# Sube la instancia de la EMPRESA a cPanel y la prepara.
# Ejecutar desde PowerShell en tu PC:
#   powershell -ExecutionPolicy Bypass -File E:\ProyectoPortafolio\backend\deploy\1-subir-empresa.ps1
# Te pedirá la contraseña de cPanel varias veces (es normal: una por cada envío).

$ErrorActionPreference = "Stop"
$Raiz = "E:\ProyectoPortafolio"
$Puerto = "54327"
$Servidor = "zmgtmpop@systemspickingpos.cl"

Write-Host "== 1/4 Compilando frontend para la empresa ==" -ForegroundColor Green
Push-Location "$Raiz\frontend"
npx ng build --configuration empresa
Pop-Location

Write-Host "== 2/4 Subiendo backend ==" -ForegroundColor Green
ssh -p $Puerto $Servidor "mkdir -p pos-backend-empresa"
scp -P $Puerto -r "$Raiz\backend\apps" "$Raiz\backend\config" "$Raiz\backend\deploy" "$Raiz\backend\manage.py" "$Raiz\backend\passenger_wsgi.py" "$Raiz\backend\requirements.txt" "${Servidor}:pos-backend-empresa/"
scp -P $Puerto -r "$Raiz\ml" "${Servidor}:pos-backend-empresa/"

Write-Host "== 3/4 Subiendo frontend ==" -ForegroundColor Green
ssh -p $Puerto $Servidor "rm -rf empresa-front-upload"
scp -P $Puerto -r "$Raiz\frontend\dist\frontend\browser" "${Servidor}:empresa-front-upload"
scp -P $Puerto "$Raiz\frontend\deploy\htaccess-spa" "${Servidor}:empresa-front-upload/htaccess-spa"

Write-Host "== 4/4 Preparando el servidor (te pedirá datos aquí mismo) ==" -ForegroundColor Green
ssh -t -p $Puerto $Servidor "bash ~/pos-backend-empresa/deploy/setup_empresa.sh"

Write-Host "Terminado." -ForegroundColor Green
