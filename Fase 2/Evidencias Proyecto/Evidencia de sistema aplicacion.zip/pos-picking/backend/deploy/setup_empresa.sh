#!/bin/bash
# Prepara la instancia de la EMPRESA en cPanel (BD y dominios propios).
# Se ejecuta en el servidor, después de que 1-subir-empresa.ps1 subió el código:
#   bash ~/pos-backend-empresa/deploy/setup_empresa.sh
# Es seguro volver a correrlo: no borra datos ni sobrescribe un .env existente.
set -euo pipefail

APP="$HOME/pos-backend-empresa"
VENV="$HOME/virtualenv/pos-backend-empresa/3.13"
PY="$VENV/bin/python"
FRONT="$HOME/empresa.systemspickingpos.cl"
API_HOST="api-empresa.systemspickingpos.cl"
DB_NAME="zmgtmpop_pospicking_empresa"
DB_USER="zmgtmpop_posemp"

if [ ! -f "$APP/manage.py" ]; then
  echo "ERROR: no encuentro $APP/manage.py. Sube el backend primero (1-subir-empresa.ps1)."
  exit 1
fi
if [ ! -x "$PY" ]; then
  echo "ERROR: no encuentro el entorno virtual en $VENV. Crea la app en cPanel → Setup Python App."
  exit 1
fi
cd "$APP"

echo "== 1/6 Archivo .env =="
if [ -f .env ]; then
  echo "Ya existe .env: no lo toco."
else
  read -r -s -p "Contraseña de la BD ($DB_USER): " DB_PASS; echo
  read -r -p "Ruta secreta del panel admin (ej: panel-x7k2/): " ADMIN_PATH
  SK1=$("$PY" -c "import secrets; print(secrets.token_urlsafe(64))")
  SK2=$("$PY" -c "import secrets; print(secrets.token_urlsafe(64))")
  cat > .env <<EOF
DJANGO_SETTINGS_MODULE=config.settings.prod
DJANGO_DEBUG=False
DJANGO_SECRET_KEY=$SK1
JWT_SIGNING_KEY=$SK2
DJANGO_ALLOWED_HOSTS=$API_HOST
DJANGO_SECURE_SSL_REDIRECT=True
DJANGO_NUM_PROXIES=1
DJANGO_LOG_DIR=$APP/logs
DJANGO_ADMIN_URL=$ADMIN_PATH

USE_SQLITE=False
DB_NAME=$DB_NAME
DB_USER=$DB_USER
DB_PASSWORD=$DB_PASS
DB_HOST=localhost
DB_PORT=3306

CORS_ALLOWED_ORIGINS=https://empresa.systemspickingpos.cl
CSRF_TRUSTED_ORIGINS=https://empresa.systemspickingpos.cl,https://$API_HOST

JWT_ACCESS_MINUTES=15
JWT_REFRESH_DAYS=1
LOGIN_MAX_INTENTOS=5
LOGIN_BLOQUEO_MINUTOS=15

DTE_PROVEEDOR=mock
EOF
  chmod 600 .env
  echo ".env creado (permisos 600)."
fi

echo "== 2/6 Dependencias =="
"$VENV/bin/pip" install --upgrade pip -q
"$VENV/bin/pip" install -r requirements.txt -q

export DJANGO_SETTINGS_MODULE=config.settings.prod
mkdir -p logs tmp

echo "== 3/6 Revisión de seguridad =="
"$PY" manage.py check --deploy || echo "AVISO: check --deploy tiene advertencias (revisar arriba)."

echo "== 4/6 Base de datos y estáticos =="
"$PY" manage.py migrate --noinput
"$PY" manage.py collectstatic --noinput -v0

echo "== 5/6 Superusuario de la empresa =="
read -r -p "¿Crear superusuario ahora? (s/n): " CREAR
if [ "$CREAR" = "s" ]; then
  "$PY" manage.py createsuperuser
fi

echo "== 6/6 Reinicio y frontend =="
touch tmp/restart.txt
if [ -d "$HOME/empresa-front-upload" ]; then
  mkdir -p "$FRONT"
  cp -r "$HOME/empresa-front-upload/." "$FRONT/"
  if [ -f "$FRONT/htaccess-spa" ]; then
    grep -q "SPA Angular (POS Picking)" "$FRONT/.htaccess" 2>/dev/null || cat "$FRONT/htaccess-spa" >> "$FRONT/.htaccess"
    rm -f "$FRONT/htaccess-spa"
  fi
  rm -rf "$HOME/empresa-front-upload"
  echo "Frontend copiado a $FRONT"
else
  echo "Sin frontend pendiente (no existe ~/empresa-front-upload)."
fi

sleep 3
echo
echo "Health de la API:"
curl -s "https://$API_HOST/api/v1/health/" || echo "(no respondió todavía: espera un minuto y reintenta)"
echo
echo "LISTO. Falta solo una cosa a mano en cPanel → Cron Jobs (agregar una vez):"
echo "*/10 * * * * $PY $APP/manage.py reintentar_dte >> $APP/logs/cron.log 2>&1"
echo "*/15 * * * * $PY $APP/manage.py generar_alertas >> $APP/logs/cron.log 2>&1"
echo "30 6 * * * $PY $APP/manage.py calcular_reposicion >> $APP/logs/cron.log 2>&1"
echo "0 3 * * * ENV_FILE=$APP/.env /bin/sh $APP/deploy/backup_db.sh >> $APP/logs/backup.log 2>&1"
