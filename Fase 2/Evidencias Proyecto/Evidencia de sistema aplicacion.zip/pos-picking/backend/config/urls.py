"""
Rutas raíz del proyecto POS Picking.

Toda la API vive bajo ``/api/v1/``. Cada app expone sus rutas en
``apps/<app>/urls.py`` y se incluyen aquí a medida que se implementan.
"""

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.http import JsonResponse
from django.urls import include, path
from django.views.static import serve as servir_estatico
from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularRedocView,
    SpectacularSwaggerView,
)


def healthcheck(_request):
    """Endpoint simple de salud para monitoreo / cron."""
    return JsonResponse({"estado": "ok", "servicio": "pos-picking-api"})


api_v1 = [
    path("health/", healthcheck, name="health"),
    path("", include("apps.usuarios.urls")),               # auth/ + usuarios/ + roles/ + permisos/
    path("catalogo/", include("apps.catalogo.urls")),      # categorias/ marcas/ productos/
    path("", include("apps.ofertas.urls")),                # ofertas/
    path("inventario/", include("apps.inventario.urls")),  # ubicaciones/ stock/ parametros/ movimientos/
    path("", include("apps.proveedores.urls")),            # proveedores/
    path("compras/", include("apps.compras.urls")),        # ordenes/ recepciones/
    path("", include("apps.ventas.urls")),                 # ventas/
    path("", include("apps.caja.urls")),                   # cajas/
    path("", include("apps.boleta.urls")),                 # boletas/
    path("", include("apps.alertas.urls")),                # alertas/
    path("dashboard/", include("apps.dashboard.urls")),    # dashboard/*
    path("prediccion/", include("apps.prediccion.urls")),  # prediccion/modelos|demanda
    path("reposicion/", include("apps.reposicion.urls")),  # reposicion/recomendaciones|parametros
]

# La documentación OpenAPI (schema/Swagger/Redoc) revela toda la superficie de
# la API; solo se sirve con DEBUG=True. En producción se consulta con
# `manage.py spectacular` o habilitando DJANGO_DEBUG puntualmente.
if settings.DEBUG:
    api_v1 += [
        path("schema/", SpectacularAPIView.as_view(), name="schema"),
        path("docs/", SpectacularSwaggerView.as_view(url_name="v1:schema"), name="swagger-ui"),
        path("redoc/", SpectacularRedocView.as_view(url_name="v1:schema"), name="redoc"),
    ]

urlpatterns = [
    path(settings.ADMIN_URL, admin.site.urls),
    path("api/v1/", include((api_v1, "api"), namespace="v1")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
else:
    # El hosting compartido no tiene un servidor aparte (nginx/Apache alias)
    # para archivos subidos por los usuarios (fotos de producto): WhiteNoise
    # solo sirve los estáticos de `collectstatic`. Bajo volumen bajo, servirlos
    # con la propia app es una solución aceptable (Django lo desaconseja para
    # tráfico alto, no es nuestro caso).
    urlpatterns += [
        path(
            f"{settings.MEDIA_URL.strip('/')}/<path:path>",
            servir_estatico,
            {"document_root": settings.MEDIA_ROOT},
        )
    ]
