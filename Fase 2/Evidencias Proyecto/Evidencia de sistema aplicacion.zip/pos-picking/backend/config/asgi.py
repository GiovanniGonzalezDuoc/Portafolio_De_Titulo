"""
Configuración ASGI del proyecto POS Picking.

Expone el callable ASGI como la variable de módulo ``application``.
"""

import os

from django.core.asgi import get_asgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.prod")

application = get_asgi_application()
