"""Configuración para la ejecución de tests."""

from .base import *  # noqa: F401,F403

DEBUG = False
ALLOWED_HOSTS = ["testserver", "localhost"]

# Clave de firma de longitud suficiente para tests (evita InsecureKeyLengthWarning).
SECRET_KEY = "clave-de-pruebas-suficientemente-larga-para-hmac-sha256-0123456789"  # noqa: S105
SIMPLE_JWT["SIGNING_KEY"] = SECRET_KEY  # noqa: F405

# Base de datos en memoria para tests rápidos si no hay MariaDB disponible.
# Con MariaDB local, exporta USE_SQLITE=False y pytest usará una BD de test real.
import os  # noqa: E402

if os.environ.get("USE_SQLITE", "True").lower() in ("1", "true", "yes"):
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": ":memory:",
        }
    }

# Hasher rápido para tests.
PASSWORD_HASHERS = ["django.contrib.auth.hashers.MD5PasswordHasher"]

# Almacenamiento de estáticos simple (evita el manifiesto de WhiteNoise en tests).
STORAGES = {  # noqa: F405
    "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
    "staticfiles": {"BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage"},
}

# Silenciar logging ruidoso en tests.
LOGGING["root"]["level"] = "WARNING"  # noqa: F405

EMAIL_BACKEND = "django.core.mail.backends.locmem.EmailBackend"

# En tests se permite el dataset sintético para la predicción de demanda.
PREDICCION_PERMITIR_SINTETICO = True
