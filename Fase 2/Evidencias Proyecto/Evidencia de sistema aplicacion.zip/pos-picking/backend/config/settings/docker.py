"""
Configuración para verificar el stack completo con docker-compose en local.

Hereda de ``prod`` (fail-fast de claves, MariaDB, WhiteNoise, cabeceras de
seguridad) pero **desactiva** lo que asume TLS, porque en local el tráfico
entre nginx y el navegador es HTTP plano. En el servidor real se usa
``config.settings.prod`` tal cual.
"""

from .prod import *  # noqa: F401,F403

# Sin TLS en local → no forzar HTTPS ni cookies "secure".
SECURE_SSL_REDIRECT = False
SECURE_HSTS_SECONDS = 0
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False
