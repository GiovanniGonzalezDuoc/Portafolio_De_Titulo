"""Configuración de desarrollo local."""

from .base import *  # noqa: F401,F403
from .base import env

DEBUG = env.bool("DJANGO_DEBUG", default=True)

ALLOWED_HOSTS = env.list(
    "DJANGO_ALLOWED_HOSTS", default=["localhost", "127.0.0.1", "0.0.0.0"]
)

# En desarrollo aceptamos el frontend de Angular por defecto.
CORS_ALLOWED_ORIGINS = env.list(
    "CORS_ALLOWED_ORIGINS", default=["http://localhost:4200", "http://127.0.0.1:4200"]
)
CSRF_TRUSTED_ORIGINS = env.list(
    "CSRF_TRUSTED_ORIGINS", default=["http://localhost:4200", "http://127.0.0.1:4200"]
)

# Consola de correo en desarrollo.
EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"

# drf-spectacular: exponer Swagger UI en desarrollo.
SPECTACULAR_SETTINGS["SERVE_INCLUDE_SCHEMA"] = True  # noqa: F405
