"""
Configuración de producción (cPanel / Passenger + MariaDB de cPanel).

Todo lo sensible se lee de ``~/.env`` (fuera de public_html y del repositorio).
"""

from django.core.exceptions import ImproperlyConfigured

from .base import *  # noqa: F401,F403
from .base import LOG_DIR, SECRET_KEY, SECRET_KEY_INSEGURO, SIMPLE_JWT, env

DEBUG = False

# ─── Fail-fast: sin claves reales, no se arranca ────────────
if not SECRET_KEY or SECRET_KEY == SECRET_KEY_INSEGURO:
    raise ImproperlyConfigured(
        "DJANGO_SECRET_KEY es obligatorio en producción (define uno largo y aleatorio en ~/.env)."
    )
_JWT_KEY = env.str("JWT_SIGNING_KEY", default="")
if not _JWT_KEY or _JWT_KEY == SECRET_KEY_INSEGURO:
    raise ImproperlyConfigured(
        "JWT_SIGNING_KEY es obligatorio en producción y debe ser distinto del SECRET_KEY."
    )
SIMPLE_JWT["SIGNING_KEY"] = _JWT_KEY

# Obligatorio definir en .env: DJANGO_ALLOWED_HOSTS=systemspickingpos.cl,www.systemspickingpos.cl
ALLOWED_HOSTS = env.list("DJANGO_ALLOWED_HOSTS")
if not ALLOWED_HOSTS:
    raise ImproperlyConfigured("DJANGO_ALLOWED_HOSTS no puede estar vacío en producción.")

# ─── Cache compartida entre procesos (Passenger levanta varios) ──
# Necesaria para que el throttling y el bloqueo por fuerza bruta sean
# consistentes. FileBasedCache no requiere tabla ni servicio extra.
CACHES = {
    "default": {
        "BACKEND": "django.core.cache.backends.filebased.FileBasedCache",
        "LOCATION": env.str("DJANGO_CACHE_DIR", default=str(LOG_DIR / "cache")),
        "TIMEOUT": 300,
    }
}

# ─── Seguridad de transporte ────────────────────────────────
SECURE_SSL_REDIRECT = env.bool("DJANGO_SECURE_SSL_REDIRECT", default=True)
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
SECURE_HSTS_SECONDS = env.int("DJANGO_HSTS_SECONDS", default=60 * 60 * 24 * 30)
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SECURE_CONTENT_TYPE_NOSNIFF = True
X_FRAME_OPTIONS = "DENY"
SECURE_REFERRER_POLICY = "same-origin"

# ─── Orígenes permitidos (frontend Angular) ─────────────────
CORS_ALLOWED_ORIGINS = env.list("CORS_ALLOWED_ORIGINS")
CSRF_TRUSTED_ORIGINS = env.list("CSRF_TRUSTED_ORIGINS")

# ─── Correo (SMTP de cPanel) ────────────────────────────────
# cPanel suele dar dos puertos de salida válidos: 587 (STARTTLS, "explícito")
# o 465 (SSL directo, "implícito") — son mutuamente excluyentes para Django.
# Con solo `EMAIL_USE_SSL=True` en el .env alcanza: TLS se desactiva solo.
EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
EMAIL_HOST = env.str("EMAIL_HOST", default="")
EMAIL_PORT = env.int("EMAIL_PORT", default=587)
EMAIL_HOST_USER = env.str("EMAIL_HOST_USER", default="")
EMAIL_HOST_PASSWORD = env.str("EMAIL_HOST_PASSWORD", default="")
EMAIL_USE_SSL = env.bool("EMAIL_USE_SSL", default=False)
EMAIL_USE_TLS = env.bool("EMAIL_USE_TLS", default=not EMAIL_USE_SSL)
DEFAULT_FROM_EMAIL = env.str("DEFAULT_FROM_EMAIL", default="no-reply@systemspickingpos.cl")

# En prod el nivel de log por defecto es INFO (ajustable por .env).
LOG_LEVEL = env.str("DJANGO_LOG_LEVEL", default="INFO")
