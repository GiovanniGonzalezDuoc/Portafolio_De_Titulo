"""
Configuración base del proyecto POS Picking.

Común a todos los entornos. Los valores sensibles y los que cambian por
entorno se leen de variables de entorno (archivo ``.env``).
Ver ``.env.example``.
"""

import sys
from datetime import timedelta
from pathlib import Path

import environ

# BASE_DIR = .../backend
BASE_DIR = Path(__file__).resolve().parent.parent.parent

# El paquete ``ml/`` (predicción de demanda) vive en la raíz del repo. En el
# deploy se copia junto al backend, así que también se busca vendido dentro de
# ``backend/`` o como hermano de ``BASE_DIR``. Se añade al path la carpeta que
# lo contenga.
REPO_DIR = BASE_DIR.parent
for _cand in (REPO_DIR, BASE_DIR, BASE_DIR.parent):
    if (_cand / "ml").is_dir() and str(_cand) not in sys.path:
        sys.path.insert(0, str(_cand))
        break
else:  # no se encontró: se deja REPO_DIR por compatibilidad
    if str(REPO_DIR) not in sys.path:
        sys.path.insert(0, str(REPO_DIR))

# ─────────────────────────────────────────────────────────────
# Variables de entorno
# ─────────────────────────────────────────────────────────────
env = environ.Env(
    DJANGO_DEBUG=(bool, False),
    DJANGO_ALLOWED_HOSTS=(list, []),
    CORS_ALLOWED_ORIGINS=(list, []),
    CSRF_TRUSTED_ORIGINS=(list, []),
    USE_SQLITE=(bool, False),
    JWT_ACCESS_MINUTES=(int, 15),
    JWT_REFRESH_DAYS=(int, 1),
    LOGIN_MAX_INTENTOS=(int, 5),
    LOGIN_BLOQUEO_MINUTOS=(int, 15),
)

# Carga el archivo .env si existe (en la raíz de backend/ o en el home en prod)
_env_file = env.str("DJANGO_ENV_FILE", default=str(BASE_DIR / ".env"))
if Path(_env_file).exists():
    env.read_env(_env_file)

# ─────────────────────────────────────────────────────────────
# Seguridad
# ─────────────────────────────────────────────────────────────
# Este default SOLO sirve para desarrollo/tests. `prod.py` aborta el arranque
# si no se define `DJANGO_SECRET_KEY` / `JWT_SIGNING_KEY` explícitamente.
SECRET_KEY_INSEGURO = "inseguro-solo-para-arranque-cambiar"  # noqa: S105
SECRET_KEY = env.str("DJANGO_SECRET_KEY", default=SECRET_KEY_INSEGURO)
DEBUG = env.bool("DJANGO_DEBUG")
ALLOWED_HOSTS = env.list("DJANGO_ALLOWED_HOSTS")

# Nombre de la ruta del admin de Django (ofuscable en producción vía .env).
ADMIN_URL = env.str("DJANGO_ADMIN_URL", default="admin/").lstrip("/")

# Predicción de demanda: cuando un producto no tiene ≥12 semanas de ventas
# reales, usar la serie sintética del paquete ml/ (marcada como SINTETICO).
# Por defecto solo en DEBUG; en producción se activa con DJANGO_PREDICCION_SINTETICO=True
# para poder demostrar el modelo mientras no hay histórico real.
PREDICCION_PERMITIR_SINTETICO = env.bool("DJANGO_PREDICCION_SINTETICO", default=DEBUG)

# ─────────────────────────────────────────────────────────────
# Aplicaciones
# ─────────────────────────────────────────────────────────────
DJANGO_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
]

THIRD_PARTY_APPS = [
    "rest_framework",
    "rest_framework_simplejwt",
    "rest_framework_simplejwt.token_blacklist",
    "corsheaders",
    "django_filters",
    "drf_spectacular",
]

# Apps del proyecto (se irán agregando por etapa)
LOCAL_APPS = [
    "apps.core",
    "apps.usuarios",
    "apps.catalogo",
    "apps.ofertas",
    "apps.inventario",
    "apps.alertas",
    "apps.proveedores",
    "apps.compras",
    "apps.ventas",
    "apps.caja",
    "apps.boleta",
    "apps.dashboard",
    "apps.prediccion",
    "apps.reposicion",
]

INSTALLED_APPS = DJANGO_APPS + THIRD_PARTY_APPS + LOCAL_APPS

# ─────────────────────────────────────────────────────────────
# Middleware
# ─────────────────────────────────────────────────────────────
MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    # Propio: id de correlación (X-Request-ID) + contexto para logs y auditoría.
    "apps.core.middleware.RequestContextMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"
ASGI_APPLICATION = "config.asgi.application"

# ─────────────────────────────────────────────────────────────
# Base de datos — MariaDB (producción y desarrollo)
# ─────────────────────────────────────────────────────────────
if env.bool("USE_SQLITE"):
    # Solo para verificación rápida del esqueleto / CI sin MariaDB.
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / "db.sqlite3",
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.mysql",
            "NAME": env.str("DB_NAME"),
            "USER": env.str("DB_USER"),
            "PASSWORD": env.str("DB_PASSWORD"),
            "HOST": env.str("DB_HOST", default="127.0.0.1"),
            "PORT": env.str("DB_PORT", default="3306"),
            "CONN_MAX_AGE": env.int("DB_CONN_MAX_AGE", default=60),
            "OPTIONS": {
                "charset": "utf8mb4",
                "init_command": (
                    "SET sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,"
                    "NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO'"
                ),
            },
        }
    }

# ─────────────────────────────────────────────────────────────
# Validación de contraseñas
# ─────────────────────────────────────────────────────────────
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
        "OPTIONS": {"min_length": 8},
    },
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# Modelo de usuario propio.
AUTH_USER_MODEL = "usuarios.Usuario"

# ─────────────────────────────────────────────────────────────
# Internacionalización — Chile
# ─────────────────────────────────────────────────────────────
LANGUAGE_CODE = "es-cl"
TIME_ZONE = "America/Santiago"
USE_I18N = True
USE_TZ = True

# ─────────────────────────────────────────────────────────────
# Archivos estáticos y media
# ─────────────────────────────────────────────────────────────
STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
STATICFILES_STORAGE = "whitenoise.storage.CompressedManifestStaticFilesStorage"

MEDIA_URL = "media/"
MEDIA_ROOT = BASE_DIR / "media"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# ─────────────────────────────────────────────────────────────
# Django REST Framework
# ─────────────────────────────────────────────────────────────
REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "apps.usuarios.authentication.JWTAuthAuditoria",
    ),
    # Nº de proxies de confianza delante de la app (LiteSpeed en cPanel = 1).
    # Evita que un cliente falsee su IP con X-Forwarded-For para saltarse el
    # throttling del login.
    "NUM_PROXIES": env.int("DJANGO_NUM_PROXIES", default=1),
    "DEFAULT_PERMISSION_CLASSES": (
        "rest_framework.permissions.IsAuthenticated",
    ),
    "DEFAULT_FILTER_BACKENDS": (
        "django_filters.rest_framework.DjangoFilterBackend",
        "rest_framework.filters.SearchFilter",
        "rest_framework.filters.OrderingFilter",
    ),
    "DEFAULT_PAGINATION_CLASS": "apps.core.pagination.PaginacionEstandar",
    "PAGE_SIZE": 25,
    "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",
    "EXCEPTION_HANDLER": "apps.core.exceptions.exception_handler_personalizado",
    "DEFAULT_THROTTLE_CLASSES": (
        "rest_framework.throttling.AnonRateThrottle",
        "rest_framework.throttling.UserRateThrottle",
        "rest_framework.throttling.ScopedRateThrottle",
    ),
    "DEFAULT_THROTTLE_RATES": {
        # Tunable por entorno. En pruebas de carga desde una sola IP hay que
        # subirlo (DJANGO_LOGIN_RATE=10000/min); en producción se deja bajo.
        "login": env.str("DJANGO_LOGIN_RATE", default="10/min"),
        "anon": env.str("DJANGO_ANON_RATE", default="60/min"),
        "user": env.str("DJANGO_USER_RATE", default="2000/hour"),
        "prediccion_calcular": "60/hour",
    },
    "DATETIME_FORMAT": "%Y-%m-%dT%H:%M:%S%z",
}

# ─────────────────────────────────────────────────────────────
# Simple JWT
# ─────────────────────────────────────────────────────────────
SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": timedelta(minutes=env.int("JWT_ACCESS_MINUTES")),
    "REFRESH_TOKEN_LIFETIME": timedelta(days=env.int("JWT_REFRESH_DAYS")),
    "ROTATE_REFRESH_TOKENS": True,
    "BLACKLIST_AFTER_ROTATION": True,
    "UPDATE_LAST_LOGIN": True,
    "SIGNING_KEY": env.str("JWT_SIGNING_KEY", default=SECRET_KEY),
    "AUTH_HEADER_TYPES": ("Bearer",),
}

# ─────────────────────────────────────────────────────────────
# CORS / CSRF
# ─────────────────────────────────────────────────────────────
CORS_ALLOWED_ORIGINS = env.list("CORS_ALLOWED_ORIGINS")
CSRF_TRUSTED_ORIGINS = env.list("CSRF_TRUSTED_ORIGINS")
CORS_ALLOW_CREDENTIALS = True
# Para que el front pueda leer el nombre del archivo en las descargas (CSV).
CORS_EXPOSE_HEADERS = ["Content-Disposition"]

# ─────────────────────────────────────────────────────────────
# drf-spectacular (documentación OpenAPI)
# ─────────────────────────────────────────────────────────────
SPECTACULAR_SETTINGS = {
    "TITLE": "POS Picking API",
    "DESCRIPTION": "API REST del sistema POS Picking — Liquidadora Los Europeos.",
    "VERSION": "0.1.0",
    "SERVE_INCLUDE_SCHEMA": False,
    "COMPONENT_SPLIT_REQUEST": True,
    "ENUM_NAME_OVERRIDES": {
        "EstadoVentaEnum": "apps.ventas.models.EstadoVenta",
        "EstadoOrdenCompraEnum": "apps.compras.models.EstadoOrdenCompra",
        "EstadoCajaEnum": "apps.caja.models.EstadoCaja",
        "EstadoDTEEnum": "apps.boleta.models.EstadoDTE",
        "EstadoAlertaEnum": "apps.alertas.models.EstadoAlerta",
        "TipoAlertaEnum": "apps.alertas.models.TipoAlerta",
        "TipoMovimientoInventarioEnum": "apps.inventario.models.TipoMovimiento",
        "TipoMovimientoCajaEnum": "apps.caja.models.TipoMovimientoCaja",
    },
}

# ─────────────────────────────────────────────────────────────
# Parámetros de negocio (defaults; el valor real vive en ParametroSistema)
# ─────────────────────────────────────────────────────────────
LOGIN_MAX_INTENTOS = env.int("LOGIN_MAX_INTENTOS")
LOGIN_BLOQUEO_MINUTOS = env.int("LOGIN_BLOQUEO_MINUTOS")

# ─────────────────────────────────────────────────────────────
# Logging
# ─────────────────────────────────────────────────────────────
LOG_DIR = Path(env.str("DJANGO_LOG_DIR", default=str(BASE_DIR / "logs")))
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_LEVEL = env.str("DJANGO_LOG_LEVEL", default="INFO")

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "verbose": {
            "format": "{asctime} {levelname} {name} req={request_id} user={usuario_id} :: {message}",
            "style": "{",
        },
        "simple": {"format": "{levelname} {name} :: {message}", "style": "{"},
    },
    "filters": {
        "request_context": {"()": "apps.core.logging.RequestContextFilter"},
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "simple",
            "filters": ["request_context"],
        },
        "archivo_app": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": str(LOG_DIR / "app.log"),
            "maxBytes": 5 * 1024 * 1024,
            "backupCount": 5,
            "formatter": "verbose",
            "filters": ["request_context"],
            "encoding": "utf-8",
        },
        "archivo_error": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": str(LOG_DIR / "error.log"),
            "maxBytes": 5 * 1024 * 1024,
            "backupCount": 5,
            "level": "ERROR",
            "formatter": "verbose",
            "filters": ["request_context"],
            "encoding": "utf-8",
        },
    },
    "root": {"handlers": ["console", "archivo_app", "archivo_error"], "level": LOG_LEVEL},
    "loggers": {
        "django.request": {
            "handlers": ["archivo_error"],
            "level": "ERROR",
            "propagate": True,
        },
        "pos": {  # logger raíz del proyecto: logging.getLogger("pos.<modulo>")
            "handlers": ["console", "archivo_app", "archivo_error"],
            "level": LOG_LEVEL,
            "propagate": False,
        },
    },
}
