"""
Configuración WSGI del proyecto POS Picking.

Expone el callable WSGI como la variable de módulo ``application``.
En producción (cPanel/Passenger) el punto de entrada es ``passenger_wsgi.py``,
que importa este módulo.
"""

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.prod")

application = get_wsgi_application()
