"""
Se ejecuta al importar el paquete `config`, antes de que Django resuelva el
backend de base de datos y antes de cualquier `import numpy` — tanto vía
`manage.py` como vía `passenger_wsgi.py`.

1. Limita los hilos de OpenBLAS/OpenMP: en el hosting compartido, numpy/scipy
   intentan crear un hilo por núcleo del NODO (~40) y chocan con el límite de
   procesos/memoria de la cuenta (LVE). Con 1 hilo es más que suficiente para
   la carga de predicción de este proyecto.
2. Registra PyMySQL como reemplazo de `MySQLdb` (mysqlclient no compila aquí).
"""

import os

for _var in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_var, "1")

try:
    import pymysql

    pymysql.install_as_MySQLdb()
except ImportError:  # pragma: no cover - solo si no está instalado PyMySQL
    pass
