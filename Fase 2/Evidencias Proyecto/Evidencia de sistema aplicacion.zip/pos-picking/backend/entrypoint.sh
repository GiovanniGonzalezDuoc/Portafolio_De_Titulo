#!/bin/sh
# Espera a MariaDB, aplica migraciones, recolecta estáticos y arranca el CMD.
set -e

DB_HOST="${DB_HOST:-db}"
DB_PORT="${DB_PORT:-3306}"

echo "→ Esperando a MariaDB en ${DB_HOST}:${DB_PORT}..."
tries=0
while ! nc -z "$DB_HOST" "$DB_PORT"; do
    tries=$((tries + 1))
    if [ "$tries" -gt 60 ]; then
        echo "✗ MariaDB no respondió tras 60 s." >&2
        exit 1
    fi
    sleep 1
done
echo "✓ MariaDB disponible."

echo "→ Migraciones..."
python manage.py migrate --noinput

# collectstatic: idempotente; WhiteNoise sirve /static/ (admin, DRF, spectacular).
if [ "${DJANGO_COLLECTSTATIC:-1}" = "1" ]; then
    echo "→ collectstatic..."
    python manage.py collectstatic --noinput
fi

echo "→ Arrancando: $*"
exec "$@"
